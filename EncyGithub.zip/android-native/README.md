# Native overrides (paste after `npx cap add android`)

After generating the Android project, copy these into the native project:

- MainActivity.java -> android/app/src/main/java/com/encymawsuah/app/MainActivity.java
- build.gradle      -> android/app/build.gradle
- AndroidManifest.xml -> android/app/src/main/AndroidManifest.xml
- styles.xml        -> android/app/src/main/res/values/styles.xml

Then: npx cap sync android

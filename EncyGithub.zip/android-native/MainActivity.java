package com.encymawsuah.app;

import android.os.Bundle;
import android.os.Build;
import android.graphics.Color;
import android.view.View;
import android.view.WindowManager;
import androidx.core.view.WindowCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // ارسم المحتوى خلف الشريطين على كلّ إصدارات أندرويد (edge-to-edge).
    WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

    // الأجهزة القديمة (قبل API 30) تحتاج علَم النظام القديم كي تمتدّ الرسمة خلف الشريطين
    // و لا يرجع الشريط أسود. آمن على كل الإصدارات.
    getWindow().getDecorView().setSystemUiVisibility(
        View.SYSTEM_UI_FLAG_LAYOUT_STABLE
      | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
      | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    );

    // على القديم: ألغِ خلفيّة الشريطين المعتمة التي يضيفها النظام (FLAG_TRANSLUCENT).
    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);

    // على API 21+ لازم هالعلَم كي يُسمح بتلوين الشريطين (و شفافيّتهما).
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

    // شفّاف تماماً — لا لون معتم أعلى الهيدر و لا أسفل الفوتر.
    getWindow().setStatusBarColor(Color.TRANSPARENT);
    getWindow().setNavigationBarColor(Color.TRANSPARENT);

    // ألغِ قناع التباين الغامق (contrast scrim) — سبب اللون الغامق على أندرويد 15.
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) { // API 29+
      getWindow().setNavigationBarContrastEnforced(false);
      getWindow().setStatusBarContrastEnforced(false);
    }
  }
}

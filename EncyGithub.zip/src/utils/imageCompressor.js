/**
 * Compresses an image file before upload.
 * @param {File} file - Original image file
 * @param {object} options
 * @param {number} options.maxWidth - Max width in px (default 800)
 * @param {number} options.maxHeight - Max height in px (default 800)
 * @param {number} options.quality - JPEG quality 0-1 (default 0.75)
 * @param {number} options.maxKB - حد أقصى صارم بالكيلوبايت.
 *                                 يخفض الجودة تدريجيا ثم الأبعاد حتى يتحقق الحد.
 * @returns {Promise<File>} - Compressed image file
 */
export async function compressImage(file, { maxWidth = 800, maxHeight = 800, quality = 0.75, maxKB = null } = {}) {
  const loadImage = (src) => new Promise((resolve) => { const im = new Image(); im.onload = () => resolve(im); im.src = src; });
  const toBlob = (canvas, q) => new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", q));
  const draw = (img, w, h) => {
    const canvas = document.createElement("canvas");
    canvas.width = w; canvas.height = h;
    canvas.getContext("2d").drawImage(img, 0, 0, w, h);
    return canvas;
  };

  const url = URL.createObjectURL(file);
  const img = await loadImage(url);
  URL.revokeObjectURL(url);

  let { width, height } = img;
  if (width > maxWidth || height > maxHeight) {
    const ratio = Math.min(maxWidth / width, maxHeight / height);
    width = Math.round(width * ratio);
    height = Math.round(height * ratio);
  }

  let q = quality;
  let blob = await toBlob(draw(img, width, height), q);

  if (maxKB) {
    const limit = maxKB * 1024;
    // أولا: تخفيض الجودة على درجات حتى أرضية 0.4
    while (blob && blob.size > limit && q > 0.4) {
      q = Math.max(0.4, q - 0.1);
      blob = await toBlob(draw(img, width, height), q);
    }
    // ثم: تقليص الأبعاد 15% في كل دورة حتى يتحقق الحد (أرضية 64px)
    while (blob && blob.size > limit && Math.min(width, height) > 64) {
      width = Math.max(64, Math.round(width * 0.85));
      height = Math.max(64, Math.round(height * 0.85));
      blob = await toBlob(draw(img, width, height), q);
    }
  }

  return new File([blob], file.name, { type: "image/jpeg", lastModified: Date.now() });
}
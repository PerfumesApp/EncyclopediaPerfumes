import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
// خطوط جوجل مُضمّنة محلياً (تعمل أوفلاين على كل الأجهزة) — للواجهة وللتصدير.
import '@fontsource/amiri/400.css'
import '@fontsource/amiri/700.css'
import '@fontsource/cairo/400.css'
import '@fontsource/cairo/700.css'
import '@fontsource/tajawal/400.css'
import '@fontsource/tajawal/700.css'
import '@fontsource/cinzel/400.css'
import '@fontsource/cinzel/700.css'
import { initThemeWatcher } from '@/lib/theme'
import { initThemeColorWatcher } from '@/lib/themeColor'
import { initFramesWatcher } from '@/lib/useFrames'
import { getReadMode, applyReadMode } from '@/lib/readMode'

// Offline image guard — if any <img> fails to load (e.g. a local catalogue
// image that hasn't been downloaded yet), swap it once to the bundled default
// placeholder instead of showing a broken-image icon. All catalogue image
// fields point to local paths, so nothing is ever fetched from the internet.
if (typeof window !== 'undefined') {
  window.addEventListener('error', (e) => {
    const el = e.target;
    if (el && el.tagName === 'IMG' && el.dataset.imgFallback !== '1') {
      el.dataset.imgFallback = '1';
      el.src = '/img-fallback.svg';
    }
  }, true); // capture phase: image error events don't bubble
}

// Apply the saved theme (or default light) before render, and keep it in sync
// with the device when the user picks "System".
initThemeWatcher();
// Apply the saved brand color (white-gilded by default).
initThemeColorWatcher();
// Apply saved frame options (table/image frames on perfume & brand pages).
initFramesWatcher();

const isNative = () => typeof window !== 'undefined' && window.Capacitor?.isNativePlatform?.();

// Status bar that follows the app theme
//
// Capacitor 8 StatusBar.Style:
//   Style.Dark   = DARK content/icons (use on LIGHT backgrounds)
//   Style.Light  = LIGHT content/icons (use on DARK backgrounds)
// ملاحظة Cap 8 / Android 15+: مع edge-to-edge قد لا يؤثر setBackgroundColor — راجع
// نموذج System Bars + env(safe-area-inset-*) على الجهاز إن ظهر تداخل مع شريط الحالة.
async function syncStatusBarWithTheme() {
  if (!isNative()) return;
  try {
    // توحيد التحكّم: شريط الحالة يتبع وضع القراءة دائماً — مخفيّ تماماً في وضع
    // القراءة (لا ساعة/شبكة/بطارية)، و ظاهر بخلفية السمة في الوضع العادي. هكذا لا
    // يُعيد تغيّر السمة/الصنف إظهار الشريط في وضع القراءة (كان هذا سبب ظهوره).
    await applyReadMode(getReadMode());
  } catch (e) {
    console.warn('StatusBar sync failed', e);
  }
}

// شريط التنقّل السفليّ للنظام يتبع خلفيّة التطبيق (مطابقاً لشريط الحالة):
//   فاتح #ffffff بأزرار داكنة · داكن #0a0a0a بأزرار فاتحة.
// هل خلفيّة التطبيق المختارة (--page-bg) غامقة؟ — لضبط تباين أزرار النظام/أيقونات الشريط
// بناءً على اللون الفعليّ لا على صنف dark وحده (خلفيّة غامقة بلا صنف dark كانت تُخفي الأزرار).
function isPageBgDark() {
  try {
    const v = getComputedStyle(document.documentElement).getPropertyValue('--page-bg').trim();
    if (!v) return document.documentElement.classList.contains('dark');
    const probe = document.createElement('div');
    probe.style.color = v; document.body.appendChild(probe);
    const rgb = getComputedStyle(probe).color; document.body.removeChild(probe);
    const m = rgb.match(/\d+(\.\d+)?/g);
    if (!m || m.length < 3) return document.documentElement.classList.contains('dark');
    const [r, g, b] = m.map(Number);
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
  } catch { return document.documentElement.classList.contains('dark'); }
}

async function syncNavigationBarWithTheme() {
  if (!isNative()) return;
  try {
    const { NavigationBar } = await import('@capgo/capacitor-navigation-bar');
    const dark = isPageBgDark();
    // نلوّن الشريط السفليّ بلون خلفيّة التطبيق نفسه (--page-bg) — لا شفّاف. الشفّاف كان
    // يجعل النظام يضيف قناع تباين أغمق على الجوالات الحديثة فيظهر الشريط بلون مختلف
    // (أغمق) عن الفوتر. اللون الصلب المطابق يلغي هذا. أندرويد 15 يتجاهل اللون فتظهر
    // خلفيّة التطبيق (--page-bg) من ورائه أصلاً — فالنتيجة مطابقة على كل الإصدارات.
    const pageHex = (() => {
      try {
        const v = getComputedStyle(document.documentElement).getPropertyValue('--page-bg').trim();
        const probe = document.createElement('div'); probe.style.color = v || '#ffffff'; document.body.appendChild(probe);
        const rgb = getComputedStyle(probe).color; document.body.removeChild(probe);
        const m = rgb.match(/\d+(\.\d+)?/g);
        if (m && m.length >= 3) { const [r, g, b] = m.map(Number); return '#' + [r, g, b].map((x) => Math.round(x).toString(16).padStart(2, '0')).join(''); }
      } catch { /* ignore */ }
      return '#ffffff';
    })();
    try { await NavigationBar.setNavigationBarColor({ color: pageHex, darkButtons: !dark }); } catch { /* الإصدار القديم من الملحق */ }
  } catch (e) {
    console.warn('NavigationBar sync failed', e);
  }
}

async function setupNative() {
  if (!isNative()) return;

  await syncStatusBarWithTheme();
  await syncNavigationBarWithTheme();

  // Watch <html class="dark"> for changes
  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.type === 'attributes' && m.attributeName === 'class') {
        syncStatusBarWithTheme();
        syncNavigationBarWithTheme();
        break;
      }
    }
  });
  observer.observe(document.documentElement, { attributes: true });

  // تغيّر لون الخلفيّة (--page-bg) لا يغيّر صنف <html>، فنستمع لحدث التخصيص لتحديث الشريطين فوراً
  window.addEventListener('themeColorChanged', () => {
    syncStatusBarWithTheme();
    syncNavigationBarWithTheme();
  });

  // Android hardware back button
  try {
    const { App: CapApp } = await import('@capacitor/app');
    CapApp.addListener('backButton', ({ canGoBack }) => {
      if (canGoBack) window.history.back();
      else CapApp.exitApp();
    });
  } catch (e) {
    console.warn('App plugin not available', e);
  }
}

setupNative();

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)

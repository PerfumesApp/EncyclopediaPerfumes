import EncyclopediaLogo from "@/components/icons/EncyclopediaLogo";
import { Download, Eraser } from "lucide-react";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import ActivityTimeline from "@/components/home/ActivityTimeline";
import { getSecureStorage, setSecureStorage } from "@/lib/storageEncryption";
import WearReminders from "@/components/shared/WearReminders";
import GlobalSearch from "@/components/home/GlobalSearch";
import ActivityExportDialog from "@/components/home/ActivityExportDialog";
import MoodBox from "@/components/home/MoodBox";
import RandomQuote from "@/components/home/RandomQuote";
import { useMemo, useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { useNumberEncryption } from "@/lib/useNumberEncryption";

export default function Home() {
  const { isAr } = useLang();
  const queryClient = useQueryClient();
  const { encryptFields } = useNumberEncryption();

  // أُزيلت المزاجات الافتراضيّة (٧ إيموجي) — نحذف أي بقايا مزروعة سابقاً و لا نعيد بذرها.
  useEffect(() => {
    (async () => {
      try {
        const existing = await apphost.entities.MoodEntry.list("-created_date", 200);
        const introRows = (existing || []).filter((m) => m && m.source === "mood_intro");
        for (const m of introRows) { try { await apphost.entities.MoodEntry.delete(m.id); } catch { /* تجاهل */ } }
        if (introRows.length) queryClient.invalidateQueries({ queryKey: ["mood-entries"] });
      } catch { /* غير حرِج */ }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // إصلاح موجّه خفيف (بلا إنعاش كامل): يضمن أن براند Arabian يحمل العطّارين
  // فرحانة و هلال آرت في perfumer_names — يدمج مع الموجود (لا يكتفي بالفارغ)
  // حتى لو حمل الجهاز قيمة قديمة. علم مستقلّ، تشغيل مرّة واحدة.
  useEffect(() => {
    (async () => {
      try {
        if (localStorage.getItem("proc_arabian_perfumers_v1")) return;
        let recs = [];
        for (const nm of ["Arabian", "ARABIAN", "arabian"]) {
          try { const r = await apphost.entities.PerfumeBrand.filter({ name: nm }, "name", 5); if (r && r.length) recs.push(...r); } catch { /* تجاهل */ }
        }
        const fits = (r) => r && String(r.name || "").toLowerCase().includes("arabian");
        const brec = recs.find((r) => fits(r) && (r.source === "app_example" || r.is_default)) || recs.find(fits) || null;
        if (brec) {
          const cur = String(brec.perfumer_names || "").split(",").map((s) => s.trim()).filter(Boolean);
          const want = ["Farhana", "Hilal Art"];
          const lower = cur.map((s) => s.toLowerCase());
          const merged = [...cur];
          for (const w of want) { if (!lower.includes(w.toLowerCase())) merged.push(w); }
          if (merged.length !== cur.length) {
            await apphost.entities.PerfumeBrand.update(brec.id, { perfumer_names: merged.join(", ") });
            queryClient.invalidateQueries({ predicate: (q) => q.queryKey[0] !== "perfumes" });
          }
        }
        localStorage.setItem("proc_arabian_perfumers_v1", "1");
      } catch { /* غير حرِج — تحاول لاحقا، العلم لا يُكتب إلا بعد النجاح */ }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const DEFAULT_HOME_FILTERS = { reviews: true, purchases: true, favorites: true, wearLogs: true, blogEntries: true, glossaryEntries: true, goals: true, budgetEntries: true, quotesActivity: true, moodEntries: true, wishes: true };
  const [filters, setFilters] = useState(() => getSecureStorage("homeFilters", DEFAULT_HOME_FILTERS) || DEFAULT_HOME_FILTERS);
  const [sortOrder, setSortOrder] = useState(() => getSecureStorage("homeSortOrder", "newest") || "newest");
  const [exportOpen, setExportOpen] = useState(false);
  const [showActivity, setShowActivity] = useState(() => getSecureStorage("showActivityTimeline", true));
  const [cleanedAt, setCleanedAt] = useState(() => Number(getSecureStorage("homeCleanedAt", 0)) || 0);
  const qc = useQueryClient();

  const handleCleanActivities = async () => {
    if (!confirm(isAr
      ? "تنظيف النشاطات من الصفحة (تبقى في القاعدة، ويُحذف المزاج نهائياً). متابعة؟"
      : "Clean activities from the page (kept in the database; mood is permanently deleted). Continue?")) return;
    // المزاج يُحذف نهائياً من القاعدة
    try {
      const moods = await apphost.entities.MoodEntry.list("-created_date");
      for (const m of (moods || [])) { try { await apphost.entities.MoodEntry.delete(m.id); } catch { /* تجاهل */ } }
    } catch { /* تجاهل */ }
    // بقيّة المدخلات: ختم تنظيف يُخفيها من العرض فقط (تبقى في القاعدة)
    const now = Date.now();
    setCleanedAt(now);
    setSecureStorage("homeCleanedAt", now);
    qc.invalidateQueries({ queryKey: ["mood-entries"] });
  };
  useEffect(() => {
    const h = () => setShowActivity(getSecureStorage("showActivityTimeline", true));
    window.addEventListener("activitySectionChanged", h);
    return () => window.removeEventListener("activitySectionChanged", h);
  }, []);
  // مزامنة فلتر النشاطات و الفرز مع الإعدادات: نقرأ المخزَّن عند أي تغيير من شيت الإعدادات
  // (و عند مسح النشاطات و المزاج تُحذف المفاتيح فيرجع الفلتر للافتراضي). قبل ذلك كان Home
  // يستخدم افتراضات ثابتة و يتجاهل الإعدادات، فيبدو الفلتر و زرّ المسح بلا أثر.
  useEffect(() => {
    const h = () => {
      setFilters(getSecureStorage("homeFilters", DEFAULT_HOME_FILTERS) || DEFAULT_HOME_FILTERS);
      setSortOrder(getSecureStorage("homeSortOrder", "newest") || "newest");
    };
    window.addEventListener("homeSettingsChanged", h);
    return () => window.removeEventListener("homeSettingsChanged", h);
  }, []);



  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: wearLogs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: blogPosts = [] } = useQuery({
    queryKey: ["blog-posts"],
    queryFn: () => apphost.entities.BlogPost.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: glossaryTerms = [] } = useQuery({
    queryKey: ["glossary-is-user"],
    queryFn: async () => {
      try { const { items } = await apphost.entities.GlossaryTerm.pageByIndexRange("is_user", { only: 1 }, 0, 200, "next", false); return items || []; }
      catch { return []; }
    },
    staleTime: 1000 * 60 * 5,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => apphost.entities.Goal.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: budgetIncomes = [] } = useQuery({
    queryKey: ["budget-incomes"],
    queryFn: () => apphost.entities.BudgetIncome.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: budgetExpenses = [] } = useQuery({
    queryKey: ["budget-expenses"],
    queryFn: () => apphost.entities.BudgetExpense.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: userQuotes = [] } = useQuery({
    queryKey: ["user-quotes"],
    queryFn: () => apphost.entities.UserQuote.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: allQuotes = [] } = useQuery({
    queryKey: ["quotes"],
    queryFn: () => apphost.entities.Quote.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: moodEntries = [] } = useQuery({
    queryKey: ["mood-entries"],
    queryFn: () => apphost.entities.MoodEntry.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: shopProducts = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: wishlists = [] } = useQuery({
    queryKey: ["wishlists"],
    queryFn: () => apphost.entities.Wishlist.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  // ترحيبة أعلى الصفحة: خمس نقاط ذهبية ثابتة (لا تتغيّر مع المزاج). المزاج يظهر
  // في صندوق المزاج فقط، لا في الهيدر.

  const { data: uBrands = [] } = useQuery({ queryKey: ["user-brand"], queryFn: () => apphost.entities.UserBrand.list("-created_date"), staleTime: 1000 * 60 * 5 });
  const { data: uNotes = [] } = useQuery({ queryKey: ["user-note"], queryFn: () => apphost.entities.UserNote.list("-created_date"), staleTime: 1000 * 60 * 5 });
  const { data: uPerfumers = [] } = useQuery({ queryKey: ["user-perfumer"], queryFn: () => apphost.entities.UserPerfumer.list("-created_date"), staleTime: 1000 * 60 * 5 });
  const { data: uGloss = [] } = useQuery({ queryKey: ["user-glossary-terms"], queryFn: () => apphost.entities.UserGlossaryTerm.list("-created_date"), staleTime: 1000 * 60 * 5 });

  // Build flat activities list for export (mirrors ActivityTimeline logic)
   const allActivitiesForExport = useMemo(() => {
     const all = [];
     userPerfumes.forEach((up) => {
       const impressionEmoji = up.impression === "great" ? "😍" : up.impression === "not_great" ? "😕" : up.impression === "neutral" ? "😐" : "";
       const ratingStars = up.rating ? "◆".repeat(up.rating) + "◇".repeat(5 - up.rating) : "";
       if (up.rating || up.impression) all.push({ type: "review", id: up.id, title: `Reviewed ${up.perfume_name}`, subtitle: `by ${up.brand_name}`, person: up.person, date: new Date(up.created_date), emoji: impressionEmoji, rating: up.rating, ratingStars, image_url: up.image_url });
       if (up.list === "favorite") all.push({ type: "favorite", id: `fav-${up.id}`, title: `Added to favorites`, subtitle: `${up.perfume_name} — ${up.brand_name}`, person: up.person, date: new Date(up.created_date) });
     });
     purchaseRecords.forEach((pr) => all.push({ type: "purchase", id: pr.id, title: `Purchased ${pr.type === "sample" ? "sample" : "bottle"}`, subtitle: `${pr.perfume_name} — ${pr.ml}ml`, person: pr.person, date: new Date(pr.purchase_date || pr.created_date) }));
     wearLogs.forEach((wl) => all.push({ type: "wear", id: wl.id, title: `Wore ${wl.perfume_name}`, subtitle: wl.brand_name, person: wl.person, date: new Date(wl.date || wl.created_date) }));
     blogPosts.forEach((bp) => all.push({ type: "blog", id: bp.id, title: bp.title, subtitle: `${bp.entry_type} entry`, person: bp.person, date: new Date(bp.created_date) }));
     glossaryTerms.forEach((gt) => all.push({ type: "glossary", id: `gl-${gt.id}`, title: gt.term_en, subtitle: gt.term_ar || "", person: null, date: new Date(gt.created_date) }));
     goals.forEach((g) => all.push({ type: "goal", id: `goal-${g.id}`, title: g.title, subtitle: `${g.category || ""} — ${g.status || "pending"}`, person: g.person === "both" ? null : g.person, date: new Date(g.created_date) }));
     budgetIncomes.forEach((inc) => all.push({ type: "budget", id: `inc-${inc.id}`, title: `Income: ${inc.type}`, subtitle: `${inc.amount} — ${inc.date || ""}`, person: inc.person === "family" ? null : inc.person, date: new Date(inc.date || inc.created_date) }));
     budgetExpenses.forEach((exp) => all.push({ type: "budget", id: `exp-${exp.id}`, title: `Expense: ${exp.category}`, subtitle: `${exp.amount} — ${exp.description || ""}`, person: exp.person === "family" ? null : exp.person, date: new Date(exp.date || exp.created_date) }));
     userQuotes.forEach((uq) => {
       const quote = allQuotes.find((q) => String(q.id) === String(uq.quote_id));
       const reactionLabel = uq.reaction === "like" ? "❤️" : uq.reaction === "dislike" ? "💔" : uq.reaction === "wtf" ? "😱" : "💬";
       const isNew = !uq.reaction || uq.reaction === "none";
       const title = isNew ? "✍️" : reactionLabel; // الحال فقط — بلا جُمل
       // Use new text_enar field with fallback to legacy text_en / snapshot copy on UserQuote
       const fullText = (quote?.text_enar) || (uq.text_enar) || (quote?.text_en) || (uq.text_en) || "";
       const subtitle = fullText.slice(0, 60) + (fullText.length > 60 ? "…" : "");
       all.push({ type: "quote", id: `uq-${uq.id}`, title, subtitle, person: null, date: new Date(uq.created_date) });
     });
     moodEntries.forEach((me) => {
       if (me.source === "app_example") return; // الترحيب المبذور: أعلى الصفحة فقط
       all.push({ type: "mood", id: `mood-${me.id}`, title: `${me.emoji} ${me.text}`, subtitle: "", person: me.person, date: new Date(me.created_date) });
     });
     wishlists.forEach((w) => {
       if (w.perfume_id) {
         all.push({ type: "wish", id: `wish-${w.id}`, title: `Added to wishlist`, subtitle: `${w.perfume_name || ""} — ${w.brand_name || ""}`, person: w.person, date: new Date(w.added_date || w.created_date) });
       }
     });
     shopProducts.forEach((sp) => {
       if (sp.cost && sp.purchase_date) {
         all.push({ type: "purchase", id: `shop-${sp.id}`, title: `Purchased ${sp.name}`, subtitle: `${sp.brand_name || "Unknown"} — ${sp.cost}`, person: sp.person, date: new Date(sp.purchase_date) });
       }
     });
     const RX = { favorite: "❤️", recommend: "👍", dislike: "👎", wtf: "😱" };
     userPerfumes.forEach((up) => { if (["recommend","dislike","wtf"].includes(up.list)) all.push({ type: "reaction", id: `rxp-${up.id}`, title: `${RX[up.list]} ${up.perfume_name || ""}`, subtitle: up.brand_name || "", person: up.person, date: new Date(up.created_date) }); });
     uBrands.forEach((b) => { if (RX[b.list]) all.push({ type: "reaction", id: `rxb-${b.id}`, title: `${RX[b.list]} ${b.brand_name || ""}`, subtitle: "Brand", person: b.person, date: new Date(b.created_date) }); });
     uNotes.forEach((n) => { if (RX[n.list]) all.push({ type: "reaction", id: `rxn-${n.id}`, title: `${RX[n.list]} ${n.note_name || n.note_name_ar || ""}`, subtitle: "Note", person: n.person, date: new Date(n.created_date) }); });
     uPerfumers.forEach((pf) => { if (RX[pf.list]) all.push({ type: "reaction", id: `rxpr-${pf.id}`, title: `${RX[pf.list]} ${pf.perfumer_name || ""}`, subtitle: "Perfumer", person: pf.person, date: new Date(pf.created_date) }); });
     uGloss.forEach((t) => { if (t.reaction === "favorite") all.push({ type: "glossary", id: `enc-${t.id}`, title: t.title_en || t.title_ar || t.title || "", subtitle: t.title_ar || "", person: t.person, date: new Date(t.created_date) }); });
     all.sort((a, b) => b.date - a.date);
     return all;
   }, [userPerfumes, purchaseRecords, wearLogs, blogPosts, glossaryTerms, goals, budgetIncomes, budgetExpenses, userQuotes, allQuotes, moodEntries, wishlists, shopProducts, uBrands, uNotes, uPerfumers, uGloss]);

  return (
    <div className="px-4 page-top pb-32 space-y-3">
      {/* Header — «.....» وحده أعلى الصفحة (البحث نُقل لما بعد النشاطات) */}
      <div className="-mx-4 px-4 pt-2 pb-0 flex items-center justify-between min-h-[44px]">
         <span style={{ color: "var(--brand)" }}><EncyclopediaLogo className="w-7 h-7" /></span>
        <div className="flex items-center gap-2">
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      <MoodBox />

      {/* تذكير ارتداء العطر */}
      <WearReminders />

      {showActivity && (
        <>
          <ActivityTimeline filters={filters} sortOrder={sortOrder} cleanedAt={cleanedAt} />
        </>
      )}

      {/* محرك البحث — منقول لما بعد النشاطات */}
      <GlobalSearch />

      {/* الاقتباس العشوائي — أسفل الصفحة */}
      {/* صندوق الاقتباس العشوائيّ أُزيل */}

      {/* شريط أدوات سفلي — منقول لما بعد الموسوعة/الاقتباس: تنظيف — تصدير */}
      <div className="flex items-center justify-center gap-12 pt-2">
        <button
          onClick={handleCleanActivities}
          className="flex items-center justify-center hover:opacity-70 transition-opacity"
          title={isAr ? "نظّف النشاطات" : "Clean Activities"}
          aria-label={isAr ? "نظّف النشاطات" : "Clean Activities"}
        >
          <Eraser className="w-5 h-5 text-[#9a7b1f]" />
        </button>
        <button
          onClick={() => setExportOpen(true)}
          className="flex items-center justify-center hover:opacity-70 transition-opacity"
          title={isAr ? "تصدير" : "Export"}
          aria-label={isAr ? "تصدير" : "Export"}
        >
          <Download className="w-5 h-5 text-[#9a7b1f]" />
        </button>
      </div>

      <ActivityExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        activities={allActivitiesForExport}
      />
    </div>
  );
}
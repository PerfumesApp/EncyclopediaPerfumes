import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { searchIndexReady, perfumeIdsByNote } from "@/lib/searchIndex";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Edit2, Upload, X, Download, FileText, ArrowDownUp, AArrowUp, AArrowDown } from "lucide-react";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import { compareEnglish } from "@/lib/sortName";
import { useLang } from "@/lib/LanguageContext";
import { downloadBlob, openExternalUrl } from "@/lib/exportHelper";
import DetailFooter from "@/components/shared/DetailFooter";
import PinButton from "@/components/shared/PinButton";
import BackIcon from "@/components/shared/BackIcon";

const PYRAMID_LABELS = { top: "افتتاحية", heart: "قلب", base: "أساس", conductor: "موصّل", innovation: "مبتكرة", all: "كل الطبقات" };
const PYRAMID_COLORS = {
  top: "bg-sky-100 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-800",
  heart: "bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800",
  base: "bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800",
  conductor: "bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800",
  all: "bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300 border-violet-200 dark:border-violet-800",
};

const CATEGORIES = [
  "Floral زهري","Woody خشبي","Citrus حمضي","Oriental شرقي","Spicy توابل",
  "Aquatic مائي","Fruity فاكهي","Green أخضر","Gourmand حلو","Earthy ترابي",
  "Musky مسكي","Powdery بودرة","Resinous راتنجي"
];
const ODOR_FAMILIES = [
  "Fresh منعش","Warm دافئ","Sweet حلو","Dry جاف","Green أخضر",
  "Earthy ترابي","Aquatic مائي","Smoky دخاني","Creamy كريمي","Leathery جلدي"
];

export default function NoteDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");
  const nameParam = urlParams.get("name") || "";
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [npSortMode, setNpSortMode] = useState("year"); // year | type | alpha
  const [npVisible, setNpVisible] = useState(12);
  const NOTE_PERFUMES_STEP = 12;

  const { data: noteRecord, isLoading } = useQuery({
    queryKey: ["note", id],
    queryFn: async () => {
      const res = await apphost.entities.PerfumeNote.filter({ id });
      return res?.[0] || null;
    },
    enabled: !!id,
  });

  // إقفال الفجوة المعاكسة: نوتة يذكرها العطر بلا سجلّ منسّق → صفحة بديلة بالاسم
  // (تُفصَل «English عربي»)، مع رسالة «لا توجد معلومات نوتة بعد» + العطور الحاوية.
  const syntheticNote = useMemo(() => {
    if (noteRecord || !nameParam) return null;
    const t = String(nameParam).trim();
    const m = t.match(/[\u0600-\u06FF]/);
    const en = m ? t.slice(0, t.indexOf(m[0])).trim() : t;
    const ar = m ? t.slice(t.indexOf(m[0])).trim() : "";
    return { id: null, name: en || t, name_en: en || t, name_ar: ar, description: "", description_ar: "", _synthetic: true };
  }, [noteRecord, nameParam]);

  const note = noteRecord || syntheticNote;

  // تفاعل النوتة (4 إيموجي) — للشخص الفعّال، يتراكم عبر كلّ العطور ليعرف ما يحبّه من النوتات
  const noteReactPerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";
  const { data: noteReacts = [] } = useQuery({
    queryKey: ["user-note", note?.id],
    queryFn: () => apphost.entities.UserNote.filter({ note_id: note.id }),
    enabled: !!note?.id,
  });
  const myNoteReact = noteReacts.find((r) => r.person === noteReactPerson) || null;
  const upsertNoteReact = useMutation({
    mutationFn: async (value) => {
      const existing = noteReacts.find((r) => r.person === noteReactPerson);
      if (existing) return apphost.entities.UserNote.update(existing.id, { list: value });
      return apphost.entities.UserNote.create({ note_id: note.id, note_name: note.name_en || note.name, note_name_ar: note.name_ar || "", person: noteReactPerson, list: value });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["user-note"] }); },
  });

  // All notes (sorted A→Z by English name) for footer prev/next navigation.
  const { data: allNotesList = [] } = useQuery({
    queryKey: ["all-notes-nav"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });
  const sortedNotes = [...allNotesList].sort((a, b) =>
    compareEnglish(a, b, 1)
  );

  if (note && !note._synthetic && form === null) setForm(note);

  // بدل تحميل كل العطور (~130 ألف) الذي كان يجمّد الصفحة: ننتظر جاهزية فهرس البحث
  // (poll خفيف) فيُعاد الرسم عند الجاهزية و تُجلب العطور عبر الفهرس فقط.
  const [noteIndexReady, setNoteIndexReady] = useState(() => searchIndexReady());
  useEffect(() => {
    if (noteIndexReady) return;
    const t = setInterval(() => { if (searchIndexReady()) { setNoteIndexReady(true); clearInterval(t); } }, 600);
    return () => clearInterval(t);
  }, [noteIndexReady]);

  const { data: allBrands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });

  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeNote.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["note", id] });
      queryClient.invalidateQueries({ queryKey: ["notes"] });
      toast.success("تم الحفظ");
      setEditOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => apphost.entities.PerfumeNote.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notes"] });
      navigate("/notes");
    },
  });

  const handleUploadImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (e.target) e.target.value = ""; // Prevent double-trigger on Android
    setUploading(true);
    try {
      const result = await apphost.integrations.Core.UploadFile({ file });
      setForm({ ...form, image_url: result.file_url });
    } catch {
      toast.error((isAr ? "فشل الرفع" : "Upload failed"));
    }
    setUploading(false);
  };

  const [exportOpen, setExportOpen] = useState(false);

  const handleExportTxt = async () => {
    const utf8Bom = '\uFEFF';
    const txt = `${note.name}${note.name_ar ? ' — ' + note.name_ar : ''}\n` +
      `التصنيف: ${note.category || '-'}\n` +
      `العائلة: ${note.odor_family || '-'}\n` +
      `الهرم: ${note.pyramid || '-'}\n` +
      `الأصل: ${note.origin || '-'}\n` +
      `الوصف:\n${note.description || '-'}\n`;
    const blob = new Blob([utf8Bom + txt], { type: "text/plain;charset=utf-8;" });
    await downloadBlob(blob, `${note.name || "note"}.txt`);
  };

  const handleExportImage = async () => {
    if (!note.image_url) { toast.error("لا توجد صورة لهذه النوتة"); return; }
    // Note image URLs are remote (CORS-restricted), so we can't fetch+blob them
    // reliably. Open in browser/overlay where the user can save it themselves.
    await openExternalUrl(note.image_url);
  };

  // العطور الحاوية لهذه النوتة: من دلو الفهرس (note_en/note_ar → getMany) بعد جاهزيته.
  const { data: matchingPerfumes = [] } = useQuery({
    queryKey: ["note-perfumes", note?.id, noteIndexReady],
    enabled: !!note && noteIndexReady,
    staleTime: 1000 * 60 * 5,
    queryFn: async () => {
      const noteEn = String(note.name_en || note.name || "").toLowerCase().trim();
      const noteAr = String(note.name_ar || "").trim();
      if (!noteEn && !noteAr) return [];
      const { ids } = await perfumeIdsByNote(noteEn, noteAr);
      return ids.length ? apphost.entities.Perfume.getMany(ids) : [];
    },
  });

  const matchingBrands = useMemo(() => (
    matchingPerfumes.length > 0
      ? Array.from(new Set(matchingPerfumes.map(p => p.brand_id)))
          .map(brandId => allBrands.find(b => String(b.id) === String(brandId))).filter(Boolean)
      : []
  ), [matchingPerfumes, allBrands]);

  const matchingPerfumers = useMemo(() => (
    matchingPerfumes.length > 0
      ? Array.from(new Set(matchingPerfumes.flatMap(p => (
          p.perfumer_ids ? p.perfumer_ids.split(",").map(s => s.trim()).filter(Boolean) : []
        ))))
          .map(perfumerId => allPerfumers.find(perf => String(perf.id) === String(perfumerId))).filter(Boolean)
      : []
  ), [matchingPerfumes, allPerfumers]);

  if (isLoading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (!note) return (
    <div className="px-5 page-top text-center">
      <p className="text-muted-foreground font-body">{isAr ? "الملاحظة غير موجودة" : "Note not found"}</p>
      <Button variant="ghost" onClick={() => navigate("/notes")} className="mt-4">{isAr ? "رجوع" : "Go Back"}</Button>
    </div>
  );

  const pyramid = note.pyramid?.split(",")[0]?.trim();

  return (
    <div className="pb-24">
      {/* Hero */}
      <div className="relative bg-background border-b border-border pt-14 pb-8 px-5">
        <Button variant="ghost" size="icon" className="absolute top-10 left-4 rounded-none hover:bg-secondary" onClick={() => navigate("/notes")}>
          <BackIcon className="w-5 h-5" />
        </Button>
        <div className="absolute top-10 right-4"><PinButton kind="note" id={note.id} /></div>

        <div className="flex flex-col items-center gap-3 mt-2">
          <div className="w-20 h-20 overflow-hidden flex items-center justify-center" style={{ background: "transparent" }}>
            {note.image_url && <img src={note.image_url} alt={note.name} data-img-fallback="1" onError={(e) => { e.currentTarget.style.display = "none"; }} className="w-full h-full object-cover" style={{ background: "transparent" }} />}
          </div>
          <div className="text-center space-y-1">
            <h1 className="font-heading text-lg font-bold">{note.name_en || note.name}</h1>
            {note.name_ar && <p className="text-muted-foreground font-body text-sm" dir="rtl">{note.name_ar}</p>}

            {/* تفاعل النوتة — 4 إيموجي (يتراكم تفضيلك) */}
            <div className="flex items-center justify-center gap-4 pt-2">
              {[["favorite", "❤️"], ["recommend", "👍"], ["dislike", "👎"], ["wtf", "😱"]].map(([val, em]) => {
                const active = myNoteReact?.list === val;
                return (
                  <button key={val} type="button" onClick={() => upsertNoteReact.mutate(active ? null : val)} disabled={upsertNoteReact.isPending}
                    aria-label={val} className="transition-all" style={{ fontSize: 22, opacity: active ? 1 : 0.35, transform: active ? "scale(1.15)" : "none" }}>
                    {em}
                  </button>
                );
              })}
            </div>

          </div>

          {/* Info list */}
          <div className="w-full mt-4 flex flex-wrap justify-center gap-x-8 gap-y-3 px-2">
            {note.note_category && (
              <button
                onClick={() => navigate(`/notes?levelFilter=${note.note_category}`)}
                className="flex flex-col items-center gap-0.5 hover:opacity-70 transition-opacity"
              >
                <span className="text-[9px] font-body font-semibold uppercase tracking-widest text-muted-foreground/60">{isAr ? "كاتلوج" : "Catalog"}</span>
                <span className={`text-sm font-heading font-bold hover:underline ${
                  note.note_category === "main_note" ? "text-emerald-600" :
                  note.note_category === "sub_notes" ? "text-sky-600" : "text-amber-600"
                }`}>
                  {note.note_category === "main_note" ? (isAr ? "رئيسية" : "Main") : note.note_category === "sub_notes" ? (isAr ? "فرعية" : "Sub") : (isAr ? "ثانوية" : "Low")}
                </span>
              </button>
            )}
            {pyramid && (
              <button
                onClick={() => navigate(`/notes?pyramidFilter=${pyramid}`)}
                className="flex flex-col items-center gap-0.5 hover:opacity-70 transition-opacity"
              >
                <span className="text-[9px] font-body font-semibold uppercase tracking-widest text-muted-foreground/60">{isAr ? "الهرم" : "Pyramid"}</span>
                <span className="text-sm font-heading font-bold text-foreground hover:underline">{PYRAMID_LABELS[pyramid]}</span>
              </button>
            )}
            {note.category && note.category.split(",").map(s => s.trim()).filter(Boolean).map((cat, i) => (
              <Link
                key={i}
                to={`/search-results?q=${encodeURIComponent(cat)}`}
                className="flex flex-col items-center gap-0.5 hover:opacity-70 transition-opacity"
                title={`@${cat}`}
              >
                {i === 0 && <span className="text-[9px] font-body font-semibold uppercase tracking-widest text-muted-foreground/60">{isAr ? "الفئة" : "Category"}</span>}
                
                <span className="text-sm font-heading font-bold text-foreground hover:underline">{cat}</span>
              </Link>
            ))}
            {note.odor_family && note.odor_family.split(",").map(s => s.trim()).filter(Boolean).map((fam, i) => (
              <Link
                key={i}
                to={`/search-results?q=${encodeURIComponent(fam)}`}
                className="flex flex-col items-center gap-0.5 hover:opacity-70 transition-opacity"
                title={`@${fam}`}
              >
                {i === 0 && <span className="text-[9px] font-body font-semibold uppercase tracking-widest text-muted-foreground/60">{isAr ? "العائلة العطرية" : "Odor Family"}</span>}
                
                <span className="text-sm font-heading font-bold text-foreground hover:underline">{fam}</span>
              </Link>
            ))}
            {note.origin && (
              <div className="flex flex-col items-center gap-0.5">
                <span className="text-[9px] font-body font-semibold uppercase tracking-widest text-muted-foreground/60">{isAr ? "المنشأ" : "Origin"}</span>
                <span className="text-sm font-heading font-bold text-foreground">{note.origin}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="px-5 space-y-4 mt-5">

        {/* Brands, Perfumers moved below - removed from here */}

        {/* Description + Status */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-2">
          <h2 className="font-heading font-semibold text-sm">About عن</h2>

          {/* Status: plain colored text — no icon, no background */}
          {note.is_allowed === false ? (
            <p className="text-sm font-body font-semibold text-red-600">Restricted-Not Allowed مقيد-غير مسموح</p>
          ) : (
            <p className="text-sm font-body font-semibold text-emerald-600">Allowed مسموح</p>
          )}

          {/* Restriction reason bilingual */}
          {note.is_allowed === false && (note.restriction_en || note.restriction_ar) && (
            <div className="space-y-1 pt-1">
              {note.restriction_en && (
                <p className="text-xs font-body text-red-700 leading-relaxed">{note.restriction_en}</p>
              )}
              {note.restriction_ar && (
                <p className="text-xs font-body text-red-700 leading-relaxed" dir="rtl">{note.restriction_ar}</p>
              )}
            </div>
          )}

          {note._synthetic && (
            <p className="text-sm font-body text-muted-foreground leading-relaxed pt-1" dir={isAr ? "rtl" : "ltr"}>
              {isAr ? "لا توجد معلومات نوتة بعد — هذه نوتة تذكرها العطور دون مدخل منسّق." : "No note info yet — referenced by perfumes without a curated entry."}
            </p>
          )}
          {note.description && <p className="text-sm font-body text-foreground/75 leading-relaxed pt-1">{note.description}</p>}
          {note.description_ar && (
            <p className="text-sm font-body text-foreground/70 leading-relaxed border-t border-border/50 pt-2" dir="rtl">{note.description_ar}</p>
          )}
        </div>

        {/* Found In - Separate sections */}
        {matchingPerfumes.length > 0 ? (
          <>
            {/* Brands Section (capped) */}
            {matchingBrands.length > 0 && (
              <div className="bg-card rounded-none p-4 shadow-sm space-y-3">
                <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">Brands براندات ({matchingBrands.length})</p>
                <div className="space-y-1.5 max-h-64 overflow-y-auto">
                  {matchingBrands.slice(0, 100).map((brand) => (
                    <button key={brand.id} onClick={() => navigate(`/brand?id=${brand.id}`)} className="w-full text-left text-sm font-medium text-sky-600 dark:text-sky-400 hover:underline py-1.5 px-2 rounded hover:bg-sky-600/5 transition-colors">
                      {brand.name}
                    </button>
                  ))}
                  {matchingBrands.length > 100 && (
                    <p className="text-[10px] text-muted-foreground font-body text-center pt-1">+{matchingBrands.length - 100} المزيد more</p>
                  )}
                </div>
              </div>
            )}

            {/* Perfumers Section (capped) */}
            {matchingPerfumers.length > 0 && (
              <div className="bg-card rounded-none p-4 shadow-sm space-y-3">
                <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">Perfumers عطارين ({matchingPerfumers.length})</p>
                <div className="space-y-1.5 max-h-64 overflow-y-auto">
                  {matchingPerfumers.slice(0, 100).map((perfumer) => (
                    <button key={perfumer.id} onClick={() => navigate(`/perfumer?id=${perfumer.id}`)} className="w-full text-left text-sm font-medium text-amber-600 dark:text-amber-400 hover:underline py-1.5 px-2 rounded hover:bg-amber-600/5 transition-colors">
                      {perfumer.name}
                    </button>
                  ))}
                  {matchingPerfumers.length > 100 && (
                    <p className="text-[10px] text-muted-foreground font-body text-center pt-1">+{matchingPerfumers.length - 100} المزيد more</p>
                  )}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="bg-card rounded-none p-5 text-center">
            <p className="text-sm text-muted-foreground font-body">No perfumes found with this note لم يتم العثور على عطور تحتوي على هذه النوتة</p>
          </div>
        )}

        {/* Perfumes cards — sorted + paginated (50/page) */}
        {matchingPerfumes.length > 0 && (() => {
          const sorted = [...matchingPerfumes].sort((a, b) => {
            if (npSortMode === "alpha_asc" || npSortMode === "alpha_desc") {
              return compareEnglish(a, b, npSortMode === "alpha_desc" ? -1 : 1);
            }
            if (npSortMode === "type") return (String(a.type || "")).localeCompare(b.type || "");
            // year
            if (b.release_year && a.release_year) return b.release_year - a.release_year;
            if (b.release_year) return 1;
            if (a.release_year) return -1;
            return 0;
          });
          const pageItems = sorted.slice(0, npVisible);
          return (
            <div className="space-y-3 mt-6">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h2 className="font-heading font-semibold text-sm">Cards كروت</h2>
                <div className="flex items-center gap-1.5">
                  <ArrowDownUp className="w-3.5 h-3.5 text-primary" />
                  {[
                    { id: "year", ar: "الإصدار", en: "Release" },
                    { id: "type", ar: "النوع", en: "Type" },
                  ].map((s) => (
                    <button key={s.id} onClick={() => { setNpSortMode(s.id); setNpVisible(NOTE_PERFUMES_STEP); }}
                      className={`text-[10px] rounded-none ${npSortMode === s.id ? " text-background" : " text-muted-foreground"}`}>
                      {isAr ? s.ar : s.en}
                    </button>
                  ))}
                  {[
                    { id: "alpha_asc", Icon: AArrowUp, ar: "أبجدي تصاعدي", en: "A → Z" },
                    { id: "alpha_desc", Icon: AArrowDown, ar: "أبجدي تنازلي", en: "Z → A" },
                  ].map((s) => (
                    <button key={s.id} onClick={() => { setNpSortMode(s.id); setNpVisible(NOTE_PERFUMES_STEP); }}
                      title={isAr ? s.ar : s.en} aria-label={isAr ? s.ar : s.en}
                      className={`p-1 rounded-none transition-colors ${npSortMode === s.id ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                      <s.Icon className="w-4 h-4" />
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {pageItems.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
              </div>
              {sorted.length > npVisible && (
                <div className="flex flex-col items-center gap-1 pt-2">
                  <button
                    onClick={() => setNpVisible((n) => n + NOTE_PERFUMES_STEP)}
                    className="text-xs rounded-none font-body transition-colors"
                  >
                    {isAr ? "تصفح أكثر" : "Browse more"}
                  </button>
                  <span className="text-[10px] text-muted-foreground font-body">
                    {Math.min(npVisible, sorted.length)} - {sorted.length}
                  </span>
                </div>
              )}
            </div>
          );
        })()}

        {/* Footer: copy + notebook + prev/next note */}
        <DetailFooter
          items={sortedNotes}
          currentId={note.id}
          pathFor={(n) => `/note?id=${n.id}`}
          labelFor={(n) => n.name || n.name_ar || ""}
          copyTextEn={note.description || ""}
          copyTextAr={note.description_ar || ""}
          copyText={`${note.name || ""}${note.name_ar ? " — " + note.name_ar : ""}\n\n${note.description || ""}${note.description_ar ? "\n\n" + note.description_ar : ""}`}
          extraActions={
            <>
              <button type="button" onClick={() => setExportOpen(true)} aria-label="تصدير Export"
                className="flex items-center justify-center w-9 h-9 rounded-none text-[#B76E79] hover:text-[var(--brand)] transition-colors">
                <Download className="w-4 h-4" />
              </button>
              {!note._synthetic && (
                <button type="button" onClick={() => { setForm({ ...note }); setEditOpen(true); }} aria-label="تعديل Edit"
                  className="flex items-center justify-center w-9 h-9 rounded-none text-[#B76E79] hover:text-[var(--brand)] transition-colors">
                  <Edit2 className="w-4 h-4" />
                </button>
              )}
            </>
          }
          bookmark={{
            item_type: "note",
            item_id: note.id,
            title_en: note.name || "",
            title_ar: note.name_ar || "",
            subtitle: note.note_family || note.family || "",
            path: `/note?id=${note.id}`,
          }}
        />
      </div>

      {/* Export Dialog */}
      {exportOpen && (
        <Dialog open onOpenChange={setExportOpen}>
          <DialogContent className="max-w-xs rounded-none">
            <DialogHeader>
              <DialogTitle className="font-heading text-base">تصدير النوتة</DialogTitle>
            </DialogHeader>
            <div className="space-y-2 pt-1">
              <button onClick={() => { handleExportTxt(); setExportOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-none border border-border bg-secondary/30 hover:bg-secondary transition-colors text-sm font-body">
                <FileText className="w-4 h-4 text-muted-foreground" />
                <span>TXT يدعم العربية</span>
              </button>
              <button onClick={() => { handleExportImage(); setExportOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-none border border-border bg-secondary/30 hover:bg-secondary transition-colors text-sm font-body">
                <Download className="w-4 h-4 text-muted-foreground" />
                <span>صورة النوتة Image</span>
              </button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Dialog */}
      {editOpen && form && (
        <Dialog open onOpenChange={setEditOpen}>
          <DialogContent className="max-w-sm rounded-none max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-heading">تعديل النوتة</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-body">Note Name (English)</Label>
                <Input value={form.name_en || ""} onChange={(e) => setForm({ ...form, name_en: e.target.value })}
                  className="rounded-none font-body" placeholder="e.g. Rose" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">اسم النوتة (عربي)</Label>
                <Input value={form.name_ar || ""} onChange={(e) => setForm({ ...form, name_ar: e.target.value })}
                  className="rounded-none font-body" placeholder="مثال: ورد" dir="rtl" />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-body">📚 Catalog Level</Label>
                <div className="grid grid-cols-3 gap-1">
                  {[
                    { val: "main_note", label: "Main", color: "bg-emerald-500 text-white" },
                    { val: "sub_notes", label: "Sub", color: "bg-sky-500 text-white" },
                    { val: "low_notes", label: "Low", color: "bg-amber-500 text-white" },
                  ].map(({ val, label, color }) => (
                    <button key={val} type="button" onClick={() => setForm({ ...form, note_category: val })}
                      className={`py-2 rounded-none text-xs font-body font-medium transition-all ${form.note_category === val ? color : "bg-secondary text-muted-foreground"}`}>
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-body">التصنيف Category</Label>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORIES.map((cat) => {
                    const selected = (form.category || "").split(",").map(s => s.trim()).includes(cat);
                    return (
                      <button key={cat} type="button"
                        onClick={() => {
                          const arr = (form.category || "").split(",").map(s => s.trim()).filter(Boolean);
                          const next = selected ? arr.filter(a => a !== cat) : [...arr, cat];
                          setForm({ ...form, category: next.join(", ") });
                        }}
                        className={` rounded-none text-xs font-body font-medium transition-all ${selected ? " text-primary-foreground " : " text-muted-foreground "}`}>
                        {cat}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-body">العائلة العطرية Odor Family</Label>
                <div className="flex flex-wrap gap-1.5">
                  {ODOR_FAMILIES.map((fam) => {
                    const selected = (form.odor_family || "").split(",").map(s => s.trim()).includes(fam);
                    return (
                      <button key={fam} type="button"
                        onClick={() => {
                          const arr = (form.odor_family || "").split(",").map(s => s.trim()).filter(Boolean);
                          const next = selected ? arr.filter(a => a !== fam) : [...arr, fam];
                          setForm({ ...form, odor_family: next.join(", ") });
                        }}
                        className={` rounded-none text-xs font-body font-medium transition-all ${selected ? " text-primary-foreground " : " text-muted-foreground "}`}>
                        {fam}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-body">الهرم العطري Pyramid</Label>
                <div className="grid grid-cols-5 gap-1">
                  {["top", "heart", "base", "conductor", "all"].map((p) => {
                    const selected = (form.pyramid || "").split(",").map(s => s.trim()).includes(p);
                    return (
                      <button key={p} type="button"
                        onClick={() => {
                          const arr = (form.pyramid || "").split(",").map(s => s.trim()).filter(Boolean);
                          const next = selected ? arr.filter(a => a !== p) : [...arr, p];
                          setForm({ ...form, pyramid: next.join(", ") });
                        }}
                        className={`py-2 rounded-none text-[10px] font-body font-medium transition-all border ${selected ? PYRAMID_COLORS[p] + " border-current" : "bg-secondary text-muted-foreground border-border"}`}>
                        {PYRAMID_LABELS[p]}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-body">{isAr ? "المنشأ" : "Origin"}</Label>
                <Input value={form.origin || ""} onChange={(e) => setForm({ ...form, origin: e.target.value })}
                  className="rounded-none font-body" placeholder="e.g. Bulgaria, India.." />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-body">صورة Photo</Label>
                {form.image_url ? (
                  <div className="relative w-full h-24 rounded-none border border-border bg-secondary/50 overflow-hidden">
                    <img src={form.image_url} alt="Note" className="w-full h-full object-cover" />
                    <button type="button" onClick={() => setForm({ ...form, image_url: "" })} className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-none flex items-center justify-center hover:bg-red-600">
                      <X className="w-3.5 h-3.5 text-white" />
                    </button>
                  </div>
                ) : (
                  <label className="flex items-center justify-center gap-2 w-full h-20 rounded-none border-2 border-dashed border-border bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                    <Upload className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs font-body text-muted-foreground">رفع صورة</span>
                    <input type="file" onChange={handleUploadImage} disabled={uploading} accept="image/*" className="hidden" />
                  </label>
                )}
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs font-body">الوصف Description</Label>
                <Textarea value={form.description || ""} onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="rounded-none font-body min-h-[60px]" placeholder="كيف تبدو رائحته؟" />
              </div>

              <Button className="w-full rounded-none font-body" onClick={() => updateMutation.mutate({ ...form, name: [form.name_en, form.name_ar].filter(Boolean).join(" ") })} disabled={updateMutation.isPending || uploading}>
                {updateMutation.isPending ? "جاري الحفظ.." : "حفظ التغييرات"}
              </Button>
              <button onClick={async () => { try { await apphost.entities.PerfumeNote.update(id, { hidden: true }); queryClient.invalidateQueries({ queryKey: ["notes"] }); toast.success("نُقل إلى المهملات Moved to Cast Away"); navigate("/notes"); } catch (e) { toast.error("تعذّر النقل"); } }} className="w-full text-xs font-body text-center py-2 hover:underline" style={{ color: "#d97706" }}>
                نقل إلى المهملات Cast away
              </button>
              <button onClick={() => { if (confirm("هل أنت متأكد من حذف هذه النوتة نهائياً؟ Delete this note permanently?")) deleteMutation.mutate(); }} className="w-full text-xs text-destructive font-body text-center py-2 hover:underline">
                حذف هذه النوتة نهائياً Delete permanently
              </button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
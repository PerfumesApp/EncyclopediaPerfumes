import { useState, useMemo, useDeferredValue } from "react";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { strictHealth } from "@/lib/headacheRisk";
import BackIcon from "@/components/shared/BackIcon";

const STEP = 60;

// تدرّج: الأصحّ ذهبيّ فاتح، الأكثف بنّيّ غامق. t من 0 (أصحّ) إلى 1 (أكثف).
function densityColor(t) {
  const c = Math.max(0, Math.min(1, t));
  const lerp = (a, b) => Math.round(a + (b - a) * c);
  return `rgb(${lerp(0xC8, 0x4A)}, ${lerp(0xA0, 0x2C)}, ${lerp(0x2E, 0x12)})`;
}

// لون كل قسم: الأصحّ ذهبيّ، الأقل صحّة غامق، المتشدّد أخضر.
function modeColor(m) {
  if (m === "worst") return "#4A2C12";
  if (m === "strict") return "#3B6D11";
  return "var(--brand)";
}

export default function HealthyIndex() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [started, setStarted] = useState(false); // صفحة خاملة — لا تحميل و لا نتائج حتى الضغط
  const [mode, setMode] = useState("best");
  const [shown, setShown] = useState(STEP);

  // كسول: لا يُحمّل حتى يُضغط زرّ (started). إن كانت العطور محمّلة مسبقاً (كاش مشترك) تُستعمل.
  const { data: perfumes = [], isLoading } = useAllPerfumes("name", { enabled: started });

  const deferredMode = useDeferredValue(mode);
  const ranked = useMemo(() => {
    if (!perfumes.length) return { rows: [], maxScore: 1, score: new Map() };
    // شرط: نوتات كاملة (افتتاحية + قلب + أساس) — وإلّا يُستبعد العطر تماماً.
    const has = (x) => String(x || "").trim().length > 0;
    const complete = (p) => has(p.top_notes) && has(p.heart_notes) && has(p.base_notes);
    const pool = perfumes.filter(complete);
    const score = new Map();
    let maxScore = 1;
    const sc = (p) => {
      let v = score.get(p.id);
      if (v == null) { v = strictHealth(p).count; score.set(p.id, v); if (v > maxScore) maxScore = v; }
      return v;
    };
    pool.forEach(sc);
    const base = deferredMode === "strict" ? pool.filter((p) => score.get(p.id) === 0) : pool;
    const dir = deferredMode === "worst" ? -1 : 1;
    const rows = [...base].sort((a, b) => {
      const d = (score.get(a.id) - score.get(b.id)) * dir;
      if (d !== 0) return d;
      return String(a.name_en || a.name || "").localeCompare(String(b.name_en || b.name || ""), "en", { sensitivity: "base" });
    });
    return { rows, maxScore, score };
  }, [perfumes, deferredMode]);

  const visible = ranked.rows.slice(0, shown);
  const pick = (m) => { setMode(m); setStarted(true); setShown(STEP); };

  return (
    <div className="px-5 page-top pb-24 space-y-4">
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => navigate(-1)}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity flex-shrink-0"
          aria-label={isAr ? "رجوع" : "Back"}>
          <BackIcon className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        <h1 className="font-heading text-xl font-bold" style={{ color: "var(--brand)" }}>
          {isAr ? "فهرس صحي" : "Healthy Index"}
        </h1>
      </div>

      {/* الأقسام بألوانها */}
      <div className="flex items-center gap-5" dir={isAr ? "rtl" : "ltr"}>
        <button type="button" onClick={() => pick("best")}
          className="text-xs font-body hover:opacity-70 transition-opacity"
          style={{ color: modeColor("best"), fontWeight: mode === "best" ? 700 : 400, opacity: mode === "best" ? 1 : 0.55 }}>
          {isAr ? "الأصحّ" : "Healthiest"}
        </button>
        <button type="button" onClick={() => pick("worst")}
          className="text-xs font-body hover:opacity-70 transition-opacity"
          style={{ color: modeColor("worst"), fontWeight: mode === "worst" ? 700 : 400, opacity: mode === "worst" ? 1 : 0.55 }}>
          {isAr ? "الأقل صحّة" : "Least Healthy"}
        </button>
        <button type="button" onClick={() => pick("strict")}
          className="text-xs font-body hover:opacity-70 transition-opacity"
          style={{ color: modeColor("strict"), fontWeight: mode === "strict" ? 700 : 400, opacity: mode === "strict" ? 1 : 0.55 }}>
          {isAr ? "متشدّد" : "Strict"}
        </button>
      </div>

      {/* تنويه مختصر */}
      <p className="text-[10px] font-body text-muted-foreground" dir={isAr ? "rtl" : "ltr"}>
        {isAr
          ? "مؤشّر صحّي تقريبيّ غير دقيق — للوعي فقط"
          : "Approximate Health Index, Not Precise — For Awareness Only"}
      </p>

      {!started ? (
        <p className="text-xs font-body text-muted-foreground py-10 text-center" dir={isAr ? "rtl" : "ltr"}>
          {isAr ? "اختر قسماً لعرض المؤشّر" : "Pick a section to load the index"}
        </p>
      ) : isLoading ? (
        <div className="flex justify-center py-20">
          <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "color-mix(in srgb, var(--brand) 30%, transparent)", borderTopColor: "var(--brand)" }} />
        </div>
      ) : ranked.rows.length === 0 ? (
        <p className="text-xs font-body text-muted-foreground py-10 text-center" dir={isAr ? "rtl" : "ltr"}>
          {isAr ? "لا عطور مطابِقة" : "No matching perfumes"}
        </p>
      ) : (
        <>
          <div className="space-y-0.5">
            {visible.map((p) => {
              const s = ranked.score?.get(p.id) ?? 0;
              const t = ranked.maxScore ? s / ranked.maxScore : 0;
              const en = p.name_en || p.name || "";
              const ar = p.name_ar && p.name_ar.trim();
              return (
                <button key={p.id} type="button" onClick={() => navigate(`/perfume?id=${p.id}`)}
                  className="w-full flex items-center gap-3 py-1.5 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                  <span className="w-2.5 h-2.5 rounded-none flex-shrink-0" style={{ background: densityColor(t) }} aria-hidden="true" />
                  <span className="flex-1 min-w-0 font-body text-xs truncate" style={{ color: densityColor(t) }}>
                    {isAr ? (
                      <>
                        {ar && <span className="font-semibold">{p.name_ar}</span>}
                        {ar && en ? <span className="opacity-50"> .. </span> : null}
                        {en && <span style={{ letterSpacing: "0.02em" }}>{en}</span>}
                      </>
                    ) : (
                      en && <span style={{ letterSpacing: "0.02em" }}>{en}</span>
                    )}
                    {p.brand_name && <span className="text-muted-foreground"> — {p.brand_name}</span>}
                  </span>
                </button>
              );
            })}
          </div>

          {ranked.rows.length > shown && (
            <button type="button" onClick={() => setShown((n) => n + STEP)}
              className="text-xs font-body font-semibold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
              {isAr ? "المزيد" : "More"}
            </button>
          )}
        </>
      )}
    </div>
  );
}

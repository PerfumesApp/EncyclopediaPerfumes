import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import BackIcon from "@/components/shared/BackIcon";

const GOLD = "var(--brand)";

// صفحة نتائج بحثٍ موحّدة لكامل المعجم: تجمع المطابقات من القصص والمفردات والرمزية
// وتقسّمها حسب القسم. يفتحها حقل البحث في الصفحات الرئيسة عند الضغط على بحث.
export default function GlossarySearch() {
  const { isAr } = useLang();
  const q = (new URLSearchParams(window.location.search).get("q") || "").trim();
  const ql = q.toLowerCase();

  const { data: terms = [] } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });
  const { data: symRows = [] } = useQuery({
    queryKey: ["perfumes-symbolism"],
    queryFn: () => apphost.entities.PerfumeSymbolism.list("-created_date", 1000000),
    staleTime: Infinity,
  });

  const match = (v) => {
    const s = String(v || "");
    return ql ? (s.toLowerCase().includes(ql) || s.includes(q)) : false;
  };

  const { stories, vocab, symbolism } = useMemo(() => {
    const stories = [], vocab = [];
    for (const t of terms) {
      if (t.hidden) continue;
      const hit = match(t.term_en) || match(t.term_ar) || match(t.meaning) || match(t.meaning_ar) || match(t.tags);
      if (!hit) continue;
      if ((t.entry_type || "term") === "story") stories.push(t); else vocab.push(t);
    }
    const symbolism = symRows.filter((r) => !r.hidden && (
      match(r.headword_en) || match(r.headword_ar) || match(r.name_en) || match(r.name_ar) ||
      match(r.meaning_en) || match(r.meaning_ar) || match(r.literal_meaning_en) || match(r.synonyms)
    ));
    return { stories, vocab, symbolism };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [terms, symRows, ql, q]);

  const total = stories.length + vocab.length + symbolism.length;

  const TermRow = (t) => (
    <Link key={t.id} to={`/glossary-term?id=${t.id}`} className="block py-2.5 hover:opacity-70 transition-opacity">
      <span className="font-body text-sm font-semibold text-foreground">{t.term_en || t.term_ar}</span>
      {t.term_ar && t.term_en ? <span dir="rtl" style={{ fontFamily: "Amiri, serif" }} className="ms-2 text-[#9D174D]">{t.term_ar}</span> : null}
    </Link>
  );

  const Section = ({ title, ar, items, render }) => items.length === 0 ? null : (
    <div className="space-y-1">
      <h2 className="text-[11px] font-body font-semibold uppercase tracking-[0.18em]" style={{ color: GOLD }}>
        {isAr ? ar : title} <span className="opacity-60">({items.length})</span>
      </h2>
      <div className="divide-y divide-border/40">{items.map(render)}</div>
    </div>
  );

  return (
    <div className="px-5 page-top pb-12 space-y-6 max-w-2xl mx-auto" dir={isAr ? "rtl" : "ltr"}>
      <div className="flex items-center gap-3">
        <Link to="/glossary" aria-label="back"><BackIcon className="w-5 h-5" /></Link>
        <div>
          <h1 className="font-heading text-lg font-bold">{isAr ? "نتائج المعجم" : "Glossary results"}</h1>
          <p className="text-xs text-muted-foreground font-body">
            «{q}» — {total} {isAr ? "نتيجة" : (total === 1 ? "result" : "results")}
          </p>
        </div>
      </div>

      {total === 0 ? (
        <p className="text-center text-sm text-muted-foreground py-12 font-body">{isAr ? "لا نتائج مطابقة" : "No matching results"}</p>
      ) : (
        <div className="space-y-7">
          <Section title="Stories" ar="القصص" items={stories} render={TermRow} />
          <Section title="Vocabulary" ar="المفردات" items={vocab} render={TermRow} />
          <Section title="Marking Meaning" ar="معنى علامة" items={symbolism} render={(e) => (
            <Link key={e.story_idx ?? e.id} to={`/glossary?tab=symbolism&sym=${e.story_idx}`} className="block py-2.5 hover:opacity-70 transition-opacity">
              <span className="font-body text-sm font-semibold" style={{ color: "#9a7b1f" }}>{e.headword_en || e.name_en}</span>
              {(e.headword_ar || e.name_ar) ? <span dir="rtl" style={{ fontFamily: "Amiri, serif" }} className="ms-2 text-[#9D174D]">{e.headword_ar || e.name_ar}</span> : null}
            </Link>
          )} />
        </div>
      )}
    </div>
  );
}

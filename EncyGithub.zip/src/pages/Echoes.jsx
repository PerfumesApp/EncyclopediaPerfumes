import { useState } from "react";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";

// «ملامح الرحلة» — صفحة توضيحيّة بسيطة: تستعرض أرقام قاعدة البيانات (المزروع + تخصيص
// المستخدم) عند الضغط فقط (كسولة عمداً كي لا تُبطئ التطبيق). بلا إطارات ولا جداول ولا تصدير.

const num = (n) => String(Number(n) || 0);

export default function Echoes() {
  const { lang } = useLang();
  const isAr = lang === "ar";
  const [state, setState] = useState("idle"); // idle | loading | done
  const [groups, setGroups] = useState([]);

  const browse = async () => {
    setState("loading");
    const count = async (ent) => {
      try { const r = await apphost.entities[ent].list(); return Array.isArray(r) ? r.length : 0; }
      catch { return 0; }
    };
    const listSafe = async (ent) => {
      try { const r = await apphost.entities[ent].list(); return Array.isArray(r) ? r : []; }
      catch { return []; }
    };

    const [perfumes, brands, notes, perfumers, terms] = await Promise.all(
      ["Perfume", "PerfumeBrand", "PerfumeNote", "Perfumer", "GlossaryTerm"].map(count)
    );
    const [encEntries, quotes, wisdom, encSections] = await Promise.all(
      ["EncEntry", "Quote", "Wisdom", "EncSection"].map(count)
    );
    const [uPerfumes, uBrands, uNotes, uPerfumers, uTerms] = await Promise.all(
      ["UserPerfume", "UserBrand", "UserNote", "UserPerfumer", "UserGlossaryTerm"].map(listSafe)
    );
    const [purchases, wears, wishes, lists] = await Promise.all(
      ["PurchaseRecord", "WearLog", "Wishlist", "CustomList"].map(listSafe)
    );

    const by = (arr, k) => arr.filter((x) => x.list === k).length;
    const sum = (arr, k) => arr.reduce((t, p) => t + (Number(p[k]) || 0), 0);
    const samples = purchases.filter((p) => p.type === "sample");
    const bottles = purchases.filter((p) => p.type === "bottle");

    const L = (ar, en, value) => ({ ar, en, value });
    const next = [
      {
        ar: "الكتالوج", en: "The Catalogue", color: "#C8A02E",
        lines: [
          L("عطور", "Perfumes", num(perfumes)),
          L("ماركات", "Brands", num(brands)),
          L("نوتات", "Notes", num(notes)),
          L("عطّارون", "Perfumers", num(perfumers)),
          L("مصطلحات", "Glossary Terms", num(terms)),
        ],
      },
      {
        ar: "الموسوعة", en: "The Encyclopedia", color: "#059669",
        lines: [
          L("مدخلات", "Entries", num(encEntries)),
          L("اقتباسات", "Quotes", num(quotes)),
          L("حِكَم", "Wisdom", num(wisdom)),
          L("أقسام", "Sections", num(encSections)),
        ],
      },
      {
        ar: "تفاعلك", en: "Your Reactions", color: "#EC4899",
        lines: [
          L("عطور تفاعلت معها", "Perfumes Reacted To", num(uPerfumes.length)),
          L("مفضّلة", "Favourites", num(by(uPerfumes, "favorite"))),
          L("موصى بها", "Recommended", num(by(uPerfumes, "recommend"))),
          L("لم تعجبك", "Disliked", num(by(uPerfumes, "dislike"))),
          L("ماركات — نوتات — عطّارون", "Brands — Notes — Perfumers", num(uBrands.length) + " — " + num(uNotes.length) + " — " + num(uPerfumers.length)),
          L("من الموسوعة", "From The Encyclopedia", num(uTerms.length)),
        ],
      },
      {
        ar: "رحلتك", en: "Your Journey", color: "#B76E79",
        lines: [
          L("مشتريات", "Purchases", num(purchases.length)),
          L("عيّنات", "Samples", num(samples.length) + " — " + num(sum(samples, "ml")) + "ml"),
          L("قنينات", "Bottles", num(bottles.length) + " — " + num(sum(bottles, "ml")) + "ml"),
          L("سجلّ الاستعمال", "Wear Log", num(wears.length)),
          L("قائمة الرغبات", "Wishlist", num(wishes.length)),
          L("قوائم مخصّصة", "Custom Lists", num(lists.length)),
        ],
      },
    ];
    setGroups(next);
    setState("done");
  };

  return (
    <div className="page-top px-4 pb-24" style={{ minHeight: "100vh" }}>
      <div className="flex items-center mb-2">
        <h1 className="font-heading" style={{ fontSize: 19, color: "var(--brand)", letterSpacing: 1 }}>
          {isAr ? "ملامح الرحلة" : "Echoes Of The Journey"}
        </h1>
      </div>
      <p className="font-body" style={{ fontSize: 13, color: "#A98B97", marginBottom: 22, lineHeight: 1.7 }}>
        {isAr
          ? "لمحة عن مكتبتك ورحلتك — من قاعدة البيانات وتخصيصك"
          : "A glance at your library and journey — from the database and your customization"}
      </p>

      {state !== "done" && (
        <button type="button" onClick={browse} disabled={state === "loading"}
          className="font-heading" style={{ fontSize: 15, color: "var(--brand)", background: "transparent", padding: "10px 0", opacity: state === "loading" ? 0.5 : 1 }}>
          {state === "loading"
            ? (isAr ? "يجمع الملامح" : "Gathering Echoes")
            : (isAr ? "استعرض ملامح الرحلة" : "Browse Echoes Of The Journey")}
        </button>
      )}

      {state === "done" && (
        <div className="flex flex-col" style={{ gap: 26, marginTop: 4 }}>
          {groups.map((g, gi) => (
            <div key={gi}>
              <div className="flex items-center gap-2" style={{ marginBottom: 8 }}>
                <span style={{ width: 22, height: 3, background: g.color, display: "inline-block" }} />
                <span className="font-heading" style={{ fontSize: 15, color: g.color, fontWeight: 700 }}>{isAr ? g.ar : g.en}</span>
              </div>
              <div className="flex flex-col" style={{ gap: 5 }}>
                {g.lines.map((ln, li) => (
                  <div key={li} className="flex items-baseline justify-between" style={{ gap: 16 }}>
                    <span className="font-body" style={{ fontSize: 13, color: "#A98B97" }}>{isAr ? ln.ar : ln.en}</span>
                    <span className="font-heading" style={{ fontSize: 15, color: "var(--foreground, #2A2024)" }} dir="ltr">{ln.value}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

import { useState, useEffect } from "react";
import { compareGlossary } from "@/lib/sortName";
import BackButton from "@/components/shared/BackButton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Search, Download, AArrowUp, AArrowDown } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import Pagination from "@/components/shared/Pagination";
import PerfumeTimeline from "@/components/explore/PerfumeTimeline";
import PerfumesSymbolism from "@/components/explore/PerfumesSymbolism";
import { useLang } from "@/lib/LanguageContext";
import { getSecureStorage, setSecureStorage } from "@/lib/storageEncryption";

/**
 * Glossary & Tales (معجم و حكايا)
 *
 * Two-tab layout:
 *   - Vocabulary (term): Quick perfumery vocabulary — "The Language of"
 *   - Stories (story): Bedtime stories of perfume houses — literary, narrative
 *
 * Entries are distinguished by `entry_type`: "term" | "story"
 */
export default function Glossary() {
  const qc = useQueryClient();
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState(() => {
    // Honor ?tab=story|term. Default landing is the Vocabulary (term) tab,
    // so the "Glossary" link shows vocabulary and the "Story" link (?tab=story)
    // shows stories.
    const t = new URLSearchParams(window.location.search).get("tab");
    if (t === "s" || t === "era") return "era";
    if (t === "symbolism") return "symbolism";
    if (t === "story") return "story";
    return "term";
  }); // "term" | "story" | "era"
  const [sortOrder, setSortOrder] = useState(() => {
    const saved = getSecureStorage("glossarySettings", null);
    return saved ? saved.sortOrder || "newest" : "newest";
  });
  const [uploadingImg, setUploadingImg] = useState(false);
  const goSearch = () => { const q = search.trim(); if (q) navigate(`/glossary-search?q=${encodeURIComponent(q)}`); };

  const { data: terms = [], isLoading } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });


  // Filter by active tab + search
  // Default entry_type for legacy entries: "term"
  const filtered = terms.filter((t) => {
    const matchesSearch = true; // البحث الموحّد يفتح صفحة نتائج مقسّمة بدل الفلترة الحيّة
    // تبويب المهملات: نعرض كل المخفيّات (قصص ومفردات معاً)
    if (activeTab === "trash") return t.hidden && matchesSearch;
    // التبويبات العادية: نستبعد المخفيّات
    if (t.hidden) return false;
    const entryType = t.entry_type || "term";
    if (entryType !== activeTab) return false;
    return matchesSearch;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortOrder === "alpha_asc") return compareGlossary(a, b, 1);
    if (sortOrder === "alpha_desc") return compareGlossary(a, b, -1);
    if (sortOrder === "newest") return new Date(b.created_date) - new Date(a.created_date);
    if (sortOrder === "oldest") return new Date(a.created_date) - new Date(b.created_date);
    return 0;
  });

  // Pagination (50 per page)
  // مختصر بلا نقاط في نهايته — قصّ عند حدّ كلمة
const excerpt = (txt, n = 90) => {
  const s2 = String(txt || "").replace(/\s+/g, " ").trim();
  if (s2.length <= n) return s2;
  const cut = s2.slice(0, n); const i = cut.lastIndexOf(" ");
  return i > 40 ? cut.slice(0, i) : cut;
};

const PAGE_SIZE = 50;
  const [page, setPage] = useState(1);
  const pageCount = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  useEffect(() => { setPage(1); }, [activeTab, search, sortOrder]);
  useEffect(() => { if (page > pageCount) setPage(1); }, [page, pageCount]);
  const pagedTerms = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => {
    const handler = () => {
      const saved = getSecureStorage("glossarySettings", null);
      if (saved) setSortOrder(saved.sortOrder || "newest");
    };
    window.addEventListener("glossarySettingsChanged", handler);
    return () => window.removeEventListener("glossarySettingsChanged", handler);
  }, []);

  const handleImgUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImg(true);
    const { file_url } = await apphost.integrations.Core.UploadFile({ file });
    setForm((f) => ({ ...f, image_url: file_url }));
    setUploadingImg(false);
  };

  const openAddDialog = () => navigate("/glossary-term-edit?type=" + (activeTab === "story" ? "story" : "term"));

  // استعادة مدخل من المهملات
  const restoreMutation = useMutation({
    mutationFn: (id) => apphost.entities.GlossaryTerm.update(id, { hidden: false }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["glossary-terms"] });
      toast.success(isAr ? "تمت الاستعادة" : "Restored");
    },
  });

  return (
    <div className="px-4 page-top pb-20 space-y-4">
      {/* Header row: back arrow + actions on one line (title below) */}
      <div className="flex items-center">
        <div className="flex items-center gap-2">
          <BackButton fallback="/" />
        </div>
        <Link
          to="/at"
          className="flex-1 text-center text-base font-body font-medium rounded-none text-[#9a7b1f] transition-colors"
          title={isAr ? "كلّ المَنشنات" : "All mentions"}
        >
          @
        </Link>
        <div className="flex items-center gap-2">
          {activeTab !== "symbolism" && (
          <button
            type="button"
            onClick={() => {
              const list = sorted.filter((t) => (activeTab === "story" ? t.entry_type === "story" : (t.entry_type || "term") === "term"));
              if (list.length === 0) {
                toast.error(isAr ? "لا عناصر للتصدير" : "Nothing to export");
                return;
              }
              import("@/lib/glossaryExport").then(({ exportTermList }) => {
                exportTermList(list, {
                  title: activeTab === "story" ? "Stories" : "Glossary",
                });
              });
            }}
            className="flex items-center gap-1 text-[10px] font-body font-medium rounded-none text-muted-foreground transition-colors"
            title={isAr ? "تصدير PDF" : "Export PDF"}
          >
            <Download className="w-3 h-3" /> PDF
          </button>
          )}
          {activeTab !== "era" && activeTab !== "symbolism" && (
          <Button
            onClick={openAddDialog}
            size="sm"
            variant="ghost"
            className="rounded-none text-[#9a7b1f] hover:bg-[var(--brand)]/10 hover:text-[var(--brand)] text-xs px-3"
          >
            {isAr ? "إضافة" : "Add"}
          </Button>
          )}
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>


      {/* موجِّهة + مصنفات — فوق التبويبات الرئيسية، بلا فاصل */}
      <div className="flex items-center gap-5">
        <Link to="/reading-guide" className="text-xs font-body font-medium rounded-none transition-colors" style={{ color: "#14532D" }} title={isAr ? "موجِّهة قراءة" : "Reading Guide"}>
          {isAr ? "موجِّهة قراءة" : "Reading Guide"}
        </Link>
      </div>

      {/* بحث المعجم الموحّد — Enter أو الأيقونة الذهبيّة ينقل لصفحة نتائج مقسّمة حسب القسم */}
      <div className="relative">
        <button type="button" onClick={goSearch} aria-label="search"
          className="absolute left-3 top-1/2 -translate-y-1/2 bg-transparent border-0 p-0 cursor-pointer">
          <Search className="w-4 h-4" style={{ color: "var(--brand)" }} />
        </button>
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") goSearch(); }}
          placeholder={isAr ? "ابحث Search" : "Search ابحث"}
          className="pl-9 rounded-none h-10 font-body text-sm"
        />
      </div>

      {/* Tabs: Stories Vocabulary (بلا أيقونات) */}
      <div className="flex gap-1 border-b border-border/60">
        <button
          onClick={() => setActiveTab("story")}
          className={`px-1.5 py-2 text-[11px] leading-tight font-body font-medium transition-colors border-b-2 ${
            activeTab === "story"
              ? "border-muted-foreground text-foreground font-semibold"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          {isAr ? "قصص" : "Stories"}
        </button>
        <button
          onClick={() => setActiveTab("term")}
          className={`px-1.5 py-2 text-[11px] leading-tight font-body font-medium transition-colors border-b-2 ${
            activeTab === "term"
              ? "border-muted-foreground text-foreground font-semibold"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          {isAr ? "مفردات" : "Vocabulary"}
        </button>
        <button
          onClick={() => setActiveTab("era")}
          className={`px-1.5 py-2 text-[11px] leading-tight font-body font-medium transition-colors border-b-2 ${
            activeTab === "era"
              ? "border-muted-foreground text-foreground font-semibold"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          {isAr ? "أطوار العطور" : "Perfumes Era"}
        </button>
        <button
          onClick={() => setActiveTab("symbolism")}
          className={`px-1.5 py-2 text-[11px] leading-tight font-body font-medium transition-colors border-b-2 ${
            activeTab === "symbolism"
              ? "border-muted-foreground text-foreground font-semibold"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          {isAr ? "معنى علامة" : "Marking Meaning"}
        </button>
      </div>

      {activeTab === "era" ? (
        <PerfumeTimeline />
      ) : activeTab === "symbolism" ? (
        <PerfumesSymbolism />
      ) : (
       <>
      {/* Tab description — bilingual, fit-to-screen, multi-line for stories */}
      {activeTab === "trash" ? (
        <p className="text-[10px] tracking-[0.18em] text-[#9a7b1f]/80 dark:text-[var(--brand)]/70 font-body uppercase">
          {isAr ? "المخفيّ من القصص و المفردات — اضغط للاستعادة" : "Hidden stories and vocabulary — tap to restore"}
        </p>
      ) : activeTab === "term" ? (
        <p className="text-[10px] tracking-[0.18em] text-[#9a7b1f]/80 dark:text-[var(--brand)]/70 font-body uppercase">
          {isAr ? "لغة ال" : "Language of"}
        </p>
      ) : (
        <div className="text-[#9a7b1f]/80 dark:text-[var(--brand)]/70 font-body leading-relaxed space-y-0.5">
          <p
            className="text-[11px] tracking-tight"
            dir="ltr"
            style={{ unicodeBidi: "isolate" }}
          >
            A stories to read.. listen.. write.. share.. think.. enjoy..
          </p>
          <p
            className="text-[11px] tracking-tight"
            dir="rtl"
            style={{ unicodeBidi: "isolate" }}
          >
            قصص للقراءة.. استماع.. للكتابة.. مشاركة.. تأمل.. للاستمتاع..
          </p>
        </div>
      )}

      {/* Sort controls — moved here from the user menu */}
      <div className="flex items-center gap-1.5 flex-wrap">
        {[
          { value: "alpha_asc", en: "Alphabetical", ar: "أبجدي", Icon: AArrowUp },
          { value: "alpha_desc", en: "Descend", ar: "معكوس", Icon: AArrowDown },
          { value: "newest", en: "Newest", ar: "الأحدث" },
          { value: "oldest", en: "Oldest", ar: "الأقدم" },
        ].map(({ value, en, ar, Icon }) => (
          <button
            key={value}
            onClick={() => {
              setSortOrder(value);
              const cur = getSecureStorage("glossarySettings", {}) || {};
              setSecureStorage("glossarySettings", { ...cur, sortOrder: value });
            }}
            className={
              Icon
                ? // Alphabetical / Descend: transparent, blends with the page; only the active one tints
                  `flex items-center gap-1 px-2 py-1 text-[9.5px] font-body font-medium bg-transparent transition-colors ${
                    sortOrder === value ? "text-[#059669]" : "text-muted-foreground hover:text-foreground"
                  }`
                : `rounded-none px-2 py-1 text-[9.5px] font-body font-medium bg-transparent transition-colors ${
   sortOrder === value ? "text-[#059669]" : "text-muted-foreground hover:text-foreground"
 }`
            }
            title={isAr ? ar : en}
          >
            {Icon ? <Icon className="w-4 h-4" /> : (isAr ? ar : en)}
          </button>
        ))}
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-[var(--brand)]/30 border-t-[var(--brand)] rounded-full animate-spin" />
        </div>
      )}

      {/* Empty */}
      {!isLoading && sorted.length === 0 && (
        <div className="text-center py-16 space-y-3">
          <p className="font-heading text-lg text-muted-foreground">
            {activeTab === "trash"
              ? isAr ? "المهملات فارغة" : "Nothing cast out"
              : activeTab === "term"
              ? isAr
                ? "لا مصطلحات بعد"
                : "No terms yet"
              : isAr
              ? "لا قصص بعد"
              : "No stories yet"}
          </p>
          {activeTab !== "trash" && (
          <Button onClick={openAddDialog} className="rounded-none bg-[var(--brand)] hover:bg-[#b08f29] text-white">
            {activeTab === "term"
              ? isAr
                ? "إضافة مصطلح"
                : "Add Term"
              : isAr
              ? "إضافة قصة"
              : "Add Story"}
          </Button>
          )}
        </div>
      )}

      {/* List — clean ruled layout: no card, no background, no box border.
          Only the distinctive title color + a thin separator line between
          entries (gold for stories, green for terms — matching the text). */}
      <div>
        {pagedTerms.map((term) => {
          const isTrash = activeTab === "trash";
          const isStory = isTrash ? term.entry_type === "story" : activeTab === "story";
          const accent = isTrash ? "#b45309" : isStory ? "#a16207" : "#a16207"; // amber | gold | gold(term)
          return (
            <div key={term.id} className="relative group flex items-center">
              <Link
                to={`/glossary-term?id=${term.id}`}
                className="flex-1 px-1 py-3 flex flex-col gap-0.5 transition-opacity hover:opacity-70"
                style={{ borderBottom: "1px solid #e5e0d5" }}
              >
                <span
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontWeight: 600,
                                        color: accent,
                    fontSize: "0.95rem",
                  }}
                >
                  {term.term_en}
                </span>
                {term.term_ar && (
                  <span
                    className="font-heading text-[13px]"
                    style={{ color: accent }}
                    dir="rtl"
                  >
                    {term.term_ar}
                  </span>
                )}
                {!isTrash && !isStory && (() => {
                  const ex = excerpt(isAr ? (term.meaning_ar || term.meaning) : (term.meaning || term.meaning_ar));
                  return ex ? <span className="text-[11px] text-muted-foreground font-body" dir="auto">{ex}</span> : null;
                })()}
                {isTrash && (
                  <span className="text-[9px] text-muted-foreground/60 font-body ml-auto">
                    {term.entry_type === "story" ? (isAr ? "قصة" : "story") : (isAr ? "مفردة" : "term")}
                  </span>
                )}
              </Link>
              {isTrash && (
                <button
                  onClick={() => restoreMutation.mutate(term.id)}
                  title={isAr ? "استعادة" : "Restore"}
                  className="absolute right-1 text-[10px] font-body text-[#9a7b1f] hover:text-[var(--brand)] px-1.5 py-1"
                >
                  {isAr ? "استعادة" : "Restore"}
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Page switcher (50 per page) */}
      <Pagination
        page={page}
        pageCount={pageCount}
        onChange={setPage}
        totalItems={sorted.length}
        pageSize={PAGE_SIZE}
      />
       </>
      )}

      {/* روابط الحكم والاقتباسات — أسفل الصفحة */}
      <div className="flex justify-center items-center gap-6 pt-8 pb-2 font-body font-medium text-[12px]">
        <Link to="/incomplete-wisdom" className="hover:opacity-70 transition-opacity" style={{ color: "#a16207" }}>{isAr ? "حِكَم" : "Wisdom"}</Link>
        <Link to="/quotes" className="hover:opacity-70 transition-opacity" style={{ color: "#4338ca" }}>{isAr ? "اقتباسات" : "Quotes"}</Link>
      </div>

      {/* Add dialog */}
      
    </div>
  );
}

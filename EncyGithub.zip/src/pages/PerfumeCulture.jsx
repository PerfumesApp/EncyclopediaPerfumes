import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Copy, Check, Edit2, Save, X, RotateCcw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import BackIcon from "@/components/shared/BackIcon";

/**
 * Culture, Rules & Courtesy
 *
 * Bilingual page — both English and Arabic shown together in every section,
 * regardless of the app's UI language. Title and headings appear in both.
 *
 * Sections (in order):
 *   1. Comments (تعليقات)
 *      - User-editable; persisted to localStorage
 *      - Bilingual; bullets use the diamond shape from the Activity timeline
 *   2. Perfume Culture (ثقافة العطور)
 *   3. How to Wear Perfume (كيفية ارتداء العطر)
 *   4. When to Wear Different Fragrances (متى ترتدي عطوراً مختلفة)
 *   5. Where NOT to Wear Strong Perfume (حيث لا تضع عطراً قوياً)
 *
 * The original Arabic comments are preserved verbatim;
 * the English is a translation companion. Users can edit either side locally.
 */

// ── Diamond bullet (matches ActivityTimeline.jsx) ─────────────────────────
function Diamond({ color = "#10b981", solid = true }) {
  return (
    <span
      aria-hidden
      style={{
        display: "inline-block",
        width: 8,
        height: 8,
        background: solid ? color : "transparent",
        border: `1.5px solid ${color}`,
        transform: "rotate(45deg)",
        flexShrink: 0,
        marginTop: 8,
        marginInlineEnd: 10,
        verticalAlign: "top",
      }}
    />
  );
}

// ── Default content ──────────────────────────────────────────────────────
const COMMENTS_DEFAULT_AR = [
  "حاول ان لا تضع عطور في الأماكن التي يرتفع معها احتمالية ان تكون سبب مشاكل صحية او صداع للأخرين و لا يستطيع الاخرين مغادرتها بسهولة مثل المستشفيات. الأندية الرياضية. أماكن العمل. المساجد و دور العبادة",
  "العطر لك مش للأخرين استمتع فيه و مع من تحب",
  "لا تحتاج شراء علبة كاملة. يوجد اكثر من مئة الف عطر.. اعتمد العينات و التقسيمات لضبط ميزانيتك و معرفة بصمتك العطرية.. المناسب لك و المناسب لشريكك هذه نقطة مهمة إذا منت لحالك",
  "ثقافة العطور تراكمية و تعتبر من الأشياء الجيدة توريثها لذريتنا و الأجيال اللاحقة بطريقة افضل من الوضع الحالي و إن كان مقدر لكنه مشتت و هبات",
  "إدمان العطور مثل إدمان الجوال لا يرتبط فيه عيب. إن كنت مدمن عطور راع بيئتك الحاضنة و شاركهم رحلتك بطريقة أفضل مثل كل الأشياء الاعتدال جيد و التوازن مهم. تغيرات بسيطة تخلق أشياء رائعة",
  "لا تكثر رش العطور.. استمتع.. رشة رشة.. رشتين و لاحقا رشتين.. كثرت الرش يسبب طمس لحواسك يشم الاخرين عطرك من بعيد لكنك لا تشمه و بكثير من الأحيان.. بالغالب.. يكون مزعج",
  "غالبية دهن العود غير مناسبة للاستخدام البشري فا وش عاد اليومي و غير جيدة للمناسبات الخاصة. لا تفسد يوم جيد و خاص لك بمزيج سيء.",
  "لا تفسدي.. لا تفسد يوم زواجكم ايضا بخويش روائح.",
  "الادهان الحديثة من دهن العود اقل حدة و تحتاج ابتكار و تطور مثل ما حصل في عالم العطور و لمواد مختلفة و صانعي الادهان سيجدون حلهم بالطبيعة",
  "اسوء شيء حصل لعالم العطور هو مزج دهن العود بالعطر و افسد خطوط انتاج لعطور جيدة من شركات عالمية",
  "اسوء شيء حصل لخشب العود او البخور هو محاولة دمجه عقد بعد عقد سنوات بعد سنوات في عطر و في العطور, ميزته باحتراقه و هو مفضل لدي هكذا.. الهبات الحالية بتخفض مبيعات شركات العطور على المدى البعيد. إصدار مثل هذه النسخ لمحاولة جذب السوق المحلي و ليس ابتكار عطر مميز",
  "العطر شيء و الرائحة شيء اخر",
  "لا اضع العطور لكن رائحتي ستكون جيدا كل يوم.. و كل الوقت",
  "تذكر الروائح الجيدة موجودة في الطبيعة لا تحتاج عطر لذلك, العطور روائح استثنائية.. استثنائية.. رائعة و ليست مزعجة.. و للأسف لا يوجد الكثير منها في الوقت الحالي",
  "رائحة حديثة لحاسة شمك لا يعني أنها جيدة.. الجدّة ليست جودة, و الإثارة الأولى تخدع الحاسة. أعطِ نفسك وقتاً قبل الحكم.",
  "لا تفسد أوقات.. أيام الاخرين بعطور سيئة و تسبب لهم صداع و مشاكل صحية, الشركات لن تقوم برفع معاييرها دون يكون المستهلك اكثر وعي و ذكي-مبتكر في قراراتها الشرائية",
  "يوجد الكثير من البشر لخلق أشياء عظيمة و رائعة و الكثير منهم لإفسادها.. اختر النموذج الذي تريد تقديم نفسك فيه",
  "مثل انجليزي مرر المعرفة.. و ازود عليها القيم و الأشياء الجيد.. خلك مضياف و رحب بمن يرغب بتطوير معرفته بالعطور و عالمها.. معرفتك للنوتات و كل ما يخص العطور لا يجعل شخصيتك افضل و كل ما صدقت بمراجعتك كل ما ارتفع اعتماديتك.. كثير من اللي ينشرون في عالم العطور فقط اعتياد النشر.. حقيقة لم اشاهد ضخ بهذه الضخامة في غير مجتمع العطور.. يبغالنا نقسم أيام النشر :p وزعوا على الأسبوع حصصه",
  "منتج محلي لا يعني أي شيء في عالم الاعمال و خصوصا في عالم العطور, ان كنت رائد اعمال توقف عن التحدث و اعمل.. لا تزعجنا و المستهلك يقرر",
  "إذا سمعت أي رائد اعمال يبدأ كلامه: اراهن على .. تجاوز الشاشة و حومة الكبد.. 90% يعاد ابتكاره و غالبيته يفشل.. ما يبتكر 10% تسعين بالمئة يفشل.. و هذا الامر سنويا يحدث من بدأ عصر الشركة ككيان مستقل يعني من عصر آدم سميث",
  "رفع معايير سوق العطور و محاربة التستر و التقليد مسؤولية مجتمع العطور و المستهلكين بنطاقه.. سوق الملابس و التجميل يقدر بأربعة تريليون دولار سنويا و في نمو مستمر. على المستوى الفردي اطمح يكون السوق السعودي الافضل عالميا و المستهلك العالمي يبحث حتى عن منتجات الشركات العالمية لدينا لكن السوق بعيد عن ابسط ادوات الاعمال و الإدارة.. ملينا من كثر الهرج.. قبل تشاهد علامة الجودة تطمن الان كنها اختفت",
  "مبسوط من رواد الاعمال.. تكاتفهم و دعمهم لبعهضم البعض.. جيد التقدم معاً و المنافسة لا تعني إلغاء الاخر موفقين",
  "هذا التطبيق من نتائج قرائتي لكتاب خطوات عظيمة Giant Steps موجود في جرير حتى الان لم اكمله و لبحثي لأشهر عن طريقة أفضل لإدارة مكتبة العطرية -عينات و تقسيم- و ربطها بالميزانية و تقاريري المالية",
  "شاكر و مقدر لمجتمع العطور تجربة رائعة في عالم العطور ما زلت ببدايتها و إن كنت محب للعطور من صغر لكن هذا وقت إكمال هذه الرحلة و رحلات اخرى.. شغفك يتجدد و يجددك",
  "للعمل و بالتوفيق",
];

const COMMENTS_DEFAULT_EN = [
  "Try not to wear fragrance in places where it could plausibly cause health issues or headaches for others — places people can't easily leave: hospitals, gyms, workplaces, mosques, and houses of worship.",
  "Perfume is for you, not for others. Enjoy it with yourself and with those you love.",
  "You don't need to buy a full bottle. There are over a hundred thousand fragrances out there. Rely on samples and decants to manage your budget and discover your scent signature — the one that suits you, and the one that suits your partner. The second point matters, unless you're on your own.",
  "Perfume culture is cumulative. It is one of the good things worth passing down to our children and to the generations that follow, in a better shape than where it stands today — currently it is appreciated, but scattered and gift-driven.",
  "Perfume addiction is like phone addiction — no inherent shame in it. If you are a perfume addict, be considerate of the people around you, and share the journey with them in a better way. As with everything: moderation is good, balance matters. Small adjustments create remarkable things.",
  "Don't over-spray. Enjoy it — one spritz, two, and later two more. Heavy spraying dulls your own senses; others smell you from a distance while you no longer smell yourself — and most of the time, it is unpleasant.",
  "Most oud oils are not suitable for human use — neither for daily wear nor for special occasions. Don't ruin a good day, a day that belongs to you, with a poor blend.",
  "Don't ruin your wedding day either, with bad scents.",
  "Modern oud oils are less harsh and need innovation and evolution — the way the wider fragrance world has evolved — across new materials. The makers of oud oils will find their answers in nature.",
  "The worst thing that happened to the world of perfumery is mixing oud oil with fragrance. It has spoiled good production lines of solid international houses.",
  "The worst thing that happened to oud wood and bukhoor is the decade-after-decade attempt to fold them into perfume and into perfumes. Their charm is in being burned — that's how I prefer it. The current trend lowers fragrance-house sales in the long run. Releases of this kind are attempts at courting the local market, not at creating distinctive perfumes.",
  "Fragrance is one thing. Smell is another.",
  "I don't always wear perfume — but my smell will still be good, every day, all the time.",
  "Remember: good smells exist in nature; you don't need a perfume for that. Perfumes are exceptional smells. Exceptional. Beautiful, not bothersome. And unfortunately, not many of them exist today.",
  "A scent being new to your nose doesn't mean it's good. Novelty is not quality, and that first thrill fools the senses. Give yourself time before you judge.",
  "Don't ruin people's hours and days with bad fragrances that give them headaches and health problems. Companies will not raise their standards unless the consumer becomes more aware, smarter, and more inventive in their buying decisions.",
  "There are plenty of people building great and beautiful things, and plenty more ruining them. Choose which model you want to present yourself as.",
  "There is an English saying: pass knowledge on. And I'd add: along with values and the good things. Be welcoming. Open your door to anyone who wants to develop their knowledge of perfumes and their world. Your knowledge of notes and everything related to perfumes does not make you a better person — and the more honest you are in your reviews, the more your credibility grows. Many who post in the perfume world simply post out of habit. Honestly, I haven't seen output of this volume in any community other than perfumes. We might need to assign days to post on :p — distribute it across the week.",
  '"Local product" doesn\'t mean much in the business world, and especially not in perfumery. If you\'re an entrepreneur, stop talking and do the work. Don\'t bother us — the consumer decides.',
  'If you hear any entrepreneur start their pitch with "I bet on.." — scroll past the screen, and past the gut. Ninety percent is being reinvented and most of it fails. Of what is genuinely invented, ninety percent fails. This has been happening yearly since the company existed as an independent entity — that is, since the era of Adam Smith.',
  "Raising the standards of the perfume market and fighting counterfeiting and imitation is the responsibility of the perfume community and the consumers within its scope. The clothing and beauty market is valued at over four trillion dollars annually and is in continuous growth. On a personal level, I aspire for the Saudi market to be the best globally — for the global consumer to seek out the products of our international houses. But the market is far from the simplest business and management practices. We're tired of the chatter. Before you see a quality mark, double-check — it's as if it has disappeared.",
  "I'm glad to see entrepreneurs supporting each other. Moving forward together is good — and competition does not mean eliminating the other. Best of luck to all of you.",
  "This app is one of the outcomes of reading the book Giant Steps. It's still available at Jarir; I haven't finished it. And of my months-long search for a better way to manage a fragrance library — samples and decants — and to link it to a budget and financial reports.",
  "Grateful and appreciative of the perfume community. A wonderful experience in the world of fragrance — I'm still at its beginning, even though I've loved perfumes since I was young. But this is the time to complete this journey, and other journeys. Your passion renews itself, and renews you.",
  "To the work — and best of luck.",
];

const STORAGE_KEY = "processapp.perfumeCulture.userComments";

function loadUserComments() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function saveUserComments(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore quota errors
  }
}

// ── Page ──────────────────────────────────────────────────────────────────
export default function PerfumeCulture() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  // ── Comments (editable) ──
  const [editing, setEditing] = useState(false);
  const [copied, setCopied] = useState(false);
  const initial = useMemo(() => loadUserComments(), []);
  const [commentsAr, setCommentsAr] = useState(initial?.ar?.join("\n\n") || "");
  const [commentsEn, setCommentsEn] = useState(initial?.en?.join("\n\n") || "");

  // Convert text-block to array (split by blank lines)
  const arItems = useMemo(() => commentsAr.split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean), [commentsAr]);
  const enItems = useMemo(() => commentsEn.split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean), [commentsEn]);

  const handleSave = () => {
    saveUserComments({ ar: arItems, en: enItems });
    setEditing(false);
    toast.success(isAr ? "تم الحفظ" : "Saved");
  };

  const handleReset = () => {
    if (!confirm(isAr ? "مسح ملاحظاتك؟" : "Clear your notes?")) return;
    setCommentsAr("");
    setCommentsEn("");
    localStorage.removeItem(STORAGE_KEY);
    toast.success(isAr ? "تم المسح" : "Cleared");
  };

  const handleCopy = async () => {
    // Plain-text bilingual export — paste-friendly in any app.
    const lines = [];
    lines.push("Your Notes and Ideas — ملاحظاتك و أفكارك");
    lines.push("");
    const max = Math.max(arItems.length, enItems.length);
    for (let i = 0; i < max; i++) {
      if (enItems[i]) lines.push("◆ " + enItems[i]);
      if (arItems[i]) lines.push("◆ " + arItems[i]);
      lines.push("");
    }
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      setCopied(true);
      toast.success(isAr ? "تم النسخ" : "Copied");
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error(isAr ? "فشل النسخ" : "Copy failed");
    }
  };

  // ── Bilingual section helper ──
  // Renders a card with English heading + Arabic heading on top, then EN paragraph + AR paragraph
  const Section = ({ headingEn, headingAr, paraEn, paraAr }) => {
    const toParas = (p) => (Array.isArray(p) ? p : [p]);
    return (
      <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
        <div className="space-y-1">
          <h2 className="font-heading font-semibold text-lg" dir="ltr">{headingEn}</h2>
          <h2 className="font-heading font-semibold text-lg text-foreground/90" dir="rtl">{headingAr}</h2>
        </div>
        <div className="space-y-3">
          {toParas(paraEn).map((p, i) => (
            <p key={`en${i}`} className="text-sm font-body text-foreground/80 leading-relaxed" dir="ltr">{p}</p>
          ))}
          {toParas(paraAr).map((p, i) => (
            <p key={`ar${i}`} className="text-sm font-body text-foreground/80 leading-relaxed" dir="rtl">{p}</p>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="relative bg-gradient-to-br from-blue-50 dark:from-blue-950/20 to-blue-100 dark:to-blue-900/20 px-5 page-top pb-8">
        <Button variant="secondary" size="icon" className="rounded-none shadow-md mb-4" onClick={() => navigate("/perfumes")}>
          <BackIcon className="w-5 h-5" />
        </Button>
        <div className="flex items-start gap-4">
          {/* Perfume-bottle icon — kept as-is */}
          <div className="w-20 h-20 rounded-none bg-card shadow-lg flex items-center justify-center flex-shrink-0">
            <span style={{ fontSize: 38, lineHeight: 1 }}>🧴</span>
          </div>
          <div className="flex-1 min-w-0">
            {/* Bilingual title — both languages always shown */}
            <h1 className="font-heading text-2xl font-bold leading-tight" dir="ltr">
              Culture, Rules &amp; Courtesy
            </h1>
            <h1 className="font-heading text-xl font-bold leading-tight text-foreground/80 mt-0.5" dir="rtl">
              الثقافة، القواعد و اللباقة
            </h1>
            <p className="text-xs text-muted-foreground font-body mt-2" dir="ltr">
              Understanding perfume etiquette and cultural significance &nbsp;&nbsp; فهم آداب العطور و دلالاتها الثقافية
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 space-y-5 mt-5">
        {/* ─── 1. Comments تعليقات ─── */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-4">
          {/* Heading row + actions */}
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div className="space-y-0.5">
              <h2 className="font-heading font-semibold text-lg" dir="ltr">{isAr ? "نوتاتك و أفكارك" : "Your Notes and Ideas"}</h2>
              <h2 className="font-heading font-semibold text-lg text-foreground/90" dir="rtl">ملاحظاتك و أفكارك</h2>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1.5 rounded-none text-foreground/80 text-xs font-body transition-colors"
                title={isAr ? "نسخ" : "Copy"}
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isAr ? "نسخ" : "Copy"}</span>
              </button>
              {!editing && (
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="flex items-center gap-1.5 rounded-none text-foreground/80 text-xs font-body transition-colors"
                  title={isAr ? "تعديل" : "Edit"}
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>{isAr ? "تعديل" : "Edit"}</span>
                </button>
              )}
              {editing && (
                <>
                  <button
                    type="button"
                    onClick={handleSave}
                    className="flex items-center gap-1.5 rounded-none text-primary-foreground text-xs font-body transition-colors"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isAr ? "حفظ" : "Save"}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditing(false)}
                    className="flex items-center gap-1.5 rounded-none text-foreground/80 text-xs font-body transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>{isAr ? "إلغاء" : "Cancel"}</span>
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-1.5 rounded-none text-muted-foreground text-xs font-body transition-colors"
                title={isAr ? "استعادة" : "Reset"}
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {editing ? (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">English (separate items with a blank line)</label>
                <textarea name="PerfumeCulture-tex1"
                  value={commentsEn}
                  onChange={(e) => setCommentsEn(e.target.value)}
                  placeholder={isAr ? "أضف نوتاتك" : "Add Your Notes"}
                  className="w-full rounded-none border border-border bg-background p-3 font-body text-xs leading-relaxed resize-y min-h-[200px]"
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">العربية (افصل بين البنود بسطر فارغ)</label>
                <textarea name="PerfumeCulture-tex2"
                  value={commentsAr}
                  onChange={(e) => setCommentsAr(e.target.value)}
                  placeholder="اضف ملاحظاتك"
                  className="w-full rounded-none border border-border bg-background p-3 font-body text-sm leading-relaxed resize-y min-h-[200px]"
                  dir="rtl"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              {(enItems.length === 0 && arItems.length === 0) ? (
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="w-full text-center py-8 text-sm font-body text-muted-foreground hover:text-foreground transition-colors"
                >
                  {isAr ? 'اضف ملاحظاتك' : 'Add Your Notes'}
                </button>
              ) : (
              /* Render up to max(en, ar) length, pairing each item EN/AR with a diamond bullet */
              <ul className="space-y-4 list-none p-0 m-0">
                {Array.from({ length: Math.max(enItems.length, arItems.length) }).map((_, i) => (
                  <li key={i} className="space-y-1.5">
                    {enItems[i] && (
                      <div className="flex items-start" dir="ltr">
                        <Diamond color="#10b981" solid />
                        <p className="text-sm font-body text-foreground/85 leading-relaxed flex-1">
                          {enItems[i]}
                        </p>
                      </div>
                    )}
                    {arItems[i] && (
                      <div className="flex items-start" dir="rtl">
                        <Diamond color="#10b981" solid={false} />
                        <p className="text-sm font-body text-foreground/85 leading-relaxed flex-1">
                          {arItems[i]}
                        </p>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
              )}
            </div>
          )}
        </div>

        {/* ─── 2. Courtesy ─── */}
        <Section
          headingEn="Courtesy"
          headingAr="اللباقة"
          paraEn={["A perfume is worn on the body, but it lives in the air around you — and that air belongs to everyone in the room. The first elegance of fragrance is not the scent itself but the consideration with which you wear it. To perfume yourself elegantly is also to perfume yourself kindly: close enough to be discovered, never so much as to be imposed.", "And there are places where it is gentler to arrive almost unscented — where the air is shared closely, where some cannot simply step away, and where a strong perfume may bring others discomfort rather than delight. Among them: hospitals and clinics, where many are unwell and sensitive; gyms and sports clubs, where breath runs deep and fast; offices and shared workplaces, where people sit together for hours; and mosques, churches, and places of worship, where stillness and closeness are part of the grace. In such spaces, the kindest perfume is a quiet one — or none at all."]}
          paraAr={["العطر يُلبَس على الجسد، لكنه يعيش في الهواء من حولك — و هذا الهواء ملك لكل من في المكان. أول أناقة في العطر ليست الرائحة نفسها بل اللطف الذي ترتديها به. أن تتعطر بأناقة هو أيضا أن تتعطر برفق: قريبا بما يكفي ليُكتشَف، لا كثيرا حتى يُفرَض.", "و ثمة أماكن يكون الأرفق أن تصل إليها بلا عطر يُذكَر — حيث الهواء مشترك عن قرب، و حيث لا يستطيع بعضهم أن ينصرف ببساطة، حيث قد يجلب العطر القوي للآخرين ضيقا لا متعة. منها: المستشفيات و العيادات، يكون كثيرون مرضى و لديهم حساسية الجيوب الأنفية؛ النوادي الرياضية، حيث النفَس عميق و سريع؛ المكاتب و أماكن العمل المشتركة، حيث يجلس الناس معا ساعات؛ المساجد و الكنائس و دور العبادة، حيث السكون و القرب جزء من الجلال. في مثل هذه الأماكن، أرحم العطر أهدؤه — أو لا عطر أفضل بكثير."]}
        />

        {/* ─── 3. Etiquette ─── */}
        <Section
          headingEn="Etiquette"
          headingAr="الإتيكيت"
          paraEn={["How. Apply to the warm pulse points — wrists, the base of the neck, behind the ears — and let the body's heat lift the scent gently; never rub the wrists together, for it bruises the delicate top notes. One or two sprays, not five: you should be the last to stop noticing your own perfume, not the first.", "When. Perfume yourself a little before you leave, so the sharpest opening has settled by the time you meet others, and the fragrance greets them softened and warm.", "What is preferred. Lighter, fresher scents by day and in the heat; richer, deeper ones by evening and in the cool. And always the quiet rule: an arm's length is the right reach of a perfume — felt by those you welcome close, unnoticed by those who merely pass."]}
          paraAr={["كيف. ضع العطر على مواضع النبض الدافئة — الرسغين، أسفل العنق، خلف الأذنين — و دع حرارة الجسد ترفع الرائحة برفق؛ و لا تفرك الرسغين معا فذلك يهشّم النوتات العليا الرقيقة. رشّة أو رشّتان لا خمس: ينبغي أن تكون آخر من يكفّ عن الإحساس بعطره لا أولهم.", "متى. تعطّر قبيل خروجك بقليل، كي تكون أحدّ بداية للعطر قد هدأت حين تلتقي الناس، فيستقبلهم العطر لينا دافئا.", "ما يُفضَّل. العطور الأخف و الأنعش نهارا و في الحر؛ و الأغنى و الأعمق مساء و بالبرد. و دائما تلك القاعدة الهادئة: مدى الذراع هو المدى الصحيح للعطر — يحسّه من تقرّبهم إليك، و لا ينتبه له العابرون."]}
        />

        {/* ─── 4. What troubles others ─── */}
        <Section
          headingEn="What troubles others"
          headingAr="ما يزعج الآخرين"
          paraEn="It helps to understand why a strong scent troubles some people, for the discomfort is real and not mere fussiness. A heavy fragrance can bring on headaches, a tightness in the chest, or a wave of nausea in those who are sensitive — and, importantly, the reaction is not always immediate. Some materials, especially the dense oily attars and concentrated oud oils, can sit lightly at first and then, an hour or more later, settle into a dull headache or a faint, draining unease, as the heaviest molecules linger and the nervous system tires of them. Because the effect can arrive so late, the wearer rarely connects it to their perfume at all. So the gentlest measure is simply restraint: a smaller dose, a lighter concentration, and the awareness that what feels lovely to you at the first spray may quietly weigh on someone beside you an hour from now."
          paraAr="يعين أن تفهم لماذا يزعج العطر القوي بعض الناس، فالضيق حقيقي لا تدلّلا. قد تجلب الرائحة الثقيلة صداعا، أو ضيقا في الصدر، أو موجة غثيان لدى الحساسين — و الأهم أن ردّ الفعل ليس دائما فوريا. بعض المواد، خاصة الأدهان الزيتية الكثيفة و زيوت العود المركّزة، قد تبدو خفيفة أول الأمر، ثم بعد ساعة أو أكثر تستقر صداعا خفيفا أو تعبا غامضا يسحب الطاقة، إذ تتباطأ أثقل الجزيئات و يملّ منها الجهاز العصبي. و لأن الأثر قد يأتي متأخرا، نادرا ما يربطه صاحب العطر بعطره أصلا. فأرفق التدابير هو ببساطة الاعتدال: جرعة أقل، و تركيز أخف، و وعي بأن ما يبدو لك جميلا عند أول رشّة قد يثقل بهدوء على من بجانبك بعد ساعة."
        />

        {/* ─── 5. Perfume Culture ─── */}
        <Section
          headingEn="Perfume Culture"
          headingAr="ثقافة العطور"
          paraEn="Perfume is one of the oldest of human arts, and one of the very few you wear. Long before it was a luxury, it was a language — of welcome and of mourning, of devotion and of desire. Cultures have prayed in smoke, anointed their dead in resin, and signed their letters in scent. To learn perfume is to learn a quiet history of how people have wished to be remembered: not by how they looked, but by the trace they left in the air when they walked out of a room."
          paraAr="العطر من أقدم فنون الإنسان، و من القليل النادر الذي يُلبَس. قبل أن يكون ترفا بزمن طويل، كان لغة — للترحيب و للحزن، و للتعبّد و للرغبة. صلّت الحضارات في الدخان، و حنّطت موتاها بالراتنج، و وقّعت رسائلها برائحة. أن تتعلّم العطر هو أن تتعلّم تاريخا هادئا لكيف أراد الناس أن يُذكَروا: لا بما بدوا عليه، بل بالأثر الذي تركوه في الهواء حين غادروا الغرفة."
        />

        {/* ─── 6. How to Wear Perfume ─── */}
        <Section
          headingEn="How to Wear Perfume"
          headingAr="كيفية ارتداء العطر"
          paraEn="Wear perfume the way you would keep a secret: close to the skin, and meant first for you. Place it on the warm points where the blood runs near the surface — the wrists, the neck, behind the ears — and let your own heat carry it outward. Do not drown it; a fragrance is meant to be discovered, not announced. And let it become part of you: the finest way to wear a scent is to wear it until you barely notice it yourself, so that only those who come near are quietly reminded that you are there."
          paraAr="ارتدِ العطر كما تحفظ سرا: قريبا من البشرة، و مقصودا لك أولا. ضعه على المواضع الدافئة حيث يجري الدم قرب السطح — الرسغان، العنق، خلف الأذنين — ودع حرارتك تحمله إلى الخارج. لا تُغرِقه؛ فالعطر يُكتشَف و لا يُعلَن. و دعه يصير جزءا منك: أجمل طريقة لارتداء رائحة أن تلبسها حتى تكاد لا تحسّها أنت، فلا يتذكّر وجودك بهدوء إلا من يقترب منك."
        />

        {/* ─── 7. When to Wear Different Fragrances ─── */}
        <Section
          headingEn="When to Wear Different Fragrances"
          headingAr="متى ترتدي عطورا مختلفة"
          paraEn="A fragrance keeps time with the day and the season. Morning and heat ask for lightness: citrus, green, cool water — everything that lifts. Evening and cold welcome weight: amber, wood, spice — everything that glows. Wear something bright and clean to work, something quieter to grief, something warm and close for those you love. A perfume wardrobe is not vanity; it is the simple wisdom that you are not the same person at dawn that you are at midnight — and your scent can keep you honest company through both."
          paraAr="العطر يضبط إيقاعه مع النهار و الفصل. الصباح و الحر يطلبان الخفّة: الحمضيات، و الأخضر، و الماء البارد — كل ما يرفع. المساء و البرد يرحّبان بالثقل: العنبر، الخشب، التوابل — كل ما يتوهّج. البَس شيئا مشرقا نقيا للعمل، و أهدأ للحزن، و أدفأ و أقرب لمن تحب. خزانة العطور ليست غرورا؛ بل حكمة بسيطة أنك لست في الفجر الشخص نفسه الذي أنت عليه في منتصف الليل — و لعطرك أن يرافقك بصدق في كليهما."
        />

        {/* ─── 8. Where NOT to Wear Strong Perfume ─── */}
        <Section
          headingEn="Where NOT to Wear Strong Perfume"
          headingAr="حيث لا تضع عطرا قويا"
          paraEn="There are rooms that ask for silence, and the same is true of scent. Reach for little or none where the air is shared and inescapable — a hospital bed, a crowded lift, an exam hall, a long flight, a small office, the closeness of worship. Reach for less where breath runs hard, as in a gym, and where food is the guest of honor, as at a fine table, for a heavy perfume can dull a meal as surely as it can crowd a prayer. Beneath all of these lies a single rule, and it is one of empathy: before the last spray, ask not whether you like it — but whether the person who cannot move away from you will."
          paraAr="ثمة غرف تطلب الصمت، و كذلك العطر. خفّف أو دع حيث الهواء مشترك و لا فكاك منه — سرير مستشفى، مصعد مكتظ، قاعة امتحان، رحلة طويلة، مكتب صغير، و قرب العبادة. و أقلِل حيث يشتدّ النفَس كالنادي الرياضي، و حيث يكون الطعام ضيف الشرف كمائدة فاخرة، فالعطر الثقيل يُفسد وجبة كما يزاحم صلاة. تحت هذا كله قاعدة منفردة، و هي رحمة: قبل الرشّة الأخيرة، لا تسأل هل يعجبك — بل هل سيعجب من لا يستطيع أن يبتعد عنك."
        />
      </div>
    </div>
  );
}

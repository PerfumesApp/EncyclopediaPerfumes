import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { compressImage } from "@/utils/imageCompressor";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Upload, X, Search, ChevronDown } from "lucide-react";
import { PRIMARY_TYPES, OTHER_TYPE_GROUPS, typeDisplay, strengthOf } from "@/lib/perfumeTypes";
import { StrengthBar } from "@/components/perfume/StrengthIndicator";
import { useLang } from "@/lib/LanguageContext";
import { OCCASIONS } from "@/lib/occasions";
import NotesTagSearch from "@/components/maestro/NotesTagSearch";
import AccordsPicker from "@/components/perfume/AccordsPicker";
import CareProductFields from "@/components/perfume/CareProductFields";
import PerfumerSearchTag from "@/components/maestro/PerfumerSearchTag";
import BackIcon from "@/components/shared/BackIcon";

const CATEGORIES = [
  "Floral","Oriental","Woody","Fresh","Citrus","Chypre","Fougère","Gourmand","Aquatic","Spicy",
  "Musky","Powdery","Green","Leather","Aromatic","Aldehyic","Amber","Oud","Rose","Vanilla",
];

const ODOR_FAMILIES = [
  { en: "Floral", ar: "زهري" },
  { en: "Woody", ar: "خشبي" },
  { en: "Oriental", ar: "شرقي" },
  { en: "Fresh / Citrus", ar: "حمضي" },
  { en: "Aquatic / Marine", ar: "مائي" },
  { en: "Fougère", ar: "مسكي" },
  { en: "Chypre", ar: "بهاري" },
  { en: "Gourmand", ar: "حلو" },
  { en: "Musk", ar: "مسك" },
  { en: "Spicy", ar: "مسكر" },
  { en: "Green", ar: "أخضر" },
  { en: "Leather", ar: "جلدي" },
  { en: "Aromatic", ar: "عطري" },
  { en: "Powdery", ar: "بودري" },
  { en: "Amber", ar: "عنبري" },
  { en: "Oud", ar: "عودي" },
  { en: "Incense", ar: "دخاني" },
  { en: "Earthy / Mossy", ar: "ترابي" },
];

const NOTES_SUGGESTIONS = [
  "Bergamot","Lemon","Orange","Grapefruit","Neroli","Mandarin","Lime","Petitgrain",
  "Rose","Jasmine","Iris","Violet","Peony","Lily","Ylang-Ylang","Gardenia","Tuberose",
  "Sandalwood","Cedarwood","Oud","Vetiver","Patchouli","Musk","Ambergris","Oakmoss",
  "Vanilla","Benzoin","Tonka Bean","Labdanum","Myrrh","Frankincense","Amber",
  "Pepper","Cardamom","Cinnamon","Ginger","Nutmeg","Saffron","Cloves",
  "Lavender","Rosemary","Thyme","Basil","Mint","Eucalyptus",
  "Fig","Apple","Peach","Blackcurrant","Raspberry","Strawberry",
];


const EMPTY_FORM = {
  name_en: "", name_ar: "", brand_id: "", brand_name: "", image_url: "",
  type: "", gender: "", time_of_day: "All", ml: "", price: "", top_notes: "", heart_notes: "", base_notes: "", accords: "",
  season: "", category: "", release_year: "", about_en: "", about_ar: "",
  price_range: "", innovation_notes: "", odor_family: "", occasions: "",
  collection_id: "", collection_name: "", perfumer_ids: "", perfumer_names: "",
  related_perfume_ids: "", related_perfume_names: "",
  discontinued: false,
  best_of_decade: false,
  product_mode: "perfume",
  care_profile: null,
};

// Bilingual odor family select component (combined EN — AR display)
function OdorFamilySelect({ selected = "", onChange, placeholder }) {
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const selectedArr = selected ? selected.split(",").map(s => s.trim()).filter(Boolean) : [];

  const filtered = search
    ? ODOR_FAMILIES.filter(f => 
        f.en.toLowerCase().includes(search.toLowerCase()) || 
        f.ar.toLowerCase().includes(search.toLowerCase())
      )
    : ODOR_FAMILIES;

  const toggle = (family) => {
    const display = `${family.en} — ${family.ar}`;
    const next = selectedArr.includes(display)
      ? selectedArr.filter(s => s !== display)
      : [...selectedArr, display];
    onChange(next.join(", "));
  };

  return (
    <div className="relative">
      <div
        className="min-h-[44px] rounded-none border border-input bg-transparent px-3 py-2 text-sm font-body cursor-pointer flex flex-wrap gap-2 items-center"
        onClick={() => setOpen(!open)}
      >
        {selectedArr.length === 0 && <span className="text-muted-foreground text-xs">{placeholder}</span>}
        {selectedArr.map(s => (
          <span key={s} className="inline-flex items-center gap-1 text-primary text-xs rounded-none">
            {s}
            <button type="button" onClick={(e) => { e.stopPropagation(); toggle(ODOR_FAMILIES.find(f => `${f.en} — ${f.ar}` === s)); }}>
              <X className="w-3 h-3" />
            </button>
          </span>
        ))}
        <ChevronDown className="w-4 h-4 text-muted-foreground ml-auto flex-shrink-0" />
      </div>
      {open && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-52 overflow-y-auto">
          <div className="p-2 border-b border-border">
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={isAr ? "بحث" : "Search.."}
              className="h-8 rounded-none font-body text-sm"
              onClick={e => e.stopPropagation()}
            />
          </div>
          {filtered.map(family => {
            const display = `${family.en} — ${family.ar}`;
            const isSelected = selectedArr.includes(display);
            return (
              <button
                key={display}
                type="button"
                onClick={() => toggle(family)}
                className={`w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0 flex items-center justify-between ${isSelected ? "text-primary font-medium" : ""}`}
              >
                <span>{display}</span>
                {isSelected && <span className="text-primary text-xs">✓</span>}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// Multi-tag select component
function TagSelect({ options, selected, onChange, placeholder, searchable = true }) {
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const selectedArr = selected ? selected.split(",").map(s => s.trim()).filter(Boolean) : [];

  const filtered = useMemo(() => {
    if (!search) return options;
    return options.filter(o => o.toLowerCase().includes(search.toLowerCase()));
  }, [options, search]);

  const toggle = (val) => {
    let next;
    if (selectedArr.includes(val)) {
      next = selectedArr.filter(s => s !== val);
    } else {
      next = [...selectedArr, val];
    }
    onChange(next.join(", "));
  };

  return (
    <div className="relative">
      <div
        className="min-h-[44px] rounded-none border border-input bg-transparent px-3 py-2 text-sm font-body cursor-pointer flex flex-wrap gap-1 items-center"
        onClick={() => setOpen(!open)}
      >
        {selectedArr.length === 0 && <span className="text-muted-foreground">{placeholder}</span>}
        {selectedArr.map(s => (
          <span key={s} className="inline-flex items-center gap-1 text-primary text-xs rounded-none">
            {s}
            <button type="button" onClick={(e) => { e.stopPropagation(); toggle(s); }}>
              <X className="w-3 h-3" />
            </button>
          </span>
        ))}
        <ChevronDown className="w-4 h-4 text-muted-foreground ml-auto flex-shrink-0" />
      </div>
      {open && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-52 overflow-y-auto">
          {searchable && (
            <div className="p-2 border-b border-border">
              <Input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder={isAr ? "بحث" : "Search.."}
                className="h-8 rounded-none font-body text-sm"
                onClick={e => e.stopPropagation()}
              />
            </div>
          )}
          {filtered.map(o => (
            <button
              key={o}
              type="button"
              onClick={() => toggle(o)}
              className={`w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0 flex items-center justify-between ${selectedArr.includes(o) ? "text-primary font-medium" : ""}`}
            >
              {o}
              {selectedArr.includes(o) && <span className="text-primary text-xs">✓</span>}
            </button>
          ))}
          {filtered.length === 0 && <p className="text-xs text-muted-foreground font-body px-3 py-2">{isAr ? "لا نتائج" : "No matches"}</p>}
        </div>
      )}
    </div>
  );
}

// Searchable single-value input with suggestions
function SearchableInput({ value, onChange, suggestions, placeholder, dir }) {
  const [search, setSearch] = useState(value || "");
  const [open, setOpen] = useState(false);

  const filtered = useMemo(() => {
    if (!search) return suggestions;
    return suggestions.filter(s => s.toLowerCase().includes(search.toLowerCase()));
  }, [search, suggestions]);

  const handleChange = (e) => {
    setSearch(e.target.value);
    onChange(e.target.value);
    setOpen(true);
  };

  const select = (val) => {
    setSearch(val);
    onChange(val);
    setOpen(false);
  };

  // sync external value
  if (value !== search && value !== undefined && !open) {
    // only sync once on mount / edit load
  }

  return (
    <div className="relative">
      <Input
        value={search}
        onChange={handleChange}
        onFocus={() => setOpen(true)}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        placeholder={placeholder}
        className="rounded-none h-11 font-body"
        dir={dir}
      />
      {open && filtered.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-44 overflow-y-auto">
          {filtered.map(s => (
            <button
              key={s}
              type="button"
              onMouseDown={() => select(s)}
              className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0"
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// Notes multi-tag input with suggestions
function NotesTagInput({ value, onChange, placeholder }) {
  const [inputVal, setInputVal] = useState("");
  const [open, setOpen] = useState(false);
  const tags = value ? value.split(",").map(s => s.trim()).filter(Boolean) : [];

  const filtered = useMemo(() => {
    if (!inputVal) return NOTES_SUGGESTIONS;
    return NOTES_SUGGESTIONS.filter(s => s.toLowerCase().includes(inputVal.toLowerCase()) && !tags.includes(s));
  }, [inputVal, tags]);

  const addTag = (tag) => {
    const trimmed = tag.trim();
    if (!trimmed || tags.includes(trimmed)) return;
    onChange([...tags, trimmed].join(", "));
    setInputVal("");
    setOpen(false);
  };

  const removeTag = (tag) => {
    onChange(tags.filter(t => t !== tag).join(", "));
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag(inputVal);
    } else if (e.key === "Backspace" && !inputVal && tags.length > 0) {
      removeTag(tags[tags.length - 1]);
    }
  };

  return (
    <div className="relative">
      <div className="min-h-[44px] rounded-none border border-input bg-transparent px-3 py-2 flex flex-wrap gap-1 items-center cursor-text"
        onClick={() => document.getElementById(`notes-input-${placeholder}`)?.focus()}
      >
        {tags.map(t => (
          <span key={t} className="inline-flex items-center gap-1 text-foreground text-xs rounded-none">
            {t}
            <button type="button" onClick={() => removeTag(t)}><X className="w-3 h-3" /></button>
          </span>
        ))}
        <input
          id={`notes-input-${placeholder}`}
          value={inputVal}
          onChange={e => { setInputVal(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          onKeyDown={handleKeyDown}
          placeholder={tags.length === 0 ? placeholder : ""}
          className="flex-1 min-w-[80px] bg-transparent outline-none text-sm font-body placeholder:text-muted-foreground"
        />
      </div>
      {open && filtered.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-44 overflow-y-auto">
          {filtered.map(s => (
            <button
              key={s}
              type="button"
              onMouseDown={() => addTag(s)}
              className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0"
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AddPerfume() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();
  const [isUploading, setIsUploading] = useState(false);
  const [showOtherTypes, setShowOtherTypes] = useState(false);

  const [perfumeSearch, setPerfumeSearch] = useState("");
  const [showPerfumeList, setShowPerfumeList] = useState(false);
  const [editingPerfume, setEditingPerfume] = useState(null);
  const [relatedSearch, setRelatedSearch] = useState("");
  const [showRelatedList, setShowRelatedList] = useState(false);

  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [brandSearch, setBrandSearch] = useState("");
  const [showBrandList, setShowBrandList] = useState(false);
  const [newBrand, setNewBrand] = useState("");
  const [newBrandAr, setNewBrandAr] = useState("");
  const [showNewBrand, setShowNewBrand] = useState(false);

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const selectedBrandId = form.brand_id;
  const { data: collections = [] } = useQuery({
    queryKey: ["collections-by-brand", selectedBrandId],
    queryFn: () => apphost.entities.PerfumeCollection.filter({ brand_id: selectedBrandId }),
    enabled: !!selectedBrandId,
  });

  const { data: allPerfumes = [] } = useAllPerfumes("name", { refetchOnMount: true, staleTime: 1000 * 60 * 5 });



  const selectPerfumeToEdit = (p) => {
    setEditingPerfume(p);
    setForm({
      name_en: p.name_en || p.name || "",
      name_ar: p.name_ar || "",
      brand_id: p.brand_id || "",
      brand_name: p.brand_name || "",
      collection_id: p.collection_id || "",
      collection_name: p.collection_name || "",
      image_url: p.image_url || "",
      type: p.type || "",
      gender: p.gender || "",
      ml: p.ml ?? "",
      price: p.price ?? "",
      time_of_day: p.time_of_day || "All",
      top_notes: p.top_notes || "",
      heart_notes: p.heart_notes || "",
      base_notes: p.base_notes || "",
      accords: p.accords || "",
      season: p.season || "",
      category: p.category || "",
      release_year: p.release_year || "",
      about_en: p.about_en || p.about || "",
      about_ar: p.about_ar || "",
      price_range: p.price_range || "",
      innovation_notes: p.innovation_notes || "",
      odor_family: p.odor_family || "",
      occasions: p.occasions || "",
      perfumer_ids: p.perfumer_ids || "",
      perfumer_names: p.perfumer_names || "",
      related_perfume_ids: p.related_perfume_ids || "",
      related_perfume_names: p.related_perfume_names || "",
      discontinued: p.discontinued || false,
      best_of_decade: p.best_of_decade || false,
      care_profile: p.care_profile || null,
      product_mode: p.care_profile ? "care" : "perfume",
    });
    setPerfumeSearch(p.name_en || p.name);
    setShowPerfumeList(false);
    setShowNewBrand(false);
  };

  const clearEdit = () => {
    setEditingPerfume(null);
    setForm({ ...EMPTY_FORM });
    setPerfumeSearch("");
    setBrandSearch("");
    setShowNewBrand(false);
  };

  // العطر يُضاف لقاعدة العطور الرئيسية مباشرة (المستخدم أدمن).
  // لا يُضاف تلقائياً لمجموعة المستخدم — تلك تتم بزر منفصل من صفحة العطر/البراند.
  const createMutation = useMutation({
    mutationFn: async (data) => {
      if (showNewBrand && newBrand) {
        const brand = await apphost.entities.PerfumeBrand.create({ name: newBrand, name_ar: newBrandAr || undefined, is_user: true });
        data.brand_id = brand.id;
        data.brand_name = newBrand;
        data.brand_name_ar = newBrandAr || undefined;
      }
      // أضف لقاعدة العطور الرئيسية فقط (موسومة كإضافة مستخدم للموجز)
      const perfume = await apphost.entities.Perfume.create({ ...data, is_user: true });
      return perfume;
    },
    onSuccess: (perfume) => {
      queryClient.invalidateQueries({ queryKey: ["perfumes"] });
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      queryClient.invalidateQueries({ queryKey: ["perfumes-by-brand"] });
      queryClient.invalidateQueries({ queryKey: ["collections-by-brand"] });
      toast.success("تم الحفظ في قاعدة العطور");
      // ننتقل لصفحة العطر المُضاف نفسه لا للاستكشاف
      setTimeout(() => navigate(perfume?.id ? `/perfume?id=${perfume.id}` : "/perfumes"), 500);
    },
    onError: (error) => {
      toast.error("خطأ:" + (error?.message || "فشل الحفظ"));
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data) => apphost.entities.Perfume.update(editingPerfume.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfumes"] });
      queryClient.invalidateQueries({ queryKey: ["perfume", editingPerfume.id] }); // صفحة التفاصيل
      queryClient.invalidateQueries({ queryKey: ["perfume"] }); // أي صفحة تفاصيل أخرى
      toast.success("تم التحديث");
      // بعد التعديل نرجع لصفحة العطر نفسه لا لصفحة الاستكشاف
      setTimeout(() => navigate(`/perfume?id=${editingPerfume.id}`), 500);
    },
    onError: (error) => {
      toast.error("خطأ:" + (error?.message || "فشل التحديث"));
    },
  });

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Only images (JPG, PNG, WebP, GIF) and PDF files are allowed');
      return;
    }
    
    // Validate file size (max 5MB)
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      toast.error('File size must be less than 5MB');
      return;
    }
    
    setIsUploading(true);
    try {
      //  صورة العطر من المستخدم تضغط لحد أقصى 250KB
      const compressed = await compressImage(file, { maxWidth: 800, maxHeight: 800, quality: 0.8, maxKB: 250 });
      const { file_url } = await apphost.integrations.Core.UploadFile({ file: compressed });
      setForm((prev) => ({ ...prev, image_url: file_url }));
      toast.success('File uploaded successfully');
    } catch (error) {
      toast.error('Upload failed:' + error.message);
    }
    setIsUploading(false);
  };

  const filteredBrands = useMemo(() => {
    if (!brandSearch) return brands;
    return brands.filter(b => b.name?.toLowerCase().includes(brandSearch.toLowerCase()));
  }, [brands, brandSearch]);

  const filteredPerfumes = useMemo(() => {
    if (!perfumeSearch.trim()) return [];
    return allPerfumes.filter(p =>
      (p.name_en || p.name_ar || p.name || "").toLowerCase().includes(perfumeSearch.toLowerCase()) ||
      (p.brand_name || "").toLowerCase().includes(perfumeSearch.toLowerCase())
    );
  }, [allPerfumes, perfumeSearch]);

  const filteredRelated = useMemo(() => {
    if (!relatedSearch.trim()) return [];
    const selected = (form.related_perfume_ids || "").split(",").map(s => s.trim()).filter(Boolean);
    return allPerfumes.filter(p =>
      p.id !== editingPerfume?.id &&
      !selected.includes(p.id) &&
      ((p.name_en || p.name_ar || p.name || "").toLowerCase().includes(relatedSearch.toLowerCase()) ||
       (p.brand_name || "").toLowerCase().includes(relatedSearch.toLowerCase()))
    );
  }, [allPerfumes, relatedSearch, form.related_perfume_ids, editingPerfume]);

  const handleBrandSelect = (brand) => {
    setForm((prev) => ({ ...prev, brand_id: brand.id, brand_name: brand.name, brand_name_ar: brand.name_ar || "", collection_id: "", collection_name: "" }));
    setBrandSearch("");
    setShowBrandList(false);
    setShowNewBrand(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errors = [];
    if (!form.name_en?.trim()) errors.push("• English name is required");
    if (!form.brand_name?.trim() && !newBrand?.trim()) errors.push("• Brand is required");
    
    if (errors.length > 0) {
      toast.error("Missing required fields:\n" + errors.join("\n"));
      return;
    }
    
    if (editingPerfume) {
      updateMutation.mutate(form);
    } else {
      createMutation.mutate(form);
    }
  };

  const update = (key, val) => setForm((prev) => ({ ...prev, [key]: val }));
  
  // For odor family - store as combined EN — AR format
  const updateOdorFamily = (val) => {
   setForm(prev => ({ ...prev, odor_family: val }));
  };

  const isSaving = createMutation.isPending || updateMutation.isPending;

  // فتح الصفحة بوضع التعديل مباشرة عبر /add?id=X (من صفحة العطر)
  const [searchParams] = useSearchParams();
  const editIdParam = searchParams.get("id");
  useEffect(() => {
    if (!editIdParam || editingPerfume) return;
    let cancelled = false;
    (async () => {
      try {
        const rows = await apphost.entities.Perfume.filter({ id: editIdParam });
        const p = Array.isArray(rows) ? rows[0] : rows;
        if (p && !cancelled) selectPerfumeToEdit(p);
      } catch {
        toast.error(isAr ? "تعذّر تحميل العطر" : "Failed to load perfume");
      }
    })();
    return () => { cancelled = true; };
  }, [editIdParam, editingPerfume]);

  // فتح الصفحة من صفحة البراند عبر /add?brand=<id> → تعبئة البراند تلقائياً
  const brandParam = searchParams.get("brand");
  useEffect(() => {
    if (!brandParam || editIdParam) return;
    let cancelled = false;
    (async () => {
      try {
        const rows = await apphost.entities.PerfumeBrand.filter({ id: brandParam });
        const b = Array.isArray(rows) ? rows[0] : rows;
        if (b && !cancelled) setForm((prev) => (prev.brand_id ? prev : { ...prev, brand_id: b.id, brand_name: b.name, brand_name_ar: b.name_ar || "" }));
      } catch { /* تجاهل */ }
    })();
    return () => { cancelled = true; };
  }, [brandParam, editIdParam]);

  return (
    <div className="px-5 page-top pb-24 space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <BackIcon className="w-5 h-5" />
        </Button>
        <h1 className="font-heading text-2xl font-bold">{editingPerfume ? (isAr ? "تعديل العطر" : "Edit Perfume") : (isAr ? "إضافة عطر" : "Add & Perfume")}</h1>
      </div>

      {/* Search existing perfume to edit */}
      <div className="space-y-1.5">
        <Label className="text-xs font-body font-medium text-muted-foreground uppercase tracking-wider">
          Edit Existing Perfume (optional)
        </Label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={perfumeSearch}
            onChange={(e) => {
              if (editingPerfume) clearEdit();
              setPerfumeSearch(e.target.value);
              setShowPerfumeList(true);
            }}
            onFocus={() => { if (!editingPerfume) setShowPerfumeList(true); }}
            placeholder={isAr ? "ابحث عن عطر لتعديله" : "Search perfume to edit.."}
            className="pl-10 rounded-none h-11 font-body"
          />
          {editingPerfume && (
            <button type="button" onClick={clearEdit} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          )}
          {showPerfumeList && !editingPerfume && filteredPerfumes.length > 0 && (
            <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20">
              {filteredPerfumes.map((p) => (
                  <button key={p.id} type="button" onClick={() => selectPerfumeToEdit(p)}
                    className="w-full text-left px-3 py-2.5 hover:bg-secondary text-sm font-body border-b border-border/50 last:border-b-0">
                    <span className="font-semibold">{p.name_en || p.name_ar || p.name}</span>
                    {p.brand_name && <span className="text-muted-foreground ml-2 text-xs">{p.brand_name}</span>}
                  </button>
                ))}
            </div>
          )}
        </div>
        {editingPerfume && <p className="text-xs text-primary font-body font-medium">✏️ Editing: {editingPerfume.name}</p>}
      </div>

      <div className="h-px bg-border/60" />

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* مبدّل نوع المنتج — أعلى النموذج */}
        <div className="flex gap-2">
          <button type="button" onClick={() => update("product_mode", "perfume")}
            className="flex-1 py-2.5 text-sm font-body font-semibold rounded-none border transition-colors"
            style={form.product_mode !== "care" ? { borderColor: "var(--brand)", background: "var(--brand)", color: "#fff" } : { borderColor: "#e2dccd", color: "var(--mut,#6B6760)" }}>
            عطر <span className="text-xs">Perfume</span>
          </button>
          <button type="button" onClick={() => update("product_mode", "care")}
            className="flex-1 py-2.5 text-sm font-body font-semibold rounded-none border transition-colors"
            style={form.product_mode === "care" ? { borderColor: "#3A4A7A", background: "#3A4A7A", color: "#fff" } : { borderColor: "#e2dccd", color: "var(--mut,#6B6760)" }}>
            منتج عناية <span className="text-xs">Care Product</span>
          </button>
        </div>

        {/* Image */}
        <div className="flex justify-center">
          <label className="w-32 h-32 rounded-none bg-secondary flex items-center justify-center cursor-pointer overflow-hidden border-2 border-dashed border-border hover:border-primary transition-colors">
            {isUploading ? (
              <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            ) : form.image_url ? (
              <img src={form.image_url} alt="Perfume" className="w-full h-full object-cover" />
            ) : (
              <div className="text-center">
                <Upload className="w-6 h-6 text-muted-foreground mx-auto" />
                <span className="text-[10px] text-muted-foreground font-body mt-1 block">{isAr ? "إضافة صورة" : "Add Photo"}</span>
              </div>
            )}
            <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
          </label>
        </div>

        {/* Name — صندوق موحد */}
         <div className="space-y-3 bg-secondary/30 rounded-none p-4 border border-primary/30">
           <div className="space-y-1.5">
             <Label className="text-xs font-body font-semibold text-primary uppercase tracking-wider">✓ Perfume Name اسم العطر (Required)</Label>
           </div>
          <div className="space-y-2">
            <div>
              <p className="text-[10px] font-body font-semibold text-foreground mb-1.5">{isAr ? "الإنجليزية" : "English"}</p>
              <Input value={form.name_en} onChange={(e) => update("name_en", e.target.value)} placeholder="e.g. Bleu de Chanel" className="rounded-none h-11 font-body" />
            </div>
            <div>
              <p className="text-[10px] font-body font-semibold text-foreground mb-1.5" dir="rtl">العربية</p>
              <Input value={form.name_ar} onChange={(e) => update("name_ar", e.target.value)} placeholder="مثال: بلو دي شانيل" className="rounded-none h-11 font-body" dir="rtl" />
            </div>
          </div>
        </div>

        {/* Brand */}
        <Field label="✓ Brand (Required)">
          <div className="relative">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Input
                  value={showNewBrand ? newBrand : form.brand_name || brandSearch}
                  onChange={(e) => {
                    if (showNewBrand) setNewBrand(e.target.value);
                    else { setBrandSearch(e.target.value); update("brand_name", ""); update("brand_id", ""); }
                    if (!showNewBrand) setShowBrandList(true);
                  }}
                  onFocus={() => setShowBrandList(true)}
                  placeholder={isAr ? "ابحث أو أنشئ برانداً" : "Search or create brand.."}
                  className="rounded-none h-11 font-body"
                />
                {showBrandList && !showNewBrand && filteredBrands.length > 0 && (
                  <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-10">
                    {filteredBrands.map((b) => (
                           <button key={b.id} type="button" onClick={() => handleBrandSelect(b)}
                             className="w-full text-left px-3 py-2.5 hover:bg-secondary text-sm font-body border-b border-border/50 last:border-b-0">
                             {b.name}
                           </button>
                         ))}
                  </div>
                )}
              </div>
              {!form.brand_id && !showNewBrand && (
                <Button type="button" onClick={() => { setShowNewBrand(true); setShowBrandList(false); setBrandSearch(""); }} size="icon" variant="outline" className="rounded-none h-11">
                  Add</Button>
              )}
              {form.brand_id && (
                <Button type="button" onClick={() => setForm(prev => ({ ...prev, brand_id: "", brand_name: "" }))} size="icon" variant="outline" className="rounded-none h-11">
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
            {showNewBrand && (
              <div className="space-y-2 mt-2">
                <Input value={newBrand} onChange={(e) => setNewBrand(e.target.value)} placeholder={isAr ? "اسم البراند بالإنجليزية" : "Brand name (English)"} className="rounded-none h-11 font-body" />
                <Input value={newBrandAr} onChange={(e) => setNewBrandAr(e.target.value)} placeholder="اسم الماركة (Arabic)" className="rounded-none h-11 font-body" dir="rtl" />
              </div>
            )}
          </div>
        </Field>

        {/* Collection — optional, appears only if brand is selected */}
        {form.brand_id && (
          <Field label="المجموعة Collection (optional)">
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => update("collection_id", "") || update("collection_name", "")}
                className={` rounded-none text-xs font-body font-medium transition-all ${!form.collection_id ? " text-primary-foreground " : " text-muted-foreground"}`}
              >
                — {isAr ? "بدون مجموعة" : "No Collection"}
              </button>
              {collections.map(c => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => { update("collection_id", c.id); update("collection_name", c.name); }}
                  className={` rounded-none text-xs font-body font-medium transition-all ${form.collection_id === c.id ? " text-primary-foreground " : " "}`}
                >
                  {c.name}
                </button>
              ))}
              {collections.length === 0 && (
                <p className="text-xs text-muted-foreground font-body italic">{isAr ? "لا مجموعات لهذا البراند" : "No collections yet for this brand"}</p>
              )}
            </div>
          </Field>
        )}

        {/* Type & Gender & Time */}
        <Field label="Type النوع">
          <div className="flex flex-wrap gap-2">
            {PRIMARY_TYPES.map(t => {
              const selected = form.type === t.value;
              return (
                <button key={t.value} type="button" onClick={() => update("type", selected ? "" : t.value)}
                  className={`rounded-none text-xs font-body transition-all text-left inline-flex items-center gap-2 ${selected ? "font-bold" : "font-medium"}`}
                  style={{ color: selected ? "var(--brand)" : undefined }}>
                  {typeDisplay(t.value, isAr ? "ar" : "both")}
                  {selected && strengthOf(t.value) && <StrengthBar strength={strengthOf(t.value)} />}
                </button>
              );
            })}
          </div>
          {/* أنواع أخرى — مجمّعة بعائلاتها (بخور/دهون/عناية) */}
          <button type="button" onClick={() => setShowOtherTypes(v => !v)}
            className="mt-2 text-xs font-body font-semibold bg-transparent transition-opacity hover:opacity-70"
            style={{ color: "var(--brand)" }}>
            {showOtherTypes ? (isAr ? "إخفاء الأنواع الأخرى" : "Hide other types") : (isAr ? "أنواع أخرى" : "Other types")}
          </button>
          {showOtherTypes && (
            <div className="mt-2 space-y-3">
              {OTHER_TYPE_GROUPS.map(grp => (
                <div key={grp.family}>
                  <p className="text-[10px] font-body font-semibold mb-1" style={{ color: "#9a8f7c" }}>{isAr ? grp.ar : grp.en}</p>
                  <div className="flex flex-wrap gap-2">
                    {grp.items.map(t => {
                      const selected = form.type === t.value;
                      return (
                        <button key={t.value} type="button" onClick={() => update("type", selected ? "" : t.value)}
                          className={`rounded-none text-xs font-body transition-all text-left ${selected ? "font-bold" : "font-medium"}`}
                          style={{ color: selected ? "var(--brand)" : undefined }}>
                          {typeDisplay(t.value, isAr ? "ar" : "both")}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Gender">
            <Select value={form.gender} onValueChange={(v) => update("gender", v)}>
              <SelectTrigger className="rounded-none h-11 font-body uppercase"><SelectValue placeholder={isAr ? "اختر" : "Select"} /></SelectTrigger>
              <SelectContent>
                {["Men","Women","Unisex"].map(g => (
                  <SelectItem key={g} value={g} className="uppercase">{g}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Time">
            <Select value={form.time_of_day} onValueChange={(v) => update("time_of_day", v)}>
              <SelectTrigger className="rounded-none h-11 font-body"><SelectValue placeholder={isAr ? "اختر" : "Select"} /></SelectTrigger>
              <SelectContent>
                {["Day","Night","All"].map(t => (
                  <SelectItem key={t} value={t}>{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </div>

        {/* About — صندوق موحد */}
         <div className="space-y-3 bg-secondary/30 rounded-none p-4">
           <div className="space-y-1.5">
             <Label className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider">About — عن العطر</Label>
           </div>
           <Textarea value={form.about_en || ""} onChange={(e) => update("about_en", e.target.value)} placeholder="EN: Tell the story.." className="rounded-none font-body min-h-[100px]" />
           <Textarea value={form.about_ar || ""} onChange={(e) => update("about_ar", e.target.value)} placeholder="اكتب قصة العطر بالعربية.." dir="rtl" className="rounded-none font-body min-h-[100px]" />
         </div>

        {/* حقول منتج العناية — تظهر في وضع العناية بدل النوتات */}
        {form.product_mode === "care" && <CareProductFields form={form} setForm={setForm} />}

        {/* Notes — tag inputs with suggestions (تظهر لوضع العطر فقط) */}
        {form.product_mode !== "care" && (<>
         <Field label="Top Notes مقدمة">
            <NotesTagSearch value={form.top_notes} onChange={(v) => update("top_notes", v)} placeholder="ابحث في النوتات.." noteCategory="all" id="top-notes" />
          </Field>
          <Field label="Heart Notes قلب">
            <NotesTagSearch value={form.heart_notes} onChange={(v) => update("heart_notes", v)} placeholder="ابحث في النوتات.." noteCategory="all" id="heart-notes" />
          </Field>
          <Field label="Base Notes أساس">
            <NotesTagSearch value={form.base_notes} onChange={(v) => update("base_notes", v)} placeholder="ابحث في النوتات.." noteCategory="all" id="base-notes" />
          </Field>
         <Field label="Added إضافية">
           <NotesTagSearch
             value={form.innovation_notes || ""}
             onChange={(v) => update("innovation_notes", v)}
             placeholder="ابحث في كل النوتات.."
             noteCategory="all"
             id="innovation-notes"
           />
         </Field>
         <div className="pt-1">
           <AccordsPicker value={form.accords || ""} onChange={(v) => update("accords", v)} />
         </div>
        </>)}

         <Field label="👃 العطار Perfumer">
            <PerfumerSearchTag
              value={form.perfumer_ids || ""}
              namesValue={form.perfumer_names || ""}
              onChange={(ids, names) => { update("perfumer_ids", ids); update("perfumer_names", names); }}
            />
          </Field>

          {/* Related Perfumes — البحث و الربط */}
          <Field label="🔗 تذكرني في Related Perfumes (optional)">
            <div className="space-y-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  value={relatedSearch}
                  onChange={(e) => {
                    setRelatedSearch(e.target.value);
                    setShowRelatedList(true);
                  }}
                  onFocus={() => setShowRelatedList(true)}
                  placeholder={isAr ? "ابحث عن عطر للربط" : "Search perfume to link.."}
                  className="pl-10 rounded-none h-11 font-body"
                />
              </div>

              {/* Related perfumes chips */}
              {(form.related_perfume_ids || "").split(",").map((id) => {
                if (!id.trim()) return null;
                const perfume = allPerfumes.find(p => String(p.id) === String(id.trim()));
                return (
                  <div key={id} className="flex items-center gap-2 p-2.5 bg-secondary/40 rounded-none">
                    {perfume?.image_url && (
                      <img
                        src={perfume.image_url}
                        alt={perfume.name_en}
                        className="w-10 h-10 rounded object-contain"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-body font-semibold truncate">{perfume?.name_en || perfume?.name_ar}</p>
                      <p className="text-[10px] text-muted-foreground">{perfume?.brand_name}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const ids = (form.related_perfume_ids || "").split(",").map(s => s.trim()).filter(Boolean);
                        const names = (form.related_perfume_names || "").split(",").map(s => s.trim()).filter(Boolean);
                        const idx = ids.indexOf(id.trim());
                        if (idx !== -1) {
                          ids.splice(idx, 1);
                          names.splice(idx, 1);
                          update("related_perfume_ids", ids.join(","));
                          update("related_perfume_names", names.join(","));
                        }
                      }}
                      className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}

              {showRelatedList && filteredRelated.length > 0 && (
                <div className="bg-card border border-border rounded-none shadow-lg z-10 max-h-52 overflow-y-auto">
                  {filteredRelated.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => {
                        const ids = (form.related_perfume_ids || "").split(",").map(s => s.trim()).filter(Boolean);
                        const names = (form.related_perfume_names || "").split(",").map(s => s.trim()).filter(Boolean);
                        ids.push(p.id);
                        names.push(p.name_en || p.name_ar);
                        update("related_perfume_ids", ids.join(","));
                        update("related_perfume_names", names.join(","));
                        setRelatedSearch("");
                        setShowRelatedList(false);
                      }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-secondary text-sm font-body border-b border-border/50 last:border-b-0"
                      >
                      {p.image_url && (
                        <img src={p.image_url} alt={p.name_en || p.name_ar} className="w-8 h-8 rounded object-contain" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold truncate">{p.name_en || p.name_ar || "Untitled"}</p>
                        {p.brand_name && <p className="text-xs text-muted-foreground">{p.brand_name}</p>}
                      </div>
                      </button>
                  ))}
                </div>
              )}
            </div>
          </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Release Year">
            <Input type="number" value={form.release_year || ""} onChange={(e) => update("release_year", e.target.value ? Number(e.target.value) : "")} placeholder="e.g. 2023" className="rounded-none h-11 font-body" />
          </Field>
          {/* Searchable Category */}
          <Field label="Category">
            <SearchableInput
              value={form.category || ""}
              onChange={(v) => update("category", v)}
              suggestions={CATEGORIES}
              placeholder="e.g. Floral, Oriental"
            />
          </Field>
        </div>

        {/* متوقّف الإنتاج Discontinued */}
        <Field label="الحالة Status">
          <button
            type="button"
            onClick={() => update("discontinued", !form.discontinued)}
            className="w-full flex items-center justify-between rounded-none h-11 px-4 border border-input bg-transparent hover:bg-secondary/30 transition-colors"
          >
            <span className="text-sm font-body">{isAr ? "متوقّف عن الإنتاج" : "Discontinued"}</span>
            <span className={`w-10 h-5 rounded-none transition-colors relative flex-shrink-0 ${form.discontinued ? "bg-red-500" : "bg-border"}`}>
              <span className={`absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all ${form.discontinued ? "left-5" : "left-0.5"}`} />
            </span>
          </button>
        </Field>

        {/* أفضل العقد Best of decade */}
        <Field label="أفضل العقد Best of decade">
          <button
            type="button"
            onClick={() => update("best_of_decade", !form.best_of_decade)}
            className="w-full flex items-center justify-between rounded-none h-11 px-4 border border-input bg-transparent hover:bg-secondary/30 transition-colors"
          >
            <span className="text-sm font-body">{isAr ? "حاصل على أفضل العقد" : "Best of decade"}</span>
            <span className={`w-10 h-5 rounded-none transition-colors relative flex-shrink-0 ${form.best_of_decade ? "bg-[#3B6D11]" : "bg-border"}`}>
              <span className={`absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all ${form.best_of_decade ? "left-5" : "left-0.5"}`} />
            </span>
          </button>
        </Field>

        {/* Odor Family — العائلة العطرية */}
         <Field label="العائلة العطرية Odor Family (optional)">
           <OdorFamilySelect 
             selected={form.odor_family || ""}
             onChange={(val) => update("odor_family", val)}
             placeholder={isAr ? "ابحث عن عائلات" : "Search families.."}
           />
         </Field>

        {/* Occasions — perfume info */}
        <Field label="Occasions (perfume info)">
          <div className="flex flex-wrap gap-2">
            {OCCASIONS.map(({ value, emoji, en, ar }) => {
              const selected = (form.occasions || "").split(",").map(s => s.trim()).includes(value);
              return (
                <button
                  key={value}
                  type="button"
                  onClick={() => {
                    const arr = (form.occasions || "").split(",").map(s => s.trim()).filter(Boolean);
                    const next = selected ? arr.filter(a => a !== value) : [...arr, value];
                    update("occasions", next.join(", "));
                  }}
                  className={`px-2 py-1 border rounded-none text-xs font-body font-medium transition-all inline-flex items-center gap-1 ${
 selected
 ? "bg-primary/10 border-primary text-primary"
 : "bg-secondary/40 border-border/50 text-muted-foreground"
 }`}
                >
                  <span>{emoji}</span><span>{isAr ? ar : en}</span>
                </button>
              );
            })}
          </div>
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="ML">
            <Input type="number" value={form.ml} onChange={(e) => update("ml", e.target.value)} placeholder="100" className="rounded-none h-11 font-body" />
          </Field>
          <Field label={isAr ? "السعر" : "Price"}>
            <Input type="number" step="0.01" value={form.price} onChange={(e) => update("price", e.target.value)} placeholder="99.99" className="rounded-none h-11 font-body" />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Season">
            <Select value={form.season} onValueChange={(v) => update("season", v)}>
              <SelectTrigger className="rounded-none h-11 font-body"><SelectValue placeholder={isAr ? "اختر" : "Select"} /></SelectTrigger>
              <SelectContent>
                {["Spring","Summer","Fall","Winter","All Seasons"].map(s => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Price Range">
            <Select value={form.price_range} onValueChange={(v) => update("price_range", v)}>
              <SelectTrigger className="rounded-none h-11 font-body"><SelectValue placeholder={isAr ? "اختر" : "Select"} /></SelectTrigger>
              <SelectContent>
                {["$","$$","$$$","$$$$"].map(p => (
                  <SelectItem key={p} value={p}>{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
        </div>

        <Button type="submit" className="w-full h-12 rounded-none font-body text-base" disabled={isSaving}>
          {isSaving ? "Saving.." : editingPerfume ? "Save Changes" : "Add to Collection"}
        </Button>

        {editingPerfume && (
          <div className="pt-1 space-y-1 border-t border-border/40">
            <Button
              type="button"
              variant="ghost"
              className="w-full rounded-none font-body"
              style={{ color: "#9a7b1f" }}
              onClick={async () => {
                try {
                  await apphost.entities.Perfume.update(editingPerfume.id, { hidden: true });
                  queryClient.invalidateQueries({ queryKey: ["perfumes"] });
                  toast.success(isAr ? "نُقل إلى المهملات" : "Moved to Cast Away");
                  navigate("/perfumes");
                } catch {
                  toast.error(isAr ? "تعذّر النقل" : "Failed");
                }
              }}
            >
              {isAr ? "نقل إلى المهملات" : "Cast away"}
            </Button>
            <Button
              type="button"
              variant="ghost"
              className="w-full rounded-none font-body text-destructive hover:text-destructive"
              onClick={async () => {
                const nm = editingPerfume.name_en || editingPerfume.name_ar || editingPerfume.name || "";
                if (!window.confirm(isAr ? `حذف "${nm}" نهائياً؟ لا يمكن التراجع.` : `Delete "${nm}" permanently? This cannot be undone.`)) return;
                try {
                  await apphost.entities.Perfume.delete(editingPerfume.id);
                  queryClient.invalidateQueries({ queryKey: ["perfumes"] });
                  toast.success(isAr ? "تم حذف العطر" : "Perfume deleted");
                  navigate("/perfumes");
                } catch {
                  toast.error(isAr ? "فشل الحذف" : "Delete failed");
                }
              }}
            >
              {isAr ? "حذف العطر نهائياً" : "Delete permanently"}
            </Button>
          </div>
        )}
      </form>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-body font-medium text-muted-foreground uppercase tracking-wider">{label}</Label>
      {children}
    </div>
  );
}
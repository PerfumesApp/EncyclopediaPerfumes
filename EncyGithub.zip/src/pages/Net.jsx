import { useState, useCallback } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ChevronDown } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import { OCCASIONS } from "@/lib/occasions";
import { BRAND_CATEGORIES } from "@/lib/brandCategories";
import BackIcon from "@/components/shared/BackIcon";

// شبكة عطور و ماركات (Perfume and Brand Net) — بديل /at الثقيلة.
// مبدأ A: الأبعاد تُعرض كعناوين بلا أيّ تحميل؛ عند فتح بُعد تُحمّل قيمه كسولاً؛
// نقر القيمة يفتح صفحة النتائج الموحّدة (تحميل كسول حسب النوع، بلا مسح 130 ألف).

const ENC_SECTIONS = [
  { en: "Stories", ar: "قصص" },
  { en: "Quotes", ar: "اقتباسات" },
  { en: "Marking", ar: "علامة" },
  { en: "Vocabulary", ar: "مصطلحات" },
  { en: "Library", ar: "مكتبة" },
  { en: "Poems", ar: "قصائد" },
  { en: "Figures", ar: "شخصيات" },
];

export default function Net() {
  const navigate = useNavigate();
  const { lang } = useLang();
  const isAr = lang === "ar";

  // الأبعاد: ساكنة (فورية) أو كسولة (تُحمّل عند الفتح)
  const [open, setOpen] = useState({});
  const [vals, setVals] = useState({});   // { dimKey: [{en, ar, q}] }
  const [busy, setBusy] = useState({});
  const [shown, setShown] = useState({});   // { dimKey: count } — عرض تدريجي كسول
  const STEP = 80;

  const go = useCallback((q) => {
    if (q) navigate(`/search-results?q=${encodeURIComponent(q)}`);
  }, [navigate]);

  // محمّلات كسولة خفيفة (لا مسح 130 ألف)
  const lazyLoaders = {
    notes: async () => {
      const rows = await apphost.entities.PerfumeNote.list("name", 100000);
      return (rows || [])
        .map((n) => ({ en: n.name || n.name_en || "", ar: n.name_ar || n.name || "", q: n.name || n.name_ar }))
        .filter((x) => x.en || x.ar);
    },
    country: async () => {
      const rows = await apphost.entities.PerfumeBrand.list("name", 100000);
      const seen = new Set();
      const out = [];
      for (const b of rows || []) {
        const c = (b.country || "").trim();
        if (c && !seen.has(c.toLowerCase())) {
          seen.add(c.toLowerCase());
          out.push({ en: c, ar: b.country_ar || c, q: c });
        }
      }
      return out.sort((a, b) => a.en.localeCompare(b.en));
    },
  };

  const toggle = useCallback(async (key) => {
    setOpen((o) => ({ ...o, [key]: !o[key] }));
    if (!vals[key] && lazyLoaders[key]) {
      setBusy((b) => ({ ...b, [key]: true }));
      try {
        const list = await lazyLoaders[key]();
        setVals((v) => ({ ...v, [key]: list }));
      } catch {
        setVals((v) => ({ ...v, [key]: [] }));
      } finally {
        setBusy((b) => ({ ...b, [key]: false }));
      }
    }
  }, [vals]); // eslint-disable-line react-hooks/exhaustive-deps

  // الأبعاد الساكنة تُهيّأ فوراً
  const staticVals = {
    occasions: OCCASIONS.map((o) => ({ en: o.en, ar: o.ar, q: isAr ? o.ar : o.en })),
    types: BRAND_CATEGORIES.map((c) => ({ en: c.en, ar: c.ar, cat: c.key })),
    sections: ENC_SECTIONS.map((s) => ({ en: s.en, ar: s.ar, q: isAr ? s.ar : s.en })),
  };

  const DIMS = [
    { key: "occasions", en: "Occasions", ar: "مناسبات", color: "#9D174D" },
    { key: "types", en: "Types & Categories", ar: "أنواع و فئات", color: "#27406B" },
    { key: "notes", en: "Notes", ar: "نوتات", color: "#2F6B4F" },
    { key: "country", en: "Countries", ar: "دول", color: "#9a7b1f" },
    { key: "sections", en: "Encyclopedia Sections", ar: "أقسام الموسوعة", color: "var(--brand)" },
  ];

  return (
    <div className="px-5 page-top pb-24 space-y-5" dir={isAr ? "rtl" : "ltr"}>
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => navigate(-1)} aria-label="back" className="hover:opacity-70 transition-opacity">
          <BackIcon className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        <div>
          <h1 className="font-heading text-lg" style={{ color: "var(--brand)" }}>
            {isAr ? "شبكة عطور و ماركات" : "Perfume and Brand Net"}
          </h1>
        </div>
      </div>

      <div className="space-y-3">
        {DIMS.map((d) => {
          const isOpen = !!open[d.key];
          const list = staticVals[d.key] || vals[d.key] || [];
          const loading = !!busy[d.key];
          return (
            <div key={d.key}>
              <button type="button" onClick={() => toggle(d.key)}
                className="w-full flex items-center justify-between gap-2 py-2 font-body font-semibold transition-opacity hover:opacity-70"
                style={{ color: d.color }}>
                <span>{isAr ? d.ar : d.en}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? "rotate-180" : ""}`} />
              </button>
              {isOpen && (
                <div className="flex flex-wrap gap-x-4 gap-y-2 ps-1 pb-2">
                  {loading && <span className="text-xs text-muted-foreground font-body">..</span>}
                  {!loading && list.length === 0 && (
                    <span className="text-xs text-muted-foreground font-body">{isAr ? "لا قيم" : "No values"}</span>
                  )}
                  {!loading && list.slice(0, shown[d.key] || STEP).map((it, i) => (
                    <button key={i} type="button" onClick={() => it.cat ? navigate(`/search-results?cat=${encodeURIComponent(it.cat)}`) : go(it.q)}
                      className="text-xs font-body text-muted-foreground hover:opacity-70 transition-opacity">
                      {isAr ? (it.ar || it.en) : (it.en || it.ar)}
                    </button>
                  ))}
                  {!loading && list.length > (shown[d.key] || STEP) && (
                    <button type="button" onClick={() => setShown((s) => ({ ...s, [d.key]: (s[d.key] || STEP) + STEP }))}
                      className="text-xs font-body font-semibold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
                      {isAr ? "المزيد" : "More"}
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="pt-2">
        <Link to="/encyclopedia" className="text-xs font-body" style={{ color: "var(--brand)" }}>
          {isAr ? "الموسوعة" : "Encyclopedia"}
        </Link>
      </div>
    </div>
  );
}

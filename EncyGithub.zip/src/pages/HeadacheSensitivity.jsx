import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import BackIcon from "@/components/shared/BackIcon";

const HEADACHE_LEVELS = [
  { value: "strong", emoji: "🔴", labelEn: "Strong", labelAr: "قوي" },
  { value: "medium", emoji: "🟠", labelEn: "Medium", labelAr: "متوسط" },
  { value: "weak",   emoji: "🟡", labelEn: "Weak",   labelAr: "ضعيف" },
  { value: "none",   emoji: "", labelEn: "None",   labelAr: "لا" },
];

export default function HeadacheSensitivity() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { names } = usePersonNames();

  const { data: userPerfumes = [], isLoading } = useQuery({
    queryKey: ["user-perfumes-headache"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  // Only entries with a headache rating
  const rated = userPerfumes.filter(u => u.headache && u.headache !== "none");

  // Group by level
  const byLevel = HEADACHE_LEVELS.reduce((acc, l) => {
    acc[l.value] = rated.filter(u => u.headache === l.value);
    return acc;
  }, {});

  return (
    <div className="px-5 page-top pb-24 space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-secondary transition-colors">
          <BackIcon className={`w-5 h-5`} />
        </button>
        <div>
          <h1 className="font-heading text-xl font-bold">صداع Headache</h1>
          <p className="text-xs text-muted-foreground font-body">{rated.length} perfume{rated.length !== 1 ? "s" : ""} rated</p>
        </div>
        <button onClick={() => navigate("/headache-guide")} className="ml-auto text-xs font-body font-semibold text-primary border border-primary/40 rounded-none px-3 py-1.5">
          {isAr ? "📖 الدليل والسجلّ" : "📖 Guide & log"}
        </button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : rated.length === 0 ? (
        <div className="text-center py-16 space-y-2">
          <p className="text-4xl">🤕</p>
          <p className="text-sm font-body text-muted-foreground">{isAr ? "لا تقييمات صداع بعد" : "No headache ratings yet."}</p>
          <p className="text-xs font-body text-muted-foreground">{isAr ? "قيّم العطور في صفحة العطر" : "Rate perfumes in the perfume detail page."}</p>
        </div>
      ) : (
        <div className="space-y-6">
          {HEADACHE_LEVELS.filter(l => byLevel[l.value]?.length > 0).map(level => (
            <div key={level.value} className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">{level.emoji}</span>
                <h2 className="font-heading font-semibold text-base">{level.labelAr} — {level.labelEn}</h2>
                <span className="text-xs text-muted-foreground font-body rounded-none">{byLevel[level.value].length}</span>
              </div>
              <div className="space-y-2">
                {byLevel[level.value].map(up => (
                  <button
                    key={up.id}
                    onClick={() => navigate(`/perfume?id=${up.perfume_id}`)}
                    className="w-full flex items-center justify-between bg-card rounded-none p-4 shadow-sm border border-border/50 hover:border-primary/30 transition-all text-left"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-body font-semibold truncate">{up.perfume_name}</p>
                      <p className="text-xs text-muted-foreground font-body truncate">{up.brand_name}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-[10px] font-bold rounded-none ${up.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                        {up.person === "person2" ? names.person2 : names.person1}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
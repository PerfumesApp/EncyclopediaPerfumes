import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { ENC, dispName, dispNameOrdered, langField } from "@/lib/encyclopedia";
import EncOptionsBar from "@/components/encyclopedia/EncOptionsBar";
import { usePersonNames } from "@/lib/usePersonNames";
import BackIcon from "@/components/shared/BackIcon";

// تنسيق السنة: سالب = ق.م، البعيد جداً نصّاً، الافتراضي بعد 2040.
function fmtYear(y, isAr) {
  if (y == null || y === "") return "";
  const n = typeof y === "number" ? y : parseInt(y, 10);
  if (!Number.isFinite(n)) return "";
  if (n < -6000) return isAr ? "التاريخ البعيد" : "The Distant Past";
  if (n < 0) return `${-n}${isAr ? " ق.م" : " BC"}`;
  if (n >= 2040) return isAr ? `${n} افتراضي` : `${n} notional`;
  return String(n);
}

// صفحة الخطوط الزمنية و المصنّفات للموسوعة — منفصلة عن التصفّح الرئيسي.
// التاريخ يظهر هنا فقط. موجّهة القراءة تتولّد تلقائياً من محتوى الموسوعة.
export default function EncyclopediaTimelines() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const location = useLocation();
  // نطاق الصفحة: poems = خطوط الشعر و مصنّفاته فقط (صفحة مستقلة عن القصص)؛ الافتراضي = الباقي بلا شعر.
  const poemsScope = (() => { try { return new URLSearchParams(location.search).get("scope") === "poems"; } catch { return false; } })();
  const { profiles } = usePersonNames();
  const activePerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";
  const userColor = profiles[activePerson]?.color || "var(--brand)";

  const { data: langs = [] } = useQuery({ queryKey: ["enc-langs"], queryFn: () => ENC.Language().list("order", 50), staleTime: 1000 * 30 });
  const { data: sections = [] } = useQuery({ queryKey: ["enc-sections"], queryFn: () => ENC.Section().list("order", 200), staleTime: 1000 * 30 });
  const { data: subs = [] } = useQuery({ queryKey: ["enc-subs-all"], queryFn: () => ENC.Subclass().list("order", 2000), staleTime: 1000 * 30 });
  const { data: lines = [] } = useQuery({ queryKey: ["enc-lines-all"], queryFn: () => ENC.Timeline().list("order", 2000), staleTime: 1000 * 30 });
  const { data: entries = [] } = useQuery({ queryKey: ["enc-fav-entries"], queryFn: () => ENC.Entry().list("-updated_date", 20000), staleTime: 1000 * 10 });
  const [titleOrder, setTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_title_order")) || "ar_en");
  const setTitleOrder = (o) => { setTitleOrderRaw(o); try { localStorage.setItem("enc_title_order", o); } catch { /* تجاهل */ } };
  const [subTitleOrder, setSubTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_sub_title_order")) || "lang");
  const setSubTitleOrder = (o) => { setSubTitleOrderRaw(o); try { localStorage.setItem("enc_sub_title_order", o); } catch { /* تجاهل */ } };
  const [encAccent, setEncAccent] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_accent_color")) || "");
  useEffect(() => {
    const h = () => setEncAccent(localStorage.getItem("enc_accent_color") || "");
    window.addEventListener("enc-accent-change", h);
    return () => window.removeEventListener("enc-accent-change", h);
  }, []);
  const [subSel, setSubSel] = useState({});
  const [clsPage, setClsPage] = useState(0);
  useEffect(() => { setClsPage(0); }, [JSON.stringify(subSel)]);

  const code = isAr ? "ar" : "en";
  const title = (e) => {
    const ar = langField(e.titles, "ar", langs) || ""; const en = langField(e.titles, "en", langs) || "";
    if (!ar || !en) return ar || en || (isAr ? "بلا عنوان" : "Untitled");
    return titleOrder === "en_ar" ? `${en} — ${ar}` : `${ar} — ${en}`;
  };

  // موجّهة القراءة + الخطوط — مرور واحد على المدخلات، محفوظ (أداء: لا إعادة حساب كل رندر).
  const poemsSecId = useMemo(() => { const s = sections.find((x) => x.name_en === "Poems"); return s ? String(s.id) : null; }, [sections]);
  const { lineData, sectionData, subCount } = useMemo(() => {
    const byTimeline = {}, bySection = {}, bySub = {};
    for (const e of entries) {
      const tl = e.timeline_id; if (tl != null && tl !== "") (byTimeline[String(tl)] = byTimeline[String(tl)] || []).push(e);
      const sc = e.section_id; if (sc != null && sc !== "") (bySection[String(sc)] = bySection[String(sc)] || []).push(e);
      const s1 = e.subclass_id; if (s1 != null && s1 !== "") bySub[String(s1)] = (bySub[String(s1)] || 0) + 1;
      const s2 = e.subclass2_id; if (s2 != null && s2 !== "" && String(s2) !== String(s1)) bySub[String(s2)] = (bySub[String(s2)] || 0) + 1;
    }
    // فصل خطوط الشعر عن القصص: في نطاق الشعر نُبقي قسم القصائد فقط، و في الافتراضي نستبعده.
    const inScope = (t) => !poemsSecId ? true : (poemsScope ? String(t.section_id) === poemsSecId : String(t.section_id) !== poemsSecId);
    const vis = lines.filter((t) => !t.hidden && inScope(t));
    const tlPriority = (t) => {
      const nm = `${t.name_ar || t.title_ar || ""} ${t.name_en || t.title_en || ""}`.toLowerCase();
      if (nm.includes("السعودية") || nm.includes("saudi")) return 0;                 // السعودية أولا
      if (nm.includes("الجزيرة") || nm.includes("arabia") || nm.includes("peninsula")) return 1; // ثم الجزيرة العربية
      if (nm.includes("معمورة") || nm.includes("world time") || nm.includes("world-time")) return 2;
      if (nm.includes("بيوت") || nm.includes("house")) return 3;
      return 4;
    };
    const secOrder = {};
    sections.forEach((s) => { secOrder[String(s.id)] = s.order ?? 99; });
    const ld = vis.map((t) => ({
      t,
      items: (byTimeline[String(t.id)] || [])
        .map((e) => ({ e, y: parseInt(e.year, 10) }))
        .sort((a, b) => (Number.isFinite(a.y) ? a.y : 9e9) - (Number.isFinite(b.y) ? b.y : 9e9)),
    })).filter((l) => l.items.length > 0)
      .sort((a, b) => (secOrder[String(a.t.section_id)] ?? 99) - (secOrder[String(b.t.section_id)] ?? 99)
        || tlPriority(a.t) - tlPriority(b.t)
        || (a.t.order ?? 0) - (b.t.order ?? 0));
    const sd = sections
      .filter((s) => !poemsSecId ? true : (poemsScope ? String(s.id) === poemsSecId : String(s.id) !== poemsSecId))
      .map((s) => ({
        s,
        count: (bySection[String(s.id)] || []).length,
        subs: subs.filter((c) => String(c.section_id) === String(s.id)),
      })).filter((x) => x.count > 0 || x.subs.length > 0);
    return { lineData: ld, sectionData: sd, subCount: bySub };
  }, [entries, lines, sections, subs, poemsScope, poemsSecId]);

  const go = (id) => navigate(`/encyclopedia/view/${id}`);
  const empty = entries.length === 0;

  return (
    <div className="px-5 page-top pb-24 space-y-6" style={encAccent ? { "--brand": encAccent } : undefined}>
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>{poemsScope ? (isAr ? "خطوط الشعر" : "Poetry Timelines") : (isAr ? "خطوط و مصنّفات" : "Timelines - Classifications")}</h1>
        <button type="button" onClick={() => navigate("/encyclopedia")}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity" aria-label={isAr ? "رجوع" : "Back"}>
          <BackIcon className={`w-5 h-5`} style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {empty ? (
        <p className="text-sm text-muted-foreground font-body py-10 text-center">{isAr ? "الموسوعة فارغة بعد" : "The encyclopedia is empty yet"}</p>
      ) : (
        <>
          {/* الخطوط الزمنية — كل خطّ تقسيمة رئيسة بصفحته الخاصة (لا تكديس) */}
          {lineData.length > 0 && (
            <section className="space-y-1">
              <h2 className="font-heading text-base font-semibold mb-2" style={{ color: "var(--brand)" }}>{poemsScope ? (isAr ? "خطوط الشعر" : "Poetry Timelines") : (isAr ? "خطوط زمنية" : "Timelines")}</h2>
              {poemsScope && (
                <button type="button" onClick={() => navigate("/encyclopedia?sec=Poems&pall=1")}
                  className="w-full text-start py-2 font-body font-semibold hover:opacity-70 transition-opacity block" style={{ color: "#7C6FB0" }}>
                  {isAr ? "كل العصور — تسلسل زمني شامل" : "All Eras — full chronology"}
                </button>
              )}
              {lineData.map(({ t, items }) => (
                <button key={t.id} type="button" onClick={() => navigate(`/encyclopedia?tl=${t.id}`)}
                  className="w-full flex items-baseline justify-between gap-3 py-1.5 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                  <span className="font-body text-xs min-w-0 truncate" style={{ color: "var(--brand)" }}>{dispNameOrdered(t, titleOrder, isAr)}</span>
                </button>
              ))}
            </section>
          )}

          {/* رابط خطوط الشعر — بنفس تنسيق صفوف الخطوط الأخرى، بلا سهم */}
          {!poemsScope && poemsSecId && (
          <section dir={isAr ? "rtl" : "ltr"}>
            <button type="button" onClick={() => navigate("/encyclopedia/timelines?scope=poems")}
              className="w-full flex items-baseline justify-between gap-3 py-1.5 text-start hover:opacity-70 transition-opacity">
              <span className="font-body text-xs min-w-0 truncate" style={{ color: "var(--brand)" }}>{isAr ? "خطوط الشعر" : "Poetry Timelines"}</span>
            </button>
          </section>
          )}

          {/* المصنّفات — كل محور كتلة أنيقة: خطّ بلون المستخدم تحت العنوان + عدّ لطيف لكل فرعيّة */}
          <section className="space-y-4">
            <h2 className="font-heading text-base font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "مصنّفات" : "Classifications"}</h2>
            {(() => {
              const AXIS = [
                { key: "kind", label: isAr ? "النوع" : "Kind" },
                { key: "era", label: isAr ? "العصر" : "Era" },
                { key: "nationality", label: isAr ? "الجنسية" : "Nationality" },
                { key: "poemtype", label: isAr ? "نوع القصيدة" : "Poem Type" },
                { key: "structure", label: isAr ? "البنية" : "Structure" },
                { key: "region", label: isAr ? "المنطقة" : "Region" },
                { key: "category", label: isAr ? "الفئة" : "Category" },
                { key: "field", label: isAr ? "الحقل" : "Field" },
              ];
              const TAG_AXES = new Set(["poemtype", "structure", "meter", "gender"]);
              const POEM_AXES = new Set(["era", "nationality", "poemtype", "structure"]);
              // إخفاء التصنيفات الفارغة (مثل fig_* المكررة بلا مداخل). أقسام الوسوم (شعر) تُطابَق بالوسوم لا بالمفتاح فتُستثنى.
              const usedSubKeys = new Set();
              entries.forEach((e) => { if (e.subclass_key) usedSubKeys.add(String(e.subclass_key)); if (e.subclass2_key) usedSubKeys.add(String(e.subclass2_key)); });
              const byAxis = {};
              subs.forEach((c) => {
                const a = c.axis || "other";
                if (entries.length && !TAG_AXES.has(a) && !usedSubKeys.has(String(c.key))) return;
                (byAxis[a] = byAxis[a] || []).push(c);
              });
              const present = AXIS.filter((a) => byAxis[a.key] && byAxis[a.key].length)
                .filter((a) => poemsScope ? POEM_AXES.has(a.key) : !POEM_AXES.has(a.key));
              return present.map((a) => (
                <div key={a.key} className="space-y-1.5">
                  <div className="space-y-1">
                    <p className="text-[11px] font-body font-semibold uppercase tracking-wider" style={{ color: "var(--brand)" }}>{a.label}</p>
                    <div style={{ height: 2, width: 28, background: userColor, opacity: 0.6, borderRadius: 1 }} />
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5" dir={isAr ? "rtl" : "ltr"}>
                    {byAxis[a.key].map((c) => {
                      const toTag = TAG_AXES.has(a.key) && c.key;
                      const href = toTag
                        ? `/encyclopedia?sec=${c.section_id}&tag=${encodeURIComponent(c.key)}`
                        : `/encyclopedia?sub=${encodeURIComponent(c.key || c.id)}`;
                      return (
                        <button key={c.id} type="button" onClick={() => navigate(href)}
                          className="font-body text-xs hover:opacity-70 transition-opacity inline-flex items-baseline gap-1" style={{ color: "var(--brand)" }}>
                          <span>{dispNameOrdered(c, subTitleOrder, isAr)}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ));
            })()}
          </section>

          {/* موجّهة القراءة — رابط فقط بعد المصنّفات؛ الشرح الكامل داخل الصفحة */}
          {!poemsScope && (
          <button type="button" onClick={() => navigate("/reading-guide")}
            className="w-full flex items-baseline gap-2 hover:opacity-70 transition-opacity pt-1" dir={isAr ? "rtl" : "ltr"}>
            <h2 className="font-heading text-base font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "موجّهة القراءة" : "Reading Guide"}</h2>
            <span className="font-body text-xs text-muted-foreground">{isAr ? "الدليل الكامل" : "the full guide"}</span>
          </button>
          )}

          <EncOptionsBar isAr={isAr} titleOrder={titleOrder} setTitleOrder={setTitleOrder} subTitleOrder={subTitleOrder} setSubTitleOrder={setSubTitleOrder} sortMode="newest" setSortMode={() => {}} showSort={false} showSubTitle={true} />
        </>
      )}
    </div>
  );
}

import { useMemo, useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useSearchParams } from "react-router-dom";
import { apphost } from "@/api/apphostClient";
import { getPerfumeTagIndex, ensurePerfumeTagIndexLocal, tagIndexBuildState } from "@/lib/perfumeTagIndex";
import BackButton from "@/components/shared/BackButton";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import {
  buildMentionIndex,
  canonicalize,
  isUnknown,
  attachEntitiesToMentions,
  ENTITY_SECTION,
  ENTITY_PATH,
  entityTitle,
  CATEGORY_COLORS,
  CATEGORY_LABELS,
} from "@/lib/atMentions";

/**
 * /at — Unified Mentions page.
 *
 *   /at                  → Index of every @ mention canonicalised from the
 *                          glossary, deduplicated across languages.
 *
 *   /at?name=Music       → Detail view. Lists every record across the app
 *                          (glossary terms/stories + brands, notes, perfumers,
 *                          quotes, wisdom) whose tag-like fields match any
 *                          alias of the mention. Sections are grouped by type.
 *
 * The mention index is built once from GlossaryTerm.tags (the only entity
 * with a curated `tags` field). Other entities attach via their semantic
 * fields (Note.category, Brand.main_activity, Perfumer.nationality, etc.).
 */
export default function At() {
  const [params] = useSearchParams();
  const requestedName = params.get("name") || "";
  const { isAr } = useLang();

  // Glossary — the index source. Always loaded.
  const { data: glossaryRecs = [], isLoading: glossaryLoading } = useQuery({
    queryKey: ["all-glossary-for-at"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
    staleTime: 1000 * 60 * 10,
  });

  // External entities — loaded only when the detail page is open. The index
  // page prefetches them in the background (low priority) so jumping into a
  // mention feels instant. staleTime is generous (10 min) so jumping between
  // mention details doesn't refetch — the catalogs barely change in a session.
  const needExtras = !!requestedName;
  const EXTRAS_STALE = 1000 * 60 * 10;

  // فهرس وسوم العطور المُسبق (localStorage). إن وُجد، نتجنّب تحميل 130 ألف عطر
  // ونجلب فقط عطور الوسم المطلوب عبر getMany. وإلا نستخدم المسار البديل القديم.
  //  البناء كسول — لا يبنى عند الإقلاع إطلاقا، بل هنا فقط حين
  // يضغط المستخدم وسما (requestedName موجود) و الفهرس غائب/قديم. شريط
  // «جاري تجهيز التطبيق ٪» يعرض تقدمه، و المسار البديل يخدم الصفحة حتى يجهز.
  const [tagIndex, setTagIndex] = useState(() => getPerfumeTagIndex());
  useEffect(() => {
    if (!requestedName) return undefined; // لا بناء قبل الضغط على وسم
    if (tagIndex) return undefined;
    let alive = true;
    ensurePerfumeTagIndexLocal().then((idx) => { if (alive && idx) setTagIndex(idx); }).catch(() => {});
    // استطلاع خفيف أثناء البناء كي تلتقط الصفحة الفهرس فور جهوزه
    const poll = setInterval(() => {
      if (!tagIndexBuildState().building) {
        const idx = getPerfumeTagIndex();
        if (alive && idx) setTagIndex(idx);
        clearInterval(poll);
      }
    }, 2500);
    return () => { alive = false; clearInterval(poll); };
  }, [requestedName]); // eslint-disable-line react-hooks/exhaustive-deps

  const { data: brandRecs = [] } = useQuery({
    queryKey: ["all-brands-for-at"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });
  const { data: noteRecs = [] } = useQuery({
    queryKey: ["all-notes-for-at"],
    queryFn: () => apphost.entities.Note.list("name"),
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });
  const { data: symbolismRecs = [] } = useQuery({
    queryKey: ["all-symbolism-for-at"],
    queryFn: () => apphost.entities.PerfumeSymbolism.list("-created_date", 100000),
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });
  const { data: perfumerRecs = [] } = useQuery({
    queryKey: ["all-perfumers-for-at"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });
  const { data: quoteRecs = [] } = useQuery({
    queryKey: ["all-quotes-for-at"],
    queryFn: () => apphost.entities.Quote.list("-created_date"),
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });
  const { data: wisdomRecs = [] } = useQuery({
    queryKey: ["all-wisdom-for-at"],
    queryFn: () => apphost.entities.Wisdom.list("-created_date"),
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });
  const { data: blogRecs = [] } = useQuery({
    queryKey: ["all-blog-for-at"],
    queryFn: () => apphost.entities.Blog.list("-created_date"),
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });
  // Perfume — the largest catalog (~32K). We load it raw, then slim each
  // matched record to {id, name_en, name_ar, name, brand_name} before
  // storing in the attachment map. With cap=50 per mention, this means at
  // most 50 slim objects per mention even if 5,000 perfumes match —
  // memory-bounded by design.
  const { data: perfumeRecs = [] } = useQuery({
    queryKey: ["all-perfumes-for-at"],
    queryFn: () => apphost.entities.Perfume.list("name_en"),
    enabled: needExtras && !tagIndex,
    staleTime: EXTRAS_STALE,
  });
  // Store — small catalog typically. Attached via country / category.
  const { data: storeRecs = [] } = useQuery({
    queryKey: ["all-stores-for-at"],
    queryFn: async () => {
      try { return await apphost.entities.ShopBrand.list("name"); }
      catch { return []; }
    },
    enabled: needExtras,
    staleTime: EXTRAS_STALE,
  });

  const index = useMemo(() => {
    if (!glossaryRecs.length) return { mentions: [], lookup: new Map(), recordsByCanonical: new Map(), visible: [] };
    const visible = glossaryRecs.filter((r) => !r.hidden);
    return { ...buildMentionIndex(visible), visible };
  }, [glossaryRecs]);

  // حلّ canonicalKey للوسم المطلوب (نفس اشتقاق MentionDetail) لجلب عطوره من الفهرس.
  const reqCanonicalKey = useMemo(() => {
    if (!requestedName || !index.lookup || !index.mentions?.length) return null;
    try {
      const m = canonicalize(requestedName, index.lookup, index.mentions);
      return m ? (m.canonical_en || m.canonical_ar) : null;
    } catch { return null; }
  }, [requestedName, index]);

  const reqPerfumeIds = useMemo(() => {
    if (!tagIndex || !reqCanonicalKey) return [];
    const e = tagIndex.map[reqCanonicalKey];
    return e && Array.isArray(e.ids) ? e.ids : [];
  }, [tagIndex, reqCanonicalKey]);

  // عطور الوسم المطلوب فقط — getMany خفيف بدل تحميل الكتالوج كاملاً.
  const { data: reqPerfumes = [] } = useQuery({
    queryKey: ["at-tag-perfumes", reqCanonicalKey, reqPerfumeIds.length],
    queryFn: () => apphost.entities.Perfume.getMany(reqPerfumeIds),
    enabled: !!tagIndex && reqPerfumeIds.length > 0,
    staleTime: EXTRAS_STALE,
  });

  const externalAttachments = useMemo(() => {
    if (!needExtras || !index.mentions.length) return new Map();
    // Slim picker for Perfume — strip heavyweight fields, keep what /at renders.
    const pickPerfume = (p) => ({
      id: p.id,
      name_en: p.name_en,
      name_ar: p.name_ar,
      name: p.name,
      brand_name: p.brand_name,
    });
    const sources = [
      { entity_type: "PerfumeBrand", records: brandRecs },
      { entity_type: "Note",         records: noteRecs },
      { entity_type: "Symbolism",    records: symbolismRecs, pickRecord: (r) => ({ id: r.id, story_idx: r.story_idx, name_en: r.name_en, name_ar: r.name_ar }) },
      { entity_type: "Perfumer",     records: perfumerRecs },
      { entity_type: "Quote",        records: quoteRecs },
      { entity_type: "Wisdom",       records: wisdomRecs },
      { entity_type: "Blog",         records: blogRecs },
      { entity_type: "Store",        records: storeRecs },
    ];
    // العطور: المسار البديل (تحميل كامل 130 ألف) فقط إن غاب الفهرس المُسبق.
    if (!tagIndex) {
      sources.push({ entity_type: "Perfume", records: perfumeRecs, pickRecord: pickPerfume });
    }
    const map = attachEntitiesToMentions(index, sources);
    // حقن عطور الوسم المطلوب من الفهرس المُسبق — بلا تحميل الكتالوج كاملاً.
    if (tagIndex && reqCanonicalKey && reqPerfumes.length) {
      const entry = tagIndex.map[reqCanonicalKey];
      if (!map.has(reqCanonicalKey)) map.set(reqCanonicalKey, new Map());
      map.get(reqCanonicalKey).set("Perfume", {
        records: reqPerfumes.map(pickPerfume),
        total: entry ? entry.total : reqPerfumes.length,
      });
    }
    return map;
  }, [needExtras, index, brandRecs, noteRecs, symbolismRecs, perfumerRecs, quoteRecs, wisdomRecs, blogRecs, storeRecs, perfumeRecs, tagIndex, reqCanonicalKey, reqPerfumes]);

  if (requestedName) {
    return (
      <MentionDetail
        requestedName={requestedName}
        index={index}
        externalAttachments={externalAttachments}
        isAr={isAr}
        isLoading={glossaryLoading}
      />
    );
  }

  return <MentionIndex mentions={index.mentions} isAr={isAr} isLoading={glossaryLoading} />;
}

function MentionIndex({ mentions, isAr, isLoading }) {
  const [search, setSearch] = useState("");
  const [showUnknown, setShowUnknown] = useState(false);
  const [catFilter, setCatFilter] = useState("all");           // 'all' | one of CATEGORY_LABELS keys
  const [shown, setShown] = useState(20);  // ترقيم: 20 مفردة ثم «تحميل المزيد»
  useEffect(() => { setShown(20); }, [search, catFilter]);

  // Partition mentions into bilingual ("known") and Unknown buckets. Unknown
  // collects everything the clustering algorithm couldn't confidently map
  // across languages: monolingual mentions (only EN or only AR), singletons
  // (no synonyms), and degenerate count-zero entries. Keeping these visible
  // — but in their own section — prevents navigation dead-ends.
  const { known, unknown } = useMemo(() => {
    const k = [], u = [];
    mentions.forEach((m) => (isUnknown(m) ? u : k).push(m));
    return { known: k, unknown: u };
  }, [mentions]);

  // Active categories present in this dataset — used to render only the
  // filter buttons for which we actually have mentions. Sorted alphabetically.
  const activeCats = useMemo(() => {
    const set = new Set();
    known.forEach((m) => { if (m.cat) set.add(m.cat); });
    return [...set].sort();
  }, [known]);

  const matchesQuery = (m, q) => {
    if (!q) return true;
    const hay = [m.canonical_en, m.canonical_ar, ...m.aliases]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
    return hay.includes(q);
  };

  const matchesCat = (m) => catFilter === "all" || m.cat === catFilter;

  const filteredKnown = useMemo(() => {
    const q = search.trim().toLowerCase();
    return known.filter((m) => matchesQuery(m, q) && matchesCat(m));
  }, [known, search, catFilter]);

  const filteredUnknown = useMemo(() => {
    const q = search.trim().toLowerCase();
    // Unknown mentions have no cat — show only when filter is "all".
    if (catFilter !== "all") return [];
    return unknown.filter((m) => matchesQuery(m, q));
  }, [unknown, search, catFilter]);

  // When searching, auto-expand Unknown so matches surface — otherwise the
  // user might wonder where their query went.
  const unknownExpanded = showUnknown || (search.trim() && filteredUnknown.length > 0);

  return (
    <div className="pb-20 page-top px-4 max-w-lg mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <BackButton />
      </div>

      <div className="space-y-1">
        <h1 className="font-heading text-xl text-amber-700" style={{ letterSpacing: "0.02em" }}>
          {isAr ? "كلّ @ في التطبيق" : "Every @ Across The App"}
        </h1>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isAr ? "بحث" : "Search"}
          className="pl-9 pr-9 h-10 rounded-none font-body text-sm bg-white"
          style={{ border: "1px solid #e5e7eb" }}
        />
        
      </div>

      {/* Category filter — shown only when there are active categories.
          Renders the catalog categories present in this dataset; "All" plus
          a colored chip per cat. Tap one to scope the list below. */}
      {activeCats.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => setCatFilter("all")}
            className={`text-[10px] rounded-none font-body transition-all ${catFilter === "all" ? " text-background" : " text-muted-foreground hover:text-foreground"}`}
          >
            {isAr ? "الكل" : "All"}
          </button>
          {activeCats.map((cat) => {
            const color = CATEGORY_COLORS[cat] || "#999";
            const lbl = CATEGORY_LABELS[cat] || { en: cat, ar: cat };
            const active = catFilter === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setCatFilter(active ? "all" : cat)}
                className="text-[10px] px-2 py-1 rounded-none font-body transition-all inline-flex items-center gap-1"
                style={active
                  ? { background: color, color: "#fff" }
                  : { background: "transparent", color }}
              >
                <span className="w-1.5 h-1.5 rotate-45" style={{ background: color }} />
                {isAr ? lbl.ar : lbl.en}
              </button>
            );
          })}
        </div>
      )}

      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-amber-300 border-t-amber-600 rounded-full animate-spin" />
        </div>
      )}

      {!isLoading && filteredKnown.length === 0 && filteredUnknown.length === 0 && (
        <p className="text-center text-xs italic text-muted-foreground py-12 font-body">
          {isAr ? "لا نتائج" : "No results"}
        </p>
      )}

      {/* Known mentions — inline flowing list, no @ prefix, small font, fits
          to screen width via flex-wrap. Each label is its own link, English
          and Arabic shaded differently. A tiny colored dot before the link
          encodes the category (city/person/note/…). Unknown-category
          mentions get no dot. */}
      <div className="flex flex-wrap gap-x-2 gap-y-1.5 items-baseline">
        {filteredKnown.slice(0, shown).map((m) => {
          const slug = encodeURIComponent(m.canonical_en || m.canonical_ar);
          const dotColor = m.cat ? CATEGORY_COLORS[m.cat] : null;
          return (
            <Link
              key={m.id}
              to={`/at?name=${slug}`}
              className="inline-flex items-baseline gap-1 transition-opacity hover:opacity-70"
            >
              {dotColor && (
                <span
                  className="self-center w-1.5 h-1.5 rotate-45 inline-block flex-shrink-0"
                  style={{ background: dotColor }}
                />
              )}
              {m.canonical_en && (
                <span className="font-heading text-xs" style={{ color: "#a16207", fontWeight: 600 }}>
                  {m.canonical_en}
                </span>
              )}
              {m.canonical_ar && (
                <span className="font-body text-xs" dir="rtl" style={{ color: "#78350f" }}>
                  {m.canonical_ar}
                </span>
              )}
            </Link>
          );
        })}
      </div>

      {filteredKnown.length > shown && (
        <button
          type="button"
          onClick={() => setShown((n) => n + 20)}
          className="w-full py-2 text-xs font-body text-amber-700 hover:text-amber-800 transition-colors"
          style={{ borderTop: "1px solid #e5e0d5" }}
        >
          {isAr ? `تحميل المزيد (${filteredKnown.length - shown})` : `Load more (${filteredKnown.length - shown})`}
        </button>
      )}

      {/* Undefined section — folded by default. Same inline-flowing style. */}
      {filteredUnknown.length > 0 && (
        <div className="pt-6">
          <button
            type="button"
            onClick={() => setShowUnknown((v) => !v)}
            className="w-full flex items-center justify-between px-1 py-2 text-[11px] font-body uppercase tracking-wider text-slate-500 hover:text-slate-700 transition-colors"
            style={{ borderTop: "1px dashed #cbd5e1", borderBottom: unknownExpanded ? "none" : "1px dashed #cbd5e1" }}
          >
            <span>
              {isAr ? "غير محدّد" : "Undefined"}
            </span>
            <span className="text-slate-400" style={{ fontSize: "13px" }}>
              {unknownExpanded ? "−" : "+"}
            </span>
          </button>
          {unknownExpanded && (
            <div className="flex flex-wrap gap-x-2 gap-y-1.5 items-baseline pt-3">
              {filteredUnknown.map((m) => {
                const lbl = m.canonical_en || m.canonical_ar;
                const slug = encodeURIComponent(lbl);
                const isAr_label = !m.canonical_en;
                return (
                  <Link
                    key={m.id}
                    to={`/at?name=${slug}`}
                    className="inline-flex transition-opacity hover:opacity-70"
                  >
                    <span
                      className="font-heading text-xs"
                      style={{ color: "#475569", fontWeight: 600 }}
                      dir={isAr_label ? "rtl" : "ltr"}
                    >
                      {lbl}
                    </span>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MentionDetail({ requestedName, index, externalAttachments, isAr, isLoading }) {
  const { mentions, lookup, recordsByCanonical, visible } = index;

  const { mention, linkedRecords, isUnknownMention, externalByType } = useMemo(() => {
    if (!visible || !visible.length) return { mention: null, linkedRecords: [], isUnknownMention: false, externalByType: new Map() };
    const m = canonicalize(requestedName, lookup, mentions);
    const canonicalKey = m.canonical_en || m.canonical_ar;
    const recIndices = recordsByCanonical.get(canonicalKey) || [];
    const linked = recIndices.map((i) => visible[i]).filter(Boolean);
    const extByType = (externalAttachments && externalAttachments.get(canonicalKey)) || new Map();
    return { mention: m, linkedRecords: linked, isUnknownMention: isUnknown(m), externalByType: extByType };
  }, [requestedName, mentions, lookup, recordsByCanonical, visible, externalAttachments]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-6 h-6 border-2 border-amber-300 border-t-amber-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (!mention) {
    return (
      <div className="pt-6 pb-20 px-4 max-w-lg mx-auto space-y-4">
        <BackButton />
        <p className="text-center text-sm italic text-muted-foreground py-12 font-body">
          {isAr ? "لم يُحدَّد المَنشن" : "No mention specified"}
        </p>
      </div>
    );
  }

  const stories = linkedRecords.filter((r) => r.entry_type === "story");
  const terms   = linkedRecords.filter((r) => r.entry_type !== "story");

  const TERM_ACCENT  = "#047857";
  const STORY_ACCENT = "#a16207";
  // Unknown mentions get a neutral slate accent instead of amber — visually
  // signals "still browsable, but not part of the curated bilingual set".
  const accent = isUnknownMention ? "#475569" : "#a16207";

  return (
    <div className="pt-4 pb-20 px-4 max-w-lg mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <BackButton />
        <Link
          to="/at"
          className="text-[10px] hover:underline font-body"
          style={{ color: accent }}
        >
          {isAr ? "العودة إلى آت" : "Back To At"}
        </Link>
      </div>

      <div className="space-y-1">
        <h1 className="flex items-baseline gap-2 flex-wrap" style={{ letterSpacing: "0.02em" }}>
          {mention.cat && CATEGORY_COLORS[mention.cat] && (
            <span
              className="self-center w-2 h-2 rotate-45 inline-block flex-shrink-0"
              style={{ background: CATEGORY_COLORS[mention.cat] }}
              title={CATEGORY_LABELS[mention.cat]?.[isAr ? "ar" : "en"] || mention.cat}
            />
          )}
          {mention.canonical_en && (
            <span className="font-heading text-2xl" style={{ color: accent, fontWeight: 700 }}>
              {mention.canonical_en}
            </span>
          )}
          {mention.canonical_ar && (
            <span className="font-body text-lg" dir="rtl" style={{ color: accent, opacity: 0.78, fontWeight: 600 }}>
              {mention.canonical_ar}
            </span>
          )}
          {mention.cat && CATEGORY_LABELS[mention.cat] && (
            <span
              className="text-[10px] font-body uppercase tracking-wider"
              style={{ color: CATEGORY_COLORS[mention.cat], opacity: 0.8 }}
            >
              {isAr ? CATEGORY_LABELS[mention.cat].ar : CATEGORY_LABELS[mention.cat].en}
            </span>
          )}
        </h1>
      </div>

      {/* Unknown banner removed — no explanation text in either language. */}

      {linkedRecords.length === 0 && !isUnknownMention && (
        <p className="text-center text-xs italic text-muted-foreground py-12 font-body">
          {isAr ? "لا مدخلات" : "No entries"}
        </p>
      )}

      {stories.length > 0 && (
        <div className="space-y-2.5">
          <p className="text-[10px] font-body uppercase tracking-wider" style={{ color: STORY_ACCENT }}>
            {isAr ? "حكايا" : "Stories"}
          </p>
          {stories.map((r) => (
            <Link
              key={r.id}
              to={`/glossary-term?id=${r.id}`}
              className="block transition-opacity hover:opacity-70"
            >
              <div className="flex items-baseline gap-2 flex-wrap">
                {r.term_en && (
                  <span className="font-heading text-sm" style={{ color: STORY_ACCENT, fontWeight: 600 }}>
                    {r.term_en}
                  </span>
                )}
                {r.term_ar && (
                  <span className="font-body text-xs text-amber-900/80" dir="rtl">
                    {r.term_ar}
                  </span>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}

      {terms.length > 0 && (
        <div className="space-y-2.5">
          <p className="text-[10px] font-body uppercase tracking-wider" style={{ color: TERM_ACCENT }}>
            {isAr ? "مصطلحات" : "Terms"}
          </p>
          {terms.map((r) => (
            <Link
              key={r.id}
              to={`/glossary-term?id=${r.id}`}
              className="block transition-opacity hover:opacity-70"
            >
              <div className="flex items-baseline gap-2 flex-wrap">
                {r.term_en && (
                  <span className="font-heading text-sm" style={{ color: TERM_ACCENT, fontWeight: 600 }}>
                    {r.term_en}
                  </span>
                )}
                {r.term_ar && (
                  <span className="font-body text-xs text-emerald-900/80" dir="rtl">
                    {r.term_ar}
                  </span>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* External entity sections — Brands, Notes, Perfumers, Quotes, Wisdom.
          Each section uses its own accent color and links to that entity's
          detail page. Records here come from cross-entity attachment, not
          from the glossary index itself. Capped at 50 per section in the
          attachment pass — matches the rest of the app's pagination size. */}
      {[...externalByType.entries()]
        .sort((a, b) => b[1].total - a[1].total)
        .map(([entityType, bucket]) => {
          const section = ENTITY_SECTION[entityType];
          if (!section || !bucket || !bucket.records.length) return null;
          const pathFn = ENTITY_PATH[entityType] || (() => "#");
          const shown = bucket.records;
          const overflow = Math.max(0, bucket.total - shown.length);
          return (
            <div key={entityType} className="space-y-2.5">
              <p className="text-[10px] font-body uppercase tracking-wider" style={{ color: section.color }}>
                {isAr ? section.ar : section.en}
              </p>
              {shown.map((r, i) => {
                const titleEn = entityTitle(entityType, r, false);
                const titleAr = entityTitle(entityType, r, true);
                // Perfumes show their brand as a faint subtitle to disambiguate
                // common names like "Eau de Parfum" or "Original" across brands.
                const subtitle = entityType === "Perfume" ? r.brand_name : null;
                return (
                  <Link
                    key={r.id || i}
                    to={pathFn(r)}
                    className="block transition-opacity hover:opacity-70"
                  >
                    <div className="flex items-baseline gap-2 flex-wrap">
                      {titleEn && (
                        <span className="font-heading text-sm" style={{ color: section.color, fontWeight: 600 }}>
                          {titleEn.length > 60 ? titleEn.slice(0, 60) + "…" : titleEn}
                        </span>
                      )}
                      {titleAr && titleAr !== titleEn && (
                        <span className="font-body text-xs opacity-80" dir="rtl" style={{ color: section.color }}>
                          {titleAr.length > 60 ? titleAr.slice(0, 60) + "…" : titleAr}
                        </span>
                      )}
                      {subtitle && (
                        <span className="font-body text-[10px] text-muted-foreground/70">
                          {subtitle}
                        </span>
                      )}
                    </div>
                  </Link>
                );
              })}
              {overflow > 0 && (
                <p className="text-[10px] italic text-muted-foreground font-body">
                  {isAr ? `${overflow} أخرى` : `${overflow} more`}
                </p>
              )}
            </div>
          );
        })}
    </div>
  );
}

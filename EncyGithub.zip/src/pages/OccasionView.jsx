import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { useNavigate } from "react-router-dom";
import { ArrowDownUp, AArrowUp, AArrowDown } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import PerfumeCard from "@/components/perfume/PerfumeCard";

import { OCCASIONS, occasionInfo } from "@/lib/occasions";
import { useOccasionMode, fmtOcc } from "@/lib/useOccasionMode";
import { searchIndexReady, perfumeIdsByOccasion } from "@/lib/searchIndex";
import BackIcon from "@/components/shared/BackIcon";

const OCCASION_LABELS = Object.fromEntries(OCCASIONS.map((o) => [o.value, { en: o.en, ar: o.ar }]));

const PER_PAGE = 25;

export default function OccasionView() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const occ = new URLSearchParams(window.location.search).get("o") || "";
  const [sortMode, setSortMode] = useState("year");
  const [page, setPage] = useState(0);
  const [occMode] = useOccasionMode();

  const occIndexReady = searchIndexReady();
  const { data: occIds = [], isFetched: occIdsFetched } = useQuery({
    queryKey: ["occ-ids", occ],
    queryFn: async () => (await perfumeIdsByOccasion(occ)).ids,
    enabled: occIndexReady && !!occ,
    staleTime: Infinity,
  });
  const useIndex = occIndexReady && occIds.length > 0;
  const { data: occPerfumes = [], isLoading: occLoading } = useQuery({
    queryKey: ["occ-perfumes", occ, occIds.length],
    queryFn: () => apphost.entities.Perfume.getMany(occIds),
    enabled: useIndex,
    staleTime: Infinity,
  });
  // سقوط للقائمة الكاملة: الفهرس غير جاهز، أو جاهز بلا دلو لهذه المناسبة (فهرس قديم/بلا مطابقات)
  const needFull = !occIndexReady || (occIndexReady && occIdsFetched && occIds.length === 0);
  const { data: allPerfumes = [], isLoading: fullLoading } = useAllPerfumes("-created_date", { enabled: needFull });
  const isLoading = useIndex ? occLoading : needFull ? fullLoading : (occIndexReady && !occIdsFetched);

  const label = OCCASION_LABELS[occ];
  const occInfo = occasionInfo(occ);
  const title = occInfo ? fmtOcc(occInfo, occMode, { isAr }) : (label ? (isAr ? label.ar : label.en) : occ);

  const matching = useIndex
    ? occPerfumes
    : allPerfumes.filter((p) =>
        (p.occasions || "")
          .split(",")
          .map((o) => o.trim())
          .includes(occ)
      );

  const sorted = [...matching].sort((a, b) => {
    if (sortMode === "alpha_asc" || sortMode === "alpha_desc") {
      const an = (a.name_en || a.name || "").trim(), bn = (b.name_en || b.name || "").trim();
      const isEng = (s) => /^[A-Za-z]/.test(s);
      const ar = isEng(an) ? 0 : 1, br = isEng(bn) ? 0 : 1;
      if (ar !== br) return ar - br;
      const cmp = an.localeCompare(bn, "en", { sensitivity: "base", numeric: true });
      return sortMode === "alpha_desc" ? -cmp : cmp;
    }
    if (sortMode === "type") return (a.type || "").localeCompare(b.type || "");
    // الافتراضي: الأقدم إصداراً أولاً — العطور بلا سنة تنزل للأسفل
    if (a.release_year && b.release_year) return a.release_year - b.release_year;
    if (a.release_year) return -1;
    if (b.release_year) return 1;
    return 0;
  });

  const totalPages = Math.ceil(sorted.length / PER_PAGE);
  const pageItems = sorted.slice(page * PER_PAGE, (page + 1) * PER_PAGE);

  return (
    <div className="page-top min-h-screen bg-background max-w-full overflow-x-hidden">
      <div className="relative bg-background border-b border-border pt-14 pb-6 px-5">
        <button onClick={() => navigate(-1)} className="absolute top-10 left-4 rounded-none p-2 hover:bg-secondary">
          <BackIcon className="w-5 h-5" />
        </button>
        <h1 className="font-heading font-bold text-xl text-center mt-2">{title}</h1>
      </div>

      <div className="px-5 py-5 space-y-4">
        {/* sort */}
        <div className="flex items-center justify-center gap-1.5">
          <ArrowDownUp className="w-3.5 h-3.5 text-primary" />
          {[
            { id: "year", ar: "الإصدار", en: "Release" },
            { id: "type", ar: "النوع", en: "Type" },
          ].map((s) => (
            <button key={s.id} onClick={() => { setSortMode(s.id); setPage(0); }}
              className={`text-[10px] rounded-none ${sortMode === s.id ? " text-background" : " text-muted-foreground"}`}>
              {isAr ? s.ar : s.en}
            </button>
          ))}
          {[
            { id: "alpha_asc", Icon: AArrowUp, ar: "أبجدي تصاعدي", en: "A → Z" },
            { id: "alpha_desc", Icon: AArrowDown, ar: "أبجدي تنازلي", en: "Z → A" },
          ].map((s) => (
            <button key={s.id} onClick={() => { setSortMode(s.id); setPage(0); }}
              title={isAr ? s.ar : s.en} aria-label={isAr ? s.ar : s.en}
              className={`p-1 rounded-none transition-colors ${sortMode === s.id ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              <s.Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : sorted.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground font-body py-10">
            {isAr ? "لا توجد عطور لهذه المناسبة" : "No perfumes for this occasion"}
          </p>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3">
              {pageItems.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
            </div>
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-3 pt-2">
                <button disabled={page === 0} onClick={() => setPage((n) => Math.max(0, n - 1))}
                  className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "السابق" : "Prev"}</button>
                <span className="text-xs text-muted-foreground">{page + 1} / {totalPages}</span>
                <button disabled={page >= totalPages - 1} onClick={() => setPage((n) => Math.min(totalPages - 1, n + 1))}
                  className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "التالي" : "Next"}</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

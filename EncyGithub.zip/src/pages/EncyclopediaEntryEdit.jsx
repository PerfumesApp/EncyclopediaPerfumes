import { useState, useEffect, useMemo, useRef } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { Trash2, X, Upload, BookOpen } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { ENC, dispName } from "@/lib/encyclopedia";
import { listBookFiles, importBookFiles } from "@/lib/libraryFiles";
import BackIcon from "@/components/shared/BackIcon";

// محرّر مدخل الموسوعة — صفحة قائمة بذاتها (لا حوار منبثق)، fit-to-screen.
// الحقول الموحّدة: عنوان/نص/صورة لكل لغة + شرح/سنة/نطق/مصدر/إشارات/وسوم،
// و ربط صريح بقسم + تصنيف فرعي + خط زمني (بالمعرّف، لا عبر الوسوم).
const EMPTY = { section_id: null, subclass_id: null, subclass2_id: null, timeline_id: null, year: "", titles: {}, texts: {}, images: [], explain: "", pronunciation: "", source: "", refs: "", tags: "", figure_key: "", figure_ar: "", figure_en: "", gender: "", library: null };

// محلّل «التقاط و تعبئة»: ينظّف ترويسة ردّ الذكاء (تحية/ماركداون/تسميات)
// و يفصل اللغتين بالنصّ ثم يجعل أول سطر لكل لغة عنواناً و الباقي محتوى.
function parseCaptured(raw) {
  if (!raw || !raw.trim()) return null;
  let t = raw.replace(/\r/g, "").replace(/```[^\n]*\n?/g, "");
  let lines = t.split("\n").map((l) =>
    l.replace(/^#{1,6}\s*/, "")
     .replace(/\*\*/g, "").replace(/__/g, "")
     .replace(/^\s*[-*]\s+/, "").replace(/^\s*>\s*/, "").replace(/`/g, "")
     .replace(/^\s*(english title|arabic title|english|arabic|title|content|story|عنوان عربي|عنوان إنجليزي|عنوان انجليزي|العنوان|العربية|الإنجليزية|الانجليزية|النص|المحتوى|قصة)\s*[:：]\s*/i, "")
     .trim()
  );
  const chatter = /^(sure|certainly|of course|here['\u2019s]*( is| are)?|absolutely|enjoy|let me know|i hope|hope you|feel free|بالطبع|إليك|اليك|هذه القصة|هاك|تفضل|بكل سرور|حسنا|طبعا|سأكتب|سوف أكتب|أتمنى|اتمنى|آمل|إن أردت|ان اردت|هل تريد|أخبرني|اخبرني)\b/i;
  while (lines.length && (!lines[0] || chatter.test(lines[0]))) lines.shift();
  while (lines.length && (!lines[lines.length - 1] || chatter.test(lines[lines.length - 1]))) lines.pop();
  const arN = (x) => (x.match(/[\u0600-\u06FF]/g) || []).length;
  const enN = (x) => (x.match(/[A-Za-z]/g) || []).length;
  const ar = [], en = [];
  for (const l of lines) { if (!l) continue; if (arN(l) >= enN(l) && arN(l) > 0) ar.push(l); else if (enN(l) > 0) en.push(l); }
  const head = (a) => (a.length ? a[0] : "");
  const body = (a) => a.slice(1).join("\n\n");
  return { titleEn: head(en), titleAr: head(ar), textEn: body(en), textAr: body(ar) };
}

export default function EncyclopediaEntryEdit() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { id } = useParams();
  const [sp] = useSearchParams();
  const presetSection = sp.get("section");
  const isEdit = !!id;

  const [form, setForm] = useState({ ...EMPTY, section_id: presetSection || null });
  const [linkLine, setLinkLine] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [capture, setCapture] = useState("");
  const fillFromCapture = () => {
    const r = parseCaptured(capture);
    if (!r) return;
    setForm((f) => ({
      ...f,
      titles: { ...f.titles, ...(r.titleEn ? { en: r.titleEn } : {}), ...(r.titleAr ? { ar: r.titleAr } : {}) },
      texts: { ...f.texts, ...(r.textEn ? { en: r.textEn } : {}), ...(r.textAr ? { ar: r.textAr } : {}) },
    }));
  };
  const [loaded, setLoaded] = useState(!isEdit);

  // كتب الجهاز المؤرشفة (PDF/EPUB) لإرفاقها بمدخل المكتبة + رفع جديد
  const [books, setBooks] = useState([]);
  const [bookBusy, setBookBusy] = useState(false);
  const [showBookPick, setShowBookPick] = useState(false);
  const bookInputRef = useRef(null);
  const refreshBooks = async () => { try { setBooks(await listBookFiles()); } catch { setBooks([]); } };
  useEffect(() => { refreshBooks(); }, []);
  const onPickBookFiles = async (e) => {
    const files = e.target.files; if (!files || !files.length) return;
    setBookBusy(true);
    try {
      const added = await importBookFiles(files);
      await refreshBooks();
      const first = Array.isArray(added) ? added[0] : added;
      if (first?.id) up({ library: { ...(form.library || {}), file_id: first.id, media_type: (form.library && form.library.media_type) || "book" } });
    } catch { /* تجاهل */ }
    finally { setBookBusy(false); if (bookInputRef.current) bookInputRef.current.value = ""; }
  };

  const { data: langs = [] } = useQuery({ queryKey: ["enc-langs"], queryFn: () => ENC.Language().list("order", 50), staleTime: 1000 * 30 });
  const { data: sections = [] } = useQuery({ queryKey: ["enc-sections"], queryFn: () => ENC.Section().list("order", 200), staleTime: 1000 * 30 });
  const { data: subs = [] } = useQuery({ queryKey: ["enc-subs", form.section_id], queryFn: () => ENC.Subclass().filter({ section_id: form.section_id }, "order", 200), enabled: !!form.section_id, staleTime: 1000 * 30 });
  const { data: lines = [] } = useQuery({ queryKey: ["enc-lines", form.section_id], queryFn: () => ENC.Timeline().filter({ section_id: form.section_id }, "order", 200), enabled: !!form.section_id, staleTime: 1000 * 30 });

  // تحميل المدخل للتعديل
  useEffect(() => {
    if (!isEdit) return;
    let alive = true;
    (async () => {
      try {
        const e = await ENC.Entry().get(Number(id));
        if (alive && e) {
          setForm({ ...EMPTY, ...e, titles: e.titles || {}, texts: e.texts || {}, images: Array.isArray(e.images) ? e.images : (e.images && typeof e.images === "object" ? Object.values(e.images).filter(Boolean) : []) });
          setLinkLine(!!e.timeline_id);
        }
      } catch { /* تجاهل */ }
      if (alive) setLoaded(true);
    })();
    return () => { alive = false; };
  }, [id, isEdit]);

  const up = (patch) => setForm((f) => ({ ...f, ...patch }));
  const upMap = (key, code, val) => setForm((f) => ({ ...f, [key]: { ...f[key], [code]: val } }));

  const addImage = (file) => {
    if (!file) return;
    const r = new FileReader();
    r.onload = () => setForm((f) => ({ ...f, images: [...(f.images || []), r.result].slice(0, 5) }));
    r.readAsDataURL(file);
  };
  const removeImage = (idx) => setForm((f) => ({ ...f, images: (f.images || []).filter((_, i) => i !== idx) }));

  const save = async () => {
    const payload = { ...form, year: form.year ? String(form.year) : "", timeline_id: linkLine ? form.timeline_id : null };
    try {
      let viewId = id;
      if (isEdit) await ENC.Entry().update(Number(id), payload);
      else { const rec = await ENC.Entry().create({ ...payload, created_date: new Date().toISOString() }); viewId = rec?.id ?? null; }
      ["enc-entries", "enc-fav-entries"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
      if (viewId != null) qc.invalidateQueries({ queryKey: ["enc-entry", String(viewId)] });
      // العودة لصفحة المدخل نفسه بعد الحفظ (لا للموسوعة)
      navigate(viewId != null ? `/encyclopedia/view/${viewId}` : "/encyclopedia");
    } catch { /* تجاهل */ }
  };

  const remove = async () => {
    if (!isEdit) return;
    try { await ENC.Entry().delete(Number(id)); ["enc-entries", "enc-fav-entries"].forEach((k) => qc.invalidateQueries({ queryKey: [k] })); navigate("/encyclopedia"); }
    catch { /* تجاهل */ }
  };

  const sectionName = useMemo(() => dispName(sections.find((s) => String(s.id) === String(form.section_id)), isAr), [sections, form.section_id, isAr]);
  const isLibrarySection = useMemo(() => sections.find((s) => String(s.id) === String(form.section_id))?.name_en === "Library", [sections, form.section_id]);
  const attachedBook = useMemo(() => (form.library?.file_id ? books.find((b) => String(b.id) === String(form.library.file_id)) : null), [books, form.library]);

  if (!loaded) return <div className="px-5 page-top"><p className="text-sm text-muted-foreground font-body py-10">{isAr ? "تحميل" : "Loading"}</p></div>;

  return (
    <div className="px-5 page-top pb-28 space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-xl font-bold" style={{ color: "var(--brand)" }}>
          {isEdit ? (isAr ? "تعديل محتوى" : "Edit content") : (isAr ? "إضافة محتوى" : "New content")}
        </h1>
        <button type="button" onClick={() => navigate("/encyclopedia")}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity" aria-label={isAr ? "رجوع" : "Back"}>
          <BackIcon className={`w-5 h-5`} style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {/* التقاط و تعبئة — الصق ردّ الذكاء فيملأ العناوين و المحتوى باللغتين تلقائياً */}
      {!isEdit && (
        <div className="border border-border/60 p-3 space-y-2">
          <div className="flex items-baseline justify-between gap-2 flex-wrap">
            <p className="text-sm font-body font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "التقاط و تعبئة" : "Capture - Fill"}</p>
            <span className="text-[11px] text-muted-foreground font-body">{isAr ? "الصق ردّ الذكاء — يُنظّف الترويسة و يملأ تلقائياً" : "Paste the AI reply — strips preamble and auto-fills"}</span>
          </div>
          <textarea value={capture} onChange={(e) => setCapture(e.target.value)} rows={4} dir="auto"
            placeholder={isAr ? "الصق هنا النصّ باللغتين" : "Paste the bilingual text here"}
            className="w-full bg-white outline-none border border-border text-sm font-body p-2 resize-y" />
          <div className="flex items-center gap-4">
            <button type="button" onClick={fillFromCapture} disabled={!capture.trim()}
              className="font-body text-sm font-semibold disabled:opacity-40 hover:opacity-70" style={{ color: "var(--brand)" }}>{isAr ? "تعبئة الحقول" : "Fill fields"}</button>
            {capture && <button type="button" onClick={() => setCapture("")} className="font-body text-sm text-muted-foreground hover:opacity-70">{isAr ? "مسح" : "Clear"}</button>}
          </div>
        </div>
      )}

      {/* القسم الرئيسي */}
      <Field label={isAr ? "القسم الرئيسي" : "Main section"}>
        <div className="flex flex-wrap gap-2">
          {sections.map((s) => (
            <button key={s.id} type="button" onClick={() => up({ section_id: s.id, subclass_id: null, subclass2_id: null, timeline_id: null })}
              className="font-body text-xs px-2.5 py-1" style={String(form.section_id) === String(s.id) ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>
              {dispName(s, isAr)}
            </button>
          ))}
          {sections.length === 0 && <span className="text-xs text-muted-foreground font-body">{isAr ? "أضف قسماً من الإعداد أولاً" : "Add a section in Setup first"}</span>}
        </div>
      </Field>

      {/* التصنيف الفرعي — مُنتقٍ لكل محور (محور 1 → subclass_id، محور 2 → subclass2_id) */}
      {subs.length > 0 && (() => {
        const AXIS_LABEL = { kind: isAr ? "النوع" : "Kind", era: isAr ? "العصر" : "Era", nationality: isAr ? "الجنسية" : "Nationality", poemtype: isAr ? "نوع القصيدة" : "Poem Type", structure: isAr ? "البنية" : "Structure", category: isAr ? "الفئة" : "Category", field: isAr ? "الحقل" : "Field", region: isAr ? "المنطقة" : "Region", other: isAr ? "تصنيف" : "Class" };
        const byAxis = {}; subs.forEach((c) => { const a = c.axis || "other"; (byAxis[a] = byAxis[a] || []).push(c); });
        const axisList = ["kind", "era", "nationality", "category", "field", "region", "poemtype", "structure", "other"].filter((a) => byAxis[a] && byAxis[a].length);
        const slots = [["subclass_id", axisList[0]], ["subclass2_id", axisList[1]]].filter(([, a]) => a);
        return slots.map(([slot, ax]) => (
          <Field key={slot} label={`${isAr ? "تصنيف فرعي" : "Sub-class"} — ${AXIS_LABEL[ax] || ""}`}>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => up({ [slot]: null })} className="font-body text-xs px-2.5 py-1" style={!form[slot] ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>{isAr ? "بلا" : "None"}</button>
              {byAxis[ax].map((c) => (
                <button key={c.id} type="button" onClick={() => up({ [slot]: c.id })} className="font-body text-xs px-2.5 py-1" style={String(form[slot]) === String(c.id) ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>{dispName(c, isAr)}</button>
              ))}
            </div>
          </Field>
        ));
      })()}

      {/* شخصية — ملف عام لكل الموسوعة (شاعر/كاتب/قائد…) يربط المدخل بملف الشخصية بدل الوسوم */}
      <Field label={isAr ? "شخصية — ملف عام (شاعر، كاتب، قائد…)" : "Figure — shared profile (poet, writer, leader…)"}>
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <input value={form.figure_ar || ""} onChange={(e) => up({ figure_ar: e.target.value })} dir="rtl"
              placeholder={isAr ? "الاسم عربي" : "Name (AR)"} className="w-full bg-white outline-none border-b border-border text-sm font-body px-1 py-1.5" />
            <input value={form.figure_en || ""} onChange={(e) => up({ figure_en: e.target.value })} dir="ltr"
              placeholder="Name (EN)" className="w-full bg-white outline-none border-b border-border text-sm font-body px-1 py-1.5" />
          </div>
          <input value={form.figure_key || ""} onChange={(e) => up({ figure_key: e.target.value.trim().toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") })} dir="ltr"
            placeholder={isAr ? "مُعرّف الشخصية (إنجليزي بلا فراغ) — يجمع كل مدخلاتها" : "figure key (slug) — groups all their entries"} className="w-full bg-white outline-none border-b border-border text-xs font-body px-1 py-1.5" />
          <div className="flex items-center gap-3" dir={isAr ? "rtl" : "ltr"}>
            <span className="text-[11px] font-body text-muted-foreground">{isAr ? "الجنس" : "Gender"}</span>
            <button type="button" onClick={() => up({ gender: form.gender === "male" ? "" : "male" })} className="font-body text-xs px-2 py-0.5" style={form.gender === "male" ? { color: "#2563EB", fontWeight: 700 } : { color: "#2563EB", opacity: 0.5 }}>{isAr ? "ذكر" : "Male"}</button>
            <button type="button" onClick={() => up({ gender: form.gender === "female" ? "" : "female" })} className="font-body text-xs px-2 py-0.5" style={form.gender === "female" ? { color: "#DB2777", fontWeight: 700 } : { color: "#DB2777", opacity: 0.5 }}>{isAr ? "أنثى" : "Female"}</button>
          </div>
        </div>
      </Field>

      {/* مكتبة — إرفاق كتاب PDF/EPUB يُفتح في القارئ الداخلي من صفحة المدخل */}
      {isLibrarySection && (
      <Field label={isAr ? "كتاب المدخل (PDF / EPUB)" : "Entry book (PDF / EPUB)"}>
        <div className="space-y-2" dir={isAr ? "rtl" : "ltr"}>
          <input ref={bookInputRef} type="file" accept=".pdf,.epub,application/pdf,application/epub+zip" onChange={onPickBookFiles} className="hidden" />
          {attachedBook ? (
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 flex-shrink-0" style={{ color: "#14532D" }} />
              <span className="flex-1 min-w-0 truncate font-body text-sm" style={{ color: "#14532D" }}>{attachedBook.name}</span>
              <button type="button" onClick={() => up({ library: { ...(form.library || {}), file_id: null } })} className="hover:opacity-60" aria-label={isAr ? "إزالة" : "Remove"} style={{ color: "#B76E79" }}><X className="w-4 h-4" /></button>
            </div>
          ) : form.library?.file_id ? (
            <p className="font-body text-[11px] text-muted-foreground">{isAr ? "كتاب مرتبط (غير موجود على هذا الجهاز)" : "Linked book (not on this device)"}</p>
          ) : (
            <p className="font-body text-[11px] text-muted-foreground">{isAr ? "لا كتاب مرفق بعد" : "No book attached yet"}</p>
          )}
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={() => bookInputRef.current?.click()} disabled={bookBusy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 font-body text-xs font-semibold disabled:opacity-50"
              style={{ background: "#14532D0f", color: "#14532D" }}>
              <Upload className="w-3.5 h-3.5" />{bookBusy ? (isAr ? "جارٍ الرفع.." : "Uploading..") : (isAr ? "ارفع كتاباً" : "Upload book")}
            </button>
            {books.length > 0 && (
              <button type="button" onClick={() => setShowBookPick((v) => !v)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 font-body text-xs font-semibold"
                style={{ background: "#14532D0f", color: "#14532D" }}>
                <BookOpen className="w-3.5 h-3.5" />{isAr ? "اختر من كتبي" : "Pick from My Books"}
              </button>
            )}
          </div>
          {showBookPick && books.length > 0 && (
            <div className="space-y-1 pt-1">
              {books.map((b) => (
                <button key={b.id} type="button"
                  onClick={() => { up({ library: { ...(form.library || {}), file_id: b.id, media_type: (form.library && form.library.media_type) || "book" } }); setShowBookPick(false); }}
                  className="w-full text-start py-1.5 font-body text-xs hover:opacity-70 block truncate"
                  style={{ color: String(form.library?.file_id) === String(b.id) ? "#14532D" : "var(--brand)", fontWeight: String(form.library?.file_id) === String(b.id) ? 700 : 400 }}>
                  {b.name} <span className="text-muted-foreground" dir="ltr">({b.kind?.toUpperCase()})</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </Field>
      )}

      {langs.map((l) => (
        <div key={l.id} className="space-y-2 border-t border-border/40 pt-3">
          <p className="text-[11px] font-body font-semibold" style={{ color: "var(--brand)" }}>{l.name}</p>
          <input value={form.titles[l.code] || ""} onChange={(e) => upMap("titles", l.code, e.target.value)} dir={l.dir}
            placeholder={isAr ? "العنوان" : "Title"} className="w-full bg-white outline-none border-b border-border text-sm font-body px-1 py-1.5" />
          <textarea value={form.texts[l.code] || ""} onChange={(e) => upMap("texts", l.code, e.target.value)} dir={l.dir} rows={4}
            placeholder={isAr ? "المحتوى" : "Content"} className="w-full bg-white outline-none border border-border text-sm font-body p-2 resize-y" />
        </div>
      ))}

      {/* صور المحتوى — حتى خمس صور (للقصة لا للعنوان) */}
      <div className="space-y-2 border-t border-border/40 pt-3">
        <p className="text-[11px] font-body font-semibold text-muted-foreground">{isAr ? "صور المحتوى (حتى خمس)" : "Content images (up to 5)"}</p>
        <div className="flex flex-wrap items-center gap-3">
          {(form.images || []).map((src, idx) => (
            <div key={idx} className="relative">
              <img src={src} alt="" className="w-16 h-16 object-cover" />
              <button type="button" onClick={() => removeImage(idx)} className="absolute -top-2 -right-2 bg-white" aria-label="remove"><X className="w-4 h-4 text-red-500" /></button>
            </div>
          ))}
          {(form.images || []).length < 5 && (
            <label className="inline-flex items-center gap-1.5 font-body text-xs cursor-pointer hover:opacity-70" style={{ color: "var(--brand)" }}>
              {isAr ? "إضافة صورة" : "Add image"}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => addImage(e.target.files?.[0])} />
            </label>
          )}
        </div>
      </div>

      {/* حقول إضافية — قائمة مطوية بعد المحتوى */}
      <div className="border-t border-border/40 pt-3">
        <button type="button" onClick={() => setShowMore((v) => !v)}
          className="font-body text-sm font-semibold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
          {isAr ? (showMore ? "اخفاء الحقول الإضافية" : "حقول إضافية") : (showMore ? "Hide extra fields" : "Extra fields")}
        </button>
        {showMore && (
          <div className="space-y-3 pt-3">
            <LabeledInput label={isAr ? "إشارات و مراجع" : "References - Sources"} value={form.explain} onChange={(v) => up({ explain: v })} dir={isAr ? "rtl" : "ltr"} area />
            <div className="grid grid-cols-2 gap-3">
              <LabeledInput label={isAr ? "السنة (للخط الزمني)" : "Year (timeline)"} value={form.year} onChange={(v) => up({ year: v })} dir="ltr" />
              <LabeledInput label={isAr ? "النطق" : "Pronunciation"} value={form.pronunciation} onChange={(v) => up({ pronunciation: v })} dir={isAr ? "rtl" : "ltr"} />
            </div>
            <LabeledInput label={isAr ? "المصدر" : "Source"} value={form.source} onChange={(v) => up({ source: v })} dir={isAr ? "rtl" : "ltr"} />
            <LabeledInput label={isAr ? "الوسوم (تُفصل بفاصلة)" : "Tags (comma-separated)"} value={form.tags} onChange={(v) => up({ tags: v })} dir={isAr ? "rtl" : "ltr"} />
          </div>
        )}
      </div>

      {/* ربط خط زمني — صريح */}
      {form.section_id && (
        <div className="space-y-2 border-t border-border/40 pt-3">
          <label className="flex items-center gap-2 font-body text-sm cursor-pointer">
            <input type="checkbox" checked={linkLine} onChange={(e) => { setLinkLine(e.target.checked); if (!e.target.checked) up({ timeline_id: null }); }} />
            {isAr ? "ربط بخط زمني" : "Link to a timeline"}
          </label>
          {linkLine && (
            lines.length ? (
              <div className="flex flex-wrap gap-2">
                {lines.map((t) => (
                  <button key={t.id} type="button" onClick={() => up({ timeline_id: t.id })}
                    className="font-body text-xs px-2.5 py-1" style={String(form.timeline_id) === String(t.id) ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>
                    {dispName(t, isAr)}
                  </button>
                ))}
              </div>
            ) : <p className="text-[11px] text-muted-foreground font-body">{isAr ? "لا خطوط زمنية لهذا القسم بعد — أضفها من الإعداد" : "No timelines for this section yet — add them in Setup"}</p>
          )}
        </div>
      )}

      {/* أزرار */}
      <div className="flex items-center gap-3 pt-2">
        <button type="button" onClick={save} disabled={!form.section_id}
          className="font-body text-sm font-semibold px-5 py-2 rounded-none disabled:opacity-40" style={{ color: "#fff", background: "var(--brand)" }}>
          {isAr ? "حفظ" : "Save"}
        </button>
        {isEdit && (
          <button type="button" onClick={remove} className="inline-flex items-center gap-1.5 font-body text-sm text-red-600 hover:opacity-70">
            <Trash2 className="w-4 h-4" />{isAr ? "حذف" : "Delete"}
          </button>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <p className="text-[11px] font-body font-semibold text-muted-foreground uppercase tracking-wide">{label}</p>
      {children}
    </div>
  );
}

function LabeledInput({ label, value, onChange, dir, area }) {
  return (
    <label className="block space-y-1">
      <span className="text-[11px] font-body text-muted-foreground">{label}</span>
      {area
        ? <textarea value={value} onChange={(e) => onChange(e.target.value)} dir={dir} rows={3} className="w-full bg-white outline-none border border-border text-sm font-body p-2 resize-y" />
        : <input value={value} onChange={(e) => onChange(e.target.value)} dir={dir} className="w-full bg-white outline-none border-b border-border text-sm font-body px-1 py-1.5" />}
    </label>
  );
}

import { useState, useEffect, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { DEFAULT_MAIN_CATEGORIES } from "@/lib/shopCategories";
import { sortStoresBy, buildUsageMap, getStorePageSort } from "@/lib/storeSort";
import { Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import ShopBrandList from "@/components/shopping/ShopBrandList";
import AddShopBrandDialog from "@/components/shopping/AddShopBrandDialog";
import BackIcon from "@/components/shared/BackIcon";

// صفحة مستقلّة للمتاجر (نُقلت من تبويب داخل /shopping ). مكتفية بذاتها
// باستعلاماتها الخاصّة كي لا تتأثّر بتبويبات/حوارات صفحة التسوّق.
export default function ShopStores() {
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { currency } = useCurrency();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const [showAddBrand, setShowAddBrand] = useState(false);
  const [viewMode] = useState(() => localStorage.getItem("shopViewMode") || "magazine");

  const { data: brands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });
  const { data: products = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const [pageSort, setPageSort] = useState(getStorePageSort());
  useEffect(() => {
    const h = () => setPageSort(getStorePageSort());
    window.addEventListener("storeSortChanged", h);
    return () => window.removeEventListener("storeSortChanged", h);
  }, []);
  const sortedBrands = useMemo(
    () => sortStoresBy(pageSort, brands, buildUsageMap(products, "brand_id")),
    [pageSort, brands, products]
  );

  return (
    <div className="px-5 page-top pb-10 space-y-4">
      {/* الترويسة */}
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold">{isAr ? "المتاجر" : "Stores"}</h1>
        <div className="flex items-center gap-2">
          <Button onClick={() => setShowAddBrand(true)} size="sm" variant="outline" className="rounded-none font-body text-xs h-9 px-3">
            {isAr ? "إضافة متجر" : "Add Store"}
          </Button>
          <button
            type="button"
            onClick={() => { if (typeof window !== "undefined" && window.history.length > 1) navigate(-1); else navigate("/shopping"); }}
            className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity"
            aria-label={isAr ? "رجوع" : "Back"}
          >
            <BackIcon className={`w-5 h-5`} style={{ color: "var(--brand)" }} />
          </button>
        </div>
      </div>

      {/* بحث موحّد: خطّ ذهبي + أيقونة بلون المستخدم عند الكتابة، بلا إطار */}
      <div className="relative flex items-center h-11 bg-white" dir="ltr">
        <div aria-hidden="true" className="w-px h-5 mx-3 flex-shrink-0" style={{ background: "var(--brand)" }} />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder=""
          dir={isAr ? "rtl" : "ltr"}
          className="flex-1 h-11 bg-transparent outline-none text-sm font-body px-1"
        />
        {(
          <span className="px-3 flex-shrink-0"><Search className="w-4 h-4" style={{ color: "var(--brand)" }} /></span>
        )}
      </div>

      <ShopBrandList
        brands={sortedBrands}
        search={search}
        isAr={isAr}
        names={names}
        currency={currency}
        mainCategories={DEFAULT_MAIN_CATEGORIES}
        products={products}
        viewMode={viewMode}
        onRefresh={() => queryClient.invalidateQueries({ queryKey: ["shop-brands"] })}
      />

      {showAddBrand && (
        <AddShopBrandDialog
          isAr={isAr}
          categories={DEFAULT_MAIN_CATEGORIES}
          onClose={() => setShowAddBrand(false)}
          onSaved={() => { setShowAddBrand(false); queryClient.invalidateQueries({ queryKey: ["shop-brands"] }); }}
        />
      )}
    </div>
  );
}

import { useState, useEffect } from "react";
import BackButton from "@/components/shared/BackButton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { ChevronDown, ChevronUp, Link2, ArchiveX } from "lucide-react";
import { useNavigate } from "react-router-dom";


import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import { getSecureStorage } from "@/lib/storageEncryption";
import { useContentEncryption } from "@/lib/useContentEncryption";
import Pagination from "@/components/shared/Pagination";
import { useLang } from "@/lib/LanguageContext";

const ENTRY_TYPES = [
  { val: "not_set", label: "Not Set", color: "bg-gray-500" },
  { val: "perfume", label: "🌹 Perfume", color: "bg-rose-500" },
  { val: "music", label: "🎵 Music", color: "bg-indigo-500" },
  { val: "tv", label: "📺 TV", color: "bg-cyan-500" },
  { val: "films", label: "🎬 Films", color: "bg-red-500" },
  { val: "idea", label: "💡 Idea", color: "bg-yellow-500" },
  { val: "poetry", label: "✍️ Poetry", color: "bg-rose-500" },
  { val: "thought", label: "💭 Thought", color: "bg-blue-500" },
  { val: "knowledge", label: "🧠 Knowledge", color: "bg-amber-500" },
  { val: "concept", label: "🔮 Concept", color: "bg-purple-500" },
];

const TYPE_BADGE = {
  not_set: "bg-gray-100 text-gray-700",
  perfume: "bg-rose-100 text-rose-700",
  music: "bg-indigo-100 text-indigo-700",
  tv: "bg-cyan-100 text-cyan-700",
  films: "bg-red-100 text-red-700",
  idea: "bg-yellow-100 text-yellow-700",
  poetry: "bg-rose-100 text-rose-700",
  thought: "bg-blue-100 text-blue-700",
  knowledge: "bg-amber-100 text-amber-700",
  concept: "bg-purple-100 text-purple-700",
  memo: "bg-blue-100 text-blue-700",
};

const TYPE_LABEL = {
  not_set: "Not Set", 
  perfume: "🌹 Perfume",
  music: "🎵 Music",
  tv: "📺 TV",
  films: "🎬 Films",
  idea: "💡 Idea", 
  poetry: "✍️ Poetry",
  thought: "💭 Thought", 
  knowledge: "🧠 Knowledge", 
  concept: "🔮 Concept", 
  memo: "📝 Thought",
};


function loadThoughtSettings() {
  return getSecureStorage("thoughtSettings", {
    sortOrder: "newest",
    show: { not_set: true, perfume: true, music: true, tv: true, films: true, idea: true, poetry: true, thought: true, knowledge: true, concept: true, memo: true },
  });
}

export default function Blog() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { names, profiles } = usePersonNames();
  const { decryptFields, userId } = useContentEncryption();
  const { isAr } = useLang();
  const [expandedId, setExpandedId] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [tagFilter, setTagFilter] = useState(() => {
    // Allow other pages to deep-link into Blog with ?tag=… (e.g. BlogDetail's @tag buttons)
    if (typeof window !== "undefined") {
      const p = new URLSearchParams(window.location.search);
      return p.get("tag") || null;
    }
    return null;
  });
  const [exportPost, setExportPost] = useState(null);
  const [showArchived, setShowArchived] = useState(false);
  const [settings, setSettings] = useState(loadThoughtSettings);

  useEffect(() => {
    const handler = () => setSettings(loadThoughtSettings());
    window.addEventListener("thoughtSettingsChanged", handler);
    return () => window.removeEventListener("thoughtSettingsChanged", handler);
  }, []);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["blog-posts", userId],
    queryFn: async () => {
      const raw = await apphost.entities.BlogPost.list("-created_date");
      if (!userId) return raw;
      return Promise.all(raw.map(async (bp) => {
        try { return await decryptFields(bp, ['title']); } catch { return bp; }
      }));
    },
    enabled: !!userId,
  });

  const { data: perfumes = [] } = useAllPerfumes("-created_date");
  const { data: brands = [] } = useQuery({ queryKey: ["brands-all"], queryFn: () => apphost.entities.PerfumeBrand.list("-created_date") });
  const { data: perfumers = [] } = useQuery({ queryKey: ["perfumers-all"], queryFn: () => apphost.entities.Perfumer.list("-created_date") });
  const { data: notes = [] } = useQuery({ queryKey: ["notes-all"], queryFn: () => apphost.entities.PerfumeNote.list("name") });


  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.BlogPost.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["blog-posts"] }); toast.success("تم الحذف"); },
  });

  const archiveMutation = useMutation({
    mutationFn: (id) => apphost.entities.BlogPost.update(id, { archived: true }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["blog-posts"] }); toast.success("مؤرشف"); },
  });

  const unarchiveMutation = useMutation({
    mutationFn: (id) => apphost.entities.BlogPost.update(id, { archived: false }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["blog-posts"] }); toast.success("استُعيد"); },
  });


  // Filter by settings visibility and archive status
  const activePosts = posts.filter((p) => settings.show[p.entry_type] !== false && !p.archived);
  const archivedPosts = posts.filter((p) => p.archived);

  // Sort
  const sorted = [...activePosts].sort((a, b) => {
    const da = new Date(a.created_date), db = new Date(b.created_date);
    return settings.sortOrder === "oldest" ? da - db : db - da;
  });

  const sortedArchived = [...archivedPosts].sort((a, b) => {
    const da = new Date(a.created_date), db = new Date(b.created_date);
    return settings.sortOrder === "oldest" ? da - db : db - da;
  });

  const displayed = (activeTab === "all"
    ? sorted
    : sorted.filter((p) => {
        if (activeTab === "thought") return p.entry_type === "thought" || p.entry_type === "memo";
        return p.entry_type === activeTab;
      })
  ).filter((p) => {
    // When a @tag is selected, only show posts that contain it.
    if (!tagFilter) return true;
    if (!p.tags) return false;
    return p.tags.split(",").map((t) => t.trim().toLowerCase()).includes(tagFilter.toLowerCase());
  });

  // Pagination (50 per page)
  const PAGE_SIZE = 50;
  const [page, setPage] = useState(1);
  const pageCount = Math.max(1, Math.ceil(displayed.length / PAGE_SIZE));
  useEffect(() => { setPage(1); }, [activeTab, tagFilter]);
  useEffect(() => { if (page > pageCount) setPage(1); }, [page, pageCount]);
  const pagedPosts = displayed.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const tabCounts = {
    all: sorted.length,
    not_set: sorted.filter(p => p.entry_type === "not_set").length,
    perfume: sorted.filter(p => p.entry_type === "perfume").length,
    music: sorted.filter(p => p.entry_type === "music").length,
    tv: sorted.filter(p => p.entry_type === "tv").length,
    films: sorted.filter(p => p.entry_type === "films").length,
    idea: sorted.filter(p => p.entry_type === "idea").length,
    poetry: sorted.filter(p => p.entry_type === "poetry").length,
    thought: sorted.filter(p => p.entry_type === "thought" || p.entry_type === "memo").length,
    knowledge: sorted.filter(p => p.entry_type === "knowledge").length,
    concept: sorted.filter(p => p.entry_type === "concept").length,
  };

  return (
    <div className="px-4 page-top pb-4 space-y-5">
      {/* Row 1: المستخدم + إضافة تدوينة */}
      <div className="flex items-center justify-between">
        <SettingsSheet>
          <UserAvatarButton size={28} />
        </SettingsSheet>
        <Button size="sm" className="rounded-none font-body h-9 text-xs text-white hover:opacity-90" style={{ background: "var(--brand)" }} onClick={() => navigate("/blog-edit")}>
          {isAr ? "إضافة تدوينة" : "Add Entry"}
        </Button>
      </div>
      {/* Row 2: سهم الرجوع */}
      <BackButton fallback="/" />
      {/* Row 3: العنوان — بلا أيقونة */}
      <h1 className="font-heading text-2xl font-bold">
        {isAr ? "اكتب & اقرأ" : "Write & Read"}
      </h1>

      {/* Tabs */}
       <div className="flex gap-2 flex-wrap">
         {[
           { val: "all", label: "All" },
           { val: "not_set", label: "Not Set" },
           { val: "perfume", label: "🌹 Perfume" },
           { val: "music", label: "🎵 Music" },
           { val: "tv", label: "📺 TV" },
           { val: "films", label: "🎬 Films" },
           { val: "idea", label: "💡 Idea" },
           { val: "poetry", label: "✍️ Poetry" },
           { val: "thought", label: "💭 Thought" },
           { val: "knowledge", label: "🧠 Knowledge" },
           { val: "concept", label: "🔮 Concept" },
         ].map(({ val, label }) => (
          <button key={val} onClick={() => setActiveTab(val)}
            className={` rounded-none text-xs font-body font-medium transition-all ${activeTab === val ? " text-primary-foreground " : " text-muted-foreground hover:text-foreground"}`}>
            {label} {tabCounts[val] > 0 && <span className="opacity-60 ml-0.5">{tabCounts[val]}</span>}
          </button>
        ))}
      </div>

      {/* Active tag filter banner — clearable */}
      {tagFilter && (
        <div className="flex items-center gap-2 px-1 py-1">
          <span className="text-xs font-body text-muted-foreground">{isAr ? "تصفية:" : "Filtering:"}</span>
          <span className="text-xs font-body font-semibold text-primary">@{tagFilter}</span>
          <button
            type="button"
            onClick={() => setTagFilter(null)}
            className="ml-auto text-xs font-body text-muted-foreground hover:text-foreground"
          >
            {isAr ? "إلغاء ×" : "Clear ×"}
          </button>
        </div>
      )}

      {isLoading && (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}

      {!isLoading && posts.length === 0 && (
        <div className="text-center py-16 space-y-3">
          <p className="text-xs text-muted-foreground font-body max-w-xs mx-auto">{isAr ? "اكتب يومياتك و دون عن العطور.. الموسيقى و الأفلام و ما إلى ذلك" : "Write your diary and journal about perfumes.. music.. films, and so on"}</p>
          <Button className="rounded-none font-body text-sm h-10 text-white hover:opacity-90" style={{ background: "var(--brand)" }} onClick={() => navigate("/blog-edit")}>{isAr ? "إضافة تدوينة" : "Add Entry"}</Button>
        </div>
      )}

      {/* Active Posts list */}
      {displayed.length > 0 && (
      <div className="space-y-2">
        {pagedPosts.map((post) => {
          const isPerson2 = post.person === "person2";
          const personColor = isPerson2
            ? (profiles?.person2?.color || "#8b5cf6")
            : (profiles?.person1?.color || "#10b981");
          const tags = post.tags ? post.tags.split(",").map((t) => t.trim()).filter(Boolean) : [];
          const hasLinks = post.linked_perfume_name || post.linked_brand_name || post.linked_perfumer_name || post.linked_notes;
          const hasMedia = post.media_urls || post.media_links;
          const types = (post.entry_type || "").split(",").map(t => t.trim()).filter(Boolean);
          const typeLabels = types.length ? types.map(t => TYPE_LABEL[t] || t).join(" — ") : "Not Set";

          return (
            <div key={post.id} className="flex items-center justify-between border-l-4 px-3 py-3 hover:bg-primary/5 transition-colors" style={{ borderLeftColor: personColor }}>
              <div className="flex-1 cursor-pointer" onClick={() => navigate(`/blog-detail?id=${post.id}`)}>
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="text-[10px] font-body font-bold rounded-none text-primary">
                    {typeLabels}
                  </span>
                  {hasMedia && <span className="text-[10px] text-muted-foreground font-body">📎</span>}
                </div>
                <p className="text-sm font-body font-semibold">{post.title}</p>
                <div className="flex gap-1 flex-wrap items-center mt-1">
                  {tags.map((tag) => (
                    <button
                      type="button"
                      key={tag}
                      onClick={(e) => { e.stopPropagation(); setTagFilter(tag); }}
                      className={`text-[9px] rounded-none font-body transition-colors ${
 tagFilter && tagFilter.toLowerCase() === tag.toLowerCase()
 ? " text-primary-foreground"
 : " text-muted-foreground hover:text-primary"
 }`}
                    >
                      @{tag}
                    </button>
                  ))}
                  {hasLinks && <Link2 className="w-3 h-3 text-muted-foreground ml-0.5" />}
                </div>
              </div>


            </div>
          );
          })}
          </div>
          )}

          {/* Page switcher (50 per page) */}
          <Pagination
            page={page}
            pageCount={pageCount}
            onChange={setPage}
            totalItems={displayed.length}
            pageSize={PAGE_SIZE}
          />

          {/* Archived section */}
          {archivedPosts.length > 0 && (
          <div className="space-y-3 pt-6 border-t border-border">
          <button
            onClick={() => setShowArchived(!showArchived)}
            className="w-full flex items-center justify-between px-1 py-3 hover:bg-secondary/30 transition-colors"
          >
            <div className="flex items-center gap-2">
              <ArchiveX className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-body font-medium">{isAr ? `الأرشيف (${archivedPosts.length})` : `Archived (${archivedPosts.length})`}</span>
            </div>
            {showArchived ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </button>

          {showArchived && (
            <div className="space-y-2 opacity-75">
              {sortedArchived.map((post) => {
                const isPerson2 = post.person === "person2";
                const personColor = isPerson2
                  ? (profiles?.person2?.color || "#8b5cf6")
                  : (profiles?.person1?.color || "#10b981");
                const tags = post.tags ? post.tags.split(",").map((t) => t.trim()).filter(Boolean) : [];
                const hasLinks = post.linked_perfume_name || post.linked_brand_name || post.linked_perfumer_name || post.linked_notes;
                const hasMedia = post.media_urls || post.media_links;
                const types = (post.entry_type || "").split(",").map(t => t.trim()).filter(Boolean);
                const typeLabels = types.length ? types.map(t => TYPE_LABEL[t] || t).join(" — ") : "Not Set";

                return (
                  <div key={post.id} className="flex items-center justify-between border-l-4 px-3 py-3 hover:bg-primary/5 transition-colors" style={{ borderLeftColor: personColor }}>
                    <div className="flex-1 cursor-pointer" onClick={() => navigate(`/blog-detail?id=${post.id}`)}>
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-[10px] font-body font-bold rounded-none text-primary">
                          {typeLabels}
                        </span>
                        {hasMedia && <span className="text-[10px] text-muted-foreground font-body">📎</span>}
                      </div>
                      <p className="text-sm font-body font-semibold">{post.title}</p>
                      <div className="flex gap-1 flex-wrap items-center mt-1">
                        {tags.map((tag) => (
                          <button
                            type="button"
                            key={tag}
                            onClick={(e) => { e.stopPropagation(); setTagFilter(tag); }}
                            className={`text-[9px] rounded-none font-body transition-colors ${
 tagFilter && tagFilter.toLowerCase() === tag.toLowerCase()
 ? " text-primary-foreground"
 : " text-muted-foreground hover:text-primary"
 }`}
                          >
                            @{tag}
                          </button>
                        ))}
                        {hasLinks && <Link2 className="w-3 h-3 text-muted-foreground ml-0.5" />}
                      </div>
                    </div>


                  </div>
                );
              })}
            </div>
          )}
          </div>
          )}



      {/* New entry dialog */}
      
    </div>
  );
}
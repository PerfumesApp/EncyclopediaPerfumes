import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { PERFUME_TYPES, DB_PERFUME_TYPES, typeLabel } from "@/lib/perfumeTypes";
import { compareEnglish } from "@/lib/sortName";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import Pagination from "@/components/Pagination";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { useLang } from "@/lib/LanguageContext";
import BackIcon from "@/components/shared/BackIcon";

const GOLD = "var(--brand)";

// لوحة ألوان نصّية متكرّرة للأنواع (يحصل كل نوع على لون ثابت من القائمة).
const TYPE_COLORS = [
  "#dc2626", "#ea580c", "#d97706", "#059669",
  "#0891b2", "#2563eb", "#4f46e5", "#7c3aed",
  "#c026d3", "#db2777", "#16a34a", "#0284c7",
];

// تقسيم اسم النوع إلى اسم أساسي وشرح اختياري بين قوسين.
function splitLabel(label) {
  const m = String(label || "").match(/^(.*?)\s*\(([^)]+)\)\s*$/);
  if (m) return { main: m[1].trim(), hint: m[2].trim() };
  return { main: String(label || "").trim(), hint: "" };
}

/**
 * Classify — صفحة التصنيف:
 * - بلا إطارات، بلا خلفيات؛ خلفية بيضاء كاملة.
 * - أنواع العطور كأزرار نصّية بألوان مختلفة. مطويّة افتراضياً (يظهر "All" فقط)
 *   وعند الضغط على "All" تنفتح؛ وعند اختيار نوع يبقى هو وحده مع "All".
 * - فرز يحترم الـ compareEnglish الموحّد.
 * - تحليل تلقائي مختصر أعلى الصفحة.
 * - ثنائية اللغة معالَجة: عنوان أساسي مختصر بكل لغة + شرح اختياري بين قوسين.
 */
export default function Classify() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [selectedType, setSelectedType] = useState("all");
  const [typesOpen, setTypesOpen] = useState(true); // الرقائق ظاهرة فوراً بلا تحميل
  const [loaded, setLoaded] = useState(false);       // الكتالوج لا يُحمَّل حتى يضغط المستخدم

  // الأنواع الموجودة فعلاً في القاعدة (مفاتيح فهرس 'type' المميّزة) — هي «الصحيحة»
  // المستوردة من Frag؛ تُكتشف ديناميكياً فيبقى /classify مطابقاً للقاعدة دائماً.
  const { data: dbTypes = [] } = useQuery({
    queryKey: ["classify-db-types"],
    staleTime: Infinity,
    queryFn: async () => {
      try {
        const keys = await apphost.entities.Perfume.distinctIndexKeys("type");
        const vals = (keys || []).map((k) => String(k)).filter(Boolean);
        return vals.length ? vals : DB_PERFUME_TYPES.map((t) => t.value);
      } catch { return DB_PERFUME_TYPES.map((t) => t.value); }
    },
  });

  // عدّ كل نوع موجود عبر index.count — فوريّ بلا تحميل أي سجلّ.
  const { data: typeCountObj = {} } = useQuery({
    queryKey: ["classify-type-counts", dbTypes.join("|")],
    staleTime: Infinity,
    enabled: dbTypes.length > 0,
    queryFn: async () => {
      const m = {};
      await Promise.all(dbTypes.map(async (v) => {
        try {
          const r = await apphost.entities.Perfume.pageByIndexRange("type", { only: v }, 0, 0, "next", true);
          m[v] = r?.total || 0;
        } catch { m[v] = 0; }
      }));
      return m;
    },
  });
  const { data: totalAll = 0 } = useQuery({
    queryKey: ["perfume-count"],
    staleTime: Infinity,
    queryFn: () => apphost.entities.Perfume.count(),
  });

  const typeCounts = useMemo(() => new Map(Object.entries(typeCountObj)), [typeCountObj]);

  // سجلات التصنيف المختار — لا تُحمَّل إلا بعد الضغط: النوع المحدّد عبر فهرس 'type'
  // (تحميل ذلك التصنيف وحده، لا القاعدة كلّها)؛ و«الكل» وحده يحمّل الكتالوج كاملاً.
  const { data: perfumes = [], isLoading } = useQuery({
    queryKey: ["classify-items", selectedType],
    staleTime: Infinity,
    enabled: loaded,
    queryFn: async () => {
      if (selectedType === "all") return await apphost.entities.Perfume.list("-created_date");
      const r = await apphost.entities.Perfume.pageByIndexRange("type", { only: selectedType }, 0, 200000, "next", false);
      return r?.items || [];
    },
  });

  // ترتيب أنواع القاعدة: الأكثر عدداً أوّلاً.
  const orderedTypes = useMemo(
    () => [...dbTypes].sort((a, b) => (typeCounts.get(b) || 0) - (typeCounts.get(a) || 0)),
    [dbTypes, typeCounts]
  );

  // المخصّصة غير الموجودة في القاعدة — قائمة مراجعة ثنائية اللغة لتحديث القاعدة لاحقاً.
  const reviewTypes = useMemo(() => {
    const present = new Set(dbTypes);
    return PERFUME_TYPES.filter((t) => !present.has(t.value));
  }, [dbTypes]);
  const [reviewOpen, setReviewOpen] = useState(false);

  const analysis = useMemo(() => {
    if (!totalAll) return null;
    const sortedByCount = orderedTypes
      .map((v) => ({ value: v, count: typeCounts.get(v) || 0 }))
      .sort((a, b) => b.count - a.count);
    const top = sortedByCount.slice(0, 3).filter((x) => x.count > 0);
    return {
      totalPerfumes: totalAll,
      activeTypes: sortedByCount.filter((x) => x.count > 0).length,
      top,
    };
  }, [totalAll, orderedTypes, typeCounts]);

  const sortedData = useMemo(() => [...perfumes].sort((a, b) => compareEnglish(a, b, 1)), [perfumes]);

  const getColor = (idx) => TYPE_COLORS[idx % TYPE_COLORS.length];

  const onPickType = (val) => {
    setLoaded(true); // أوّل ضغط يبدأ تحميل الكتالوج (مرّة واحدة)
    if (val === "all") {
      setSelectedType("all");
      setTypesOpen(true);
      return;
    }
    if (!typesOpen && val === selectedType) {
      setTypesOpen(true);
      return;
    }
    setSelectedType(val);
    setTypesOpen(false);
  };

  const renderTypeButton = (typeValue, idx) => {
    const enParts = splitLabel(typeLabel(typeValue, false));
    const arParts = splitLabel(typeLabel(typeValue, true));
    const main = isAr ? arParts.main : enParts.main;
    const hint = isAr ? arParts.hint : enParts.hint;
    const count = typeCounts.get(typeValue) || 0;
    const active = selectedType === typeValue;
    const color = getColor(idx);
    return (
      <button
        key={typeValue}
        onClick={() => onPickType(typeValue)}
        className="text-start py-1 hover:opacity-70 transition-opacity"
        style={{ color, opacity: active ? 1 : 0.85, fontWeight: active ? 700 : 500 }}
      >
        <span className="text-xs font-body">{main}</span>
        {hint && <span className="text-[10px] font-body opacity-70 ms-1">({hint})</span>}
        <span className="text-[10px] font-body text-muted-foreground ms-1">{count}</span>
      </button>
    );
  };

  return (
    <div className="px-5 page-top pb-24 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className={`flex items-center gap-2.5 ${isAr ? "flex-row-reverse" : ""}`}>
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity"
            title={isAr ? "رجوع" : "Back"}
          >
            <BackIcon className={`w-5 h-5`} style={{ color: GOLD }} />
          </button>
          <h1 className="font-heading text-lg font-semibold" style={{ color: GOLD }}>
            {isAr ? "التصنيف والتناغمات" : "Classify & Accord"}
          </h1>
        </div>
        <SettingsSheet>
          <UserAvatarButton size={28} />
        </SettingsSheet>
      </div>

      {/* Auto-analysis */}
      {analysis && (
        <p className="text-[11px] font-body" style={{ color: GOLD }}>
          {isAr
            ? `${analysis.totalPerfumes} عطر ${analysis.activeTypes} نوع نشط${analysis.top.length ? ` الأكثر: ${analysis.top.map(t => splitLabel(typeLabel(t.value, true)).main).join("، ")}` : ""}`
            : `${analysis.totalPerfumes} perfumes — ${analysis.activeTypes} active types${analysis.top.length ? ` — top: ${analysis.top.map(t => splitLabel(typeLabel(t.value, false)).main).join(", ")}` : ""}`}
        </p>
      )}

      {/* Type chooser — مطوي افتراضياً، يفتح بضغط All؛ عند اختيار نوع يطوي الباقي */}
      <div className="flex flex-col gap-1">
        <button
          onClick={() => onPickType("all")}
          className="text-start py-1 hover:opacity-70 transition-opacity"
          style={{ color: GOLD, fontWeight: selectedType === "all" ? 700 : 500 }}
        >
          <span className="text-xs font-body font-semibold">{isAr ? "الكل" : "All"}</span>
          <span className="text-[10px] font-body text-muted-foreground ms-1">{totalAll}</span>
        </button>
        {typesOpen
          ? orderedTypes.map((tv, i) => renderTypeButton(tv, i))
          : (selectedType !== "all" &&
              renderTypeButton(selectedType, orderedTypes.indexOf(selectedType) >= 0 ? orderedTypes.indexOf(selectedType) : 0))}
      </div>

      {reviewTypes.length > 0 && (
        <div>
          <button
            onClick={() => setReviewOpen((v) => !v)}
            className="text-start py-1 hover:opacity-70 transition-opacity"
            style={{ color: "#9a7b1f", fontWeight: 600 }}
          >
            <span className="text-xs font-body">
              {isAr ? `المخصّصة قيد المراجعة — غير موجودة في القاعدة (${reviewTypes.length})` : `Custom under review — not in the database (${reviewTypes.length})`}
            </span>
          </button>
          {reviewOpen && (
            <div className="flex flex-col gap-0.5 mt-1">
              {reviewTypes.map((t) => (
                <div key={t.value} className="text-[11px] font-body text-muted-foreground py-0.5" style={{ borderBottom: "1px solid #f0ece2" }}>
                  <span style={{ color: "#9a7b1f" }}>{splitLabel(t.label_ar).main}</span>
                  <span className="ms-2">{splitLabel(t.label_en).main}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {selectedType !== "all" && (
        <p className="text-xs text-muted-foreground font-body">
          {sortedData.length} {isAr ? "عطر" : `perfume${sortedData.length !== 1 ? "s" : ""}`}
        </p>
      )}

      {!loaded ? (
        <div className="text-center py-12 space-y-2">
          <p className="text-sm font-body text-muted-foreground">
            {isAr ? "اختر تصنيفاً لعرض عطوره" : "Pick a classification to load its perfumes"}
          </p>
        </div>
      ) : isLoading ? (
        <div className="text-center py-12 text-muted-foreground font-body text-sm">{isAr ? "جارٍ التحميل…" : "Loading…"}</div>
      ) : sortedData.length === 0 ? (
        <div className="text-center py-12 space-y-2">
          <p className="text-sm font-body text-muted-foreground">
            {isAr ? "لا توجد عطور في هذا التصنيف" : "No perfumes in this category"}
          </p>
        </div>
      ) : (
        <Pagination
          items={sortedData}
          itemsPerPage={50}
          renderItem={(items) => (
            <div className="grid grid-cols-2 gap-3">
              {items.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
            </div>
          )}
          emptyMessage={isAr ? "لا توجد عطور" : "No perfumes"}
        />
      )}
    </div>
  );
}

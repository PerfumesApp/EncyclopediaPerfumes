import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import { headacheLog } from "@/lib/headacheLogStore";
import { RISK_GROUPS, MECH, perfumeLabels } from "@/lib/headacheRisk";
import { searchIndexReady, searchPerfumeIds } from "@/lib/searchIndex";
import { rankName } from "@/lib/sortName";
import BackIcon from "@/components/shared/BackIcon";

const PAGE_SIZE = 20;

const SEVERITY = [
  { value: "strong", emoji: "🔴", en: "Strong", ar: "قوي" },
  { value: "medium", emoji: "🟠", en: "Medium", ar: "متوسط" },
  { value: "weak", emoji: "🟡", en: "Weak", ar: "ضعيف" },
];

const TIPS = [
  { en: "Apply to clothing, not skin, and spray less — lower dose, less projection.", ar: "ضع العطر على الملابس لا الجلد، و رُشّ أقل — جرعة أقل و انتشار أخف." },
  { en: "Test on a blotter first; let it settle before wearing.", ar: "جرّبه على ورقة اختبار أولاً و دعه يستقر قبل اللبس." },
  { en: "Ventilate the room; avoid wearing in small enclosed spaces.", ar: "هوِّ الغرفة و تجنّب اللبس في الأماكن الضيّقة المغلقة." },
  { en: "Prefer light EDT over heavy parfum if you are sensitive.", ar: "فضّل العطر الخفيف (EDT) على البارفان الثقيل إن كنت حسّاساً." },
  { en: "If a note keeps triggering you (heady florals, aldehydes, strong musk/oud), avoid that family.", ar: "إن تكرّر تأثّرك من عائلة (زهور كثيفة، ألدهيدات، مسك/عود قوي) فتجنّبها." },
  { en: "Hydrate and step into fresh air at the first sign.", ar: "اشرب ماءً و اخرج لهواء نقي عند أول إشارة." },
  { en: "For a true allergy (skin rash), a patch test with a dermatologist is the reference.", ar: "للتحسّس الحقيقي (طفح جلدي) اختبار الرقعة لدى طبيب الجلدية هو المرجع." },
];

function startOfWindow(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.getTime();
}

export default function HeadacheGuide() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  const [showExplain, setShowExplain] = useState(false);
  const [page, setPage] = useState(1);
  const [log, setLog] = useState([]);
  const [showForm, setShowForm] = useState(false);

  // form state
  const [fSeverity, setFSeverity] = useState("medium");
  const [fPerfumeId, setFPerfumeId] = useState("");
  const [fPerfumeName, setFPerfumeName] = useState("");
  const [fNote, setFNote] = useState("");
  const [fReduced, setFReduced] = useState("");

  // user perfumes (for linking + showing existing ratings)
  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes-all"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });
  const ratingByPid = useMemo(() => {
    const m = {};
    userPerfumes.forEach((u) => { if (u.perfume_id != null) m[String(u.perfume_id)] = u; });
    return m;
  }, [userPerfumes]);

  // total count + paginated browse (cursor — no full load)
  const { data: totalCount = 0 } = useQuery({
    queryKey: ["perfumes-count"],
    queryFn: () => apphost.entities.Perfume.count(),
  });
  const { data: browseData, isLoading: browseLoading } = useQuery({
    queryKey: ["headache-browse", page],
    queryFn: () => apphost.entities.Perfume.pageByIndex("sort_key", (page - 1) * PAGE_SIZE, PAGE_SIZE, "next", false, "name"),
  });
  const items = browseData?.items || [];
  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));

  // search (on-demand full load only when a query is typed — same pattern as Explore)
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search.trim()), 250);
    return () => clearTimeout(t);
  }, [search]);
  const searching = debouncedSearch.length >= 2;
  // البحث عبر فهرس البحث (searchPerfumeIds) ثمّ getMany — بلا تحميل الـ130 ألف.
  // السقوط: فهرس البادئة sort_key (محدود) إن لم يكن فهرس البحث جاهزاً.
  const { data: searchResults = [], isLoading: searchLoading } = useQuery({
    queryKey: ["headache-search", debouncedSearch],
    enabled: searching,
    staleTime: 10 * 60 * 1000,
    queryFn: async () => {
      const t = debouncedSearch.toLowerCase();
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(t);
        if (ids && ids.length) return apphost.entities.Perfume.getMany(ids.slice(0, 60));
      }
      const prefix = String(rankName(t)) + t;
      const { items: hits } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", { lower: prefix, upper: prefix + "\uffff" }, 0, 60, "next", false
      );
      return hits || [];
    },
  });
  const displayItems = searching ? searchResults : items;

  // load headache log
  async function refreshLog() {
    try {
      
      const all = await headacheLog.getAll();
      all.sort((a, b) => new Date(b.date) - new Date(a.date));
      setLog(all);
    } catch { /* ignore */ }
  }
  useEffect(() => { refreshLog(); }, []);

  async function addEntry() {
    try {
      
      await headacheLog.add({
        date: new Date().toISOString(),
        severity: fSeverity,
        perfume_id: fPerfumeId || null,
        perfume_name: fPerfumeName || (fPerfumeId && ratingByPid[fPerfumeId]?.perfume_name) || "",
        suspected: fNote || "",
        reduced: fReduced || "",
      });
      setFSeverity("medium"); setFPerfumeId(""); setFPerfumeName(""); setFNote(""); setFReduced("");
      setShowForm(false);
      refreshLog();
    } catch { /* ignore */ }
  }

  async function delEntry(id) {
    try { await headacheLog.delete(id); refreshLog(); } catch { /* ignore */ }
  }

  // statistics
  const stats = useMemo(() => {
    const w = startOfWindow(7), mo = startOfWindow(30), y = startOfWindow(365);
    let week = 0, month = 0, year = 0;
    const bySeverity = { strong: 0, medium: 0, weak: 0 };
    const byPerfume = {};
    log.forEach((e) => {
      const t = new Date(e.date).getTime();
      if (t >= w) week++;
      if (t >= mo) month++;
      if (t >= y) year++;
      if (e.severity && bySeverity[e.severity] != null) bySeverity[e.severity]++;
      const nm = e.perfume_name || (isAr ? "غير محدّد" : "Unspecified");
      byPerfume[nm] = (byPerfume[nm] || 0) + 1;
    });
    const topPerfumes = Object.entries(byPerfume).sort((a, b) => b[1] - a[1]).slice(0, 5);
    return { week, month, year, all: log.length, bySeverity, topPerfumes };
  }, [log, isAr]);

  return (
    <div className="px-5 page-top pb-24 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-secondary transition-colors">
          <BackIcon className={`w-5 h-5`} />
        </button>
        <div>
          <h1 className="font-heading text-xl font-bold text-[var(--brand)]">صداع و حساسية <span className="text-muted-foreground font-normal">Headache & Sensitivity</span></h1>
          <p className="text-xs text-muted-foreground font-body">ما قد يسبّب صداعاً أو تحسّساً، و سجلّ لمتابعته</p>
        </div>
      </div>

      {/* رابط دليل منتجات العناية — أعلى الصفحة، بلا أيقونة و لا إطار، بلون مختلف */}
      <button type="button" onClick={() => navigate("/care-guide")} className="block w-full text-start font-body text-sm font-semibold hover:opacity-70" style={{ color: "#7C6FB0" }}>
        اقرأ دليل الصحة لمنتجات العناية من هنا<br /><span className="text-xs">Read Health Guide For Care Products From Here</span>
      </button>

      {/* Explanation — Arabic block then English block */}
      <div className="bg-white rounded-none border-b border-[var(--brand)] overflow-hidden">
        <button onClick={() => setShowExplain((v) => !v)} className="w-full flex items-center justify-between p-4">
          <span className="font-heading font-semibold text-sm">لماذا تسبّب العطور صداعاً <span className="text-muted-foreground font-normal">Why fragrances cause headaches</span></span>
          {showExplain ? <ChevronUp className="w-4 h-4 text-primary" /> : <ChevronDown className="w-4 h-4 text-primary" />}
        </button>
        {showExplain && (
          <div className="px-4 pb-4 text-sm font-body leading-relaxed text-muted-foreground">
            <div className="space-y-2">
              <p>أغلب «صداع العطر» ليس حساسية مناعية، بل تهيّج عصبي أو تنفّسي. هناك ثلاث آليات:</p>
              <p><b className="text-foreground">١) عصبي شقيقة:</b> الرائحة القوية تنبّه العصب ثلاثي التوائم في الأنف فيحدث التهاب عصبي و صداع. دماغ مريض الشقيقة مفرط الحساسية للروائح، و العطر هو المثير الأشيع.</p>
              <p><b className="text-foreground">٢) الجيوب و الأنف:</b> المركّبات المتطايرة و الكحول الحامل تهيّج الغشاء المخاطي فتسبّب احتقاناً و ضغط جيوب يُشعَر كصداع.</p>
              <p><b className="text-foreground">٣) تحسّس مناعي:</b> تعرّض متكرّر لمواد محسِّسة مثل اليوجينول و الأوكموس و اللينالول المتأكسد يبني حساسية تظهر غالباً كأكزيما جلدية، و أحياناً أعراض تنفّسية.</p>
              <p>الاستجابة فردية جداً و لا تصيب الجميع. للتشخيص الفعلي راجع طبيب جلدية أو حساسية.</p>
            </div>
            <div className="mt-3 pt-3 border-t border-border/40 space-y-2 text-xs italic opacity-80">
              <p>Most fragrance headaches are not an immune allergy but neural or respiratory irritation. Three mechanisms:</p>
              <p>1) Neural migraine: strong odours stimulate the trigeminal nerve, causing neurogenic inflammation and pain. Migraine brains are hypersensitive to smell, and perfume is the most common trigger.</p>
              <p>2) Sinus and nose: volatile compounds and the alcohol carrier irritate the mucosa, causing congestion and sinus pressure felt as a headache.</p>
              <p>3) Immune allergy: repeated exposure to sensitisers such as eugenol, oakmoss and oxidised linalool builds an allergy, usually skin eczema and sometimes respiratory symptoms.</p>
              <p>Responses are highly individual. For a real diagnosis, see a dermatologist or allergist.</p>
            </div>
          </div>
        )}
      </div>

      {/* Note labels — Arabic block then English block per card */}
      <div className="space-y-3">
        <h2 className="font-heading font-semibold text-base text-[var(--brand)]">وسوم النوتات <span className="text-muted-foreground font-normal">Note labels</span></h2>
        <div className="grid grid-cols-1 gap-2">
          {RISK_GROUPS.map((g) => (
            <div key={g.id} className="bg-white rounded-none border-b border-[var(--brand)] p-3">
              <div className="flex items-center justify-between gap-2">
                <span className="font-body font-semibold text-sm">{g.ar}</span>
                <span className="flex gap-1.5 flex-shrink-0">
                  {g.mech.map((m) => (<span key={m} title={MECH[m].ar}>{MECH[m].emoji}</span>))}
                </span>
              </div>
              <p className="text-xs text-muted-foreground font-body mt-1">{g.reasonAr}</p>
              <div className="mt-2 pt-2 border-t border-border/40">
                <span className="font-body font-medium text-xs text-muted-foreground">{g.en}</span>
                <p className="text-[11px] text-muted-foreground/80 font-body italic">{g.reasonEn}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Statistics */}
      <div className="space-y-3">
        <h2 className="font-heading font-semibold text-base text-[var(--brand)]">إحصاء الصداع <span className="text-muted-foreground font-normal">Headache statistics</span></h2>
        <div className="grid grid-cols-4 gap-2">
          {[
            { ar: "الأسبوع", en: "Week", n: stats.week },
            { ar: "الشهر", en: "Month", n: stats.month },
            { ar: "السنة", en: "Year", n: stats.year },
            { ar: "الكل", en: "All", n: stats.all },
          ].map((c) => (
            <div key={c.en} className="bg-white rounded-none border-b border-[var(--brand)] p-3 text-center">
              <p className="text-2xl font-heading font-bold text-primary">{c.n}</p>
              <p className="text-[11px] text-muted-foreground font-body">{c.ar}<br /><span className="opacity-70">{c.en}</span></p>
            </div>
          ))}
        </div>
        {stats.all > 0 && (
          <div className="bg-white rounded-none border-b border-[var(--brand)] p-3 space-y-2">
            <p className="text-xs font-body font-semibold">حسب الشدّة <span className="text-muted-foreground font-normal">By severity</span></p>
            {SEVERITY.map((sv) => {
              const v = stats.bySeverity[sv.value] || 0;
              const pct = stats.all ? Math.round((v / stats.all) * 100) : 0;
              return (
                <div key={sv.value} className="flex items-center gap-2">
                  <span className="text-xs w-20 font-body">{sv.emoji} {sv.ar}</span>
                  <div className="flex-1 h-2 bg-secondary rounded-none overflow-hidden"><div className="h-full bg-primary" style={{ width: `${pct}%` }} /></div>
                  <span className="text-xs w-6 text-right font-body">{v}</span>
                </div>
              );
            })}
            {stats.topPerfumes.length > 0 && (
              <>
                <p className="text-xs font-body font-semibold pt-1">الأكثر ارتباطاً <span className="text-muted-foreground font-normal">Most linked</span></p>
                {stats.topPerfumes.map(([nm, n]) => (
                  <div key={nm} className="flex items-center justify-between text-xs font-body">
                    <span className="truncate">{nm}</span><span className="text-muted-foreground">{n}×</span>
                  </div>
                ))}
              </>
            )}
          </div>
        )}
      </div>

      {/* Headache log */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-heading font-semibold text-base text-[var(--brand)]">سجلّ الصداع <span className="text-muted-foreground font-normal">Headache log</span></h2>
          <button onClick={() => setShowForm((v) => !v)} className="text-xs font-body font-semibold text-primary">{showForm ? "إغلاق" : "تسجيل"}</button>
        </div>

        {showForm && (
          <div className="bg-white rounded-none border-b border-[var(--brand)] p-4 space-y-3">
            <div>
              <p className="text-xs font-body font-semibold mb-1">الشدّة</p>
              <div className="flex gap-2">
                {SEVERITY.map((sv) => (
                  <button key={sv.value} onClick={() => setFSeverity(sv.value)} className={`flex-1 text-xs font-body py-1.5 rounded-none border ${fSeverity === sv.value ? "border-primary bg-primary/10 text-primary font-bold" : "border-border/60"}`}>{sv.emoji} {sv.ar}</button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs font-body font-semibold mb-1">العطر المرتبط</p>
              {userPerfumes.length > 0 && (
                <select name="HeadacheGuide-sel1" value={fPerfumeId} onChange={(e) => { setFPerfumeId(e.target.value); const u = ratingByPid[e.target.value]; setFPerfumeName(u?.perfume_name || ""); }} className="w-full text-sm font-body bg-secondary rounded-none border border-border/60 p-2 mb-2">
                  <option value="">— اختر من عطورك —</option>
                  {userPerfumes.map((u) => (<option key={u.id} value={String(u.perfume_id)}>{u.perfume_name}{u.brand_name ? ` — ${u.brand_name}` : ""}</option>))}
                </select>
              )}
              <input name="HeadacheGuide-1" value={fPerfumeName} onChange={(e) => setFPerfumeName(e.target.value)} placeholder="أو اكتب اسم العطر" className="w-full text-sm font-body bg-secondary rounded-none border border-border/60 p-2" />
            </div>
            <div>
              <p className="text-xs font-body font-semibold mb-1">النوتة أو السبب المشتبه</p>
              <input name="HeadacheGuide-2" value={fNote} onChange={(e) => setFNote(e.target.value)} placeholder="مثال: زهور كثيفة، ألدهيدات" className="w-full text-sm font-body bg-secondary rounded-none border border-border/60 p-2" />
            </div>
            <div>
              <p className="text-xs font-body font-semibold mb-1">ما الذي خفّفه</p>
              <input name="HeadacheGuide-3" value={fReduced} onChange={(e) => setFReduced(e.target.value)} placeholder="مثال: هواء نقي، ماء، غسل" className="w-full text-sm font-body bg-secondary rounded-none border border-border/60 p-2" />
            </div>
            <button onClick={addEntry} className="w-full bg-primary text-primary-foreground font-body font-semibold text-sm py-2 rounded-none">حفظ التسجيل</button>
          </div>
        )}

        {log.length === 0 ? (
          <p className="text-xs text-muted-foreground font-body text-center py-4">لا تسجيلات بعد</p>
        ) : (
          <div className="space-y-2">
            {log.map((e) => {
              const sev = SEVERITY.find((sv) => sv.value === e.severity);
              return (
                <div key={e.id} className="bg-white rounded-none border-b border-[var(--brand)] p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-body font-semibold">{sev?.emoji} {sev?.ar || ""}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-muted-foreground font-body">{new Date(e.date).toLocaleDateString(isAr ? "ar" : "en")}</span>
                      <button onClick={() => delEntry(e.id)} className="text-muted-foreground hover:text-rose-500"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                  {e.perfume_name && <p className="text-xs font-body mt-1">🧴 {e.perfume_name}</p>}
                  {e.suspected && <p className="text-xs text-muted-foreground font-body">المشتبه: {e.suspected}</p>}
                  {e.reduced && <p className="text-xs text-muted-foreground font-body">خفّفه: {e.reduced}</p>}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Tips — Arabic block then English block */}
      <div className="space-y-3">
        <h2 className="font-heading font-semibold text-base text-[var(--brand)]">طرق التقليل و التجنّب <span className="text-muted-foreground font-normal">Reduce & avoid</span></h2>
        <div className="bg-white rounded-none border-b border-[var(--brand)] p-4">
          <div className="space-y-2" dir="rtl">
            {TIPS.map((t, i) => (
              <p key={`ar-${i}`} className="text-xs font-body text-muted-foreground flex gap-2 text-right"><span className="text-[var(--brand)] text-[8px] mt-1">◆</span><span>{t.ar}</span></p>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-border/40 space-y-2" dir="ltr">
            {TIPS.map((t, i) => (
              <p key={`en-${i}`} className="text-[11px] font-body text-muted-foreground/80 italic flex gap-2 text-left"><span className="text-[var(--brand)] text-[8px] mt-1">◆</span><span>{t.en}</span></p>
            ))}
          </div>
        </div>
      </div>

      {/* Perfumes & labels — plain search, English name only */}
      <div className="space-y-3">
        <h2 className="font-heading font-semibold text-base text-[var(--brand)]">العطور و وسومها <span className="text-muted-foreground font-normal">Perfumes & their labels</span></h2>
        <input name="HeadacheGuide-4"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث"
          className="w-full text-sm font-body bg-white rounded-none border-b border-[var(--brand)] p-2"
        />
        {(searching ? searchLoading : browseLoading) ? (
          <div className="flex justify-center py-10"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>
        ) : displayItems.length === 0 ? (
          <p className="text-xs text-muted-foreground font-body text-center py-6">لا نتائج</p>
        ) : (
          <div className="space-y-2">
            {displayItems.map((p) => {
              const labels = perfumeLabels(p);
              const rating = ratingByPid[String(p.id)];
              return (
                <button key={p.id} onClick={() => navigate(`/perfume?id=${p.id}`)} className="w-full text-left bg-white rounded-none border-b border-[var(--brand)] hover:border-primary/30 transition-all p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-body font-semibold truncate">{p.name_en || p.name || ""}</p>
                      <p className="text-xs text-muted-foreground font-body truncate">{p.brand_name}</p>
                    </div>
                    {rating?.headache && rating.headache !== "none" && (
                      <span className="text-[10px] font-bold text-rose-600 flex-shrink-0">صداع مُقيّم</span>
                    )}
                  </div>
                  {labels.length > 0 ? (
                    <div className="mt-2 space-y-1">
                      {labels.map((l) => (
                        <p key={l.mech} className="text-xs font-body">
                          <span>{l.emoji}</span>{" "}
                          <span className="text-muted-foreground">{l.groups.map((g) => g.ar).join(" - ")}</span>
                        </p>
                      ))}
                    </div>
                  ) : (
                    <p className="mt-2 text-xs text-muted-foreground font-body">لا وسوم خطر بارزة</p>
                  )}
                </button>
              );
            })}
          </div>
        )}
        {!searching && (
          <div className="flex items-center justify-between pt-1">
            <button disabled={page <= 1} onClick={() => setPage((v) => Math.max(1, v - 1))} className="text-xs font-body px-3 py-1.5 rounded-none border border-border/60 disabled:opacity-40">السابق</button>
            <span className="text-xs text-muted-foreground font-body">{page} / {totalPages}</span>
            <button disabled={page >= totalPages} onClick={() => setPage((v) => Math.min(totalPages, v + 1))} className="text-xs font-body px-3 py-1.5 rounded-none border border-border/60 disabled:opacity-40">التالي</button>
          </div>
        )}
      </div>

      {/* رابط دليل منتجات العناية — أسفل الصفحة */}
      <button type="button" onClick={() => navigate("/care-guide")} className="block w-full text-start font-body text-sm font-semibold hover:opacity-70" style={{ color: "#7C6FB0" }}>
        اقرأ دليل الصحة لمنتجات العناية من هنا<br /><span className="text-xs">Read Health Guide For Care Products From Here</span>
      </button>
    </div>
  );
}

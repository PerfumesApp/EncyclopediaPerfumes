import { compareEnglish } from "@/lib/sortName";
import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  RefreshCw, Search, Heart, ThumbsUp, ThumbsDown,
  Copy, Download, Pencil, ChevronLeft, ChevronRight,
} from "lucide-react";
import EraserIcon from "@/components/icons/EraserIcon";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import BookmarkButton from "@/components/shared/BookmarkButton";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { resolveUserMark, DEFAULT_USER_MARK } from "@/lib/exportSettings";
import { captureElement } from "@/lib/captureCanvas";
import GlosseryExplain from "@/components/shared/GlosseryExplain";
import { toast } from "sonner";

const PAGE_SIZE = 50;
const CATEGORY_SUGGESTIONS = ["life", "love", "wisdom", "success", "time", "patience", "gratitude", "art", "music", "other"];

export default function IncompleteWisdom() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [page, setPage] = useState(0);
  const [randomWisdom, setRandomWisdom] = useState(null);

  const [confirmDelete, setConfirmDelete] = useState(null);

  const { data: wisdoms = [] } = useQuery({
    queryKey: ["wisdom"],
    queryFn: () => apphost.entities.Wisdom.list("-created_date"),
  });
  const { data: userWisdoms = [] } = useQuery({
    queryKey: ["user-wisdom"],
    queryFn: () => apphost.entities.UserWisdom.list("-updated_date"),
  });

  const userMap = useMemo(() => {
    const m = {};
    for (const uw of userWisdoms) m[String(uw.wisdom_id)] = uw;
    return m;
  }, [userWisdoms]);

  const filtered = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    let result = wisdoms.filter((w) => {
      if (w.hidden) return false;
      if (!q) return true;
      const hay = [w.title, w.title_ar, w.wisdom, w.wisdom_ar, w.category, (w.tags || []).join(" ")]
        .filter(Boolean).join(" ").toLowerCase();
      return hay.includes(q);
    });
    const txt = (w) => (w.wisdom || w.title || w.wisdom_ar || w.title_ar || "");
    if (sortBy === "newest") result = [...result].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    else if (sortBy === "oldest") result = [...result].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    else if (sortBy === "alpha") result = [...result].sort((a, b) => compareEnglish(a, b, 1));
    else if (sortBy === "category") result = [...result].sort((a, b) => (a.category || "").localeCompare(b.category || ""));
    return result;
  }, [wisdoms, searchTerm, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const pageItems = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  const pickRandom = () => {
    if (filtered.length > 0) setRandomWisdom(filtered[Math.floor(Math.random() * filtered.length)]);
  };

  // ---- user reactions / favorite (persisted in UserWisdom) ----
  const updateUser = useMutation({
    mutationFn: async ({ wisdom, patch }) => {
      const existing = userMap[String(wisdom.id)];
      if (existing) return apphost.entities.UserWisdom.update(existing.id, patch);
      const snapshot = {
        wisdom_id: wisdom.id,
        title: wisdom.title || "", title_ar: wisdom.title_ar || "",
        wisdom: wisdom.wisdom || "", wisdom_ar: wisdom.wisdom_ar || "",
        reaction: "none", favorite: false,
      };
      return apphost.entities.UserWisdom.create({ ...snapshot, ...patch });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-wisdom"] }),
  });

  const toggleReaction = (wisdom, kind) => {
    const cur = userMap[String(wisdom.id)]?.reaction || "none";
    updateUser.mutate({ wisdom, patch: { reaction: cur === kind ? "none" : kind } });
  };
  const toggleFavorite = (wisdom) => {
    const cur = !!userMap[String(wisdom.id)]?.favorite;
    updateUser.mutate({ wisdom, patch: { favorite: !cur } });
  };

  // ---- add / edit / delete (user wisdom) ----
  const openAdd = () => navigate("/content-edit?type=wisdom");
  const openEdit = (w) => navigate(`/content-edit?type=wisdom&id=${w.id}`);


  const deleteWisdom = useMutation({
    mutationFn: async (w) => apphost.entities.Wisdom.update(w.id, { hidden: true }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["wisdom"] }); setConfirmDelete(null); },
  });

  // ---- copy / export ----
  const copyWisdom = (w) => {
    const parts = [w.title, w.wisdom, w.title_ar, w.wisdom_ar].filter(Boolean);
    if (w.category) parts.push("#" + w.category);
    if (w.tags?.length) parts.push(w.tags.map((t) => "@" + t).join(" "));
    navigator.clipboard?.writeText(parts.join("\n"));
    toast.success(isAr ? "تم النسخ" : "Copied");
  };
  const exportWisdom = async (w) => {
    const GOLD = "#c8a24a", GOLD_SOFT = "#e6cf95", GOLD_DEEP = "#9c7a2e";
    let mark = DEFAULT_USER_MARK;
    try { mark = (await resolveUserMark()) || DEFAULT_USER_MARK; } catch { /* keep default */ }

    const card = document.createElement("div");
    card.style.cssText = `
      position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none;
      width:560px; box-sizing:border-box;
      background:linear-gradient(135deg,#11302a 0%,#0e3b30 55%,#10302c 100%);
      padding:46px 42px; display:flex; flex-direction:column; gap:16px;
      border:1.5px solid ${GOLD_DEEP}; border-radius:18px;
      font-family:'Playfair Display','Amiri','Georgia',serif;`;
    const inner = document.createElement("div");
    inner.style.cssText = `position:absolute; inset:10px; border:0.5px solid rgba(200,162,74,0.45); border-radius:12px; pointer-events:none;`;
    card.appendChild(inner);

    const add = (text, css) => {
      if (!text) return;
      const el = document.createElement("div");
      el.textContent = text;
      el.style.cssText = "position:relative;" + css;
      card.appendChild(el);
    };
    // العنوان + الحكمة بالإنجليزية (يسار)، ثم بالعربية (يمين) — بلا هاشتاق.
    add(w.title, `direction:ltr;text-align:left;color:${GOLD};font-size:21px;font-weight:700;`);
    add(w.wisdom, `direction:ltr;text-align:left;color:${GOLD_SOFT};font-size:18px;font-style:italic;line-height:1.5;`);
    if ((w.title || w.wisdom) && (w.title_ar || w.wisdom_ar)) {
      const sep = document.createElement("div");
      sep.style.cssText = `position:relative;height:1px;background:linear-gradient(90deg,transparent,${GOLD_DEEP},transparent);margin:2px 0;`;
      card.appendChild(sep);
    }
    add(w.title_ar, `direction:rtl;text-align:right;color:${GOLD};font-size:21px;font-weight:700;font-family:'Amiri',serif;`);
    add(w.wisdom_ar, `direction:rtl;text-align:right;color:${GOLD_SOFT};font-size:19px;line-height:1.7;font-family:'Amiri',serif;`);
    add(mark, `color:${GOLD_DEEP};font-size:15px;letter-spacing:3px;text-align:center;margin-top:6px;font-family:sans-serif;`);

    document.body.appendChild(card);
    try {
      // دفعتا rAF لإتمام التخطيط قبل الالتقاط (نمط التصدير المثبت)
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const fullWidth = card.scrollWidth || 560;
      const fullHeight = card.scrollHeight;
      const canvas = await captureElement(card, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: null,
        width: fullWidth,
        height: fullHeight,
        windowWidth: fullWidth,
        windowHeight: fullHeight,
      });
      const base = (w.title || w.wisdom || w.title_ar || "wisdom")
        .replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-+|-+$/g, "").slice(0, 28) || "wisdom";
      const d = new Date(); const pad = (n) => String(n).padStart(2, "0");
      const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
      await saveCanvasAsImage(canvas, `Wisdom-${base}-${stamp}.png`);
      toast(isAr ? "تم التصدير" : "Exported", { position: "bottom-right" });
    } catch (e) {
      toast.error(isAr ? "فشل التصدير" : "Export failed", { position: "bottom-right" });
    } finally {
      document.body.removeChild(card);
    }
  };

  const t = (en, ar) => (isAr ? ar : en);

  return (
    <div className={`px-4 page-top pb-24 space-y-4 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <h1 className="font-heading text-xl font-bold">{t("Wisdom", "الحكمة")}</h1>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={openAdd}
            className="text-xs font-body font-medium rounded-none text-primary transition-colors">
            {t("Add", "إضافة")}
          </button>
          <SettingsSheet>
            <UserAvatarButton size={28} />
          </SettingsSheet>
        </div>
      </div>

      {/* Search + controls */}
      <div className="space-y-3">
        <div className="relative">
          <Input
            placeholder={t("Search..", "ابحث..")}
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); setPage(0); }}
            className="rounded-none pl-9 font-body text-sm"
          />
          <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        </div>
        <div className="flex flex-wrap gap-2 items-center">
          <select name="IncompleteWisdom-sel1"
            value={sortBy}
            onChange={(e) => { setSortBy(e.target.value); setPage(0); }}
            className="px-3 py-1.5 rounded-none border border-input bg-transparent text-xs font-body"
          >
            <option value="newest">{t("Newest", "الأحدث")}</option>
            <option value="oldest">{t("Oldest", "الأقدم")}</option>
            <option value="alpha">{t("Alphabetical", "أبجدي")}</option>
            <option value="category">{t("Category", "الفئة")}</option>
          </select>
          <button onClick={pickRandom}
            className=" rounded-none text-xs font-body font-medium text-muted-foreground hover:text-foreground transition-all flex items-center gap-1.5">
            <RefreshCw className="w-3 h-3" /> {t("Random", "عشوائي")}
          </button>
        </div>
      </div>

      {/* Random highlight */}
      {randomWisdom && (
        <div className="bg-primary/5 rounded-none p-5 space-y-2 border border-primary/30 shadow-sm">
          {randomWisdom.title && <p className="font-heading font-semibold text-sm" dir="ltr" style={{ unicodeBidi: "isolate" }}>{randomWisdom.title}</p>}
          {randomWisdom.wisdom && <p className="text-sm font-body" dir="ltr" style={{ unicodeBidi: "isolate" }}>{randomWisdom.wisdom}</p>}
          {randomWisdom.title_ar && <p className="font-heading font-semibold text-sm" dir="rtl" style={{ unicodeBidi: "isolate" }}>{randomWisdom.title_ar}</p>}
          {randomWisdom.wisdom_ar && <p className="text-sm font-body" dir="rtl" style={{ unicodeBidi: "isolate" }}>{randomWisdom.wisdom_ar}</p>}
          {randomWisdom.category && <span className="inline-block text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded">{randomWisdom.category}</span>}
        </div>
      )}

      {/* List */}
      <div className="space-y-2">
        {pageItems.length === 0 ? (
          <div className="py-8 text-center text-sm text-muted-foreground font-body">
            {t("No wisdom found", "لم يتم العثور على حكم")}
          </div>
        ) : (
          pageItems.map((w) => {
            const uw = userMap[String(w.id)] || {};
            const react = uw.reaction || "none";
            const fav = !!uw.favorite;
            const iconBtn = (active, activeClass) =>
              `p-1 rounded-none transition-colors ${active ? activeClass : "text-muted-foreground hover:text-foreground hover:bg-muted/50"}`;
            return (
              <div key={w.id} className="bg-card rounded-none p-4 border border-border/60 space-y-2 hover:border-primary/30 transition-all">
                {w.title && <p className="font-heading font-semibold text-sm" dir="ltr" style={{ unicodeBidi: "isolate" }}>{w.title}</p>}
                {w.wisdom && <p className="text-sm font-body" dir="ltr" style={{ unicodeBidi: "isolate" }}>{w.wisdom}</p>}
                {w.title_ar && <p className="font-heading font-semibold text-sm" dir="rtl" style={{ unicodeBidi: "isolate" }}>{w.title_ar}</p>}
                {w.wisdom_ar && <p className="text-sm font-body" dir="rtl" style={{ unicodeBidi: "isolate" }}>{w.wisdom_ar}</p>}

                {/* «شرح و إشارات» — موجة الحكم 500/500 (1.808): مطوية بعد المتنين، ثنائية دائما */}
                <GlosseryExplain entry={w} />

                {Array.isArray(w.images) && w.images.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {w.images.map((url, i) => (
                      <img key={i} src={url} alt="" className="h-20 w-20 object-cover rounded-lg" />
                    ))}
                  </div>
                )}

                {/* action bar — smaller icons + extra spacing from the Arabic text above (mobile) */}
                <div className="flex items-center gap-1 flex-wrap mt-3 pt-3 border-t border-border/40">
                  <button onClick={() => toggleFavorite(w)} title={t("Favorite", "مفضلة")} className={iconBtn(fav, "text-rose-500")}>
                    <Heart className="w-3.5 h-3.5" fill={fav ? "currentColor" : "none"} />
                  </button>
                  <button onClick={() => toggleReaction(w, "like")} title={t("Like", "إعجاب")} className={iconBtn(react === "like", "text-green-600")}>
                    <ThumbsUp className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => toggleReaction(w, "dislike")} title={t("Dislike", "عدم إعجاب")} className={iconBtn(react === "dislike", "text-orange-600")}>
                    <ThumbsDown className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => toggleReaction(w, "wtf")} title={t("Astonishing", "مذهل")} className={iconBtn(react === "wtf", "opacity-100")}>
                    <span className={`text-sm leading-none ${react === "wtf" ? "opacity-100" : "opacity-60"}`}>😱</span>
                  </button>
                  <BookmarkButton size={24} descriptor={{
                    item_type: "wisdom", item_id: String(w.id),
                    title_en: w.title || w.wisdom || "", title_ar: w.title_ar || w.wisdom_ar || "",
                    subtitle: w.category || "", path: "/incomplete-wisdom",
                  }} />
                  <button onClick={() => copyWisdom(w)} title={t("Copy", "نسخ")} className={iconBtn(false)}>
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => exportWisdom(w)} title={t("Export", "تصدير")} className={iconBtn(false)}>
                    <Download className="w-3.5 h-3.5" />
                  </button>
                  {w.is_user && (
                    <button onClick={() => openEdit(w)} title={t("Edit", "تعديل")} className={iconBtn(false)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {/* Cast Out — available for every wisdom (built-in is hidden, restorable) */}
                  <button onClick={() => setConfirmDelete(w)} title={t("Cast Out", "إهمال")} className="p-1 rounded-none text-muted-foreground hover:text-destructive hover:bg-muted/50 transition-colors">
                    <EraserIcon className="w-3.5 h-3.5" style={{ color: "#d97706" }} />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Pagination (50 / page) */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-2">
          <button disabled={safePage === 0} onClick={() => setPage(safePage - 1)}
            className="w-8 h-8 rounded-none flex items-center justify-center border border-border/60 disabled:opacity-30 hover:bg-muted/50">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-body text-muted-foreground">{safePage + 1} / {totalPages}</span>
          <button disabled={safePage >= totalPages - 1} onClick={() => setPage(safePage + 1)}
            className="w-8 h-8 rounded-none flex items-center justify-center border border-border/60 disabled:opacity-30 hover:bg-muted/50">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* أيقونة أدوات المائدة الذهبية — نهاية الصفحة الأولى فقط */}
      {safePage === 0 && (
        <div className="flex justify-center pt-5" aria-hidden="true">
          <svg className="w-6 h-6 text-[var(--brand)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8" />
            <path d="M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7" />
            <path d="m2.1 21.8 6.4-6.3" />
            <path d="m19 5-7 7" />
          </svg>
        </div>
      )}

      {/* Add / Edit dialog */}
      

      {/* Delete confirm */}
      <Dialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <DialogContent className="max-w-xs rounded-none">
          <DialogHeader><DialogTitle className="font-heading text-base">{t("Cast out this wisdom?", "إهمال هذه الحكمة؟")}</DialogTitle></DialogHeader>
          <p className="text-xs text-muted-foreground font-body -mt-1">{t("It will move to Cast Away — restore anytime.", "ستنتقل للمهملات — يمكنك استعادتها لاحقاً.")}</p>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 rounded-none" onClick={() => setConfirmDelete(null)}>{t("Cancel", "إلغاء")}</Button>
            <Button variant="destructive" className="flex-1 rounded-none" onClick={() => deleteWisdom.mutate(confirmDelete)}>{t("Cast Out", "إهمال")}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

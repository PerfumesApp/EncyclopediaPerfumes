import { useState, useMemo, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Download, SlidersHorizontal, Eye, EyeOff, FileText, ImageDown } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { usePersonNames } from "@/lib/usePersonNames";
import { usePins } from "@/lib/usePins";
import { useLang } from "@/lib/LanguageContext";
import { openHtmlReport, saveCanvasAsImage } from "@/lib/exportHelper";
import { captureElementHQ } from "@/lib/captureCanvas";
import { accordColor } from "@/lib/accordColors";
import { useCurrency } from "@/lib/useCurrency";
import { RATING_AXES } from "@/lib/ratingAxes";

/**
 * تفاعل / Reaction — الصفحة الموحّدة لكل قوائم المستخدمين في صفحة واحدة بلا تبويبات.
 * كل قسم قابل للطيّ (المدخلات قد تكون ضخمة) بلا أسهم وبلا تعداد. كل مدخل يحمل خطّاً
 * أفقيّاً صغيراً بلون ملفّ صاحبه. للمراجعة/تمت المراجعة مشتقّتان من التقييم. بلا أيقونات
 * للمدخلات، بلا إطارات، بلا جداول، بلا صور افتراضية، بلا رموز. الأكسنت = لون المستخدم.
 */

const PERSONS = ["person1", "person2"];
const cleanLatin = (x) => (/[\u0600-\u06FF]/.test(x || "") ? "" : x);

function pName(p, isAr) {
  return p?.name_en || (isAr ? cleanLatin(p?.name || "") : (p?.name || "")) || p?.name || "";
}

export default function Reaction() {
  const { names, profiles } = usePersonNames();
  const { isAr } = useLang();
  const [closed, setClosed] = useState({ notebook: true }); // المفكّرة مطويّة افتراضاً
  const [manageOpen, setManageOpen] = useState(false);
  const [showPurchases, setShowPurchases] = useState(25);
  const [nbShown, setNbShown] = useState(25); // تحميل تدريجيّ للمفكّرة
  const { currency } = useCurrency();
  const summaryImgRef = useRef(null);
  const [summaryPerson, setSummaryPerson] = useState("all"); // خلاصة: الكل | person1 | person2
  const handleSummaryImage = async () => {
    const el = summaryImgRef.current;
    if (!el) return;
    try {
      const bg = getComputedStyle(document.documentElement).getPropertyValue("--page-bg").trim() || "#ffffff";
      const canvas = await captureElementHQ(el, { pixelRatio: 3, backgroundColor: bg });
      const tag = (summaryPerson !== "all" ? (nameOf(summaryPerson) + "-") : "") + Date.now().toString(36).slice(-5);
      await saveCanvasAsImage(canvas, `reaction-${tag}.png`);
    } catch { /* تجاهل */ }
  };
  const [hidden, setHidden] = useState(() => {
    try { return JSON.parse((typeof localStorage !== "undefined" && localStorage.getItem("reaction_hidden")) || "{}") || {}; } catch { return {}; }
  });
  const toggleHidden = (k) => setHidden((h) => {
    const next = { ...h, [k]: !h[k] };
    try { localStorage.setItem("reaction_hidden", JSON.stringify(next)); } catch { /* تجاهل */ }
    return next;
  });
  const SECTION_META = [
    { key: "summary", ar: "خلاصة", en: "Essence" },
    { key: "reactions", ar: "تفاعلات ❤️👍👎😱", en: "Reactions" },
    { key: "notes", ar: "نوتات", en: "Notes" },
    { key: "own", ar: "مجموعات", en: "Collections" },
    { key: "forreview", ar: "للمراجعة", en: "For Review" },
    { key: "reviewed", ar: "تمت مراجعة", en: "Reviewed" },
    { key: "iwant", ar: "أرغب بشرائه", en: "I Want To Buy" },
    { key: "purchases", ar: "مشتريات", en: "Purchases" },
    { key: "wear", ar: "ارتداء", en: "Wear" },
    { key: "custom", ar: "مخصّص", en: "Custom" },
    { key: "encfav", ar: "موسوعة", en: "Encyclopedia" },
    { key: "notebook", ar: "تفاعل", en: "Interactions" },
  ];

  const colorOf = (person) => profiles?.[person]?.color || "var(--brand)";
  const nameOf = (person) => names?.[person] || person;

  const { data: _userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });
  const { data: customLists = [] } = useQuery({
    queryKey: ["custom-lists"],
    queryFn: () => apphost.entities.CustomList.list("name"),
  });
  const { data: _userGlossaryTerms = [] } = useQuery({
    queryKey: ["user-glossary-terms"],
    queryFn: () => apphost.entities.UserGlossaryTerm.list("-created_date"),
  });
  const { data: _wishes = [] } = useQuery({
    queryKey: ["wishlists"],
    queryFn: () => apphost.entities.Wishlist.list("-added_date"),
  });
  const { data: _wearLogs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-date"),
  });
  const { data: bookmarks = [] } = useQuery({
    queryKey: ["bookmarks"],
    queryFn: () => apphost.entities.Bookmark.list("-created_date"),
  });
  const { data: _purchases = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
  });
  const { data: _userNotes = [] } = useQuery({
    queryKey: ["user-note"],
    queryFn: () => apphost.entities.UserNote.list("-created_date"),
  });
  const { data: _userBrands = [] } = useQuery({
    queryKey: ["user-brand"],
    queryFn: () => apphost.entities.UserBrand.list("-created_date"),
  });
  const { data: _userPerfumers = [] } = useQuery({
    queryKey: ["user-perfumer"],
    queryFn: () => apphost.entities.UserPerfumer.list("-created_date"),
  });

  // معرّفات المجموعة فقط ثم getMany — بلا تحميل 130 ألف
  // فلتر الشخص لكامل الصفحة — يضبطه مربّع المستخدم أعلى الصفحة (الكل/Alpha/Bravo)
  const pf = (arr) => summaryPerson === "all" ? arr : arr.filter((x) => x.person === summaryPerson);
  const userPerfumes = pf(_userPerfumes);
  const userGlossaryTerms = pf(_userGlossaryTerms);
  const wishes = pf(_wishes);
  const wearLogs = pf(_wearLogs);
  const purchases = pf(_purchases);
  const userNotes = pf(_userNotes);
  const userBrands = pf(_userBrands);
  const userPerfumers = pf(_userPerfumers);

  const collectionIds = useMemo(() => {
    const set = new Set();
    userPerfumes.forEach((u) => { if (u.perfume_id) set.add(String(u.perfume_id)); });
    customLists.forEach((l) => (l.perfume_ids || "").split(",").forEach((id) => { const t = id.trim(); if (t) set.add(t); }));
    return [...set];
  }, [userPerfumes, customLists]);

  const { data: collectionPerfumes = [] } = useQuery({
    queryKey: ["reaction-perfumes", collectionIds.join(",")],
    queryFn: () => apphost.entities.Perfume.getMany(collectionIds),
    enabled: collectionIds.length > 0,
    staleTime: 1000 * 60 * 5,
  });

  const byId = useMemo(() => {
    const m = new Map();
    collectionPerfumes.forEach((p) => m.set(String(p.id), p));
    return m;
  }, [collectionPerfumes]);


  // مدخلات عطور من شرط على UserPerfume → [{p, person}]
  const perfEntries = (pred) =>
    userPerfumes.filter(pred).map((u) => ({ p: byId.get(String(u.perfume_id)), person: u.person, u })).filter((x) => x.p);

  // «مراجعة» = أيّ مدخل سجّله المستخدم (التقييم جزء منها). مدخل واحد ⇒ تمت مراجعة.
  const hasReviewInput = (u) => !!(
    (u.rating && u.rating > 0) ||
    (u.list && ["favorite", "recommend", "dislike", "wtf"].includes(u.list)) ||
    (u.personal_notes && String(u.personal_notes).trim()) ||
    u.recommend_to ||
    u.r_scent || u.r_longevity || u.r_sillage || u.r_bottle ||
    u.rate_originality || u.rate_consistency || u.rate_value || u.rate_craft
  );

  // الأقسام (مشتقّة) — التفاعلات الأربعة مدموجة في قسم واحد بإيموجي، العيّنات بلا مراجعات
  const REACT_EMOJI = { favorite: "❤️", recommend: "👍", dislike: "👎", wtf: "😱" };
  const reactionEntries = userPerfumes
    .filter((u) => ["favorite", "recommend", "dislike", "wtf"].includes(u.list))
    .map((u) => ({ p: byId.get(String(u.perfume_id)), person: u.person, emoji: REACT_EMOJI[u.list], list: u.list, u }))
    .filter((x) => x.p);

  const noteReactionEntries = userNotes
    .filter((n) => ["favorite", "recommend", "dislike", "wtf"].includes(n.list))
    .map((n) => ({ id: n.id, note_id: n.note_id, name: n.note_name, name_ar: n.note_name_ar, person: n.person, emoji: REACT_EMOJI[n.list] }));

  // البراند — موحّد مع العطر: تفاعل 4-إيموجي + لمراجعة(مجدوَل وبلا مدخل) + تمت مراجعة(أيّ مدخل)
  const brandReviewed = (b) => !!(b.rating || ["favorite", "recommend", "dislike", "wtf"].includes(b.list) || (b.personal_notes && String(b.personal_notes).trim()) || RATING_AXES.some((ax) => b[ax.key]));
  const brandReactionEntries = userBrands
    .filter((b) => ["favorite", "recommend", "dislike", "wtf"].includes(b.list))
    .map((b) => ({ id: b.id, brand_id: b.brand_id, name: b.brand_name, person: b.person, emoji: REACT_EMOJI[b.list] }));
  const brandForReview = userBrands.filter((b) => b.review_scheduled && !brandReviewed(b)).map((b) => ({ id: b.id, brand_id: b.brand_id, name: b.brand_name, person: b.person }));
  const brandReviewedList = userBrands.filter((b) => brandReviewed(b)).map((b) => ({ id: b.id, brand_id: b.brand_id, name: b.brand_name, person: b.person }));

  const perfumerReactionEntries = userPerfumers
    .filter((pf) => ["favorite", "recommend", "dislike", "wtf"].includes(pf.list))
    .map((pf) => ({ id: pf.id, perfumer_id: pf.perfumer_id, name: pf.perfumer_name, person: pf.person, emoji: REACT_EMOJI[pf.list] }));

  // ── المثبّتات (تجميع كل الأنواع في «تفاعل») ──
  const { pinnedIds: pinPerf } = usePins("perfume");
  const { pinnedIds: pinBrand } = usePins("brand");
  const { pinnedIds: pinPerfumer } = usePins("perfumer");
  const { pinnedIds: pinNote } = usePins("note");
  const { pinnedIds: pinEnc } = usePins("encentry");
  const { data: pinPerfData = [] } = useQuery({ queryKey: ["pin-perf", pinPerf], queryFn: () => apphost.entities.Perfume.getMany(pinPerf), enabled: pinPerf.length > 0 });
  const { data: pinBrandData = [] } = useQuery({ queryKey: ["pin-brand", pinBrand], queryFn: () => apphost.entities.PerfumeBrand.getMany(pinBrand), enabled: pinBrand.length > 0 });
  const { data: pinPerfumerData = [] } = useQuery({ queryKey: ["pin-perfumer", pinPerfumer], queryFn: () => apphost.entities.Perfumer.getMany(pinPerfumer), enabled: pinPerfumer.length > 0 });
  const { data: pinNoteData = [] } = useQuery({ queryKey: ["pin-note", pinNote], queryFn: () => apphost.entities.PerfumeNote.getMany(pinNote), enabled: pinNote.length > 0 });
  const { data: pinEncData = [] } = useQuery({ queryKey: ["pin-enc", pinEnc], queryFn: () => apphost.entities.EncEntry.getMany(pinEnc), enabled: pinEnc.length > 0 });
  const pinnedRows = useMemo(() => {
    const nm = (x) => isAr ? (x?.name_ar || x?.name) : (x?.name || x?.name_ar);
    const encTitle = (e) => (e?.titles && (e.titles.ar || e.titles.en)) || e?.title || e?.name || "";
    const ord = (ids, data, fn) => ids.map((pid) => { const x = data.find((d) => String(d.id) === String(pid)); return x ? fn(x) : null; }).filter(Boolean);
    return [
      ...ord(pinPerf, pinPerfData, (x) => ({ k: "pp" + x.id, name: nm(x), label: isAr ? "عطر" : "Perfume", to: `/perfume?id=${x.id}` })),
      ...ord(pinBrand, pinBrandData, (x) => ({ k: "pb" + x.id, name: nm(x), label: isAr ? "ماركة" : "Brand", to: `/brand?id=${x.id}` })),
      ...ord(pinPerfumer, pinPerfumerData, (x) => ({ k: "pf" + x.id, name: x.name, label: isAr ? "عطّار" : "Perfumer", to: `/perfumer?id=${x.id}` })),
      ...ord(pinNote, pinNoteData, (x) => ({ k: "pn" + x.id, name: nm(x), label: isAr ? "نوتة" : "Note", to: `/note?id=${x.id}` })),
      ...ord(pinEnc, pinEncData, (x) => ({ k: "pe" + x.id, name: encTitle(x), label: isAr ? "موسوعة" : "Encyclopedia", to: `/encyclopedia/view/${x.id}` })),
    ];
  }, [pinPerf, pinBrand, pinPerfumer, pinNote, pinEnc, pinPerfData, pinBrandData, pinPerfumerData, pinNoteData, pinEncData, isAr]);

  const sections = [
    { key: "own", ar: "مجموعات", en: "Collections", entries: perfEntries((u) => u.in_collection === 1) },
    { key: "forreview", ar: "للمراجعة", en: "For Review",
      entries: userPerfumes.filter((u) => u.review_scheduled && !hasReviewInput(u)).map((u) => ({ p: byId.get(String(u.perfume_id)), person: u.person, u })).filter((x) => x.p) },
    { key: "reviewed", ar: "تمت مراجعة", en: "Reviewed",
      entries: userPerfumes.filter((u) => hasReviewInput(u)).map((u) => ({ p: byId.get(String(u.perfume_id)), person: u.person, u })).filter((x) => x.p) },
  ];

  // رغبات Wishlist: تُعرض الآن كأيقونة داخل «مخصّص» (لا قائمة منفردة)
  const wishPerfumes = pf(userPerfumes).filter((u) => u.list === "wishlist").map((u) => byId.get(String(u.perfume_id))).filter(Boolean);

  const encFavs = userGlossaryTerms.filter((t) => t.reaction === "favorite");
  // للمفكّرة: مفضّلة الموسوعة تظهر بغضّ النظر عن فلتر الشخص (تماماً مثل bookmarks بلا person)
  const encFavsAll = _userGlossaryTerms.filter((t) => t.reaction === "favorite");

  const iWantToBuy = wishes.map((w) => ({ name: w.perfume_name || "", brand: w.brand_name || "", person: w.person, pid: w.perfume_id }));
  const wearList = (() => {
    const seen = new Map();
    wearLogs.forEach((l) => { const k = String(l.perfume_id || l.id); if (!seen.has(k)) seen.set(k, { name: l.perfume_name || "", brand: l.brand_name || "", person: l.person, pid: l.perfume_id }); });
    return [...seen.values()];
  })();
  const purchasesList = purchases.map((p) => ({ name: p.perfume_name || "", brand: p.brand_name || "", person: p.person, pid: p.perfume_id, type: p.type, ml: p.ml, cost: p.cost, date: p.purchase_date }));
  const purchaseStats = useMemo(() => {
    const num = (x) => Number(x) || 0;
    const sum = (arr, k) => arr.reduce((t, p) => t + num(p[k]), 0);
    const samples = purchases.filter((p) => p.type === "sample");
    const bottles = purchases.filter((p) => p.type === "bottle");
    const totVol = sum(purchases, "ml"), totCost = sum(purchases, "cost");
    return {
      count: purchases.length, totVol, totCost,
      perMl: totVol > 0 ? (totCost / totVol).toFixed(2) : "0",
      sVol: sum(samples, "ml"), sCost: sum(samples, "cost"), sN: samples.length,
      bVol: sum(bottles, "ml"), bCost: sum(bottles, "cost"), bN: bottles.length,
    };
  }, [purchases]);

  const toggle = (k) => setClosed((c) => ({ ...c, [k]: !c[k] }));

  const handleExport = async () => {
    const root = typeof getComputedStyle !== "undefined" ? getComputedStyle(document.documentElement) : null;
    const brand = ((root && root.getPropertyValue("--brand")) || "#C8A02E").trim() || "#C8A02E";
    const cOf = (person) => profiles?.[person]?.color || brand;
    const esc = (x) => String(x == null ? "" : x).replace(/[&<>]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[m]));
    const exportSections = [
      { ar: "❤️👍👎😱", en: "❤️👍👎😱", rows: [...reactionEntries.map((e) => ({ name: pName(e.p, isAr), name_ar: e.p.name_ar, brand: e.p.brand_name, person: e.person, emoji: e.emoji })), ...brandReactionEntries.map((e) => ({ name: e.name, person: e.person, emoji: e.emoji })), ...perfumerReactionEntries.map((e) => ({ name: e.name, person: e.person, emoji: e.emoji }))] },
      { ar: "نوتات", en: "Notes", rows: noteReactionEntries.map((e) => ({ name: isAr ? (e.name_ar || e.name) : (e.name || e.name_ar), name_ar: isAr ? e.name : e.name_ar, person: e.person, emoji: e.emoji })) },
      ...sections.map((s) => {
        const extra = s.key === "forreview" ? brandForReview : s.key === "reviewed" ? brandReviewedList : [];
        return { ar: s.ar, en: s.en, rows: [...s.entries.map((e) => ({ name: pName(e.p, isAr), name_ar: e.p.name_ar, brand: e.p.brand_name, person: e.person })), ...extra.map((b) => ({ name: b.name, person: b.person }))] };
      }),
      { ar: "أرغب بشرائه", en: "I Want To Buy", rows: iWantToBuy.map((w) => ({ name: w.name, brand: w.brand, person: w.person })) },
      { ar: "مشتريات", en: "Purchases", rows: purchasesList.map((w) => ({ name: w.name, brand: w.brand, person: w.person })) },
      { ar: "ارتداء", en: "Wear", rows: wearList.map((w) => ({ name: w.name, brand: w.brand, person: w.person })) },
      { ar: "مخصّص", en: "Custom", rows: customLists.flatMap((l) => (l.perfume_ids || "").split(",").map((x) => x.trim()).filter(Boolean).map((idv) => byId.get(idv)).filter(Boolean).map((p) => ({ name: pName(p, isAr), brand: p.brand_name, person: null, emoji: l.icon || "📋", group: l.name }))) },
      { ar: "موسوعة", en: "Encyclopedia", rows: encFavs.map((t) => ({ name: t.title_en || t.title || t.term, name_ar: t.title_ar, person: t.person })) },
      { ar: "تفاعل", en: "Interactions", rows: bookmarks.map((b) => ({ name: b.title_en || b.title_ar || b.subtitle, name_ar: b.title_en ? b.title_ar : "", person: null })) },
    ].filter((s) => s.rows.length);
    const rowHtml = (r) => `<div class="row"><span class="ln" style="background:${r.person ? cOf(r.person) : brand}"></span>${r.emoji ? '<span class="em">' + r.emoji + "</span>" : ""}<span class="t"><span class="nm">${esc(r.name)}${r.name_ar && r.name_ar !== r.name ? ' <span class="ar">' + esc(r.name_ar) + "</span>" : ""}</span>${r.brand ? '<span class="br">' + esc(r.brand) + "</span>" : ""}${r.group ? '<span class="br">' + esc(r.group) + "</span>" : ""}</span></div>`;
    const bodyHtml = exportSections.map((s) => `<div class="sec"><div class="secttl">${esc(isAr ? s.ar : s.en)}</div>${s.rows.map(rowHtml).join("")}</div>`).join("");
    await openHtmlReport(`<!DOCTYPE html>
<html dir="${isAr ? "rtl" : "ltr"}" lang="${isAr ? "ar" : "en"}">
<head><meta charset="utf-8"/><title>تفاعل Reaction</title>
<style>
  @font-face { font-family:'Cairo'; src:url('/fonts/Cairo.woff') format('woff'); font-weight:400 800; font-display:swap; }
  @font-face { font-family:'Amiri'; src:url('/fonts/Amiri.woff') format('woff'); font-weight:400 700; font-display:swap; }
  *{box-sizing:border-box;} body{font-family:'Cairo','Segoe UI',Arial,sans-serif; direction:${isAr ? "rtl" : "ltr"}; padding:32px; color:#2a2926; background:#fff; font-size:13px; line-height:1.7;}
  h1{font-size:24px; font-weight:800; text-align:center; margin-bottom:2px; color:${brand};}
  .subtitle{text-align:center; color:${brand}; opacity:.75; margin-bottom:22px; font-size:12px;}
  .sec{margin-top:20px;} .secttl{font-size:14px; font-weight:800; color:${brand}; margin-bottom:6px;}
  .row{display:flex; align-items:flex-start; gap:10px; padding:4px 0;}
  .ln{flex:0 0 auto; width:20px; height:3px; margin-top:9px; display:inline-block;}
  .em{flex:0 0 auto; font-size:13px; line-height:1.4;}
  .nm{font-weight:700; font-size:14px; display:block;} .ar{color:#8a8580; font-weight:400; font-size:12px;}
  .br{color:#8a8580; font-size:11px; display:block; text-transform:uppercase; letter-spacing:1px; margin-top:1px;}
  @media print{ body{padding:18px;} @page{margin:1.2cm; size:A4;} }
</style></head>
<body>
<h1>${isAr ? "تفاعل" : "Reaction"}</h1>
<div class="subtitle">${isAr ? "كل القوائم في صفحة واحدة" : "All lists in one page"}</div>
${bodyHtml || `<div class="subtitle">${isAr ? "لا شيء بعد" : "Empty"}</div>`}
</body></html>`, "reaction");
  };

  const Line = ({ person }) => (
    <span aria-hidden className="rxn-line" style={{ display: "inline-block", width: 20, height: 3, background: colorOf(person), flexShrink: 0, marginTop: 11 }} />
  );

  // صفّ مشترى بتنسيق صفحة العيّنات: النوع · الحجم · السعر · التاريخ + رابط العطر
  const purchaseTypeLabel = (t) => t === "sample" ? (isAr ? "عيّنة" : "Sample") : t === "bottle" ? (isAr ? "قنينة" : "Bottle") : t === "product" ? (isAr ? "منتج" : "Product") : (t || "");
  const PurchaseRow = ({ w }) => {
    const fmtDate = w.date ? new Date(w.date).toLocaleDateString(isAr ? "ar" : "en-GB", { year: "numeric", month: "short", day: "numeric" }) : "";
    const sub = [purchaseTypeLabel(w.type), w.ml ? `${w.ml}ml` : "", w.cost ? `${Number(w.cost).toFixed(0)} ${currency}` : "", fmtDate].filter(Boolean).join(" \u00b7 ");
    const inner = (
      <>
        <Line person={w.person || "person1"} />
        <span style={{ minWidth: 0 }}>
          <span className="font-heading block" style={{ fontSize: 15, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{w.name}</span>
          {sub && <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", marginTop: 1 }}>{sub}</span>}
        </span>
      </>
    );
    return w.pid
      ? <Link to={`/perfume?id=${w.pid}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>{inner}</Link>
      : <div className="flex items-start gap-3 py-2">{inner}</div>;
  };

  const BrandRow = ({ b, emoji }) => (
    <Link to={`/brand?id=${b.brand_id}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
      <Line person={b.person || "person1"} />
      {emoji && <span style={{ fontSize: 14, marginTop: 7, flexShrink: 0, lineHeight: 1 }}>{emoji}</span>}
      <span className="font-heading group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{b.name}</span>
    </Link>
  );

  const PerfumerRow = ({ pf, emoji }) => (
    <Link to={`/perfumer?id=${pf.perfumer_id}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
      <Line person={pf.person || "person1"} />
      {emoji && <span style={{ fontSize: 14, marginTop: 7, flexShrink: 0, lineHeight: 1 }}>{emoji}</span>}
      <span className="font-heading group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{pf.name}</span>
    </Link>
  );

  // صفّ مثبّت — يحمل نوعه و رابطه لصفحته
  const PinRow = ({ p }) => (
    <Link to={p.to} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
      <span aria-hidden style={{ display: "inline-block", width: 20, height: 3, background: "var(--brand)", flexShrink: 0, marginTop: 9 }} />
      <span style={{ minWidth: 0 }}>
        <span className="font-heading block group-hover:opacity-70 transition-opacity" style={{ fontSize: 14, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{p.name}</span>
        <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", marginTop: 1 }}>{p.label}</span>
      </span>
    </Link>
  );

  const PerfRow = ({ p, person, emoji }) => (
    <Link to={`/perfume?id=${p.id}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
      <Line person={person} />
      {emoji && <span style={{ fontSize: 14, marginTop: 7, flexShrink: 0, lineHeight: 1 }}>{emoji}</span>}
      <span style={{ minWidth: 0 }}>
        <span className="font-heading block group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>
          {pName(p, isAr)}
          {p.name_ar && p.name_ar !== pName(p, isAr) && (
            <span className="font-body" style={{ fontSize: 12, color: "#A98B97", marginInlineStart: 8 }}>{p.name_ar}</span>
          )}
        </span>
        {p.brand_name && (
          <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginTop: 1 }}>{p.brand_name}</span>
        )}
      </span>
    </Link>
  );

  const TermRow = ({ t }) => (
    <Link to={`/glossary-term?id=${t.term_id || t.id}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
      <Line person={t.person || "person1"} />
      <span className="font-heading group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>
        {t.title_en || t.title || t.term || ""}
        {t.title_ar && <span className="font-body" style={{ fontSize: 12, color: "#A98B97", marginInlineStart: 8 }}>{t.title_ar}</span>}
      </span>
    </Link>
  );

  const SelfRow = ({ name, brand, person, pid }) => {
    const inner = (
      <>
        <Line person={person || "person1"} />
        <span style={{ minWidth: 0 }}>
          <span className="font-heading block group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{name}</span>
          {brand && <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginTop: 1 }}>{brand}</span>}
        </span>
      </>
    );
    return pid
      ? <Link to={`/perfume?id=${pid}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>{inner}</Link>
      : <div className="flex items-start gap-3 py-2 group">{inner}</div>;
  };

  const NoteRow = ({ b }) => (
    <Link to={b.path || "#"} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
      <span aria-hidden style={{ display: "inline-block", width: 20, height: 3, background: "var(--brand)", flexShrink: 0, marginTop: 11 }} />
      <span className="font-heading group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>
        {b.title_en || b.title_ar || b.subtitle || ""}
        {b.title_ar && b.title_en && <span className="font-body" style={{ fontSize: 12, color: "#A98B97", marginInlineStart: 8 }}>{b.title_ar}</span>}
      </span>
    </Link>
  );

  const SectionHead = ({ k, ar, en }) => (
    <button type="button" onClick={() => toggle(k)} className="flex items-baseline gap-3 w-full text-start py-1">
      <span className="font-heading" style={{ fontSize: 14, color: "var(--brand)", fontWeight: 700 }}>{ar}</span>
      <span className="font-heading" style={{ fontSize: 12, color: "#A98B97", letterSpacing: 1 }}>{en}</span>
    </button>
  );

  // ── خلاصة ذكيّة: تُبنى تلقائيّاً من مدخلات المستخدم، وتتعامل مع الفراغ الابتدائيّ ──
  const summary = useMemo(() => {
    const LIKE = ["favorite", "recommend"];
    const fp = (arr) => summaryPerson === "all" ? arr : arr.filter((x) => x.person === summaryPerson);
    const uPerfumes = fp(userPerfumes), uBrands = fp(userBrands), uNotes = fp(userNotes), uPerfumers = fp(userPerfumers), uEnc = fp(encFavs);
    const likedP = uPerfumes.filter((u) => LIKE.includes(u.list)).map((u) => byId.get(String(u.perfume_id))).filter(Boolean);
    const tally = (arr) => { const m = {}; arr.forEach((x) => { const k = String(x).trim(); if (k) m[k] = (m[k] || 0) + 1; }); return m; };
    const splitNotes = (p) => [p.top_notes, p.heart_notes, p.base_notes].flatMap((s) => String(s || "").split(",")).map((x) => x.trim()).filter(Boolean);
    const top = (m, min, n) => Object.entries(m).filter(([, c]) => c >= min).sort((a, b) => b[1] - a[1]).slice(0, n).map(([k]) => k);
    const topNotes = top(tally(likedP.flatMap(splitNotes)), 2, 8);
    const topAccords = top(tally(likedP.flatMap((p) => String(p.accords || "").split(",").map((x) => x.trim()).filter(Boolean))), 2, 6);
    const splitBi = (t) => { const m = String(t || "").trim().match(/^([A-Za-z][A-Za-z \-/&]*)(.*)$/); return m ? { en: m[1].trim(), ar: m[2].trim() } : { en: String(t || "").trim(), ar: "" }; };
    const famT = {}; likedP.flatMap((p) => String(p.odor_family || "").split(",").map((x) => x.trim()).filter(Boolean)).forEach((tok) => { const b = splitBi(tok); const disp = isAr ? (b.ar || b.en) : (b.en || b.ar); const key = (b.en || b.ar).toLowerCase(); if (!key) return; if (!famT[key]) famT[key] = { name: disp, raw: tok, count: 0 }; famT[key].count++; });
    const topFamilies = Object.values(famT).sort((a, b) => b.count - a.count).slice(0, 6).map((fm) => ({ name: fm.name, color: accordColor(fm.raw) }));
    const favBrands = [...new Set(uBrands.filter((b) => LIKE.includes(b.list)).map((b) => b.brand_name).filter(Boolean))];
    const favNotes = [...new Set(uNotes.filter((nn) => LIKE.includes(nn.list)).map((nn) => (isAr ? (nn.note_name_ar || nn.note_name) : (nn.note_name || nn.note_name_ar))).filter(Boolean))];
    const favPerfumers = [...new Set(uPerfumers.filter((pp) => LIKE.includes(pp.list)).map((pp) => pp.perfumer_name).filter(Boolean))];
    const encNames = uEnc.map((t) => (isAr ? (t.title_ar || t.title_en || t.title) : (t.title_en || t.title_ar || t.title))).filter(Boolean);
    const empty = likedP.length === 0 && favBrands.length === 0 && favNotes.length === 0 && favPerfumers.length === 0 && encNames.length === 0;
    return { likedCount: likedP.length, topNotes, topAccords, topFamilies, favBrands, favNotes, favPerfumers, encNames, empty };
  }, [userPerfumes, byId, userBrands, userNotes, userPerfumers, encFavs, isAr, summaryPerson]);

  const summaryLine = (label, arr) => (!arr || !arr.length) ? null : (
    <div>
      <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginBottom: 2 }}>{label}</span>
      <span className="font-heading block" style={{ fontSize: 14, color: "var(--foreground, #2A2024)", lineHeight: 1.6 }}>{arr.join(isAr ? "، " : ", ")}</span>
    </div>
  );

  const summaryLineColored = (label, items) => (!items || !items.length) ? null : (
    <div>
      <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginBottom: 2 }}>{label}</span>
      <span className="font-heading block" style={{ fontSize: 14, color: "var(--foreground, #2A2024)", lineHeight: 1.6 }}>
        {items.map((it, i) => (
          <span key={i}>
            <span style={{ display: "inline-block", width: 9, height: 9, borderRadius: 2, background: it.color, marginInlineEnd: 5, verticalAlign: "middle" }} />
            {it.name}{i < items.length - 1 ? (isAr ? "، " : ", ") : ""}
          </span>
        ))}
      </span>
    </div>
  );

  const handleSummaryExport = () => {
    const s = summary;
    const esc = (x) => String(x == null ? "" : x).replace(/[&<>]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[m]));
    const row = (arL, enL, arr) => (arr && arr.length) ? `<div class="r"><span class="l">${esc(arL)} — ${esc(enL)}</span><span class="v">${arr.map(esc).join("، ")}</span></div>` : "";
    const rowFam = (arL, enL, items) => (items && items.length) ? `<div class="r"><span class="l">${esc(arL)} — ${esc(enL)}</span><span class="v">${items.map((it) => `<span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${esc(it.color)};margin-inline-end:5px;vertical-align:middle"></span>${esc(it.name)}`).join("، ")}</span></div>` : "";
    const body = s.empty
      ? `<div class="sub">تتكوّن خلاصتك تلقائيّاً من تفاعلك — ابدأ بالإعجاب بالعطور والنوتات<br>Your summary builds automatically from your reactions — start by liking perfumes and notes</div>`
      : [
          row("بصمتك العطريّة", "Your olfactory fingerprint", s.topNotes),
          rowFam("العائلة العطريّة", "Olfactory family", s.topFamilies),
          row("ماركات مفضّلة", "Brands you favour", s.favBrands),
          row("نوتات مفضّلة", "Notes you favour", s.favNotes),
          row("عطّارون مفضّلون", "Perfumers you favour", s.favPerfumers),
          row("من الموسوعة", "From the encyclopedia", s.encNames),
        ].join("");
    openHtmlReport(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>خلاصة Essence</title>
<style>body{font-family:system-ui,'Segoe UI',Tahoma,sans-serif; max-width:680px; margin:0 auto; padding:28px; color:#2A2024;}
h1{font-size:22px; color:#9a7b1f; margin:0 0 4px;} .sub{font-size:13px; color:#8a8580; margin-bottom:18px; line-height:1.7;}
.r{padding:10px 0; border-bottom:1px solid #eee;} .l{display:block; font-size:12px; color:#8a8580; letter-spacing:1px; text-transform:uppercase; margin-bottom:3px;}
.v{display:block; font-size:15px; color:#2A2024; line-height:1.7;}
@media print{ @page{margin:1.4cm; size:A4;} }</style></head>
<body><h1>خلاصة — Essence</h1><div class="sub">تُبنى من تفاعلك — Built from your reactions</div>${body}</body></html>`, "summary");
  };

  return (
    <div className="page-top px-4 pb-24" style={{ minHeight: "100vh" }}>
      <style>{`.rxn-line{transition:background .12s ease;} a:active .rxn-line{background:#B76E79 !important;}`}</style>
      <div className="flex items-center mb-4">
        <h1 className="font-heading" style={{ fontSize: 19, color: "var(--brand)", letterSpacing: 1 }}>{isAr ? "تفاعل" : "Reaction"}</h1>
      </div>

      {/* مربّع المستخدم — منتقي شخص بتصميم التطبيق: يفلتر الخلاصة ويبيّن لون كلّ ملفّ */}
      <div className="flex gap-5 mb-4 items-center" dir="ltr">
        <button type="button" onClick={() => setSummaryPerson("all")} className="font-body" style={{ background: "transparent", fontSize: 14, color: summaryPerson === "all" ? "var(--brand)" : "#A98B97", fontWeight: summaryPerson === "all" ? 700 : 400 }}>{isAr ? "الكل" : "All"}</button>
        {PERSONS.map((p) => (
          <button key={p} type="button" onClick={() => setSummaryPerson(p)} className="flex items-center gap-2" style={{ background: "transparent" }}>
            <span style={{ width: 20, height: 3, background: colorOf(p), display: "inline-block" }} />
            <span className="font-body" style={{ fontSize: 14, color: summaryPerson === p ? "var(--foreground, #2A2024)" : "#A98B97", fontWeight: summaryPerson === p ? 700 : 400 }}>{nameOf(p)}</span>
          </button>
        ))}
      </div>

      {/* تفاعلات مدموجة — العنوان إيموجي فقط، وكلّ مدخل يسبقه إيموجي تفاعله وقبله خطّ اللون */}
      <section style={{ marginTop: 22 }} hidden={!!hidden.reactions}>
        <button type="button" onClick={() => toggle("reactions")} className="w-full text-start py-1">
          <span style={{ fontSize: 18, letterSpacing: 6 }}>❤️👍👎😱</span>
        </button>
        {!closed.reactions && (
          <div style={{ marginTop: 4 }}>
            {reactionEntries.length === 0 && brandReactionEntries.length === 0 && perfumerReactionEntries.length === 0
              ? null
              : <>
                  {reactionEntries.map((e, i) => <PerfRow key={e.u?.id || i} p={e.p} person={e.person} emoji={e.emoji} />)}
                  {brandReactionEntries.map((e) => <BrandRow key={"b" + e.id} b={e} emoji={e.emoji} />)}
                  {perfumerReactionEntries.map((e) => <PerfumerRow key={"pf" + e.id} pf={e} emoji={e.emoji} />)}
                </>}
          </div>
        )}
      </section>

      {/* تفاعل النوتات — يتراكم ما تحبّينه وما لا تحبّينه من النوتات */}
      <section style={{ marginTop: 26 }} hidden={!!hidden.notes}>
        <SectionHead k="notes" ar="نوتات" en="Notes" />
        {!closed.notes && (
          <div style={{ marginTop: 4 }}>
            {noteReactionEntries.length === 0
              ? null
              : noteReactionEntries.map((e, i) => (
                  <Link key={e.id || i} to={`/note?id=${e.note_id}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
                    <Line person={e.person} />
                    <span style={{ fontSize: 14, marginTop: 7, flexShrink: 0, lineHeight: 1 }}>{e.emoji}</span>
                    <span style={{ minWidth: 0 }}>
                      <span className="font-heading block group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>
                        {isAr ? (e.name_ar || e.name) : (e.name || e.name_ar)}
                        {e.name_ar && e.name && e.name_ar !== e.name && <span className="font-body" style={{ fontSize: 12, color: "#A98B97", marginInlineStart: 8 }}>{isAr ? e.name : e.name_ar}</span>}
                      </span>
                    </span>
                  </Link>
                ))}
          </div>
        )}
      </section>

      {sections.map((s) => {
        const brandRows = s.key === "forreview" ? brandForReview : s.key === "reviewed" ? brandReviewedList : [];
        const empty = s.entries.length === 0 && brandRows.length === 0;
        return (
          <section key={s.key} style={{ marginTop: 26 }} hidden={!!hidden[s.key]}>
            <SectionHead k={s.key} ar={s.ar} en={s.en} />
            {!closed[s.key] && (
              <div style={{ marginTop: 4 }}>
                {empty
                  ? null
                  : <>
                      {s.entries.map((e, i) => <PerfRow key={e.u?.id || i} p={e.p} person={e.person} />)}
                      {brandRows.map((b) => <BrandRow key={"b" + b.id} b={b} />)}
                    </>}
              </div>
            )}
          </section>
        );
      })}

      {/* أرغب بشراء */}
      <section style={{ marginTop: 26 }} hidden={!!hidden.iwant}>
        <SectionHead k="iwant" ar="أرغب بشرائه" en="I Want To Buy" />
        {!closed.iwant && (
          <div style={{ marginTop: 4 }}>
            {iWantToBuy.length === 0
              ? null
              : iWantToBuy.map((w, i) => <SelfRow key={i} name={w.name} brand={w.brand} person={w.person} pid={w.pid} />)}
          </div>
        )}
      </section>


      {/* الارتداء */}
      <section style={{ marginTop: 26 }} hidden={!!hidden.wear}>
        <SectionHead k="wear" ar="ارتداء" en="Wear" />
        {!closed.wear && (
          <div style={{ marginTop: 4 }}>
            {wearList.length === 0
              ? null
              : wearList.map((w, i) => <SelfRow key={i} name={w.name} brand={w.brand} person={w.person} pid={w.pid} />)}
          </div>
        )}
      </section>

      {/* القوائم المخصّصة */}
      <section style={{ marginTop: 26 }} hidden={!!hidden.custom}>
        <SectionHead k="custom" ar="مخصّص" en="Custom" />
        {!closed.custom && (
          <div style={{ marginTop: 4 }}>
            {wishPerfumes.map((p) => (
              <Link key={"wish-" + p.id} to={`/perfume?id=${p.id}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
                <span aria-hidden style={{ display: "inline-block", width: 20, height: 3, background: "var(--brand)", flexShrink: 0, marginTop: 11 }} />
                <span style={{ fontSize: 14, marginTop: 7, flexShrink: 0, lineHeight: 1 }}>🤍</span>
                <span style={{ minWidth: 0 }}>
                  <span className="font-heading block group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{pName(p, isAr)}</span>
                  {p.brand_name && <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginTop: 1 }}>{p.brand_name}</span>}
                </span>
              </Link>
            ))}
            {customLists.flatMap((l) => {
                  const ids = (l.perfume_ids || "").split(",").map((x) => x.trim()).filter(Boolean);
                  const ps = ids.map((id) => byId.get(id)).filter(Boolean);
                  const icon = l.icon || "📋";
                  return ps.map((p) => (
                    <Link key={l.id + "-" + p.id} to={`/perfume?id=${p.id}`} className="flex items-start gap-3 py-2 group" style={{ textDecoration: "none" }}>
                      <span aria-hidden style={{ display: "inline-block", width: 20, height: 3, background: "var(--brand)", flexShrink: 0, marginTop: 11 }} />
                      <span style={{ fontSize: 14, marginTop: 7, flexShrink: 0, lineHeight: 1 }}>{icon}</span>
                      <span style={{ minWidth: 0 }}>
                        <span className="font-heading block group-hover:opacity-70 transition-opacity" style={{ fontSize: 13, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{pName(p, isAr)}</span>
                        {p.brand_name && <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginTop: 1 }}>{p.brand_name}</span>}
                      </span>
                    </Link>
                  ));
                })}
          </div>
        )}
      </section>

      {/* مفكّرة (موسوعة + مفكّرة مدموجتان) — مطويّة، تحميل 25 */}
      <section style={{ marginTop: 26 }} hidden={!!hidden.notebook && !!hidden.encfav}>
        <SectionHead k="notebook" ar="تفاعل" en="Interactions" />
        {!closed.notebook && (() => {
          const merged = [
            ...pinnedRows.map((p) => ({ kind: "pin", k: p.k, d: p })),
            ...encFavsAll.map((t, i) => ({ kind: "term", k: "t" + (t.id || i), d: t })),
            ...bookmarks.map((b, i) => ({ kind: "note", k: "b" + (b.id || i), d: b })),
          ];
          if (merged.length === 0) return null;
          const shown = merged.slice(0, nbShown);
          return (
            <div style={{ marginTop: 4 }}>
              {shown.map((m) => m.kind === "pin"
                ? <PinRow key={m.k} p={m.d} />
                : m.kind === "term"
                ? <TermRow key={m.k} t={m.d} />
                : <NoteRow key={m.k} b={m.d} />)}
              {merged.length > nbShown && (
                <button onClick={() => setNbShown((n) => n + 25)} className="font-body" style={{ marginTop: 10, background: "none", border: "none", color: "var(--brand)", cursor: "pointer", fontSize: 13, padding: 0 }}>
                  {isAr ? "تصفّح أكثر" : "Browse More"}
                </button>
              )}
            </div>
          );
        })()}
      </section>

      {/* المشتريات (عيّنات + قنينات) — قبل الخلاصة، خطوط ملوّنة بلا أيقونات/جداول */}
      <section style={{ marginTop: 26 }} hidden={!!hidden.purchases}>
        <SectionHead k="purchases" ar="مشتريات" en="Purchases" />
        {!closed.purchases && (
          <div style={{ marginTop: 4 }}>
            {purchasesList.length === 0
              ? null
              : <>
                  <div className="font-body" style={{ fontSize: 12, color: "#A98B97", lineHeight: 1.9, marginBottom: 8 }}>
                    <span style={{ color: "var(--foreground, #2A2024)" }}>{purchaseStats.count}</span> {isAr ? "عنصر" : "items"} · <span style={{ color: "var(--foreground, #2A2024)" }}>{purchaseStats.totVol}</span>ml · <span style={{ color: "var(--foreground, #2A2024)" }}>{purchaseStats.totCost}</span> {currency} · {isAr ? "للمل" : "/ml"} <span style={{ color: "var(--foreground, #2A2024)" }}>{purchaseStats.perMl}</span>
                    {(purchaseStats.sN > 0 || purchaseStats.bN > 0) && (
                      <><br />{isAr ? "عيّنات" : "Samples"}: {purchaseStats.sN} · {purchaseStats.sVol}ml · {purchaseStats.sCost} {currency} &nbsp;|&nbsp; {isAr ? "قنينات" : "Bottles"}: {purchaseStats.bN} · {purchaseStats.bVol}ml · {purchaseStats.bCost} {currency}</>
                    )}
                  </div>
                  {purchasesList.slice(0, showPurchases).map((w, i) => <PurchaseRow key={i} w={w} />)}
                  {purchasesList.length > showPurchases && (
                    <button type="button" onClick={() => setShowPurchases((n) => n + 25)} className="font-body" style={{ fontSize: 12, color: "var(--brand)", padding: "6px 0", background: "transparent" }}>{isAr ? "تحميل المزيد" : "Load more"}</button>
                  )}
                </>}
          </div>
        )}
      </section>

      {/* خلاصة ذكيّة — قبل أزرار التصدير، قائمة مطوية */}
      <section style={{ marginTop: 32 }} hidden={!!hidden.summary}>
        <SectionHead k="summary" ar="خلاصة" en="Essence" />
        {!closed.summary && (
          <div style={{ marginTop: 4 }}>
            <div className="flex gap-3" style={{ marginBottom: 10 }} dir="ltr">
              {[["all", isAr ? "الكل" : "All"], ["person1", nameOf("person1")], ["person2", nameOf("person2")]].map(([v, l]) => (
                <button key={v} type="button" onClick={() => setSummaryPerson(v)} className="font-body" style={{ fontSize: 12, background: "transparent", color: summaryPerson === v ? "var(--brand)" : "#A98B97", fontWeight: summaryPerson === v ? 700 : 400 }}>{l}</button>
              ))}
            </div>
            {summary.empty
              ? <p className="font-body" style={{ fontSize: 13, color: "#A98B97", padding: "4px 0", lineHeight: 1.7 }}>{isAr ? "تتكوّن خلاصتك تلقائيّاً من تفاعلك — ابدأ بالإعجاب بالعطور والنوتات" : "Your summary builds automatically from your reactions — start by liking perfumes and notes"}</p>
              : <div className="flex flex-col" style={{ gap: 10, marginTop: 2 }}>
                  {summaryLine(isAr ? "بصمتك العطريّة" : "Your olfactory fingerprint", summary.topNotes)}
                  {summaryLineColored(isAr ? "العائلة العطريّة" : "Olfactory family", summary.topFamilies)}
                  {summaryLine(isAr ? "ماركات مفضّلة" : "Brands you favour", summary.favBrands)}
                  {summaryLine(isAr ? "نوتات مفضّلة" : "Notes you favour", summary.favNotes)}
                  {summaryLine(isAr ? "عطّارون مفضّلون" : "Perfumers you favour", summary.favPerfumers)}
                  {summaryLine(isAr ? "من الموسوعة" : "From the encyclopedia", summary.encNames)}
                </div>}
          </div>
        )}
      </section>

      {/* أزرار التصدير — أيقونات بلا نص: تصدير الكلّ + تصدير الخلاصة */}
      <div className="flex items-center justify-center gap-8" style={{ marginTop: 30 }}>
        <button type="button" onClick={() => setManageOpen((v) => !v)} aria-label={isAr ? "إدارة التفاعل" : "Manage"} className="p-1">
          <SlidersHorizontal className="w-5 h-5" style={{ color: manageOpen ? "#B76E79" : "var(--brand)" }} />
        </button>
        <button type="button" onClick={handleExport} aria-label={isAr ? "تصدير الكلّ" : "Export all"} className="p-1">
          <Download className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        <button type="button" onClick={handleSummaryExport} aria-label={isAr ? "تصدير الخلاصة" : "Export summary"} className="p-1">
          <FileText className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        {!summary.empty && (
          <button type="button" onClick={handleSummaryImage} aria-label={isAr ? "تصدير الخلاصة صورة" : "Export summary image"} className="p-1">
            <ImageDown className="w-5 h-5" style={{ color: "var(--brand)" }} />
          </button>
        )}
      </div>

      {/* لوحة إدارة التفاعل — إظهار/إخفاء الأقسام + إدارة القوائم المخصّصة */}
      {manageOpen && (
        <div className="mb-4" style={{ paddingBottom: 8 }}>
          <p className="font-heading" style={{ fontSize: 15, color: "var(--brand)", marginBottom: 6 }}>{isAr ? "إدارة التفاعل" : "Manage Reaction"}</p>
          <p className="font-body" style={{ fontSize: 12, color: "#A98B97", marginBottom: 8 }}>{isAr ? "إظهار أو إخفاء أقسام هذه الصفحة" : "Show or hide sections of this page"}</p>
          <div className="flex flex-col">
            {SECTION_META.map((s) => {
              const isHidden = !!hidden[s.key];
              return (
                <button key={s.key} type="button" onClick={() => toggleHidden(s.key)}
                  className="flex items-center justify-between py-2 text-start" style={{ background: "transparent", border: "none" }}>
                  <span className="font-body" style={{ fontSize: 14, color: isHidden ? "#A98B97" : "var(--foreground, #2A2024)" }}>{isAr ? s.ar : s.en}</span>
                  {isHidden
                    ? <EyeOff className="w-[18px] h-[18px]" style={{ color: "#A98B97" }} />
                    : <Eye className="w-[18px] h-[18px]" style={{ color: "var(--brand)" }} />}
                </button>
              );
            })}
          </div>
          <Link to="/lists" className="flex items-center gap-2 py-2 mt-1" style={{ textDecoration: "none" }}>
            <SlidersHorizontal className="w-[18px] h-[18px]" style={{ color: "var(--brand)" }} />
            <span className="font-body" style={{ fontSize: 14, color: "var(--brand)" }}>{isAr ? "إدارة القوائم المخصّصة" : "Manage Custom Lists"}</span>
          </Link>
        </div>
      )}

      {/* عنصر خارج الشاشة لالتقاط صورة الخلاصة — بسيط، ملوّن، بلا إطارات/فواصل */}
      {!summary.empty && (
        <div ref={summaryImgRef} aria-hidden="true" style={{ position: "absolute", left: 0, top: 0, transform: "translateX(-200vw)", width: 620, padding: 48, background: "var(--page-bg, #ffffff)", direction: isAr ? "rtl" : "ltr", boxSizing: "border-box" }}>
          <div className="font-heading" style={{ fontSize: 32, fontWeight: 800, color: "var(--brand)", marginBottom: 6 }}>{isAr ? "خلاصة" : "Essence"}{summaryPerson !== "all" ? ` — ${nameOf(summaryPerson)}` : ""}</div>
          <div className="font-body" style={{ fontSize: 14, color: "#A98B97", marginBottom: 34 }}>{isAr ? "تُبنى من تفاعلك" : "Built from your reactions"}</div>
          {[[isAr ? "بصمتك العطريّة" : "Your olfactory fingerprint", summary.topNotes],
            [isAr ? "ماركات مفضّلة" : "Brands you favour", summary.favBrands],
            [isAr ? "نوتات مفضّلة" : "Notes you favour", summary.favNotes],
            [isAr ? "عطّارون مفضّلون" : "Perfumers you favour", summary.favPerfumers],
            [isAr ? "من الموسوعة" : "From the encyclopedia", summary.encNames]].map(([lbl, arr], i) => (arr && arr.length) ? (
            <div key={i} style={{ marginBottom: 24 }}>
              <div className="font-body" style={{ fontSize: 12, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 }}>{lbl}</div>
              <div className="font-heading" style={{ fontSize: 20, color: "var(--foreground, #2A2024)", lineHeight: 1.5 }}>{arr.join(isAr ? "، " : ", ")}</div>
            </div>
          ) : null)}
          {summary.topFamilies && summary.topFamilies.length ? (
            <div style={{ marginBottom: 24 }}>
              <div className="font-body" style={{ fontSize: 12, color: "#A98B97", textTransform: "uppercase", letterSpacing: 1, marginBottom: 5 }}>{isAr ? "العائلة العطريّة" : "Olfactory family"}</div>
              <div className="font-heading" style={{ fontSize: 20, color: "var(--foreground, #2A2024)", lineHeight: 1.6 }}>
                {summary.topFamilies.map((fm, i) => (
                  <span key={i}>
                    <span style={{ display: "inline-block", width: 12, height: 12, borderRadius: 3, background: fm.color, marginInlineEnd: 7, verticalAlign: "middle" }} />
                    {fm.name}{i < summary.topFamilies.length - 1 ? (isAr ? "، " : ", ") : ""}
                  </span>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}

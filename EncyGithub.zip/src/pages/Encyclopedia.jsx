import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import LibraryCard from "@/components/library/LibraryCard";
import LibraryDiscovery, { LIB_TYPES } from "@/components/library/LibraryDiscovery";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Heart, Search, Pin, ChevronLeft } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";
import { usePins } from "@/lib/usePins";
import { useLang } from "@/lib/LanguageContext";
import { ENC, ensureDefaultLanguages, seedEncyclopedia, dispName, dispNameOrdered, langField } from "@/lib/encyclopedia";
import EncOptionsBar from "@/components/encyclopedia/EncOptionsBar";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";

// صفحة تصفّح الموسوعة — مستقلّة تماماً عن المعجم القائم. تبدأ فارغة.
// الأقسام الرئيسية أزرار أعلى الصفحة؛ التصنيفات الفرعية أسفلها؛ المدخلات أسفلهما.
const SHELF_COLORS = ["#9a7b1f", "#7C2D12", "#1E3A5F", "#4C1D95", "#9D174D", "#6D28D9", "#B7791F", "#1E40AF", "#92400E", "#5B21B6"];
export default function Encyclopedia() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [sectionId, setSectionId] = useState(null);
  const [tlId, setTlId] = useState(() => { try { return new URLSearchParams(window.location.search).get("tl"); } catch { return null; } });
  const [subId, setSubId] = useState(() => { try { return new URLSearchParams(window.location.search).get("sub"); } catch { return null; } });
  const [tagId, setTagId] = useState(() => { try { return new URLSearchParams(window.location.search).get("tag"); } catch { return null; } });
  const [poetKey, setPoetKey] = useState(() => { try { return new URLSearchParams(window.location.search).get("poet"); } catch { return null; } });
  const [poemsAll, setPoemsAll] = useState(() => { try { return new URLSearchParams(window.location.search).get("pall") === "1"; } catch { return false; } });
  const [genericAll, setGenericAll] = useState(false); // «كل القصص» — يتجاوز landing الأقسام و يعرض الكلّ بالفرز
  const [yrFilter, setYrFilter] = useState(() => { try { return new URLSearchParams(window.location.search).get("yr"); } catch { return null; } });
  const [figBioOpen, setFigBioOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [libMood, setLibMood] = useState(() => { try { return new URLSearchParams(window.location.search).get("lm"); } catch { return null; } });
  const [libType, setLibType] = useState(() => { try { return new URLSearchParams(window.location.search).get("lt"); } catch { return null; } }); // فلتر نوع المكتبة — يُحفظ في الرابط للرجوع
  const [libShelf, setLibShelf] = useState(() => { try { return new URLSearchParams(window.location.search).get("ls"); } catch { return null; } }); // قسم النوع — يُحفظ في الرابط للرجوع
  const [sortMode, setSortModeRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_sort")) || "newest");
  const setSortMode = (m) => { setSortModeRaw(m); try { localStorage.setItem("enc_sort", m); } catch { /* تجاهل */ } };
  const [titleOrder, setTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_title_order")) || "ar_en");
  const setTitleOrder = (o) => { setTitleOrderRaw(o); try { localStorage.setItem("enc_title_order", o); } catch { /* تجاهل */ } };
  const [subTitleOrder, setSubTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_sub_title_order")) || "lang");
  const setSubTitleOrder = (o) => { setSubTitleOrderRaw(o); try { localStorage.setItem("enc_sub_title_order", o); } catch { /* تجاهل */ } };
  const [encAccent, setEncAccent] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_accent_color")) || "");
  const [encFs, setEncFs] = useState(() => parseInt((typeof localStorage !== "undefined" && localStorage.getItem("enc_font_scale")) || "0", 10) || 0);
  useEffect(() => {
    const ha = () => setEncAccent(localStorage.getItem("enc_accent_color") || "");
    const hf = () => setEncFs(parseInt(localStorage.getItem("enc_font_scale") || "0", 10) || 0);
    window.addEventListener("enc-accent-change", ha);
    window.addEventListener("enc-fs-change", hf);
    return () => { window.removeEventListener("enc-accent-change", ha); window.removeEventListener("enc-fs-change", hf); };
  }, []);
  const ENC_FS = [11, 12, 13, 14.5, 16];
  const encFsPx = (ENC_FS[encFs] || 11) + "px";

  const qcc = useQueryClient();
  useEffect(() => {
    let alive = true;
    (async () => {
      await ensureDefaultLanguages();
      await seedEncyclopedia();
      if (alive) ["enc-langs", "enc-sections", "enc-subs", "enc-entries", "enc-fav-entries"].forEach((k) => qcc.invalidateQueries({ queryKey: [k] }));
    })();
    return () => { alive = false; };
  }, [qcc]);

  const { data: sections = [] } = useQuery({
    queryKey: ["enc-sections"],
    queryFn: () => ENC.Section().list("order", 200),
    staleTime: 1000 * 30,
  });

  const { data: langs = [] } = useQuery({
    queryKey: ["enc-langs"],
    queryFn: () => ENC.Language().list("order", 50),
    staleTime: 1000 * 30,
  });

  const { data: timelines = [] } = useQuery({
    queryKey: ["enc-timelines"],
    queryFn: () => ENC.Timeline().list("order", 500),
    staleTime: 1000 * 30,
  });

  const { data: subs = [] } = useQuery({
    queryKey: ["enc-subs"],
    queryFn: () => ENC.Subclass().list("order", 1000),
    staleTime: 1000 * 30,
  });

  const code = isAr ? "ar" : "en";

  // أوّل قسم يُختار تلقائياً — أو القسم المُمرَّر من المصنّفات (?sec=)
  useEffect(() => {
    if (sectionId || !sections.length) return;
    let pick = null;
    try { pick = new URLSearchParams(window.location.search).get("sec"); } catch { pick = null; }
    const found = pick && sections.find((s) => String(s.id) === String(pick) || s.name_en === pick || s.name_ar === pick);
    const libDefault = sections.find((s) => s.name_en === "Library") || sections[0];
    setSectionId(found ? found.id : libDefault.id);
  }, [sections, sectionId]);

  const { profiles } = usePersonNames();
  const activePerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";
  const { data: allEntries = [] } = useQuery({ queryKey: ["enc-fav-entries"], queryFn: () => ENC.Entry().list("-updated_date", 20000), staleTime: 1000 * 60 * 10 });

  // المدخلات المثبّتة (encentry) — تُعرض أعلى الرئيسية بترتيب التثبيت
  const { pinnedIds } = usePins("encentry");
  const pinnedEntries = useMemo(() => {
    if (!pinnedIds.length) return [];
    const byId = new Map(allEntries.map((e) => [String(e.id), e]));
    const list = pinnedIds.map((id) => byId.get(String(id))).filter(Boolean);
    // الترتيب: مدخلات الموسوعة أولا، ثم المكتبة، ثم القصائد — فرز ثابت يحفظ ترتيب كل مجموعة
    const rank = (e) => (e.poem ? 2 : e.library ? 1 : 0);
    return list.map((e, i) => [e, i]).sort((a, b) => rank(a[0]) - rank(b[0]) || a[1] - b[1]).map((x) => x[0]);
  }, [pinnedIds, allEntries]);
  // مثبّتات القسم الحاليّ فقط — كلّ قسم يعرض تثبيته منه و فيه
  const sectionPins = useMemo(
    () => (sectionId ? pinnedEntries.filter((e) => String(e.section_id) === String(sectionId)) : []),
    [pinnedEntries, sectionId]
  );
  const favColor = profiles[activePerson]?.color || "var(--brand)";
  const hasFav = allEntries.some((e) => {
    const r = (e.reactions || (e.reaction ? { person1: e.reaction } : {}))[activePerson] || "none";
    const d = (e.reads || (e.read_status ? { person1: e.read_status } : {}))[activePerson] || "none";
    return r !== "none" || d !== "none";
  });

  // الفرز مطبّق على الموسوعة: الأحدث (افتراضي) أو أبجدي بالعنوان.
  const titleOf = (e) => (langField(e.titles, code, langs) || "").trim();
  // ترتيب ثانويّ بالعصر (year) قراءةً فقط — قصص البذرة بلا created_date فكانت تقع بترتيب
  // المصفوفة (الأحدث إضافةً يطفو/يغرق اعتباطاً)؛ التعادل الآن يُحسم بالحقبة دون مسّ السنة.
  const yrOf = (e) => { const n = parseInt(e.year, 10); return Number.isFinite(n) ? n : 999999; };
  const byNewest = (a, b) => (new Date(b.created_date || 0) - new Date(a.created_date || 0)) || (yrOf(b) - yrOf(a));
  const byOldest = (a, b) => (new Date(a.created_date || 0) - new Date(b.created_date || 0)) || (yrOf(a) - yrOf(b));
  const byAlphaAsc = (a, b) => titleOf(a).localeCompare(titleOf(b), isAr ? "ar" : "en");
  const sorter = sortMode === "alpha_asc" ? byAlphaAsc
    : sortMode === "alpha_desc" ? ((a, b) => -byAlphaAsc(a, b))
    : sortMode === "oldest" ? byOldest : byNewest;
  // عنوان المدخل حسب تخصيص لغة القراءة (عربي/إنجليزي/ثنائي)
  const [langTick, setLangTick] = useState(0);
  useEffect(() => { const h = () => setLangTick((t) => t + 1); window.addEventListener("enc-lang-change", h); return () => window.removeEventListener("enc-lang-change", h); }, []);
  void langTick; // re-render trigger
  const browseLang = (typeof localStorage !== "undefined" && localStorage.getItem("enc_read_lang")) || "both";
  const PER_PAGE = 25;
  const [page, setPage] = useState(0);
  useEffect(() => { setPage(0); }, [sortMode, tlId, subId, tagId]);
  // مزامنة حالة التصفّح (خط زمني/عصر/شاعر/كل العصور) مع الرابط — كي تعيدنا العودة من
  // صفحة المدخل (navigate(-1)) إلى نفس الخط أو العصر الذي جئنا منه، لا إلى مدخل القسم.
  useEffect(() => {
    try {
      const sp = new URLSearchParams(window.location.search);
      const setOrDel = (k, v) => { if (v) sp.set(k, v); else sp.delete(k); };
      setOrDel("sec", sectionId ? String(sectionId) : "");
      setOrDel("tl", tlId);
      setOrDel("sub", subId);
      setOrDel("tag", tagId);
      setOrDel("poet", poetKey);
      setOrDel("pall", poemsAll ? "1" : "");
      setOrDel("yr", yrFilter);
      setOrDel("lt", libType);
      setOrDel("ls", libShelf);
      setOrDel("lm", libMood);
      const qs = sp.toString();
      window.history.replaceState(window.history.state, "", window.location.pathname + (qs ? `?${qs}` : ""));
    } catch { /* تجاهل */ }
  }, [sectionId, tlId, subId, tagId, poetKey, poemsAll, yrFilter, libType, libShelf, libMood]);
  // حفظ آخر صفحة لكل قسم و استعادتها عند الرجوع من المدخل (صفحات التنقل ترجع لآخر صفحة)
  useEffect(() => { if (!sectionId || tlId || subId || tagId) return; try { const sv = sessionStorage.getItem(`enc_page_${sectionId}`); setPage(sv ? Number(sv) : 0); } catch { setPage(0); } }, [sectionId, tlId, subId]);
  useEffect(() => { if (sectionId) { try { sessionStorage.setItem(`enc_page_${sectionId}`, String(page)); } catch { /* تجاهل */ } } }, [page, sectionId]);
  const activeSection = sections.find((x) => String(x.id) === String(sectionId));
  const yearNum = (e) => { const n = parseInt(e.year, 10); return Number.isFinite(n) ? n : 999999; };
  // وضع الفلترة: خط زمنيّ (?tl) مرتّب بالسنة — فرعيّة (?sub) — أو القسم.
  const filterTimeline = tlId ? timelines.find((t) => String(t.id) === String(tlId)) : null;
  // كل من في خطّ السعودية يظهر في خطّ الجزيرة العربية أيضا (احتواء جغرافيّ باتجاه واحد)
  const tlArabiaId = timelines.find((t) => t.title_ar === "الجزيرة العربية")?.id;
  const tlSaudiId = timelines.find((t) => t.title_ar === "السعودية")?.id;
  // ملوك و أمراء السعودية يظهرون أيضا في خط «القادة عبر التاريخ» (احتواء بالنوع)
  const tlLeadersId = timelines.find((t) => t.title_ar === "القادة عبر التاريخ")?.id;
  const filterSub = subId ? subs.find((c) => String(c.key) === String(subId) || String(c.id) === String(subId)) : null;
  const filterTag = tagId ? subs.find((c) => String(c.key) === String(tagId)) : null;
  const entries = useMemo(() => (yrFilter
    ? allEntries.filter((e) => String(e.year) === String(yrFilter) && (!sectionId || String(e.section_id) === String(sectionId)))
    : poemsAll
    ? allEntries.filter((e) => String(e.section_id) === String(sectionId)).sort((a, b) => yearNum(a) - yearNum(b))
    : tlId
    ? allEntries.filter((e) => String(e.timeline_id) === String(tlId)
        || (tlArabiaId != null && String(tlId) === String(tlArabiaId) && tlSaudiId != null && String(e.timeline_id) === String(tlSaudiId))
        || (tlLeadersId != null && String(tlId) === String(tlLeadersId) && String(e.subclass2_key) === "r_saudi" && String(e.subclass_key) === "k_leaders")
      ).sort((a, b) => yearNum(a) - yearNum(b))
    : subId
    ? allEntries.filter((e) => String(e.subclass_key) === String(subId) || String(e.subclass2_key) === String(subId)
        || (filterSub && (String(e.subclass_key) === String(filterSub.key) || String(e.subclass2_key) === String(filterSub.key)))
        || String(e.subclass_id) === String(subId) || String(e.subclass2_id) === String(subId))
    : tagId
    ? allEntries.filter((e) => (!sectionId || String(e.section_id) === String(sectionId)) && String(e.tags || "").split(/[,\s]+/).includes(String(tagId)))
    : sectionId ? allEntries.filter((e) => String(e.section_id) === String(sectionId)) : []),
    [allEntries, tlId, subId, tagId, sectionId, poemsAll, yrFilter, tlArabiaId, tlSaudiId, tlLeadersId, filterSub]);
  // الخط الزمنيّ: تقطيع بالأجيال (٣٠ سنة) أو ٣٠ مدخلاً، و كشف تدريجيّ بزرّ التالي (بلا تحميل الخط كاملاً)
  const GEN = 30;
  const tlChunks = useMemo(() => {
    if (!tlId && !poemsAll) return [];
    const out = [];
    for (let i = 0; i < entries.length; i += GEN) out.push(entries.slice(i, i + GEN));
    return out;
  }, [entries, tlId, poemsAll]);
  const [tlReveal, setTlReveal] = useState(1);
  useEffect(() => { setTlReveal(1); }, [tlId, poemsAll]);
  const tlShown = useMemo(() => tlChunks.slice(0, tlReveal).flat(), [tlChunks, tlReveal]);
  const fmtYr = (y) => { const n = parseInt(y, 10); if (!Number.isFinite(n)) return ""; return n < 0 ? `${-n}${isAr ? " ق.م" : " BC"}` : String(n); };
  const shown = tlId ? entries.slice() : entries.slice().sort(sorter);
  // «أطوار العطور» مستثناة من قاعدة الـ25/صفحة (تُعرض كاملة)
  const isPhases = !tlId && !subId && !!activeSection && (activeSection.name_ar === "اطوار العطور" || activeSection.name_en === "Perfumes Era" || activeSection.name_en === "Perfume Era" || activeSection.name_en === "Perfume Phases");
  const isLibrary = !!activeSection && activeSection.name_en === "Library";
  // فلتر نشط (تصنيف/خط/وسم) يتجاوز وضع المكتبة الخاص كي تظهر مداخل التصنيف داخل قسم المكتبة
  const filterActive = !!(subId || tlId || tagId);
  const libMode = isLibrary && !filterActive;
  const isPoems = !!activeSection && activeSection.name_en === "Poems";
  // أزرار الواجهة المميّزة فوق محرّك البحث: أطوار العطور — مكتبة — قصائد — لكلٍّ لون.
  // الشخصيات تُنقل لروابط الأسفل، فلا تظهر بين التبويبات.
  const FEATURE_EN = ["Perfumes Era", "Perfume Era", "Perfume Phases", "Library", "Poems"];
  const FEATURE_COLOR = { "Perfumes Era": "#B7791F", "Perfume Era": "#B7791F", "Perfume Phases": "#B7791F", Library: "#2E7D6B", Poems: "#7C6FB0" };
  const FEATURE_ORDER = { "Perfumes Era": 0, "Perfume Era": 0, "Perfume Phases": 0, Library: 1, Poems: 2 };
  const isFeatureSec = (s) => FEATURE_EN.includes(s.name_en);
  const featureSections = sections.filter(isFeatureSec).sort((a, b) => (FEATURE_ORDER[a.name_en] ?? 9) - (FEATURE_ORDER[b.name_en] ?? 9));
  const figuresSection = sections.find((s) => s.name_en === "Figures");
  const tabSections = sections.filter((s) => !isFeatureSec(s) && s.name_en !== "Figures");
  const selectSection = (sid) => { setSectionId(sid); setSubId(null); setTagId(null); setTlId(null); setPoetKey(null); setPoemsAll(false); setGenericAll(false); setLibMood(null); setLibType(null); setLibShelf(null); setYrFilter(null); try { window.scrollTo(0, 0); } catch { /* تجاهل */ } };
  const poemEras = isPoems
    ? subs.filter((c) => String(c.section_id) === String(sectionId) && c.axis === "era")
        .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
    : [];
  const poemsLanding = isPoems && !tlId && !subId && !tagId && !poemsAll && !yrFilter;
  // landing تصنيفات عامّ: قصص/اقتباسات/علامة/مصطلحات تعرض أقسامها أولاً مثل القصائد
  const sectionSubs = subs.filter((c) => String(c.section_id) === String(sectionId));
  const primaryAxis = (() => {
    if (!sectionSubs.length) return null;
    const counts = {};
    sectionSubs.forEach((c) => { counts[c.axis] = (counts[c.axis] || 0) + 1; });
    const pref = ["kind", "category", "field", "theme", "era"];
    return pref.find((a) => counts[a]) || Object.keys(counts)[0];
  })();
  const catSubs = sectionSubs.filter((c) => c.axis === primaryAxis).sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  // الشخصيات — ملف عام يتكرر عبر كل أقسام الموسوعة (بدل الوسوم). الشعراء حالة خاصة داخل قصائد.
  const GENDER_COLOR = { male: "#2563EB", female: "#DB2777" };
  const isFigures = !!activeSection && activeSection.name_en === "Figures";
  const genericSection = !!activeSection && !isLibrary && !isPoems && !isFigures && !isPhases;
  const genericLanding = genericSection && !subId && !tlId && !tagId && !yrFilter && catSubs.length > 0 && !genericAll;
  const figureKeyOf = (e) => String(e.figure_key || e.poem?.poet_key || e.poem?.poet_ar || e.poem?.poet_en || "").trim();
  const figureNameOf = (e, ar) => (ar
    ? (e.figure_ar || e.poem?.poet_ar || e.figure_en || e.poem?.poet_en || "")
    : (e.figure_en || e.poem?.poet_en || e.figure_ar || e.poem?.poet_ar || ""));
  const figureGenderOf = (e) => e.gender || e.poem?.gender || "";
  const poemsEraView = isPoems && !!subId && !tagId && !tlId && !poetKey;        // أسماء شعراء العصر
  const figureView = !!poetKey && ((isPoems && !!subId) || isFigures);           // ملف الشخصية
  // شعراء العصر (من قصائد العصر)
  const poets = useMemo(() => {
    if (!poemsEraView) return [];
    const map = new Map();
    for (const e of shown) {
      const k = figureKeyOf(e); if (!k) continue;
      if (!map.has(k)) map.set(k, { key: k, ar: figureNameOf(e, true), en: figureNameOf(e, false), gender: figureGenderOf(e), year: yearNum(e) });
      const o = map.get(k); o.year = Math.min(o.year, yearNum(e));
    }
    const arr = [...map.values()];
    arr.sort((a, b) => sortMode === "oldest" ? a.year - b.year : sortMode === "newest" ? b.year - a.year : (a.ar || a.en).localeCompare(b.ar || b.en, "ar"));
    return arr;
  }, [poemsEraView, shown, sortMode]);
  // كل الشخصيات (تبويب الشخصيات) — عبر كل المدخلات
  const allFigures = useMemo(() => {
    if (!isFigures || poetKey) return [];
    const map = new Map();
    for (const e of allEntries) {
      const k = figureKeyOf(e); if (!k) continue;
      if (!map.has(k)) map.set(k, { key: k, ar: figureNameOf(e, true), en: figureNameOf(e, false), gender: figureGenderOf(e), year: yearNum(e) });
      const o = map.get(k); o.year = Math.min(o.year, yearNum(e));
    }
    const arr = [...map.values()];
    arr.sort((a, b) => sortMode === "oldest" ? a.year - b.year : sortMode === "newest" ? b.year - a.year : (a.ar || a.en).localeCompare(b.ar || b.en, "ar"));
    return arr;
  }, [isFigures, poetKey, allEntries, sortMode]);
  // مدخلات الشخصية عبر كل الأقسام (بدل الوسوم)
  const figureEntries = useMemo(() => {
    if (!figureView) return [];
    const arr = allEntries.filter((e) => figureKeyOf(e) === String(poetKey));
    arr.sort((a, b) => sortMode === "oldest" ? yearNum(a) - yearNum(b) : yearNum(b) - yearNum(a));
    return arr;
  }, [figureView, allEntries, poetKey, sortMode]);
  const figureProfile = figureView ? (figureEntries.find((e) => e.poem)?.poem || null) : null;
  const figureHead = figureView && figureEntries[0]
    ? { ar: figureNameOf(figureEntries[0], true), en: figureNameOf(figureEntries[0], false), gender: figureGenderOf(figureEntries[0]) } : null;
  // الاسم/العنوان يحترم لغة الموسوعة: مدمج = عربي ثم إنجليزي
  const nameByLang = (ar, en) => browseLang === "ar" ? (ar || en) : browseLang === "en" ? (en || ar) : ([ar, en].filter(Boolean).join("  ") || ar || en);
  const crumbs = [];
  if (activeSection) {
    const resetAll = () => { setSubId(null); setTagId(null); setTlId(null); setPoetKey(null); setPoemsAll(false); setYrFilter(null); setGenericAll(false); };
    crumbs.push({ label: isAr ? "الموسوعة" : "Encyclopedia", go: resetAll });
    crumbs.push({ label: dispName(activeSection, isAr), go: resetAll });
    if (poemsAll) crumbs.push({ label: isAr ? "كل العصور" : "All Eras", go: null });
    if (filterSub) crumbs.push({ label: dispName(filterSub, isAr), go: poetKey ? () => setPoetKey(null) : null });
    else if (filterTag) crumbs.push({ label: dispName(filterTag, isAr), go: null });
    else if (filterTimeline) crumbs.push({ label: dispNameOrdered(filterTimeline, titleOrder, isAr), go: null });
    if (poetKey && figureHead) crumbs.push({ label: nameByLang(figureHead.ar, figureHead.en), go: null });
  }
  const sectionNameById = (sid) => dispName(sections.find((s) => String(s.id) === String(sid)), isAr);
  const poemLabel = (e) => {
    const firstHemistich = (code) => {
      const t = langField(e.texts, code, langs);
      const ln = String(t || "").split(/\r?\n/).map((s) => s.trim()).filter(Boolean)[0] || "";
      return ln.split(/\s*\.\.\s*/)[0].trim();
    };
    const ar = firstHemistich("ar"), en = firstHemistich("en");
    const merged = browseLang === "ar" ? (ar || en) : browseLang === "en" ? (en || ar) : ([ar, en].filter(Boolean).join(" — ") || ar || en);
    return merged || (langField(e.titles, isAr ? "ar" : "en", langs) || (isAr ? "محتوى" : "Entry"));
  };
  // تصفية المكتبة بالنوع/المزاج، ثم اشتقاق أقسام النوع، ثم التصفية بالقسم المختار
  const libBase = isLibrary
    ? shown.filter((e) =>
        (!libType || e.library?.media_type === libType) &&
        (!libMood || (Array.isArray(e.library?.moods) && e.library.moods.includes(libMood))))
    : shown;
  const libShelves = (() => {
    if (!isLibrary || !libType) return [];
    const m = new Map();
    for (const e of libBase) {
      const k = e.library?.shelf_key; if (!k) continue;
      if (!m.has(k)) m.set(k, { key: k, ar: e.library.shelf_ar, en: e.library.shelf_en, order: e.library.shelf_order ?? 99, count: 0 });
      m.get(k).count++;
    }
    return [...m.values()].sort((a, b) => a.order - b.order);
  })();
  const curShelf = libShelf ? libShelves.find((s) => s.key === libShelf) : null;
  const libShown = libShelf ? libBase.filter((e) => e.library?.shelf_key === libShelf) : libBase;
  const pageCount = isPhases ? 1 : Math.max(1, Math.ceil(libShown.length / PER_PAGE));
  const pageItems = isPhases ? libShown : libShown.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);
  // اكتشاف المكتبة: فاجئني (من المعروض) و سهرة الليلة (فيلم/مسلسل عشوائي)
  const pickRandom = (pool) => { if (pool && pool.length) navigate(`/encyclopedia/view/${pool[Math.floor(Math.random() * pool.length)].id}`); };
  const onSurprise = () => pickRandom(libShown.length ? libShown : shown);
  const onTonight = () => { const w = shown.filter((e) => e.library?.media_type === "film" || e.library?.media_type === "series"); pickRandom(w.length ? w : shown); };
  // البحث يُوجّه لصفحة النتائج الموحّدة نفسها التي يستخدمها /home و باقي التطبيق
  const runSearch = () => { const s = search.trim(); if (s) navigate(`/search-results?q=${encodeURIComponent(s)}`); };

  return (
    <div className="px-5 page-top pb-24 space-y-4 overflow-x-hidden" style={{ ...(encAccent ? { "--brand": encAccent } : {}), "--enc-fs": encFsPx }}>
      {/* الترويسة */}
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-[10px] font-bold opacity-40 leading-none" style={{ color: "var(--brand)" }}>
          {isAr ? "موسوعة" : "Encyclopedia"}
        </h1>
        <SettingsSheet><UserAvatarButton size={28} /></SettingsSheet>
      </div>

      {/* البحث أسفل الهيدر مباشرة — يُوجّه لصفحة النتائج الموحّدة (نفس /home) */}
      <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
        <div className="relative flex-1 min-w-[130px] flex items-center gap-2">
          <button type="button" onClick={runSearch} aria-label={isAr ? "بحث" : "Search"} className="flex-shrink-0 hover:opacity-70 transition-opacity">
            <Search className="w-4 h-4" style={{ color: "var(--brand)" }} />
          </button>
          <input value={search} onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") runSearch(); }}
            aria-label={isAr ? "بحث" : "Search"}
            className="w-full bg-transparent outline-none border-0 text-sm font-body py-1.5" style={{ color: "var(--brand)" }} />
          {search.trim() && (
            <span className="text-[10px] font-body text-muted-foreground/80 flex-shrink-0 whitespace-nowrap" aria-hidden="true">{isAr ? "اضغط انتر" : "Press Enter"}</span>
          )}
        </div>
      </div>


      {sections.length === 0 ? (
        <div className="py-16 text-center space-y-3">
          <p className="text-sm text-muted-foreground font-body">
            {isAr ? "الموسوعة فارغة، ابدأ بإضافة قسم رئيسي — قصة، مصطلح، رمزية" : "Empty. Start by adding a main section: Story, Term, Symbolism"}
          </p>
          <button type="button" onClick={() => navigate("/encyclopedia/setup")}
            className="font-body text-sm font-semibold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
            {isAr ? "ابدأ تنصيب الموسوعة" : "Start Encyclopedia Setup"}
          </button>
        </div>
      ) : (
        <>
          {/* 1) الأقسام أعلى الصفحة — المفضلة + تبويبات الأقسام (أو ترويسة الوضع المفلتر) — تُخفى كلّياً في عرض العصر/الشاعر sub لأنّ التنقّل موجود بالأسفل */}
          <div>
            {filterSub ? null : (filterTimeline || filterTag) ? (
              <>
              <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
                <button type="button" onClick={() => { setTlId(null); setSubId(null); setTagId(null); setPoetKey(null); setGenericAll(false); }}
                  className="font-body text-xs hover:opacity-70 transition-opacity" style={{ color: "var(--brand)", opacity: 0.7 }}>
                  {isAr ? "الأقسام" : "Sections"}
                </button>
                <span className="font-body text-sm font-semibold" style={{ color: "var(--brand)" }}>
                  {dispNameOrdered(filterTimeline || filterSub || filterTag, titleOrder, isAr)}
                </span>
              </div>
              {/* خط بلون المستخدم لكل خط زمنيّ في صفحته */}
              {filterTimeline && <div className="mt-2" style={{ height: 2, background: favColor, opacity: 0.55, borderRadius: 1 }} />}
              </>
            ) : (
            <div className="flex flex-wrap items-center gap-2" dir={isAr ? "rtl" : "ltr"}>
              <button type="button" onClick={() => navigate("/encyclopedia/favorites")}
                className="flex items-center justify-center w-8 h-8 hover:opacity-70 transition-opacity"
                aria-label={isAr ? "المفضلة" : "Favorites"} title={isAr ? "المفضلة" : "Favorites"}>
                <Heart className="w-6 h-6" style={{ color: "var(--brand)" }} />
              </button>
              {tabSections.map((s) => (
                <button key={s.id} type="button" onClick={() => selectSection(s.id)}
                  className="font-body text-[11px] px-1 pb-1.5 transition-opacity hover:opacity-70"
                  style={{ color: "var(--brand)", fontWeight: sectionId === s.id ? 700 : 400, borderBottom: sectionId === s.id ? "2px solid var(--brand)" : "2px solid transparent" }}>
                  {dispName(s, isAr)}
                </button>
              ))}
              {/* أقسام الميزات مدموجة في صفّ التبويبات بألوانها، خط أصغر */}
              {featureSections.map((s) => {
                const col = FEATURE_COLOR[s.name_en] || "var(--brand)";
                const on = String(sectionId) === String(s.id);
                return (
                  <button key={s.id} type="button" onClick={() => selectSection(s.id)}
                    className="font-body text-[11px] px-1 pb-1.5 transition-opacity hover:opacity-70"
                    style={{ color: col, fontWeight: on ? 700 : 400, borderBottom: on ? `2px solid ${col}` : "2px solid transparent", opacity: on ? 1 : 0.82 }}>
                    {dispName(s, isAr)}
                  </button>
                );
              })}
            </div>
            )}
          </div>

          {/* أقسام الميزات صارت ضمن صفّ التبويبات أعلاه */}

          {/* مثبّتات القسم — أسفل التبويبات أعلى العناوين، أيقونة تثبيت قبل كلّ عنوان، بلا «All» */}
          {sectionId && !tlId && !subId && sectionPins.length > 0 && (
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5" dir={isAr ? "rtl" : "ltr"}>
              {sectionPins.map((e) => {
                const ar = langField(e.titles, "ar", langs) || "";
                const en = langField(e.titles, "en", langs) || "";
                const label = isAr ? (ar || en) : (en || ar);
                return (
                  <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                    className="flex items-center gap-1 hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                    <Pin className="w-3 h-3 flex-shrink-0" fill="var(--brand)" style={{ color: "var(--brand)" }} />
                    <span className="font-body" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{label || (isAr ? "بلا عنوان" : "Untitled")}</span>
                  </button>
                );
              })}
            </div>
          )}


          {/* 4) شرح القسم — تحت حقل البحث */}
          {!filterTimeline && !filterSub && !isLibrary && activeSection && (isAr ? activeSection.desc_ar : activeSection.desc_en) && (
            <div className="mt-0.5">
              <p className="text-[10px] text-muted-foreground font-body leading-relaxed" dir={isAr ? "rtl" : "ltr"}>
                {isAr ? activeSection.desc_ar : activeSection.desc_en}
              </p>
            </div>
          )}

          {/* مسار التنقل + رابط الخط الزمني — نُقل لأسفل الصفحة قبل «اضافة مدخل» */}
          {(
          <>
          {(filterTimeline || poemsAll) ? (
            /* الخط الزمنيّ المرسوم — كأطوار العطور، كشف تدريجيّ بالأجيال؛ «كل العصور» نفس التنسيق بلا تاريخ */
            shown.length === 0 ? (
              <p className="text-sm text-muted-foreground font-body py-8 text-center">{isAr ? "لا مدخلات في هذا الخط بعد" : "No entries in this timeline yet"}</p>
            ) : (
            <div className="relative pt-1" dir="ltr">
              <div className="absolute top-0 bottom-0 w-0.5 z-0" style={{ left: 54, background: "linear-gradient(to bottom, color-mix(in srgb, var(--brand) 18%, transparent), var(--brand), color-mix(in srgb, var(--brand) 18%, transparent))" }} />
              <div className="relative z-10">
                {tlShown.map((e) => {
                  const ar = langField(e.titles, "ar", langs) || "";
                  const en = langField(e.titles, "en", langs) || "";
                  const showBothT = browseLang === "both" && ar && en && titleOrder !== "lang";
                  const prim = titleOrder === "lang" ? (isAr ? (ar || en) : (en || ar))
                    : browseLang === "ar" ? (ar || en) : browseLang === "en" ? (en || ar)
                    : titleOrder === "en_ar" ? (en || ar) : (ar || en);
                  const sec = titleOrder === "en_ar" ? ar : en;
                  const yr = ""; // التاريخ أُلغي من كل الخطوط الزمنية — يظهر فقط في «شرح و إشارات» كرابط
                  return (
                    <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                      className="w-full flex items-start pb-2.5 relative hover:opacity-70 transition-opacity" dir="ltr">
                      <span className="shrink-0 font-body" style={{ width: 46, textAlign: "right", color: "var(--brand)", opacity: 0.6, fontSize: "8.5px", lineHeight: 1.5, paddingTop: 2 }}>{yr}</span>
                      <span className="absolute w-2 h-2 rotate-45 z-10" style={{ left: 50, top: 6, background: "var(--brand)" }} />
                      <span className="min-w-0 flex-1" style={{ paddingLeft: 22 }}>
                        <span className="block font-body" dir="auto" style={{ textAlign: "left", color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{prim || (isAr ? "بلا عنوان" : "Untitled")}</span>
                        {showBothT && sec && (
                          <span className="block font-body truncate" dir="auto" style={{ textAlign: "left", color: "var(--brand)", fontSize: "var(--enc-fs, 11px)", opacity: 0.85 }}>{sec}</span>
                        )}
                      </span>
                    </button>
                  );
                })}
                {tlReveal < tlChunks.length && (
                  <button type="button" onClick={() => setTlReveal((r) => r + 1)}
                    className="w-full flex items-start pb-2 relative hover:opacity-70 transition-opacity" dir="ltr">
                    <span className="shrink-0" style={{ width: 46 }} />
                    <span className="absolute w-2 h-2 rotate-45 z-10" style={{ left: 50, top: 6, background: "var(--brand)", opacity: 0.55 }} />
                    <span className="flex-1 block font-body font-semibold" style={{ paddingLeft: 22, color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{isAr ? "التالي" : "Next"}</span>
                  </button>
                )}
              </div>
            </div>
            )
          ) : (
          <>
          {/* قصائد سنة محدّدة — عند الضغط على رابط السنة في «شرح و إشارات» */}
          {yrFilter && (
            <div dir={isAr ? "rtl" : "ltr"}>
              <p className="font-body font-semibold mb-2" style={{ color: "var(--brand)", fontSize: 14 }}>{(isAr ? "قصائد سنة " : "Poems of year ") + yrFilter}</p>
              {shown.length === 0 ? (
                <p className="text-sm text-muted-foreground font-body py-8 text-center">{isAr ? "لا قصائد في هذه السنة" : "No poems in this year"}</p>
              ) : shown.map((e) => {
                const ar = langField(e.titles, "ar", langs) || ""; const en = langField(e.titles, "en", langs) || "";
                return (
                  <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                    className="w-full block text-start py-2 hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                    <span className="block font-body" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 13px)" }}>{isAr ? (ar || en) : (en || ar)}</span>
                  </button>
                );
              })}
            </div>
          )}
          {/* قصائد: الرئيسية = العصور (أقسام رئيسية) — اختر عصراً لرؤية شعرائه */}
          {poemsLanding && (
            <div dir={isAr ? "rtl" : "ltr"}>
              {poemEras.map((c) => (
                <button key={c.id} type="button" onClick={() => { setSubId(String(c.key || c.id)); setPoetKey(null); setPage(0); }}
                  className="w-full text-start py-3 font-body font-semibold hover:opacity-70 transition-opacity block"
                  style={{ color: "var(--brand)", fontSize: 15 }}>
                  {dispName(c, isAr)}
                </button>
              ))}
            </div>
          )}
          {/* الأقسام العامّة (قصص/اقتباسات/علامة/مصطلحات): اعرض التصنيفات أولاً مثل القصائد */}
          {genericLanding && (
            <div dir={isAr ? "rtl" : "ltr"}>
              {catSubs.map((c) => (
                <button key={c.id} type="button" onClick={() => { setSubId(String(c.key || c.id)); setPage(0); }}
                  className="w-full text-start py-3 font-body font-semibold hover:opacity-70 transition-opacity block"
                  style={{ color: "var(--brand)", fontSize: 15 }}>
                  {dispName(c, isAr)}
                </button>
              ))}
              {/* كل القصص — أسفل الأقسام؛ يعرض الكلّ بترتيب الفرز (الأحدث افتراضاً، ثم تخصيص المستخدم) */}
              <button type="button" onClick={() => { setGenericAll(true); setPage(0); try { window.scrollTo(0, 0); } catch { /* تجاهل */ } }}
                className="w-full text-start py-3 font-body font-semibold hover:opacity-70 transition-opacity block"
                style={{ color: "var(--brand)", fontSize: 15, borderTop: "1px solid color-mix(in srgb, var(--brand) 22%, transparent)", marginTop: 4 }}>
                {isAr ? `كل ${dispName(activeSection, true) === "قصص" ? "القصص" : dispName(activeSection, true)}` : `All ${dispName(activeSection, false)}`}
              </button>
            </div>
          )}
          {/* قصائد: داخل العصر = أسماء الشعراء — ذكور أزرق، إناث وردي — تنقلك لملف الشاعر */}
          {poemsEraView && (
            <div dir={isAr ? "rtl" : "ltr"}>
              {poets.length === 0 ? (
                <p className="text-sm text-muted-foreground font-body py-8 text-center">{isAr ? "لا شعراء في هذا العصر بعد" : "No poets in this era yet"}</p>
              ) : poets.map((p) => (
                <button key={p.key} type="button" onClick={() => { setPoetKey(p.key); setPage(0); }}
                  className="w-full text-start py-2 font-body font-semibold hover:opacity-70 transition-opacity block"
                  style={{ color: GENDER_COLOR[p.gender] || "var(--brand)", fontSize: 13 }}>
                  {nameByLang(p.ar, p.en)}
                </button>
              ))}
            </div>
          )}
          {/* تبويب الشخصيات — كل الشخصيات عبر الموسوعة (ذكور أزرق، إناث وردي) */}
          {isFigures && !poetKey && (
            <div dir={isAr ? "rtl" : "ltr"}>
              {allFigures.length === 0 ? (
                <p className="text-sm text-muted-foreground font-body py-8 text-center">{isAr ? "لا شخصيات بعد — تُربط من حقل الشخصية في المدخل" : "No figures yet — link them from the entry's Figure field"}</p>
              ) : allFigures.map((p) => (
                <button key={p.key} type="button" onClick={() => { setPoetKey(p.key); setPage(0); }}
                  className="w-full text-start py-2 font-body font-semibold hover:opacity-70 transition-opacity block"
                  style={{ color: GENDER_COLOR[p.gender] || "var(--brand)", fontSize: 13 }}>
                  {nameByLang(p.ar, p.en)}
                </button>
              ))}
            </div>
          )}
          {/* ملف الشخصية — نبذة ثم مدخلاتها عبر كل أقسام الموسوعة (بدل الوسوم) */}
          {figureView && (
            <div dir={isAr ? "rtl" : "ltr"} className="space-y-4">
              <button type="button" onClick={() => setPoetKey(null)}
                className="flex items-center gap-1.5 hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
                <ChevronLeft className={`w-4 h-4`} />
                <span className="font-body font-semibold text-sm">{isAr ? "رجوع" : "Back"}</span>
              </button>
              {/* اسم الشاعر يظهر في شريط التنقّل (breadcrumb) فقط — حُذف العنوان المكرّر */}
              {/* قائمة القصائد أولاً */}
              {(() => {
                const bySec = {};
                figureEntries.forEach((e) => { (bySec[e.section_id] = bySec[e.section_id] || []).push(e); });
                return Object.entries(bySec).map(([sid, list]) => (
                  <div key={sid} className="space-y-1">
                    <p className="text-[11px] font-body font-semibold text-muted-foreground">{sectionNameById(sid)}</p>
                    {list.map((e) => (
                      <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                        className="w-full text-start py-2 font-body hover:opacity-70 transition-opacity block" dir="auto"
                        style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 14px)" }}>
                        {e.poem ? poemLabel(e) : (langField(e.titles, isAr ? "ar" : "en", langs) || langField(e.titles, isAr ? "en" : "ar", langs) || (isAr ? "محتوى" : "Entry"))}
                      </button>
                    ))}
                  </div>
                ));
              })()}
              {/* النبذة بقائمة مطوية بعد القصائد */}
              {figureProfile && (
                <div className="pt-1" dir={isAr ? "rtl" : "ltr"}>
                  <button type="button" onClick={() => setFigBioOpen((v) => !v)} className="font-body text-xs font-semibold hover:opacity-70" style={{ color: "var(--brand)" }}>{isAr ? "نبذة" : "Profile"}</button>
                  {figBioOpen && (
                    <div className="space-y-1 pt-2">
                      <p className="text-xs font-body text-muted-foreground">
                        {[isAr ? figureProfile.laqab_ar : figureProfile.laqab_en, isAr ? figureProfile.period : figureProfile.period_en, isAr ? figureProfile.homeland_ar : figureProfile.homeland_en].filter(Boolean).join("  —  ")}
                      </p>
                      {(isAr ? figureProfile.bio_ar : figureProfile.bio_en) && (
                        <p className="text-sm font-body leading-relaxed" style={{ color: "#2a2926" }}>{isAr ? figureProfile.bio_ar : figureProfile.bio_en}</p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          {/* المكتبة الرئيسية: روابط الأنواع صفًّا صفًّا — بلا إطار/خلفية/وصف */}
          {isLibrary && !tlId && !subId && !libType && !libMood && (
            <div dir={isAr ? "rtl" : "ltr"}>
              {LIB_TYPES.map(([key, ar, en]) => (
                <button key={key} type="button" onClick={() => { setLibType(key); setLibShelf(null); setLibMood(null); setPage(0); }}
                  className="w-full text-start py-3 font-body font-semibold hover:opacity-70 transition-opacity block"
                  style={{ color: "var(--brand)", fontSize: 15 }}>
                  {isAr ? ar : en}
                </button>
              ))}
              {/* كتبي — أسفل الأقسام: رفع و قراءة كتب الجهاز PDF/EPUB في القارئ الداخلي */}
              <button type="button" onClick={() => navigate("/library")}
                className="w-full text-start py-3 font-body font-semibold hover:opacity-70 transition-opacity block"
                style={{ color: "var(--brand)", fontSize: 15 }}>
                {isAr ? "كتبي" : "My Books"}
              </button>
            </div>
          )}
          {/* عند اختيار نوع/قسم/وسم: رأس رجوع متدرّج (قسم ← نوع ← مكتبة) */}
          {isLibrary && !tlId && !subId && (libType || libMood) && (
            <button type="button" onClick={() => { if (libShelf) { setLibShelf(null); } else { setLibType(null); setLibMood(null); } setPage(0); }}
              className="flex items-center gap-1.5 mb-3 hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}
              style={{ color: "var(--brand)" }}>
              <ChevronLeft className={`w-4 h-4`} />
              <span className="font-body font-semibold text-sm">
                {curShelf ? (isAr ? curShelf.ar : curShelf.en) : libType ? (isAr ? (LIB_TYPES.find(([k]) => k === libType)?.[1]) : (LIB_TYPES.find(([k]) => k === libType)?.[2])) : (isAr ? "المكتبة" : "Library")}
              </span>
            </button>
          )}
          {/* أقسام النوع — تظهر بعد اختيار نوع و قبل اختيار قسم؛ تشكيلة ألوان و فراغ، بلا أعداد */}
          {isLibrary && !tlId && !subId && libType && !libShelf && !libMood && libShelves.length > 0 && (
            <div className="space-y-2" dir={isAr ? "rtl" : "ltr"}>
              {libShelves.map((s, i) => (
                <button key={s.key} type="button" onClick={() => { setLibShelf(s.key); setPage(0); }}
                  className="w-full text-start py-1 font-body font-semibold hover:opacity-70 transition-opacity block"
                  style={{ color: SHELF_COLORS[i % SHELF_COLORS.length], fontSize: 15 }}>
                  <span className="min-w-0 truncate">{isAr ? s.ar : s.en}</span>
                </button>
              ))}
            </div>
          )}
          {/* المكتبة: الرئيسية أقسام فقط — العناوين تظهر بعد اختيار قسم (نوع) أو وسم */}
          {(!libMode || libShelf || libMood) && !poemsLanding && !genericLanding && !poemsEraView && !figureView && !isFigures && (
          <>
          {/* المدخلات — عنوان فقط بلا صورة، حسب لغة العرض، خطّ أصغر بلون التطبيق */}
          <div className={libMode ? "space-y-2" : "space-y-1"}>
            {(libMode ? libShown : shown).length === 0 ? (
              <p className="text-sm text-muted-foreground font-body py-8 text-center">
                {isAr ? "لا مدخلات في هذا القسم بعد" : "No entries in this section yet"}
              </p>
            ) : libMode ? pageItems.map((e) => (
              <LibraryCard key={e.id} entry={e} hideType={!!libType} onClick={() => navigate(`/encyclopedia/view/${e.id}`)} />
            )) : pageItems.map((e) => {
              const ar = langField(e.titles, "ar", langs) || "";
              const en = langField(e.titles, "en", langs) || "";
              const showBothT = browseLang === "both" && ar && en;
              const single = browseLang === "ar" ? (ar || en) : browseLang === "en" ? (en || ar) : (ar || en);
              return (
                <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                  className="w-full block py-1.5 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                  {titleOrder === "lang" ? (
                    <span className="block font-body truncate" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{(isAr ? (ar || en) : (en || ar)) || (isAr ? "بلا عنوان" : "Untitled")}</span>
                  ) : showBothT ? (
                    titleOrder === "en_ar" ? (
                      <>
                        <span className="block font-body truncate" dir="ltr" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{en}</span>
                        <span className="block font-body truncate" dir="rtl" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)", opacity: 0.85 }}>{ar}</span>
                      </>
                    ) : (
                      <>
                        <span className="block font-body truncate" dir="rtl" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{ar}</span>
                        <span className="block font-body truncate" dir="ltr" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)", opacity: 0.85 }}>{en}</span>
                      </>
                    )
                  ) : (
                    <span className="block font-body truncate" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{single || (isAr ? "بلا عنوان" : "Untitled")}</span>
                  )}
                </button>
              );
            })}
          </div>

          {/* شريط الصفحات — صفحة X / Y فقط، بلا مجموع الموسوعة، أرقام بلا فواصل */}
          {pageCount > 1 && !poemsEraView && !figureView && !isFigures && (
            <div className="flex items-center justify-center gap-5 pt-2" dir="ltr">
              <button type="button" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}
                className="font-body text-xs hover:opacity-70 disabled:opacity-30" style={{ color: "var(--brand)" }}>{isAr ? "السابق" : "Prev"}</button>
              <span className="font-body text-xs" style={{ color: "var(--brand)" }}>{isAr ? `صفحة ${page + 1}-${pageCount}` : `Page ${page + 1}-${pageCount}`}</span>
              <button type="button" disabled={page >= pageCount - 1} onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
                className="font-body text-xs hover:opacity-70 disabled:opacity-30" style={{ color: "var(--brand)" }}>{isAr ? "التالي" : "Next"}</button>
            </div>
          )}
          {/* المكتبة: الوسوم/المقترح/العشوائي أسفل العناوين */}
          {isLibrary && !tlId && !subId && (libType || libMood) && (
            <LibraryDiscovery activeMood={libMood} onMood={(m) => { setLibMood(m); setPage(0); }} onSurprise={onSurprise} onTonight={onTonight} />
          )}
          </>
          )}
          </>
          )}
          </>
          )}
          {/* مسار التنقل + رابط الخط الزمني — أسفل الصفحة قبل «اضافة مدخل» */}
          {activeSection && !isPhases && !filterTimeline && (
            <div className="flex items-center justify-between gap-2 flex-wrap pt-3" dir={isAr ? "rtl" : "ltr"}>
              <div className="flex items-center gap-1 flex-wrap font-body text-[11px]" style={{ color: "var(--brand)" }}>
                {crumbs.map((c, i) => (
                  <span key={i} className="flex items-center gap-1">
                    {i > 0 && <span style={{ opacity: 0.35 }}>{isAr ? "‹" : "›"}</span>}
                    {i < crumbs.length - 1 && c.go
                      ? <button type="button" onClick={c.go} className="hover:opacity-70" style={{ opacity: 0.7 }}>{c.label}</button>
                      : <span style={{ fontWeight: i === crumbs.length - 1 ? 700 : 400, opacity: i === crumbs.length - 1 ? 1 : 0.7 }}>{c.label}</span>}
                  </span>
                ))}
              </div>
              <button type="button" onClick={() => navigate(isPoems ? "/encyclopedia/timelines?scope=poems" : "/encyclopedia/timelines")}
                className="font-body text-[11px] hover:opacity-70 whitespace-nowrap" style={{ color: "var(--brand)", opacity: 0.7 }}>
                {isAr ? "الخط الزمني" : "Timeline"}
              </button>
            </div>
          )}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-3 font-body text-xs font-semibold">
            <button type="button" onClick={() => navigate(`/encyclopedia/entry?section=${sectionId}`)}
              style={{ color: "var(--brand)" }} className="hover:opacity-70 transition-opacity">{isAr ? "إضافة محتوى" : "Add Content"}</button>
            {figuresSection && (
              <button type="button" onClick={() => selectSection(figuresSection.id)}
                style={{ color: "#3E7CB1" }} className="hover:opacity-70 transition-opacity">{dispName(figuresSection, isAr)}</button>
            )}
            <button type="button" onClick={() => navigate("/encyclopedia/timelines")}
              style={{ color: "#2E7D6B" }} className="hover:opacity-70 transition-opacity">{isAr ? "خطوط و مصنّفات" : "Timelines - Classifications"}</button>
            <button type="button" onClick={() => navigate("/reading-guide")}
              style={{ color: "#7C6FB0" }} className="hover:opacity-70 transition-opacity">{isAr ? "موجِّهة القراءة" : "Reading Guide"}</button>
            <button type="button" onClick={() => navigate("/blog")}
              style={{ color: "#9D174D" }} className="hover:opacity-70 transition-opacity">{isAr ? "مدوّنة" : "Blog"}</button>
            <button type="button" onClick={() => navigate("/encyclopedia/setup")}
              style={{ color: "#B76E79" }} className="hover:opacity-70 transition-opacity">{isAr ? "إدارة موسوعة" : "Manage Encyclopedia"}</button>
          </div>

          {/* خط ذهبي خفيف يفصل الرؤية عن المحتوى — يحترم لون المستخدم، غير عاكس */}
          <div className="mt-6 mb-3" style={{ height: 1, background: "linear-gradient(to right, transparent, color-mix(in srgb, var(--brand) 50%, transparent), transparent)" }} />
          {/* خيارات الموسوعة — بعد الروابط أسفل الصفحة */}
          <EncOptionsBar isAr={isAr} titleOrder={titleOrder} setTitleOrder={setTitleOrder} subTitleOrder={subTitleOrder} setSubTitleOrder={setSubTitleOrder} sortMode={sortMode} setSortMode={setSortMode} showSubTitle={true} isLibrary={isLibrary} libType={libType} setLibType={(t) => { setLibType(t); setPage(0); }} />
        </>
      )}
    </div>
  );
}

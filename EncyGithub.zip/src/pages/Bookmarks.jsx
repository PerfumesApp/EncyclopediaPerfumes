import { useNavigate, Link } from "react-router-dom";
import { Notebook, Download } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { downloadBlob } from "@/lib/exportHelper";
import { toast } from "sonner";
import BookmarksContent, { TYPE_LABEL, useGroupedBookmarks } from "@/components/shared/BookmarksContent";
import BackIcon from "@/components/shared/BackIcon";

export default function Bookmarks() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { bookmarks, grouped } = useGroupedBookmarks();

  // تصدير المفكرة نصاً: عناوين الأقسام بلغتين ثم المدخلات سطراً سطراً — بلا رموز.
  const handleTextExport = async () => {
    if (!bookmarks.length) { toast.error(isAr ? "المفكرة فارغة" : "Notebook is empty"); return; }
    const lines = [isAr ? "مفكرة" : "Notebook", ""];
    for (const g of grouped) {
      const lbl = TYPE_LABEL[g.type] || { en: g.type, ar: g.type };
      lines.push(`${lbl.en} ${lbl.ar}`);
      for (const b of g.items) {
        const title = [b.title_en, b.title_ar].filter(Boolean).join(" ");
        lines.push(b.subtitle ? `- ${title} (${b.subtitle})` : `- ${title}`);
      }
      lines.push("");
    }
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const ok = await downloadBlob(blob, "notebook.txt", { toDownload: true });
    if (ok !== false) toast.success(isAr ? "تم تصدير المفكرة نصاً" : "Notebook exported as text");
  };

  return (
    <div className="px-4 page-top pb-20 max-w-lg mx-auto space-y-5">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button onClick={() => navigate(-1)} className="flex items-center justify-center w-8 h-8 rounded-none hover:bg-secondary transition-colors">
            <BackIcon className="w-4 h-4" />
          </button>
          <h1 className="font-heading text-xl font-bold flex items-center gap-2">
            <Notebook className="w-5 h-5" strokeWidth={1.25} style={{ color: "var(--brand)" }} />
            {isAr ? "مفكرة" : "Notebook"}
          </h1>
        </div>
        <div className="flex items-center gap-4">
          <button type="button" onClick={handleTextExport} aria-label={isAr ? "تصدير" : "Export"}
            className="flex items-center justify-center transition-opacity hover:opacity-70 bg-transparent" style={{ color: "#a16207" }}>
            <Download className="w-5 h-5" strokeWidth={1.6} />
          </button>
        </div>
      </div>

      <BookmarksContent showRemove />

      {/* رابط الشبكة — أسفل الصفحة */}
      <div className="flex justify-center pt-2">
        <Link to="/net" className="font-body text-sm transition-opacity hover:opacity-70" style={{ color: "#a16207", letterSpacing: "0.04em" }}>
          {isAr ? "شبكة عطور و ماركات" : "Perfume and Brand Net"}
        </Link>
      </div>
    </div>
  );
}

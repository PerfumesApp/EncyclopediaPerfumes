import { useEffect, useRef, useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ChevronLeft, ChevronRight, Highlighter, StickyNote, X, List, Trash2, Maximize2, Minimize2, NotebookPen } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { getBookFile, saveBookPosition, addNote, listNotes, deleteNote } from "@/lib/libraryFiles";
import * as pdfjsLib from "pdfjs-dist";
import pdfWorkerUrl from "pdfjs-dist/build/pdf.worker.min.js?url";
import ePub from "epubjs";
import BackIcon from "@/components/shared/BackIcon";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;
const HL = "#F6C453";
const COLORS = ["#F6C453", "#86C28B", "#8FB8DE", "#E59BB5", "#E8A66B"]; // أصفر — أخضر — أزرق — وردي — برتقالي

// قارئ داخلي — PDF عبر PDF.js و EPUB عبر epub.js، حفظ موضع التوقّف، وطبقة تظليل
// وملاحظات تُخزَّن محلياً لكل كتاب.
export default function Reader() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const { id } = useParams();

  const [rec, setRec] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [notes, setNotes] = useState([]);
  const [pendingSel, setPendingSel] = useState(null);
  const [noteDraft, setNoteDraft] = useState(null);
  const [drawer, setDrawer] = useState(false);
  const [immersive, setImmersive] = useState(false);
  // إظهار/إخفاء تلقائيّ لزرّ الخروج في الوضع الغامر — يظهر عند الدخول/اللمس ثم يختفي
  const [chrome, setChrome] = useState(true);
  const chromeTimer = useRef(null);
  const pokeChrome = useCallback(() => {
    setChrome(true);
    if (chromeTimer.current) clearTimeout(chromeTimer.current);
    chromeTimer.current = setTimeout(() => setChrome(false), 2800);
  }, []);
  useEffect(() => {
    if (immersive) pokeChrome();
    else { setChrome(true); if (chromeTimer.current) clearTimeout(chromeTimer.current); }
    return () => { if (chromeTimer.current) clearTimeout(chromeTimer.current); };
  }, [immersive, pokeChrome]);
  const [hlColor, setHlColor] = useState(COLORS[0]);

  const canvasRef = useRef(null);
  const textLayerRef = useRef(null);
  const hlLayerRef = useRef(null);
  const wrapRef = useRef(null);
  const pdfRef = useRef(null);
  const renderTaskRef = useRef(null);
  const [page, setPage] = useState(1);
  const [pageCount, setPageCount] = useState(0);

  const epubHostRef = useRef(null);
  const bookRef = useRef(null);
  const rendRef = useRef(null);
  const cfiRef = useRef(null);

  const refreshNotes = useCallback(async () => {
    try { setNotes(await listNotes(id)); } catch { setNotes([]); }
  }, [id]);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const f = await getBookFile(id);
        if (!alive) return;
        if (!f) { setErr(isAr ? "تعذّر العثور على الملف" : "File not found"); setLoading(false); return; }
        setRec(f);
        if (f.kind === "epub") cfiRef.current = f.position || null;
        else setPage(Number(f.position) > 0 ? Number(f.position) : 1);
        await refreshNotes();
      } catch {
        if (alive) { setErr(isAr ? "تعذّر فتح الكتاب" : "Could not open the book"); setLoading(false); }
      }
    })();
    return () => { alive = false; };
  }, [id, isAr, refreshNotes]);

  // ── PDF ──
  const drawPdfHighlights = useCallback((pageNum) => {
    const layer = hlLayerRef.current; if (!layer) return;
    layer.innerHTML = "";
    const w = layer.clientWidth, h = layer.clientHeight;
    notes.filter((n) => n.loc && n.loc.page === pageNum && Array.isArray(n.loc.rects)).forEach((n) => {
      n.loc.rects.forEach((r) => {
        const d = document.createElement("div");
        d.style.cssText = `position:absolute;left:${r.x * w}px;top:${r.y * h}px;width:${r.w * w}px;height:${r.h * h}px;background:${n.color || HL};opacity:.32;border-radius:2px;pointer-events:none;`;
        layer.appendChild(d);
      });
    });
  }, [notes]);

  const renderPdfPage = useCallback(async (pdf, n) => {
    if (!pdf || !canvasRef.current) return;
    try { renderTaskRef.current?.cancel?.(); } catch { /* تجاهل */ }
    const pg = await pdf.getPage(n);
    const canvas = canvasRef.current; if (!canvas) return;
    const containerW = wrapRef.current?.parentElement?.clientWidth || 360;
    const base = pg.getViewport({ scale: 1 });
    const scale = Math.max(0.2, (containerW - 6) / base.width);
    const vp = pg.getViewport({ scale });
    const ctx = canvas.getContext("2d");
    canvas.width = vp.width; canvas.height = vp.height;
    if (wrapRef.current) { wrapRef.current.style.width = vp.width + "px"; wrapRef.current.style.height = vp.height + "px"; }
    const task = pg.render({ canvasContext: ctx, viewport: vp });
    renderTaskRef.current = task;
    try { await task.promise; } catch { return; }
    const tl = textLayerRef.current;
    if (tl) {
      tl.innerHTML = ""; tl.style.width = vp.width + "px"; tl.style.height = vp.height + "px";
      try {
        const tc = await pg.getTextContent();
        await pdfjsLib.renderTextLayer({ textContent: tc, container: tl, viewport: vp, textDivs: [] }).promise;
      } catch { /* اختياري */ }
    }
    drawPdfHighlights(n);
  }, [drawPdfHighlights]);

  useEffect(() => {
    if (!rec || rec.kind === "epub") return;
    let alive = true;
    (async () => {
      try {
        const pdf = await pdfjsLib.getDocument({ data: rec.data.slice(0) }).promise;
        if (!alive) return;
        pdfRef.current = pdf; setPageCount(pdf.numPages);
        const start = Math.min(Math.max(1, Number(rec.position) || 1), pdf.numPages);
        setPage(start); await renderPdfPage(pdf, start); setLoading(false);
      } catch { if (alive) { setErr(isAr ? "تعذّر عرض ملف PDF" : "Could not render the PDF"); setLoading(false); } }
    })();
    return () => { alive = false; try { renderTaskRef.current?.cancel?.(); } catch { /* تجاهل */ } };
  }, [rec, renderPdfPage, isAr]);

  useEffect(() => { if (rec && rec.kind !== "epub") drawPdfHighlights(page); }, [notes, page, rec, drawPdfHighlights]);

  const goPdf = useCallback((n) => {
    const pdf = pdfRef.current; if (!pdf) return;
    const clamped = Math.min(Math.max(1, n), pdf.numPages);
    setPage(clamped); renderPdfPage(pdf, clamped);
    saveBookPosition(id, clamped, pdf.numPages ? Math.round((clamped / pdf.numPages) * 100) : 0).catch(() => {});
  }, [id, renderPdfPage]);

  const onPdfMouseUp = () => {
    if (rec?.kind === "epub") return;
    const sel = window.getSelection?.();
    const txt = sel?.toString().trim();
    if (!sel || !txt || sel.rangeCount === 0) return;
    const wrap = wrapRef.current; if (!wrap) return;
    const box = wrap.getBoundingClientRect();
    const W = box.width || 1, H = box.height || 1;
    const rects = [];
    for (let i = 0; i < sel.rangeCount; i++) {
      const rcs = sel.getRangeAt(i).getClientRects();
      for (const r of rcs) {
        if (r.width < 2 || r.height < 2) continue;
        rects.push({ x: (r.left - box.left) / W, y: (r.top - box.top) / H, w: r.width / W, h: r.height / H });
      }
    }
    if (rects.length) setPendingSel({ text: txt, loc: { page, rects } });
  };

  // ── EPUB ──
  const applyEpubHighlight = useCallback((n) => {
    try {
      rendRef.current?.annotations?.highlight(n.loc, { id: n.id }, () => setDrawer(true), "", { fill: n.color || HL, "fill-opacity": "0.3" });
    } catch { /* تجاهل */ }
  }, []);

  useEffect(() => {
    if (!rec || rec.kind !== "epub") return;
    let alive = true;
    (async () => {
      try {
        const book = ePub(rec.data.slice(0)); bookRef.current = book;
        const rendition = book.renderTo(epubHostRef.current, { width: "100%", height: "100%", flow: "paginated", spread: "none" });
        rendRef.current = rendition;
        await rendition.display(cfiRef.current || undefined);
        if (!alive) return;
        rendition.on("relocated", (loc) => {
          const cfi = loc?.start?.cfi;
          const prog = loc?.start?.percentage != null ? Math.round(loc.start.percentage * 100) : undefined;
          if (cfi) { cfiRef.current = cfi; saveBookPosition(id, cfi, prog).catch(() => {}); }
        });
        rendition.on("selected", (cfiRange, contents) => {
          let txt = "";
          try { txt = contents?.window?.getSelection?.().toString().trim() || ""; } catch { /* تجاهل */ }
          setPendingSel({ text: txt, loc: cfiRange });
          try { contents?.window?.getSelection?.().removeAllRanges?.(); } catch { /* تجاهل */ }
        });
        for (const n of await listNotes(id)) if (n.loc && typeof n.loc === "string") applyEpubHighlight(n);
        setLoading(false);
      } catch { if (alive) { setErr(isAr ? "تعذّر عرض ملف EPUB" : "Could not render the EPUB"); setLoading(false); } }
    })();
    return () => { alive = false; try { bookRef.current?.destroy?.(); } catch { /* تجاهل */ } };
  }, [rec, id, isAr, applyEpubHighlight]);

  const isEpub = rec?.kind === "epub";
  const goPrev = () => (isEpub ? rendRef.current?.prev?.() : goPdf(page - 1));
  const goNext = () => (isEpub ? rendRef.current?.next?.() : goPdf(page + 1));

  const saveMark = async (kind, noteText) => {
    if (!pendingSel) return;
    const nid = await addNote(id, { kind, loc: pendingSel.loc, text: pendingSel.text, note: noteText || "", color: hlColor });
    if (isEpub) applyEpubHighlight({ id: nid, loc: pendingSel.loc, color: hlColor });
    setPendingSel(null); setNoteDraft(null);
    await refreshNotes();
  };
  // ملاحظة للصفحة الحالية دون الحاجة لتحديد نص (يسهّل التدوين على الجوّال)
  const addPageNote = () => {
    setImmersive(false);
    const loc = isEpub ? (cfiRef.current || null) : { page, rects: [] };
    setPendingSel({ text: "", loc });
    setNoteDraft({ text: "" });
  };
  const jumpTo = (n) => {
    setDrawer(false);
    if (isEpub) { try { rendRef.current?.display(n.loc); } catch { /* تجاهل */ } }
    else if (n.loc?.page) goPdf(n.loc.page);
  };
  const removeNote = async (n) => {
    try { if (isEpub && n.loc) rendRef.current?.annotations?.remove(n.loc, "highlight"); } catch { /* تجاهل */ }
    await deleteNote(n.id); await refreshNotes();
  };

  return (
    <div className={`flex flex-col ${immersive ? "fixed inset-0 z-50 bg-[var(--background,#fafafa)]" : "h-[100dvh]"}`} dir={isAr ? "rtl" : "ltr"}>
      <style>{`.pdfTextLayer{position:absolute;inset:0;overflow:hidden;line-height:1;}
      .pdfTextLayer>span{position:absolute;white-space:pre;color:transparent;transform-origin:0 0;cursor:text;}
      .pdfTextLayer ::selection{background:rgba(246,196,83,.45);}`}</style>

      {!immersive && (
      <div className="flex items-center gap-2 px-4 py-2 border-b" style={{ borderColor: "var(--border,#e5e7eb)" }}>
        <button onClick={() => navigate(-1)} className="w-9 h-9 flex items-center justify-center hover:opacity-70" aria-label={isAr ? "رجوع" : "Back"}>
          <BackIcon className={`w-5 h-5`} style={{ color: "var(--brand)" }} />
        </button>
        <h1 className="font-heading text-base font-bold truncate flex-1" style={{ color: "#14532D" }}>{rec?.name || (isAr ? "قارئ" : "Reader")}</h1>
        {!isEpub && pageCount > 0 && <span className="font-body text-xs tabular-nums" style={{ color: "var(--brand)" }} dir="ltr">{page} / {pageCount}</span>}
        <button onClick={addPageNote} className="w-9 h-9 flex items-center justify-center hover:opacity-70" aria-label={isAr ? "أضف ملاحظة" : "Add note"}>
          <NotebookPen className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        <button onClick={() => setImmersive(true)} className="w-9 h-9 flex items-center justify-center hover:opacity-70" aria-label={isAr ? "وضع القراءة" : "Reading mode"}>
          <Maximize2 className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        <button onClick={() => setDrawer(true)} className="relative w-9 h-9 flex items-center justify-center hover:opacity-70" aria-label={isAr ? "الملاحظات" : "Notes"}>
          <List className="w-5 h-5" style={{ color: "var(--brand)" }} />
          {notes.length > 0 && <span className="absolute -top-0.5 -end-0.5 text-[9px] font-bold rounded-full px-1" style={{ color: "#fff", background: "#14532D" }}>{notes.length}</span>}
        </button>
      </div>
      )}

      <div className="relative flex-1 overflow-hidden">
        <div className="absolute inset-0 overflow-auto bg-[var(--background,#fafafa)]" onMouseUp={onPdfMouseUp} onTouchEnd={onPdfMouseUp} onClick={() => { if (immersive) pokeChrome(); }}>
          {loading && !err && <div className="absolute inset-0 flex items-center justify-center"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>}
          {err && <div className="absolute inset-0 flex items-center justify-center px-6 text-center"><p className="font-body text-sm text-muted-foreground">{err}</p></div>}
          {!isEpub && (
            <div className="flex justify-center p-1">
              <div ref={wrapRef} className="relative">
                <canvas ref={canvasRef} className="block max-w-full shadow-sm" />
                <div ref={textLayerRef} className="pdfTextLayer" />
                <div ref={hlLayerRef} className="absolute inset-0 pointer-events-none" />
              </div>
            </div>
          )}
          {isEpub && <div ref={epubHostRef} className="absolute inset-0" />}
        </div>
        {/* مناطق لمس للتنقّل — حافة البداية: السابق، حافة النهاية: التالي. الوسط حرّ للقراءة و التحديد */}
        {!err && !pendingSel && !noteDraft && (
          <>
            <button type="button" onClick={goPrev} aria-label={isAr ? "السابق" : "Prev"} className="absolute inset-y-0 start-0 w-[15%] z-20 bg-transparent" />
            <button type="button" onClick={goNext} aria-label={isAr ? "التالي" : "Next"} className="absolute inset-y-0 end-0 w-[15%] z-20 bg-transparent" />
          </>
        )}
        {/* خروج من وضع القراءة الكامل — أسفل الزاوية اليسرى، يختفي تلقائياً و يظهر عند اللمس */}
        {immersive && (
          <button type="button" onClick={() => setImmersive(false)} aria-label={isAr ? "إنهاء وضع القراءة" : "Exit reading mode"}
            className={`absolute bottom-3 left-3 z-30 w-9 h-9 flex items-center justify-center rounded-full transition-opacity duration-500 ${chrome ? "opacity-100" : "opacity-0 pointer-events-none"}`}
            style={{ background: "rgba(0,0,0,.35)" }}>
            <Minimize2 className="w-5 h-5" style={{ color: "#fff" }} />
          </button>
        )}
      </div>

      {pendingSel && !noteDraft && (
        <div className="px-4 py-3 border-t bg-[var(--paper,#fff)] space-y-2.5" style={{ borderColor: "var(--border,#e5e7eb)" }}>
          <div className="flex items-center justify-center gap-2.5">
            {COLORS.map((c) => (
              <button key={c} onClick={() => setHlColor(c)} aria-label="color"
                className="w-6 h-6 rounded-full transition-transform"
                style={{ background: c, outline: hlColor === c ? "2px solid #14532D" : "none", outlineOffset: 2, transform: hlColor === c ? "scale(1.12)" : "none" }} />
            ))}
          </div>
          <div className="flex items-center justify-center gap-6">
            <button onClick={() => saveMark("highlight")} className="flex items-center gap-1.5 font-body text-sm hover:opacity-70" style={{ color: "#14532D" }}><Highlighter className="w-4 h-4" />{isAr ? "تظليل" : "Highlight"}</button>
            <button onClick={() => setNoteDraft({ text: pendingSel.text })} className="flex items-center gap-1.5 font-body text-sm hover:opacity-70" style={{ color: "var(--brand)" }}><StickyNote className="w-4 h-4" />{isAr ? "ملاحظة" : "Note"}</button>
            <button onClick={() => setPendingSel(null)} className="flex items-center gap-1.5 font-body text-sm text-muted-foreground hover:opacity-70"><X className="w-4 h-4" />{isAr ? "إلغاء" : "Cancel"}</button>
          </div>
        </div>
      )}

      {noteDraft && (
        <div className="px-4 py-3 border-t bg-[var(--paper,#fff)] space-y-2" style={{ borderColor: "var(--border,#e5e7eb)" }}>
          <p className="text-[11px] text-muted-foreground font-body line-clamp-2">{pendingSel?.text}</p>
          <textarea autoFocus value={noteDraft.note || ""} onChange={(e) => setNoteDraft({ ...noteDraft, note: e.target.value })}
            placeholder={isAr ? "اكتب ملاحظتك" : "Write your note"} rows={2}
            className="w-full rounded-none border p-2 text-sm font-body bg-transparent" style={{ borderColor: "#14532D44" }} dir={isAr ? "rtl" : "ltr"} />
          <div className="flex items-center justify-end gap-4">
            <button onClick={() => { setNoteDraft(null); setPendingSel(null); }} className="font-body text-sm text-muted-foreground hover:opacity-70">{isAr ? "إلغاء" : "Cancel"}</button>
            <button onClick={() => saveMark("note", noteDraft.note)} className="font-body text-sm font-semibold hover:opacity-70" style={{ color: "#14532D" }}>{isAr ? "حفظ" : "Save"}</button>
          </div>
        </div>
      )}

      {!err && !pendingSel && !noteDraft && !immersive && (
        <div className="flex items-center justify-between px-6 py-3 border-t" style={{ borderColor: "var(--border,#e5e7eb)" }}>
          <button onClick={goPrev} className="flex items-center gap-1 font-body text-sm hover:opacity-70" style={{ color: "var(--brand)" }}>
            <ChevronRight className={`w-5 h-5 ${isAr ? "" : "hidden"}`} /><ChevronLeft className={`w-5 h-5 ${isAr ? "hidden" : ""}`} />{isAr ? "السابق" : "Prev"}
          </button>
          <button onClick={goNext} className="flex items-center gap-1 font-body text-sm hover:opacity-70" style={{ color: "var(--brand)" }}>
            {isAr ? "التالي" : "Next"}<ChevronLeft className={`w-5 h-5 ${isAr ? "" : "hidden"}`} /><ChevronRight className={`w-5 h-5 ${isAr ? "hidden" : ""}`} />
          </button>
        </div>
      )}

      {drawer && (
        <div className="absolute inset-0 z-40 flex" onClick={() => setDrawer(false)}>
          <div className="absolute inset-0 bg-black/30" />
          <div className="relative ms-auto w-[86%] max-w-sm h-full bg-[var(--paper,#fff)] shadow-xl overflow-auto p-4" onClick={(e) => e.stopPropagation()} dir={isAr ? "rtl" : "ltr"}>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-heading text-lg font-bold" style={{ color: "#14532D" }}>{isAr ? "الملاحظات و التظليل" : "Notes - Highlights"}</h2>
              <button onClick={() => setDrawer(false)} className="w-8 h-8 flex items-center justify-center hover:opacity-70"><X className="w-5 h-5" style={{ color: "var(--brand)" }} /></button>
            </div>
            {notes.length === 0 ? (
              <p className="text-sm font-body text-muted-foreground text-center py-10">{isAr ? "لا ملاحظات بعد — حدّد نصاً لتظلّله أو تعلّق عليه" : "No notes yet — select text to highlight or note"}</p>
            ) : (
              <div className="space-y-2">
                {notes.map((n) => (
                  <div key={n.id} className="rounded-none border p-2.5" style={{ borderColor: "#14532D33", borderInlineStartWidth: 3, borderInlineStartColor: n.color || HL }}>
                    <button onClick={() => jumpTo(n)} className="block w-full text-start hover:opacity-70">
                      {n.text && <p className="text-[12px] font-body line-clamp-2" style={{ color: "#14532D" }}>{n.text}</p>}
                      {n.note && <p className="text-[12px] font-body text-muted-foreground mt-1">{n.note}</p>}
                    </button>
                    <div className="flex items-center justify-between mt-1.5">
                      <span className="text-[10px] font-body text-muted-foreground">{n.kind === "note" ? (isAr ? "ملاحظة" : "Note") : (isAr ? "تظليل" : "Highlight")}{n.loc?.page ? ` - ${isAr ? "صفحة" : "p."} ${n.loc.page}` : ""}</span>
                      <button onClick={() => removeNote(n)} className="w-7 h-7 flex items-center justify-center hover:opacity-70"><Trash2 className="w-3.5 h-3.5 text-muted-foreground" /></button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

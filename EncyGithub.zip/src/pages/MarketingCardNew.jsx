import { useState, useRef, useMemo, useEffect } from "react";
import { useLang } from "@/lib/LanguageContext";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useCurrency } from "@/lib/useCurrency";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { searchIndexReady, searchPerfumeIds, searchPerfumesDirect } from "@/lib/searchIndex";
import { captureElementHQ } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { ExportFooter } from "@/lib/exportHeader";
import { Search, Upload, Package } from "lucide-react";
import PerfumeSprayIcon from "@/components/icons/PerfumeSprayIcon";
import { toast } from "sonner";
import { exportHistory } from "@/lib/exportHistoryStore";
import ExportHistoryList, { recordExport } from "@/components/export/ExportHistoryList";
import { DEFAULT_USER_MARK, resolveUserMark } from "@/lib/exportSettings";
import { occasionInfo } from "@/lib/occasions";
import BackIcon from "@/components/shared/BackIcon";

// بطاقة تسويقية — تصميم الجديد + مزايا القديم: السعر/الخصم/الضريبة/التوصيل،
// الوصف، المناسبات وأسطر الخصائص (عائلة·مناسبة·وقت·نوع·موسم·عطّار) مع وضع
// التسمية (أيقونة/إنجليزي/عربي/بدون)، الفريم، إطار النوتات، رفع صورة، العملة،
// العلامة، مقياس الخطّ. الربط بالعطر كفؤ عبر فهرس البحث (بلا تحميل 130 ألف).

const GOLD = "var(--brand)";
const PINK = "#B76E79";
const BG_COLORS = ["#ffffff", "#1a1a2e", "#4b1528", "#0c447c", "#173404", "#2c2c2a", "#412402"];
const ATTR_META = {
  family:   { ar: "العائلة العطرية", en: "Family",   icon: "🌸" },
  occasion: { ar: "المناسبة",        en: "Occasion", icon: "🎯" },
  time:     { ar: "الوقت",           en: "Time",     icon: "🕐" },
  ptype:    { ar: "النوع",           en: "Type",     icon: "🏷️" },
  season:   { ar: "الموسم",          en: "Season",   icon: "🍂" },
  gender:   { ar: "الجنس",           en: "Gender",   icon: "⚧" },
  perfumer: { ar: "العطّار",          en: "Perfumer", icon: "👃" },
};
const GENDER_DISP = { male: { ar: "رجالي", en: "Men" }, female: { ar: "نسائي", en: "Women" }, unisex: { ar: "للجميع", en: "Unisex" }, men: { ar: "رجالي", en: "Men" }, women: { ar: "نسائي", en: "Women" } };
const ATTR_KEYS = ["family", "occasion", "time", "ptype", "season", "gender", "perfumer"];
const emptyAttrs = () => ATTR_KEYS.reduce((o, k) => ((o[k] = { show: false, value: "" }), o), {});

function TextInput({ label, value, onChange, ph, dir, type }) {
  return (
    <label className="flex items-center gap-2 border rounded-none px-3 py-2">
      <span className="text-xs text-muted-foreground whitespace-nowrap" style={{ minWidth: 72 }}>{label}</span>
      <input name="MarketingCardNew-1"
        type={type || "text"}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={ph}
        dir={dir}
        className="flex-1 bg-transparent outline-none text-sm"
      />
    </label>
  );
}

export default function MarketingCardNew() {
  const { isAr } = useLang();
  const { symbol } = useCurrency();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const cardRef = useRef(null);
  const fitWrapRef = useRef(null);
  const [fitScale, setFitScale] = useState(1); // ملاءمة العرض للشاشة: المسرح 460px يُصغَّر بصريّاً ليظهر كاملاً (لا يؤثّر على دقّة التصدير)
  useEffect(() => {
    const wrap = fitWrapRef.current, card = cardRef.current;
    if (!wrap || !card) { setFitScale(1); return undefined; }
    const measure = () => {
      const avail = wrap.clientWidth || 1;
      const natural = card.offsetWidth || card.scrollWidth || 460;
      setFitScale(natural > avail ? Math.max(0.4, Math.round((avail / natural) * 1000) / 1000) : 1);
    };
    const t = setTimeout(measure, 40);
    let ro;
    try { ro = new ResizeObserver(measure); ro.observe(wrap); } catch { /* بيئة بلا ResizeObserver */ }
    window.addEventListener("resize", measure);
    return () => { clearTimeout(t); if (ro) ro.disconnect(); window.removeEventListener("resize", measure); };
  });
  const skipAutofill = useRef(false);

  const [mode, setMode] = useState("perfume"); // 'perfume' | 'standalone'
  const [query, setQuery] = useState("");
  const [picked, setPicked] = useState(null);

  // standalone product fields
  const [pName, setPName] = useState("");
  const [pNameAr, setPNameAr] = useState("");
  const [pBrand, setPBrand] = useState("");
  const [pNotes, setPNotes] = useState("");
  const [pImage, setPImage] = useState("");
  // صورة خلفية بارزة + وضع جعلها بارزة والبطاقة مصغّرة بداخلها
  const [bgImage, setBgImage] = useState("");
  const [imgDom, setImgDom] = useState(false);
  const [cardPct, setCardPct] = useState(0.55);
  const [cardPos, setCardPos] = useState("center");

  // shared marketing fields
  const [tagline, setTagline] = useState("");
  const [desc, setDesc] = useState("");
  const [price, setPrice] = useState("");
  const [discount, setDiscount] = useState("");
  const [taxPct, setTaxPct] = useState("");
  const [shipping, setShipping] = useState("");
  const [customCur, setCustomCur] = useState("");
  const [cta, setCta] = useState("");
  const [company, setCompany] = useState("");
  const [location, setLocation] = useState("");
  const [social, setSocial] = useState("");

  // attribute lines (family — occasion — time — type — season — perfumer)
  const [attrs, setAttrs] = useState(emptyAttrs);
  const [labelMode, setLabelMode] = useState("emoji"); // emoji | icon | en | ar | none

  // options
  const [bg, setBg] = useState("#ffffff");
  const [lang, setLang] = useState("both"); // both | ar | en
  const [frame, setFrame] = useState("solid"); // solid | dotted | none
  const [fontScale, setFontScale] = useState(1);
  const [showImage, setShowImage] = useState(true);
  const [showNotes, setShowNotes] = useState(true);
  const [notesFramed, setNotesFramed] = useState(false);
  const [noteImages, setNoteImages] = useState(true);
  const [showMark, setShowMark] = useState(true);
  const [busy, setBusy] = useState(false);
  const [recId, setRecId] = useState(null);

  const showAr = lang !== "en";
  const showEn = lang !== "ar";
  const curSym = customCur || symbol || "﷼";
  const fs = (n) => Math.round(n * fontScale);

  // ربط كفؤ: فهرس البحث ثم getMany (لا تحميل كامل الكتالوج)
  const t = query.trim();
  const { data: results = [] } = useQuery({
    queryKey: ["mkt-search", t],
    enabled: mode === "perfume" && t.length >= 2,
    queryFn: async () => {
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(t);
        if (ids && ids.length) return apphost.entities.Perfume.getMany(ids.slice(0, 20));
      }
      return await searchPerfumesDirect(t, 20);
    },
    staleTime: 3e5,
  });

  // تعبئة الخصائص تلقائيًّا من حقول العطر عند الربط (تُظهر ما له قيمة)
  useEffect(() => {
    if (skipAutofill.current) { skipAutofill.current = false; return; }
    if (mode !== "perfume" || !picked) return;
    const fill = (v) => (v || "").toString().trim();
    const dbVal = {
      family: fill(picked.odor_family),
      occasion: fill(picked.occasions),
      time: fill(picked.time_of_day),
      ptype: fill(picked.type),
      season: fill(picked.season),
      gender: fill(picked.gender),
    };
    setAttrs((s) => {
      const next = { ...s };
      for (const k of Object.keys(dbVal)) {
        const v = dbVal[k];
        next[k] = { value: v || s[k].value, show: v ? true : s[k].show };
      }
      return next;
    });
    setDesc((d) => d || fill(isAr ? (picked.description_ar || picked.description) : (picked.description || picked.description_ar)));
  }, [picked, mode, isAr]);

  const data = mode === "perfume" && picked
    ? {
        name: picked.name_en || picked.name || "",
        name_ar: picked.name_ar || "",
        brand: picked.brand_name || "",
        notes: [picked.top_notes, picked.heart_notes, picked.base_notes].filter(Boolean).join(", "),
        image: picked.image_url || "",
      }
    : { name: pName, name_ar: pNameAr, brand: pBrand, notes: pNotes, image: pImage };

  const notesList = useMemo(
    () => (data.notes || "").split(",").map((s) => s.trim()).filter(Boolean).slice(0, 10),
    [data.notes]
  );

  const [userMark, setUserMark] = useState(DEFAULT_USER_MARK);
  useEffect(() => { let on = true; resolveUserMark().then((m) => { if (on) setUserMark(m || DEFAULT_USER_MARK); }); return () => { on = false; }; }, []);

  // صور النوتات عند الربط بعطر: فهرسة PerfumeNote بالاسم → image_url (مربّعات مجمّعة كبطاقة العطر)
  const linked = mode === "perfume" && !!picked;
  const { data: noteRecords = [] } = useQuery({
    queryKey: ["mkt-notes"],
    enabled: linked && showNotes && noteImages,
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 6e5,
  });
  const noteIndex = useMemo(() => {
    const m = {};
    for (const r of noteRecords) { const k = (r.name || "").trim().toLowerCase(); if (k) m[k] = r; const ka = (r.name_ar || "").trim(); if (ka) m[ka] = r; }
    return m;
  }, [noteRecords]);
  const findNoteImg = (n) => { const r = noteIndex[(n || "").trim().toLowerCase()] || noteIndex[(n || "").trim()]; return (r && r.image_url) || ""; };
  const phaseGroups = useMemo(() => {
    if (!linked || !picked) return [];
    const split = (x) => (x || "").split(",").map((y) => y.trim()).filter(Boolean);
    return [
      [isAr ? "مقدمة" : "Top", split(picked.top_notes)],
      [isAr ? "قلب" : "Heart", split(picked.heart_notes)],
      [isAr ? "أساس" : "Base", split(picked.base_notes)],
    ].filter(([, arr]) => arr.length);
  }, [linked, picked, isAr]);

  // ---- price math: (price + tax%) - discount% + shipping ----
  const priceNum = parseFloat(price) || 0;
  const taxNum = parseFloat(taxPct) || 0;
  const discNum = parseFloat(discount) || 0;
  const shipNum = parseFloat(shipping) || 0;
  const afterTax = priceNum + priceNum * (taxNum / 100);
  const total = Math.round(afterTax - afterTax * (discNum / 100) + shipNum);
  const inclLine = (taxNum > 0 && shipNum > 0) ? (isAr ? "شامل ضريبة وشحن" : "incl. tax & shipping")
    : (taxNum > 0 ? (isAr ? "شامل الضريبة" : "incl. tax")
      : (shipNum > 0 ? (isAr ? "شامل الشحن" : "incl. shipping") : ""));

  const attrLabel = (key) => {
    const L = ATTR_META[key];
    if (labelMode === "icon") return L.icon;
    if (labelMode === "ar") return L.ar;
    if (labelMode === "en") return L.en;
    return "";
  };
  const onImagePick = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => setPImage(r.result);
    r.readAsDataURL(f);
  };
  const onBgPick = (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => { setBgImage(String(r.result || "")); setImgDom(true); };
    r.readAsDataURL(f);
  };

  const serialize = () => ({
    mode, pickedId: (picked && picked.id) || null,
    pName, pNameAr, pBrand, pNotes, pImage,
    bgImage, imgDom, cardPct, cardPos,
    tagline, desc, price, discount, taxPct, shipping, customCur, cta, company, location, social,
    attrs, labelMode,
    bg, lang, frame, fontScale,
    showImage, showNotes, notesFramed, noteImages, showMark,
  });

  // استعادة بطاقة محفوظة عند فتحها من السجلّ (?rec=)
  useEffect(() => {
    const rec = searchParams.get("rec");
    if (!rec) return;
    let on = true;
    exportHistory.get(Number(rec)).then(async (r) => {
      if (!on || !r || !r.payload) return;
      const d = r.payload;
      setRecId(r.id);
      if (d.mode) setMode(d.mode);
      setPName(d.pName || ""); setPNameAr(d.pNameAr || ""); setPBrand(d.pBrand || ""); setPNotes(d.pNotes || ""); setPImage(d.pImage || "");
      setBgImage(d.bgImage || ""); setImgDom(!!d.imgDom); if (typeof d.cardPct === "number") setCardPct(d.cardPct); setCardPos(d.cardPos || "center");
      setTagline(d.tagline || ""); setDesc(d.desc || ""); setPrice(d.price || ""); setDiscount(d.discount || ""); setTaxPct(d.taxPct || ""); setShipping(d.shipping || ""); setCustomCur(d.customCur || ""); setCta(d.cta || ""); setCompany(d.company || ""); setLocation(d.location || ""); setSocial(d.social || "");
      if (d.attrs) setAttrs(d.attrs); if (d.labelMode) setLabelMode(d.labelMode);
      if (d.bg) setBg(d.bg); if (d.lang) setLang(d.lang); if (d.frame) setFrame(d.frame); if (typeof d.fontScale === "number") setFontScale(d.fontScale);
      setShowImage(d.showImage !== false); setShowNotes(d.showNotes !== false); setNotesFramed(!!d.notesFramed); setNoteImages(d.noteImages !== false); setShowMark(d.showMark !== false);
      if (d.pickedId) { try { const arr = await apphost.entities.Perfume.getMany([d.pickedId]); if (on && arr && arr[0]) { skipAutofill.current = true; setPicked(arr[0]); } } catch { /* noop */ } }
    });
    return () => { on = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleExport = async () => {
    if (!cardRef.current) return;
    setBusy(true);
    try {
      const canvas = await captureElementHQ(cardRef.current, { pixelRatio: 3, backgroundColor: bg });
      const base = (data.name || "marketing").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "marketing";
      await saveCanvasAsImage(canvas, `marketing-${base}.png`);
      const nm = data.name || data.name_ar || (isAr ? "بطاقة تسويق" : "Marketing card");
      const newId = await recordExport({ type: "marketing", refId: (mode === "perfume" && picked) ? picked.id : "", name: nm, payload: serialize(), recId });
      if (newId) setRecId(newId);
      toast.success(isAr ? "تم حفظ البطاقة" : "Card saved");
    } catch {
      toast.error(isAr ? "تعذّر الحفظ" : "Export failed");
    } finally {
      setBusy(false);
    }
  };

  const dark = bg !== "#ffffff";
  const fg = dark ? "#ffffff" : "#1a1a1a";
  const sub = dark ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.55)";
  const noteBorder = dark ? "rgba(255,255,255,0.3)" : "rgba(0,0,0,0.2)";
  const cardBorder = frame === "none" ? "none" : `2px ${frame === "dotted" ? "dashed" : "solid"} ${GOLD}`;
  // وضع «الصورة بارزة»
  const useImgStage = imgDom && !!bgImage;
  const cardScale = Math.max(0.3, Math.min(0.95, cardPct || 0.55));
  const stageAlign = cardPos === "top" ? "flex-start" : cardPos === "bottom" ? "flex-end" : "center";
  const stageOrigin = cardPos === "top" ? "top center" : cardPos === "bottom" ? "bottom center" : "center";
  const stageStyle = { width: 460, height: 460, position: "relative", overflow: "hidden", background: dark ? "#000" : "#e9e6df", display: "flex", justifyContent: "center", alignItems: stageAlign };
  const cardInnerStyle = useImgStage
    ? { width: 460, background: bg, color: fg, padding: 28, border: cardBorder === "none" ? `2px solid ${GOLD}` : cardBorder, display: "flex", flexDirection: "column", alignItems: "center", gap: 10, textAlign: "center", transform: `scale(${cardScale})`, transformOrigin: stageOrigin, boxShadow: "0 10px 40px rgba(0,0,0,.45)", flexShrink: 0 }
    : { width: 460, background: bg, color: fg, padding: 28, border: cardBorder, display: "flex", flexDirection: "column", alignItems: "center", gap: 10, textAlign: "center" };

  const tabCls = (on) =>
    `flex-1 py-2 rounded-none text-xs font-body font-semibold transition-colors ${on ? "bg-[var(--brand)] text-white" : "bg-transparent text-muted-foreground border"}`;
  const miniTab = (on) =>
    `px-3 py-1.5 rounded-none text-[11px] font-body transition-colors ${on ? "bg-[var(--brand)] text-white" : "bg-transparent text-muted-foreground border"}`;

  const activeAttrs = ATTR_KEYS.map((k) => [k, attrs[k]]).filter(([, a]) => a.show && a.value);

  return (
    <div className="min-h-screen bg-background" dir={isAr ? "rtl" : "ltr"}>
      <div className="flex items-center gap-2 p-3 border-b">
        <button onClick={() => navigate(-1)} aria-label="back"><BackIcon className="w-5 h-5" /></button>
        <h1 className="font-body font-semibold text-sm flex items-center gap-2">
          <PerfumeSprayIcon className="w-4 h-4" />
          {isAr ? "بطاقة تسويقية" : "Marketing Card"}
        </h1>
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto">
        {/* mode */}
        <div className="flex gap-2">
          <button onClick={() => setMode("perfume")} className={tabCls(mode === "perfume")}>
            {isAr ? "ربط عطر" : "Link perfume"}
          </button>
          <button onClick={() => { setMode("standalone"); setPicked(null); }} className={tabCls(mode === "standalone")}>
            {isAr ? "منتج منفصل" : "Standalone product"}
          </button>
        </div>

        {mode === "perfume" ? (
          <div className="space-y-1">
            <div className="flex items-center gap-2 border rounded-none px-3 py-2">
              <Search className="w-4 h-4 opacity-60" />
              <input name="MarketingCardNew-2"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={isAr ? "ابحث عن عطر" : "Search a perfume"}
                className="flex-1 bg-transparent outline-none text-sm"
              />
            </div>
            {!searchIndexReady() && (
              <p className="text-xs text-muted-foreground">{isAr ? "فهرس البحث قيد البناء…" : "Search index building…"}</p>
            )}
            {!picked && results.length > 0 && (
              <div className="border rounded-none max-h-48 overflow-auto">
                {results.map((p) => (
                  <button key={p.id} onClick={() => setPicked(p)} className="block w-full text-start px-3 py-2 text-sm hover:bg-accent">
                    {p.name_en || p.name}{p.brand_name ? <span className="opacity-60"> — {p.brand_name}</span> : null}
                  </button>
                ))}
              </div>
            )}
            {picked && (
              <div className="flex items-center justify-between border rounded-none px-3 py-2 text-sm">
                <span>{picked.name_en || picked.name}</span>
                <button onClick={() => { setPicked(null); setAttrs(emptyAttrs()); }} className="text-xs text-[#B76E79]">{isAr ? "تغيير" : "Change"}</button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            <TextInput label={isAr ? "الاسم" : "Name"} value={pName} onChange={setPName} />
            <TextInput label={isAr ? "بالعربي" : "Arabic"} value={pNameAr} onChange={setPNameAr} dir="rtl" />
            <TextInput label={isAr ? "البراند" : "Brand"} value={pBrand} onChange={setPBrand} />
            <TextInput label={isAr ? "النوتات" : "Notes"} value={pNotes} onChange={setPNotes} ph="Rose, Oud, Musk" />
            <TextInput label={isAr ? "رابط صورة" : "Image URL"} value={pImage} onChange={setPImage} dir="ltr" />
          </div>
        )}

        {/* upload image (both modes) */}
        <label className="flex items-center justify-center gap-2 border rounded-none px-3 py-2 cursor-pointer text-sm text-muted-foreground hover:bg-accent">
          <Upload className="w-4 h-4" />
          {isAr ? "رفع صورة المنتج" : "Upload product image"}
          <input type="file" accept="image/*" onChange={onImagePick} className="hidden" />
        </label>

        {/* text fields */}
        <div className="space-y-2">
          <TextInput label={isAr ? "السطر التسويقي" : "Tagline"} value={tagline} onChange={setTagline} dir={isAr ? "rtl" : "ltr"} />
          <TextInput label={isAr ? "الوصف" : "Description"} value={desc} onChange={setDesc} dir={isAr ? "rtl" : "ltr"} ph={isAr ? "أضف وصف المنتج" : "Add a marketing line"} />
          <TextInput label={isAr ? "الشركة" : "Company"} value={company} onChange={setCompany} dir={isAr ? "rtl" : "ltr"} />
          <TextInput label={isAr ? "العطّار" : "Perfumer"} value={attrs.perfumer.value} onChange={(v) => setAttrs((s) => ({ ...s, perfumer: { show: !!v, value: v } }))} dir={isAr ? "rtl" : "ltr"} />
          <div className="flex gap-2">
            <TextInput label={isAr ? "الموقع" : "Location"} value={location} onChange={setLocation} dir={isAr ? "rtl" : "ltr"} />
            <TextInput label="@" value={social} onChange={setSocial} dir="ltr" ph="@social" />
          </div>
        </div>

        {/* price block */}
        <div className="space-y-2">
          <div className="flex gap-2">
            <TextInput label={isAr ? "السعر" : "Price"} value={price} onChange={setPrice} dir="ltr" type="number" />
            <TextInput label={isAr ? "الخصم %" : "Disc %"} value={discount} onChange={setDiscount} dir="ltr" type="number" />
          </div>
          <div className="flex gap-2">
            <TextInput label={isAr ? "الضريبة %" : "Tax %"} value={taxPct} onChange={setTaxPct} dir="ltr" type="number" />
            <TextInput label={isAr ? "التوصيل" : "Delivery"} value={shipping} onChange={setShipping} dir="ltr" type="number" />
          </div>
          <div className="flex gap-2">
            <TextInput label={isAr ? "رمز العملة" : "Currency"} value={customCur} onChange={setCustomCur} dir="ltr" ph={symbol || "﷼"} />
            <TextInput label={isAr ? "الوسم" : "Tag"} value={cta} onChange={setCta} dir={isAr ? "rtl" : "ltr"} ph={isAr ? "وسم صغير" : "Small tag"} />
          </div>
        </div>

        {/* attribute toggles (perfume) */}
        {mode === "perfume" && (
          <div className="space-y-2">
            <div className="flex flex-wrap gap-1.5">
              {ATTR_KEYS.filter((k) => k !== "perfumer").map((k) => (
                <button key={k} onClick={() => setAttrs((s) => ({ ...s, [k]: { ...s[k], show: !s[k].show } }))}
                  className={miniTab(attrs[k].show && !!attrs[k].value)} disabled={!attrs[k].value}
                  style={{ opacity: attrs[k].value ? 1 : 0.4 }}>
                  {isAr ? ATTR_META[k].ar : ATTR_META[k].en}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] text-muted-foreground">{isAr ? "التسمية:" : "Labels:"}</span>
              {[["emoji", isAr ? "إيموجي" : "Emoji"], ["icon", isAr ? "أيقونة" : "Icon"], ["en", "EN"], ["ar", "ع"], ["none", isAr ? "بدون" : "None"]].map(([v, l]) => (
                <button key={v} onClick={() => setLabelMode(v)} className={miniTab(labelMode === v)}>{l}</button>
              ))}
            </div>
          </div>
        )}

        {/* visual options */}
        <div className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {BG_COLORS.map((c) => (
              <button key={c} onClick={() => setBg(c)} style={{ background: c }}
                className={`w-7 h-7 rounded-none border ${bg === c ? "ring-2 ring-[var(--brand)]" : ""}`} aria-label={c} />
            ))}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <label className="inline-flex items-center gap-1.5 border rounded-none px-2.5 py-1 text-[11px] cursor-pointer text-muted-foreground hover:bg-accent">
              <Upload className="w-3.5 h-3.5" /> {isAr ? "صورة خلفية" : "BG image"}
              <input type="file" accept="image/*" onChange={onBgPick} className="hidden" />
            </label>
            {bgImage ? (
              <>
                <button onClick={() => { setBgImage(""); setImgDom(false); }} className="border rounded-none px-2 py-1 text-[11px] text-muted-foreground hover:bg-accent">✕</button>
                <label className="inline-flex items-center gap-1.5 text-[11px]">
                  <input type="checkbox" checked={imgDom} onChange={(e) => setImgDom(e.target.checked)} />
                  {isAr ? "الصورة بارزة (البطاقة بداخلها)" : "Image dominant (card inside)"}
                </label>
              </>
            ) : null}
          </div>
          {imgDom && bgImage ? (
            <div className="space-y-2">
              <div>
                <div className="text-[11px] text-muted-foreground mb-1">{isAr ? `حجم البطاقة: ${Math.round(cardScale * 100)}%` : `Card size: ${Math.round(cardScale * 100)}%`}</div>
                <input type="range" min={30} max={90} step={5} value={Math.round(cardScale * 100)} onChange={(e) => setCardPct(Number(e.target.value) / 100)} style={{ width: "100%", accentColor: GOLD }} />
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] text-muted-foreground">{isAr ? "الموضع:" : "Position:"}</span>
                {[["top", isAr ? "أعلى" : "Top"], ["center", isAr ? "وسط" : "Center"], ["bottom", isAr ? "أسفل" : "Bottom"]].map(([v, l]) => (
                  <button key={v} onClick={() => setCardPos(v)} className={miniTab(cardPos === v)}>{l}</button>
                ))}
              </div>
            </div>
          ) : null}
          <div className="flex gap-2">
            {["both", "ar", "en"].map((l) => (
              <button key={l} onClick={() => setLang(l)} className={tabCls(lang === l)}>
                {l === "both" ? (isAr ? "اللغتان" : "Both") : l.toUpperCase()}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-muted-foreground">{isAr ? "الإطار:" : "Frame:"}</span>
            {[["solid", isAr ? "خطّ" : "Solid"], ["dotted", isAr ? "منقّط" : "Dotted"], ["none", isAr ? "بدون" : "None"]].map(([v, l]) => (
              <button key={v} onClick={() => setFrame(v)} className={miniTab(frame === v)}>{l}</button>
            ))}
            <span className="text-[11px] text-muted-foreground ms-2">{isAr ? "الخطّ:" : "Size:"}</span>
            {[0.8, 0.92, 1, 1.12, 1.28].map((v, i) => (
              <button key={v} onClick={() => setFontScale(v)} className={miniTab(Math.abs(fontScale - v) < 0.001)} style={{ fontSize: 9 + i * 2.5, lineHeight: 1, padding: "5px 9px" }}>A</button>
            ))}
          </div>
          <div className="flex gap-4 flex-wrap">
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={showImage} onChange={(e) => setShowImage(e.target.checked)} />
              {isAr ? "الصورة" : "Image"}
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={showNotes} onChange={(e) => setShowNotes(e.target.checked)} />
              {isAr ? "النوتات" : "Notes"}
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={notesFramed} onChange={(e) => setNotesFramed(e.target.checked)} />
              {isAr ? "إطار النوتات" : "Notes frame"}
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={noteImages} onChange={(e) => setNoteImages(e.target.checked)} />
              {isAr ? "صور النوتات" : "Note images"}
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={showMark} onChange={(e) => setShowMark(e.target.checked)} />
              {isAr ? "العلامة" : "Mark"}
            </label>
          </div>
        </div>

        {/* preview card */}
        <div className="flex justify-center">
          {(() => {
            const cardBody = (
              <>
            {showImage && data.image ? (
              <img src={data.image} alt="" crossOrigin="anonymous" style={{ width: 150, height: 150, objectFit: "contain" }} />
            ) : null}
            {showEn && data.name ? (
              <div style={{ fontFamily: "Cinzel, serif", color: GOLD, fontSize: fs(26), fontWeight: 700, letterSpacing: ".05em", textTransform: "uppercase" }}>{data.name}</div>
            ) : null}
            {showAr && data.name_ar ? (
              <div style={{ fontFamily: "Amiri, serif", color: PINK, fontSize: fs(26), fontWeight: 700 }}>{data.name_ar}</div>
            ) : null}
            {data.brand ? (
              <div style={{ fontSize: fs(14), color: sub, letterSpacing: ".08em", textTransform: "uppercase" }}>{data.brand}</div>
            ) : null}
            {company ? (
              <div style={{ fontSize: fs(13), color: sub, fontWeight: 600 }}>{company}</div>
            ) : null}
            {tagline ? (
              <div style={{ fontFamily: isAr ? "Amiri, serif" : "Georgia, serif", fontStyle: "italic", fontSize: fs(16), color: fg, maxWidth: 380 }}>{tagline}</div>
            ) : null}
            {desc ? (
              <div style={{ fontSize: fs(14), lineHeight: 1.55, color: sub, maxWidth: 380, overflowWrap: "anywhere" }}>{desc}</div>
            ) : null}
            {showNotes && noteImages && linked && phaseGroups.length ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 4, alignItems: "center" }}>
                {phaseGroups.map(([label, arr]) => (
                  <div key={label} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                    <div style={{ fontSize: fs(9), letterSpacing: ".12em", textTransform: "uppercase", color: sub, fontFamily: isAr ? "Amiri, serif" : "Cinzel, serif" }}>{label}</div>
                    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 4, maxWidth: 380 }}>
                      {arr.map((n, i) => { const img = findNoteImg(n); return img
                        ? <img key={i} src={img} alt="" crossOrigin="anonymous" style={{ width: fs(30), height: fs(30), objectFit: "cover", background: "#fff" }} />
                        : <span key={i} style={{ fontSize: fs(11), color: sub }}>{n}</span>; })}
                    </div>
                  </div>
                ))}
              </div>
            ) : (showNotes && notesList.length > 0 ? (
              <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 6, marginTop: 4 }}>
                {notesList.map((n, i) => (
                  <span key={i} style={{ fontSize: fs(12), color: sub, border: notesFramed ? `1px solid ${noteBorder}` : "none", padding: notesFramed ? "2px 8px" : "0 4px" }}>{n}</span>
                ))}
              </div>
            ) : null)}
            {activeAttrs.length > 0 ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: 4, alignItems: "center" }}>
                {activeAttrs.map(([k, a]) => {
                  const meta = ATTR_META[k];
                  const emojiMode = labelMode === "emoji" || labelMode === "icon";
                  if (k === "occasion") {
                    const items = a.value.split(",").map((x) => x.trim()).filter(Boolean).map((o) => occasionInfo(o) || { ar: o, en: o, emoji: "" });
                    return (
                      <div key={k} style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", alignItems: "center", gap: fs(7), fontSize: fs(12), color: sub, maxWidth: 380 }}>
                        {items.map((it, i) => (
                          <span key={i} style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
                            {emojiMode && it.emoji ? <span>{it.emoji}</span> : null}
                            {!emojiMode ? <span>{isAr ? it.ar : it.en}</span> : null}
                          </span>
                        ))}
                      </div>
                    );
                  }
                  const gd = GENDER_DISP[(a.value || "").toLowerCase()];
                  const val = (k === "gender" && gd) ? (isAr ? gd.ar : gd.en) : a.value;
                  return (
                    <div key={k} style={{ fontSize: fs(12), color: sub, display: "inline-flex", alignItems: "center", gap: 5, flexWrap: "wrap", justifyContent: "center" }}>
                      {emojiMode ? <span>{meta.icon}</span> : (labelMode !== "none" ? <span style={{ fontWeight: 600, color: fg }}>{attrLabel(k)} </span> : null)}
                      <span>{val}</span>
                    </div>
                  );
                })}
              </div>
            ) : null}
            {(priceNum > 0 || total > 0) ? (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexWrap: "wrap", gap: 8, marginTop: 6 }}>
                <span style={{ fontSize: fs(22), fontWeight: 700, color: GOLD }}>{total || priceNum}{curSym}</span>
                {discNum > 0 && priceNum > 0 ? (
                  <>
                    <span style={{ fontSize: fs(14), textDecoration: "line-through", opacity: 0.55, color: sub }}>{priceNum}{curSym}</span>
                    <span style={{ fontSize: fs(12), color: PINK }}>−{discNum}%</span>
                  </>
                ) : null}
                {shipNum > 0 ? (
                  <span style={{ fontSize: fs(12), color: sub, display: "inline-flex", alignItems: "center", gap: 3 }}>
                    <Package style={{ width: fs(12), height: fs(12) }} />{shipNum}{curSym}
                  </span>
                ) : null}
              </div>
            ) : null}
            {inclLine ? (<div style={{ fontSize: fs(10), opacity: 0.8, color: sub }}>{inclLine}</div>) : null}
            {cta ? (
              <div style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: fs(12), letterSpacing: ".06em", textTransform: "uppercase", color: GOLD, fontWeight: 700, marginTop: 4 }}>🏷️ {cta}</div>
            ) : null}
            {(location || social) ? (
              <div style={{ display: "flex", gap: 14, fontSize: fs(11), color: sub, marginTop: 2 }}>
                {location ? <span>{location}</span> : null}
                {social ? <span>{social}</span> : null}
              </div>
            ) : null}
            {showMark && userMark ? (
              <div style={{ fontFamily: "Amiri, serif", color: dark ? "rgba(255,255,255,0.85)" : "#9a7b1f", fontWeight: 700, fontSize: fs(12), marginTop: 4 }}>{userMark}</div>
            ) : null}
            <ExportFooter compact />
              </>
            );
            const stageEl = useImgStage ? (
              <div ref={cardRef} style={stageStyle}>
                <img src={bgImage} alt="" crossOrigin="anonymous" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
                <div style={{ ...cardInnerStyle, position: "relative", zIndex: 1 }}>{cardBody}</div>
              </div>
            ) : (
              <div ref={cardRef} style={cardInnerStyle}>{cardBody}</div>
            );
            // حاوية الملاءمة: تصغّر المسرح بصريّاً ليظهر كاملاً داخل عرض الشاشة (الـcardRef يبقى بأبعاده للتصدير)
            return (
              <div ref={fitWrapRef} style={{ width: "100%", overflow: "hidden", display: "flex", justifyContent: "center" }}>
                <div style={{ transform: `scale(${fitScale})`, transformOrigin: "top center", flexShrink: 0 }}>{stageEl}</div>
              </div>
            );
          })()}
        </div>

        <button
          onClick={handleExport}
          disabled={busy}
          className="w-full h-11 rounded-none bg-[var(--brand)] text-white font-body gap-2 inline-flex items-center justify-center disabled:opacity-50"
        >
          <PerfumeSprayIcon className="w-4 h-4" />
          {busy ? (isAr ? "جارٍ الحفظ…" : "Saving…") : (isAr ? "حفظ صورة البطاقة" : "Save card image")}
        </button>

        <ExportHistoryList type="marketing" title={isAr ? "بطاقات التسويق المحفوظة" : "Saved marketing cards"} />
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Heart, ThumbsUp, ThumbsDown, BookOpen, BookCheck, Eraser, Pin, Notebook } from "lucide-react";
import BookmarksContent from "@/components/shared/BookmarksContent";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { usePins } from "@/lib/usePins";
import { ENC, langField } from "@/lib/encyclopedia";
import BackIcon from "@/components/shared/BackIcon";

// صفحة مفضلة الموسوعة — مربعات المستخدمين أعلى، و لكل مستخدم تفاعله و ما قرأ و ما سيقرأ.
// كل عنصر رابط للمدخل، قبل العنوان أيقونة التفاعل، بلا تاريخ، مرتّب بوقت التخصيص (updated_date).
function reactionOf(entry, person) {
  const m = entry.reactions || (entry.reaction ? { person1: entry.reaction } : {});
  return m[person] || "none";
}
function readOf(entry, person) {
  const m = entry.reads || (entry.read_status ? { person1: entry.read_status } : {});
  return m[person] || "none";
}

const REACT_ICON = { favorite: Heart, like: ThumbsUp, dislike: ThumbsDown };

export default function EncyclopediaFavorites() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const { names, profiles } = usePersonNames();
  const [person, setPerson] = useState("all");

  const { data: langs = [] } = useQuery({ queryKey: ["enc-langs"], queryFn: () => ENC.Language().list("order", 50), staleTime: 1000 * 30 });
  const { data: entries = [] } = useQuery({ queryKey: ["enc-fav-entries"], queryFn: () => ENC.Entry().list("-updated_date", 20000), staleTime: 1000 * 10 });

  const code = isAr ? "ar" : "en";
  const title = (e) => langField(e.titles, code, langs) || (isAr ? "بلا عنوان" : "Untitled");

  const persons = person === "all" ? ["person1", "person2"] : [person];
  const anyReact = (e, v) => persons.some((pk) => reactionOf(e, pk) === v);
  const anyRead = (e, v) => persons.some((pk) => readOf(e, pk) === v);
  const favorites = entries.filter((e) => anyReact(e, "favorite"));
  const reactions = entries.filter((e) => ["like", "dislike", "wtf"].some((v) => anyReact(e, v)));
  const read = entries.filter((e) => anyRead(e, "done"));
  const toRead = entries.filter((e) => anyRead(e, "to_read"));
  const castaway = entries.filter((e) => anyReact(e, "castaway"));
  // المثبّتات (عامّة، غير مرتبطة بشخص) — تُعرض ضمن القلب أيضاً
  const { pinnedIds } = usePins("encentry");
  const pinned = pinnedIds.map((id) => entries.find((e) => String(e.id) === String(id))).filter(Boolean);
  const color = person === "all" ? "var(--brand)" : (profiles[person]?.color || "var(--brand)");
  const reactKind = (e) => { for (const pk of persons) { const r = reactionOf(e, pk); if (["like","dislike","wtf"].includes(r)) return r; } return "like"; };
  // تسلسل مجمّع واحد لترقيم ٢٥/صفحة عبر كل المجموعات
  const FAV_PER_PAGE = 25;
  const [favPage, setFavPage] = useState(0);
  useEffect(() => { setFavPage(0); }, [person]);
  const groupsDef = [
    { label: isAr ? "المثبّتة" : "Pinned", items: pinned, kindOf: () => "pinned" },
    { label: isAr ? "المفضلة" : "Favorites", items: favorites, kindOf: () => "favorite" },
    { label: isAr ? "التفاعل" : "Reactions", items: reactions, kindOf: reactKind },
    { label: isAr ? "تمت القراءة" : "Done Reading", items: read, kindOf: () => "done" },
    { label: isAr ? "للقراءة" : "To Read", items: toRead, kindOf: () => "to_read" },
    { label: isAr ? "إبعاد" : "Cast away", items: castaway, kindOf: () => "castaway" },
  ];
  const flat = [];
  groupsDef.forEach((g) => g.items.forEach((e) => flat.push({ label: g.label, kind: g.kindOf(e), e })));
  const favPageCount = Math.max(1, Math.ceil(flat.length / FAV_PER_PAGE));
  const flatPage = flat.slice(favPage * FAV_PER_PAGE, favPage * FAV_PER_PAGE + FAV_PER_PAGE);

  const Item = ({ e, kind }) => {
    const Icon = REACT_ICON[kind];
    return (
      <button type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
        className="w-full flex items-center gap-2 py-2 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
        {kind === "wtf"
          ? <span className="text-base leading-none flex-shrink-0">😱</span>
          : kind === "pinned" ? <Pin className="w-4 h-4 flex-shrink-0 fill-current" style={{ color }} />
          : kind === "to_read" ? <BookOpen className="w-4 h-4 flex-shrink-0" style={{ color }} />
          : kind === "done" ? <BookCheck className="w-4 h-4 flex-shrink-0" style={{ color }} />
          : kind === "castaway" ? <Eraser className="w-4 h-4 flex-shrink-0" style={{ color }} />
          : Icon ? <Icon className={`w-4 h-4 flex-shrink-0 ${kind === "favorite" ? "fill-current" : ""}`} style={{ color }} /> : null}
        <span className="flex-1 min-w-0 font-body text-sm truncate">{title(e)}</span>
      </button>
    );
  };

  const Group = ({ label, items, render }) => items.length ? (
    <section className="space-y-1">
      <h2 className="font-heading text-sm font-semibold pt-2" style={{ color }}>{label}</h2>
      {items.map((e) => render(e))}
    </section>
  ) : null;

  const empty = !pinned.length && !favorites.length && !reactions.length && !read.length && !toRead.length && !castaway.length;

  return (
    <div className="px-5 page-top pb-24 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>{isAr ? "المفضلة" : "Favorites"}</h1>
        <button type="button" onClick={() => navigate("/encyclopedia")}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity" aria-label={isAr ? "رجوع" : "Back"}>
          <BackIcon className={`w-5 h-5`} style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {/* اعرض الكل و بجانبهم التخصيص — أسماء بلون المستخدم بلا إطارات */}
      <div className="flex items-center gap-5" dir={isAr ? "rtl" : "ltr"}>
        <button type="button" onClick={() => setPerson("all")} className="font-body text-sm transition-opacity hover:opacity-70"
          style={{ color: "var(--brand)", fontWeight: person === "all" ? 700 : 400, opacity: person === "all" ? 1 : 0.55 }}>{isAr ? "الكل" : "All"}</button>
        {["person1", "person2"].map((pk) => (
          <button key={pk} type="button" onClick={() => setPerson(pk)} className="font-body text-sm transition-opacity hover:opacity-70"
            style={{ color: profiles[pk].color, fontWeight: person === pk ? 700 : 400, opacity: person === pk ? 1 : 0.55 }}>
            {names[pk]}
          </button>
        ))}
      </div>

      {empty ? (
        <p className="text-sm text-muted-foreground font-body py-10 text-center">
          {isAr ? "لا تفاعل لهذا المستخدم بعد" : "No interactions for this user yet"}
        </p>
      ) : (
        <div className="space-y-1">
          {flatPage.map((row, i) => {
            const prev = flatPage[i - 1];
            const showHeader = !prev || prev.label !== row.label;
            return (
              <div key={row.e.id + ":" + row.kind}>
                {showHeader && <h2 className="font-heading text-sm font-semibold pt-3" style={{ color }}>{row.label}</h2>}
                <Item e={row.e} kind={row.kind} />
              </div>
            );
          })}
          {favPageCount > 1 && (
            <div className="flex items-center justify-center gap-5 pt-3" dir="ltr">
              <button type="button" disabled={favPage === 0} onClick={() => setFavPage((p) => Math.max(0, p - 1))} className="font-body text-xs hover:opacity-70 disabled:opacity-30" style={{ color: "var(--brand)" }}>{isAr ? "السابق" : "Prev"}</button>
              <span className="font-body text-xs" style={{ color: "var(--brand)" }}>{isAr ? `صفحة ${favPage + 1} / ${favPageCount}` : `Page ${favPage + 1} / ${favPageCount}`}</span>
              <button type="button" disabled={favPage >= favPageCount - 1} onClick={() => setFavPage((p) => Math.min(favPageCount - 1, p + 1))} className="font-body text-xs hover:opacity-70 disabled:opacity-30" style={{ color: "var(--brand)" }}>{isAr ? "التالي" : "Next"}</button>
            </div>
          )}
        </div>
      )}

      {/* المفكرة (النوت بوك) مدموجة مباشرةً — لا رابط */}
      <div className="pt-4 space-y-3">
        <h2 className="font-heading font-semibold text-base flex items-center gap-2" style={{ color: "var(--brand)" }}>
          <Notebook className="w-5 h-5" strokeWidth={1.25} />
          {isAr ? "مفكرة" : "Notebook"}
        </h2>
        <BookmarksContent />
      </div>
    </div>
  );
}

import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { format, subMonths } from "date-fns";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Trash2, CalendarDays, BarChart2, LineChart, User, Users, StickyNote, Edit2, LayoutDashboard } from "lucide-react";
import { Link } from "react-router-dom";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import WearCalendar from "@/components/wearlog/WearCalendar";
import WearStats from "@/components/wearlog/WearStats";
import PerfumePicker from "@/components/wearlog/PerfumePicker";
import WearNotes from "@/components/wearlog/WearNotes";
import WearReport from "@/components/wearlog/WearReport";
import EditLogDialog from "@/components/wearlog/EditLogDialog";
import LogEditSections from "@/components/wearlog/LogEditSections";
import SeasonalSuggestions from "@/components/wearlog/SeasonalSuggestions";
import SeasonalRecommendationsTable from "@/components/wearlog/SeasonalRecommendationsTable";
import MoodTrendChart from "@/components/wearlog/MoodTrendChart";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  LineChart as ReLineChart, Line, CartesianGrid, PieChart, Pie, Legend,
} from "recharts";
import { useCurrency } from "@/lib/useCurrency";
import { useLang } from "@/lib/LanguageContext";
import StatCard from "@/components/dashboard/StatCard";
import BrandChart from "@/components/dashboard/BrandChart";
import RatingChart from "@/components/dashboard/RatingChart";
import DonutChart from "@/components/dashboard/DonutChart";
import ListDistribution from "@/components/dashboard/ListDistribution";

const COLORS = [
  "hsl(156,80%,40%)", "hsl(36,60%,50%)", "hsl(197,60%,45%)",
  "hsl(280,55%,55%)", "hsl(340,70%,55%)", "hsl(43,74%,55%)",
];

const SEASON_MAP = { 12:"Winter",1:"Winter",2:"Winter",3:"Spring",4:"Spring",5:"Spring",6:"Summer",7:"Summer",8:"Summer",9:"Fall",10:"Fall",11:"Fall" };
const SEASON_COLORS = { Spring:"hsl(120,55%,45%)",Summer:"hsl(43,90%,55%)",Fall:"hsl(27,80%,50%)",Winter:"hsl(197,65%,50%)" };

function DashboardChartCard({ title, children }) {
  return (
    <div className="bg-card rounded-none p-3 border border-border/60 space-y-2">
      <h3 className="font-heading font-semibold text-xs">{title}</h3>
      {children}
    </div>
  );
}

function ChartCard({ title, subtitle, children }) {
  return (
    <div className="bg-card rounded-none p-3 border border-border/60 space-y-2">
      <div>
        <h3 className="font-heading font-semibold text-xs">{title}</h3>
        {subtitle && <p className="text-[9px] text-muted-foreground font-body">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

function EmptyState({ text }) {
  return <div className="py-6 text-center text-xs text-muted-foreground font-body">{text}</div>;
}

/* Person filter pill */
function PersonFilter({ value, onChange, names }) {
  return (
    <div className="flex gap-2">
      {[
        { val: "all", label: "Both", icon: <Users className="w-3 h-3" /> },
        { val: "person1", label: names.person1, icon: <User className="w-3 h-3" /> },
        { val: "person2", label: names.person2, icon: <User className="w-3 h-3" /> },
      ].map(({ val, label, icon }) => (
        <button
          key={val}
          onClick={() => onChange(val)}
          className={`flex items-center gap-1 rounded-none text-xs font-body font-medium transition-all ${
 value === val
 ? val === "person2"
 ? " text-white "
 : " text-primary-foreground "
 : " text-muted-foreground hover:text-foreground"
 }`}
        >
          {icon}{label}
        </button>
      ))}
    </div>
  );
}

/* Analytics sub-components */
function WearTrend({ logs, names }) {
  const [period, setPeriod] = useState("month");

  const data = useMemo(() => {
    let periods, format_key, format_label;
    
    if (period === "month") {
      periods = 6;
      format_key = (d) => format(d, "yyyy-MM");
      format_label = (d) => format(d, "MMM");
    } else if (period === "quarter") {
      periods = 8;
      format_key = (d) => `${d.getFullYear()}-Q${Math.ceil((d.getMonth() + 1) / 3)}`;
      format_label = (d) => {
        const q = Math.ceil((d.getMonth() + 1) / 3);
        return `Q${q} '${format(d, "yy")}`;
      };
    } else if (period === "year") {
      periods = 5;
      format_key = (d) => format(d, "yyyy");
      format_label = (d) => format(d, "yyyy");
    } else {
      // All time - show by year
      const yearCounts = {};
      logs.forEach((l) => {
        if (l.date) {
          const year = l.date.slice(0, 4);
          if (!yearCounts[year]) yearCounts[year] = { [names.person1]: 0, [names.person2]: 0 };
          if (l.person === "person2") yearCounts[year][names.person2]++;
          else yearCounts[year][names.person1]++;
        }
      });
      return Object.entries(yearCounts)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([year, counts]) => ({ month: year, ...counts }));
    }

    return Array.from({ length: periods }, (_, i) => {
      const d = new Date();
      if (period === "month") d.setMonth(d.getMonth() - (periods - 1 - i));
      else if (period === "quarter") d.setMonth(d.getMonth() - ((periods - 1 - i) * 3));
      else d.setFullYear(d.getFullYear() - (periods - 1 - i));
      
      const key = format_key(d);
      const label = format_label(d);
      
      return {
        month: label,
        [names.person1]: logs.filter((l) => format_key(new Date(l.date)) === key && (l.person === "person1" || !l.person)).length,
        [names.person2]: logs.filter((l) => format_key(new Date(l.date)) === key && l.person === "person2").length,
      };
    });
  }, [logs, names, period]);

  return (
    <ChartCard title="Above Trends: Wear Activity" subtitle={period === "month" ? "Last 6 months" : period === "quarter" ? "Last 8 quarters" : period === "year" ? "Last 5 years" : "All time"}>
      <div className="flex gap-1 overflow-x-auto pb-2">
        {["month", "quarter", "year", "all"].map((p) => (
          <button key={p} onClick={() => setPeriod(p)}
            className={`flex-shrink-0 text-[9px] font-body rounded-none transition-all ${period === p ? " text-primary-foreground font-semibold" : " text-muted-foreground "}`}>
            {p === "month" ? "Monthly" : p === "quarter" ? "Quarterly" : p === "year" ? "Yearly" : "All Time"}
          </button>
        ))}
      </div>
      <ResponsiveContainer width="100%" height={160}>
        <ReLineChart data={data} margin={{ left: -16, right: 8, top: 4, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis dataKey="month" tick={{ fontSize: 9, fontFamily: "var(--font-body)" }} />
          <YAxis tick={{ fontSize: 9, fontFamily: "var(--font-body)" }} allowDecimals={false} />
          <Tooltip contentStyle={{ fontSize: 10, fontFamily: "var(--font-body)", borderRadius: 8, border: "1px solid hsl(var(--border))" }} />
          <Line type="monotone" dataKey={names.person1} stroke="hsl(156,80%,40%)" strokeWidth={2} dot={{ r: 2.5 }} />
          <Line type="monotone" dataKey={names.person2} stroke="hsl(280,55%,55%)" strokeWidth={2} dot={{ r: 2.5 }} />
          <Legend iconType="circle" iconSize={6} formatter={(v) => <span style={{ fontSize: 9, fontFamily: "var(--font-body)" }}>{v}</span>} />
        </ReLineChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}

function MonthlyTop({ logs, names }) {
  const [period, setPeriod] = useState("month");
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [person, setPerson] = useState("all");

  const periods = useMemo(() => {
    if (period === "month") {
      return Array.from({ length: 12 }, (_, i) => format(subMonths(new Date(), 11 - i), "yyyy-MM"));
    } else if (period === "quarter") {
      const result = [];
      for (let i = 7; i >= 0; i--) {
        const d = new Date();
        d.setMonth(d.getMonth() - (i * 3));
        result.push(`${d.getFullYear()}-Q${Math.ceil((d.getMonth() + 1) / 3)}`);
      }
      return result;
    } else {
      const years = new Set();
      logs.forEach((l) => {
        if (l.date) years.add(l.date.slice(0, 4));
      });
      return Array.from(years).sort().reverse();
    }
  }, [logs, period]);

  const actualIndex = selectedIndex !== null ? selectedIndex : periods.length - 1;
  const selectedPeriod = periods[actualIndex];

  const data = useMemo(() => {
    if (!selectedPeriod) return [];
    
    const filtered = logs.filter((l) => {
      if (!l.date) return false;
      let match = false;
      if (period === "month") {
        match = l.date.startsWith(selectedPeriod);
      } else if (period === "quarter") {
        const parts = selectedPeriod.split("-Q");
        if (parts.length === 2) {
          const [year, quarter] = parts;
          const q = parseInt(quarter);
          const month = parseInt(l.date.slice(5, 7));
          const logYear = l.date.slice(0, 4);
          const logQuarter = Math.ceil(month / 3);
          match = logYear === year && logQuarter === q;
        }
      } else {
        match = l.date.startsWith(selectedPeriod);
      }
      
      const matchPerson = person === "all" || (person === "person1" ? (l.person === "person1" || !l.person) : l.person === "person2");
      return match && matchPerson;
    });
    
    const counts = {};
    filtered.forEach((l) => {
      if (!counts[l.perfume_id]) counts[l.perfume_id] = { name: l.perfume_name, count: 0 };
      counts[l.perfume_id].count++;
    });
    return Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 12);
  }, [logs, selectedPeriod, person, period]);

  return (
    <ChartCard title={`Most Worn ${period === "month" ? "This Month" : period === "quarter" ? "This Quarter" : "This Year"}`} subtitle="Top perfumes by wear count">
      <div className="space-y-2">
        <div className="flex gap-1 items-center">
          <span className="text-[9px] font-body font-semibold text-muted-foreground uppercase">
            {period === "month" ? "Month:" : period === "quarter" ? "Quarter:" : "Year:"}
          </span>
          <div className="flex gap-1 overflow-x-auto flex-1">
            {periods.map((p, idx) => (
              <button key={p} onClick={() => setSelectedIndex(idx)}
                className={`flex-shrink-0 text-[8px] font-body rounded-none transition-all ${actualIndex === idx ? " text-primary-foreground font-semibold" : " text-muted-foreground"}`}>
                {period === "month" ? format(new Date(p + "-01"), "MMM yy") : p}
              </button>
            ))}
          </div>
        </div>
        <div className="flex gap-1 overflow-x-auto">
          {["month", "quarter", "year"].map((p) => (
            <button key={p} onClick={() => { setPeriod(p); setSelectedIndex(null); }}
              className={`flex-shrink-0 text-[8px] font-body rounded-none transition-all ${period === p ? " text-primary-foreground font-semibold" : " text-muted-foreground"}`}>
              {p === "month" ? "Monthly" : p === "quarter" ? "Quarterly" : "Yearly"}
            </button>
          ))}
        </div>
      </div>
      <PersonFilter value={person} onChange={setPerson} names={names} />
      {data.length === 0 ? <EmptyState text="No logs for this selection" /> : (
        <ResponsiveContainer width="100%" height={Math.max(160, data.length * 16)}>
          <BarChart data={data} layout="vertical" margin={{ left: 0, right: 12, top: 4, bottom: 4 }}>
            <XAxis type="number" tick={{ fontSize: 8, fontFamily: "var(--font-body)" }} allowDecimals={false} />
            <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 8, fontFamily: "var(--font-body)" }} tickFormatter={(v) => v?.length > 12 ? v.slice(0, 11) + "…" : v} />
            <Tooltip formatter={(val) => [val, "wears"]} contentStyle={{ fontSize: 9, fontFamily: "var(--font-body)", borderRadius: 8, border: "1px solid hsl(var(--border))" }} />
            <Bar dataKey="count" radius={[0, 4, 4, 0]}>
              {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      )}
    </ChartCard>
  );
}

function AllTimeTop({ logs, names }) {
  const [person, setPerson] = useState("all");
  const data = useMemo(() => {
    const filtered = logs.filter((l) =>
      person === "all" || (person === "person1" ? (l.person === "person1" || !l.person) : l.person === "person2")
    );
    const counts = {};
    filtered.forEach((l) => {
      if (!counts[l.perfume_id]) counts[l.perfume_id] = { id: l.perfume_id, name: l.perfume_name, brand: l.brand_name, count: 0 };
      counts[l.perfume_id].count++;
    });
    return Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 8);
  }, [logs, person]);

  return (
    <ChartCard title="All-Time Most Worn" subtitle="Your go-to fragrances">
      <PersonFilter value={person} onChange={setPerson} names={names} />
      {data.length === 0 ? <EmptyState text="No wear history yet" /> : (
        <div className="space-y-2">
          {data.map((item, i) => (
            <div key={item.name} className="space-y-0.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-[10px] text-muted-foreground font-body w-4 text-right flex-shrink-0">{i + 1}</span>
                  <div className="min-w-0">
                    <Link to={`/perfume?id=${item.id}`} className="text-xs font-body font-medium truncate block hover:text-primary transition-colors">{item.name}</Link>
                    <p className="text-[10px] text-muted-foreground font-body truncate">{item.brand}</p>
                  </div>
                </div>
                <span className="text-xs font-body font-semibold text-primary flex-shrink-0 ml-2">{item.count}×</span>
              </div>
              <div className="ms-6 h-1.5 bg-secondary rounded-none overflow-hidden">
                <div className="h-full rounded-none bg-primary/70" style={{ width: `${(item.count / data[0].count) * 100}%` }} />
              </div>
            </div>
          ))}
        </div>
      )}
    </ChartCard>
  );
}

function SeasonalPrefs({ logs }) {
  const data = useMemo(() => {
    const counts = { Spring: 0, Summer: 0, Fall: 0, Winter: 0 };
    logs.forEach((l) => {
      if (!l.date) return;
      const m = parseInt(l.date.split("-")[1], 10);
      const s = SEASON_MAP[m];
      if (s) counts[s]++;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value })).filter((d) => d.value > 0);
  }, [logs]);

  return (
    <ChartCard title="Seasonal Preferences" subtitle="Which seasons you wear most">
      {data.length === 0 ? <EmptyState text="No wear history yet" /> : (
        <ResponsiveContainer width="100%" height={170}>
          <PieChart>
            <Pie data={data} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={3}>
              {data.map((e) => <Cell key={e.name} fill={SEASON_COLORS[e.name]} />)}
            </Pie>
            <Tooltip formatter={(val, name) => [val + " wears", name]} contentStyle={{ fontSize: 10, fontFamily: "var(--font-body)", borderRadius: 8, border: "1px solid hsl(var(--border))" }} />
            <Legend iconType="circle" iconSize={6} formatter={(v) => <span style={{ fontSize: 9, fontFamily: "var(--font-body)" }}>{v}</span>} />
          </PieChart>
        </ResponsiveContainer>
      )}
    </ChartCard>
  );
}

function TopRated({ perfumes }) {
  const top = useMemo(() =>
    [...perfumes].filter((p) => p.rating > 0).sort((a, b) => b.rating - a.rating).slice(0, 10), [perfumes]);

  return (
    <ChartCard title="Top Rated Fragrances" subtitle="Your highest-rated picks">
      {top.length === 0 ? <EmptyState text="Rate some perfumes to see them here" /> : (
        <div className="space-y-2.5">
          {top.map((p, i) => (
            <div key={p.id} className="flex items-center gap-3">
              <span className={`text-xs font-body font-bold w-5 text-center rounded-none py-0.5 ${i < 3 ? "bg-primary/10 text-primary" : "text-muted-foreground"}`}>{i + 1}</span>
              <div className="flex-1 min-w-0">
                <Link to={`/perfume?id=${p.id}`} className="text-xs font-body font-medium truncate block hover:text-primary transition-colors">{p.name}</Link>
                <p className="text-[10px] text-muted-foreground font-body truncate">{p.brand_name}</p>
              </div>
              <div className="flex gap-px">
                {[1,2,3,4,5].map((s) => <span key={s} className={`text-xs ${s <= p.rating ? "text-primary" : "text-border"}`}>{s <= p.rating ? "◆" : "◇"}</span>)}
              </div>
            </div>
          ))}
        </div>
      )}
    </ChartCard>
  );
}

/* Dashboard content sub-component */
function DashboardContent({ logs, perfumes, names }) {
  const { isAr } = useLang();
  const { formatPrice } = useCurrency();
  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    staleTime: 1000 * 60 * 5,
  });
  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });
  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const rated = perfumes.filter((p) => p.rating > 0);
  const avgRating = rated.length ? (rated.reduce((s, p) => s + p.rating, 0) / rated.length).toFixed(1) : "—";
  const topRated = [...perfumes].filter((p) => p.rating >= 4).sort((a, b) => b.rating - a.rating).slice(0, 5);
  const totalPrice = perfumes.reduce((sum, p) => sum + (p.price || 0), 0);
  const totalMl = perfumes.reduce((sum, p) => sum + (p.ml || 0), 0);
  const totalSampleMl = userPerfumes.reduce((sum, u) => sum + (u.sample_ml || 0), 0);

  const getSampleStats = (person) => {
    const items = userPerfumes.filter((u) => u.person === person);
    const volume = items.reduce((sum, u) => sum + (u.sample_ml || 0), 0);
    const cost = items.reduce((sum, u) => sum + (u.sample_cost || 0), 0);
    const avgCost = items.length > 0 ? (cost / items.length).toFixed(2) : 0;
    return { volume, cost, avgCost, count: items.length };
  };

  const p1Stats = getSampleStats("person1");
  const p2Stats = getSampleStats("person2");
  const allStats = {
    volume: totalSampleMl,
    cost: userPerfumes.reduce((sum, u) => sum + (u.sample_cost || 0), 0),
    avgCost: userPerfumes.length > 0 ? (userPerfumes.reduce((sum, u) => sum + (u.sample_cost || 0), 0) / userPerfumes.length).toFixed(2) : 0,
  };

  return (
    <div className="space-y-3">
      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2">
        <StatCard label="Total Perfumes" value={perfumes.length} sub={`${brands.length} brands`} />
        <StatCard label="Avg Rating" value={avgRating} sub={`${rated.length} rated`} />
        <StatCard label="Favorites" value={perfumes.filter((p) => p.list === "favorite").length} sub="in favorites list" />
        <StatCard label="Own" value={perfumes.filter((p) => p.list === "own").length} sub="in collection" />
        <StatCard label="Days Tracked" value={new Set(logs.map((l) => l.date)).size} sub={`${logs.length} total logs`} />
        <StatCard label="This Month" value={logs.filter((l) => l.date?.startsWith(new Date().toISOString().slice(0, 7))).length} sub="wear logs" />
        <StatCard label="Total Value" value={formatPrice(totalPrice.toFixed(0))} sub="collection worth" />
        <StatCard label="Total Sample Volume" value={`${totalSampleMl}ml`} sub="across all samples" />
        <StatCard label="Total ML" value={`${totalMl}ml`} sub="total volume" />
        <StatCard label="Total Purchases" value={purchaseRecords.length} sub="sample & bottle" />
      </div>

      {/* Sample Stats */}
      <div className="space-y-2">
        <h3 className="font-heading font-semibold text-xs px-1">{isAr ? "إحصاءات العيّنات" : "Sample Stats"}</h3>
        <div className="grid grid-cols-3 gap-2">
          <DashboardChartCard title={names.person1}>
            <div className="space-y-1.5">
              <StatCard label="Volume" value={`${p1Stats.volume}ml`} sub={`${p1Stats.count} items`} />
              <StatCard label="Cost" value={formatPrice(p1Stats.cost.toFixed(0))} sub="total" />
              <StatCard label="Avg Cost/Item" value={formatPrice(p1Stats.avgCost)} sub="per sample" />
            </div>
          </DashboardChartCard>
          <DashboardChartCard title={names.person2}>
            <div className="space-y-1.5">
              <StatCard label="Volume" value={`${p2Stats.volume}ml`} sub={`${p2Stats.count} items`} />
              <StatCard label="Cost" value={formatPrice(p2Stats.cost.toFixed(0))} sub="total" />
              <StatCard label="Avg Cost/Item" value={formatPrice(p2Stats.avgCost)} sub="per sample" />
            </div>
          </DashboardChartCard>
          <DashboardChartCard title="All">
            <div className="space-y-1.5">
              <StatCard label="Volume" value={`${allStats.volume}ml`} sub={`${userPerfumes.length} items`} />
              <StatCard label="Cost" value={formatPrice(allStats.cost.toFixed(0))} sub="total" />
              <StatCard label="Avg Cost/Item" value={formatPrice(allStats.avgCost)} sub="per sample" />
            </div>
          </DashboardChartCard>
        </div>
      </div>

      {/* Charts */}
      <DashboardChartCard title="By Brand">
        <BrandChart perfumes={perfumes} />
      </DashboardChartCard>
      <DashboardChartCard title="Rating Distribution">
        <RatingChart perfumes={perfumes} />
      </DashboardChartCard>
      <div className="grid grid-cols-2 gap-2">
        <DashboardChartCard title="By Type">
          <DonutChart perfumes={perfumes} field="type" />
        </DashboardChartCard>
        <DashboardChartCard title="By Gender">
          <DonutChart perfumes={perfumes} field="gender" />
        </DashboardChartCard>
      </div>
      <DashboardChartCard title="By Season">
        <DonutChart perfumes={perfumes} field="season" />
      </DashboardChartCard>
      <DashboardChartCard title="List Breakdown">
        <ListDistribution perfumes={perfumes} />
      </DashboardChartCard>

      {/* Top Rated */}
      {topRated.length > 0 && (
        <DashboardChartCard title="Top Rated">
          <div className="space-y-2">
            {topRated.map((p, i) => (
              <div key={p.id} className="flex items-center gap-2">
                <span className="text-[10px] text-muted-foreground font-body w-4 text-right">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <Link to={`/perfume?id=${p.id}`} className="text-xs font-body font-medium truncate block hover:text-primary transition-colors">{p.name}</Link>
                  <p className="text-[9px] text-muted-foreground font-body">{p.brand_name}</p>
                </div>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <span key={s} className={`text-[10px] ${s <= p.rating ? "text-primary" : "text-border"}`}>{s <= p.rating ? "◆" : "◇"}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </DashboardChartCard>
      )}

      {/* Recent Purchases */}
      {purchaseRecords.length > 0 && (
        <DashboardChartCard title="Recent Purchases">
          <div className="space-y-1.5">
            {purchaseRecords.slice(0, 8).map((record) => (
              <div key={record.id} className="flex items-center justify-between bg-secondary/40 rounded-none p-2">
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-[9px] font-body font-bold rounded-none text-primary">
                    {record.type === "sample" ? "Sample" : "Bottle"}
                  </span>
                  <div className="flex-1 min-w-0">
                    <Link to={`/perfume?id=${record.perfume_id}`} className="text-xs font-body font-medium truncate block hover:text-primary transition-colors">{record.perfume_name}</Link>
                    <p className="text-[9px] text-muted-foreground font-body">{record.purchase_date}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs font-body font-medium">{record.ml}ml</p>
                  <p className="text-[9px] text-muted-foreground font-body">{formatPrice(record.cost)}</p>
                </div>
              </div>
            ))}
          </div>
        </DashboardChartCard>
      )}
    </div>
  );
}

/* ── Main page ── */
export default function WearHistory() {
  const qc = useQueryClient();
  const { names } = usePersonNames();
  const { isAr } = useLang();
  const [selectedDay, setSelectedDay] = useState(null);
  const [selectedDayLogs, setSelectedDayLogs] = useState([]);
  const [pickedPerfume, setPickedPerfume] = useState(null);
  const [logPerson, setLogPerson] = useState("person1");
  const [logMood, setLogMood] = useState("");
  const [note, setNote] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editLog, setEditLog] = useState(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);

  const { data: logs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: perfumes = [] } = useAllPerfumes("name", { staleTime: 1000 * 60 * 5 });

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.create(data),
    onSuccess: (newLog) => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success((isAr ? "سُجّل" : "Logged"));
      setSelectedDayLogs((prev) => [...prev, newLog]);
      setPickedPerfume(null);
      setNote("");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.WearLog.delete(id),
    onSuccess: (_, id) => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      setSelectedDayLogs((prev) => prev.filter((l) => l.id !== id));
      toast.success((isAr ? "أُزيل" : "Removed"));
    },
  });

  const handleDayClick = (day, dayLogs) => {
    setSelectedDay(day);
    setSelectedDayLogs(dayLogs);
    setPickedPerfume(null);
    setLogMood("");
    setNote("");
    setDialogOpen(true);
  };

  const handleLog = () => {
    if (!pickedPerfume) { toast.error((isAr ? "اختر عطراً أولاً" : "Pick a perfume first")); return; }
    createMutation.mutate({
      date: format(selectedDay, "yyyy-MM-dd"),
      perfume_id: pickedPerfume.id,
      perfume_name: pickedPerfume.name,
      brand_name: pickedPerfume.brand_name,
      person: logPerson,
      mood: logMood || null,
      note,
    });
  };

  const totalDaysLogged = new Set(logs.map((l) => l.date)).size;
  const p1Count = logs.filter((l) => l.person === "person1" || !l.person).length;
  const p2Count = logs.filter((l) => l.person === "person2").length;
  const notesCount = logs.filter((l) => l.note && l.note.trim()).length;

  return (
    <div className={`px-4 page-top pb-4 space-y-4 overflow-x-hidden ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <h1 className="font-heading text-xl font-bold">{isAr ? 'تقدم' : 'Progress'}</h1>
          <p className="text-[10px] text-muted-foreground font-body mt-0.5 truncate">
            {totalDaysLogged} days — <span className="text-primary">{names.person1}: {p1Count}</span> — <span className="text-violet-500">{names.person2}: {p2Count}</span>
          </p>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <WearReport logs={logs} names={names} />
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      <Tabs defaultValue="dashboard">
        <TabsList className="w-full bg-secondary/50 p-0.5 rounded-none grid grid-cols-5 gap-0.5">
          <TabsTrigger value="calendar" className="rounded-none text-[9px] font-body gap-0.5 flex-col h-9 data-[state=active]:bg-card data-[state=active]:shadow-sm">
            <CalendarDays className="w-3 h-3" /><span>{isAr ? 'تقويم' : 'Calendar'}</span>
          </TabsTrigger>
          <TabsTrigger value="stats" className="rounded-none text-[9px] font-body gap-0.5 flex-col h-9 data-[state=active]:bg-card data-[state=active]:shadow-sm">
            <BarChart2 className="w-3 h-3" /><span>{isAr ? 'تكرار' : 'Frequency'}</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="rounded-none text-[9px] font-body gap-0.5 flex-col h-9 data-[state=active]:bg-card data-[state=active]:shadow-sm">
            <LineChart className="w-3 h-3" /><span>{isAr ? 'الاتجاهات العليا' : 'Above Trends'}</span>
          </TabsTrigger>
          <TabsTrigger value="notes" className="rounded-none text-[9px] font-body gap-0.5 flex-col h-9 data-[state=active]:bg-card data-[state=active]:shadow-sm">
            <StickyNote className="w-3 h-3" /><span>{isAr ? 'ملاحظات' : 'Review'}</span>
          </TabsTrigger>
          <TabsTrigger value="dashboard" className="rounded-none text-[9px] font-body gap-0.5 flex-col h-9 data-[state=active]:bg-card data-[state=active]:shadow-sm">
            <LayoutDashboard className="w-3 h-3" /><span>{isAr ? 'لوحة التحكم' : 'Dashboard'}</span>
          </TabsTrigger>
        </TabsList>

        {/* Calendar tab */}
        <TabsContent value="calendar" className="mt-3 space-y-2">
          <div className="bg-card rounded-none p-3 border border-border/60">
            <WearCalendar logs={logs} onDayClick={handleDayClick} />
          </div>
          <p className="text-[9px] text-muted-foreground font-body text-center">{isAr ? "اضغط أي يوم لتسجّل أو ترى ما ارتديت" : "Tap any day to log or view what you wore"}</p>
        </TabsContent>

        {/* Frequency tab */}
        <TabsContent value="stats" className="mt-3 space-y-3">
          <LogEditSections logs={logs} />
          
          {/* Person 1 section */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 px-1">
              <div className="w-2 h-2 rounded-none bg-primary" />
              <p className="text-xs font-body font-semibold text-primary">{names.person1}</p>
              <span className="text-[9px] text-muted-foreground font-body">{logs.filter((l) => l.person === "person1" || !l.person).length} logs</span>
            </div>
            <div className="bg-card rounded-none p-3 border border-border/60 space-y-2">
              <WearStats logs={logs.filter((l) => l.person === "person1" || !l.person)} perfumes={perfumes} />
            </div>
            {logs.filter((l) => l.person === "person1" || !l.person).length > 0 && (
              <div className="bg-card rounded-none p-3 border border-border/60 space-y-1.5">
                <p className="text-[10px] font-body font-medium text-muted-foreground">الأخيرة Recent</p>
                <div className="space-y-1.5">
                  {logs.filter((l) => l.person === "person1" || !l.person).slice(0, 5).map((l) => {
                    const moodEmojis = { amazing: "😍", happy: "😊", calm: "😌", confident: "😎", romantic: "💕", sexy: "🔥", sad: "😔", energetic: "⚡", thoughtful: "🤔", relaxing: "😴", unknown: "🤷", neutral: "😑" };
                    return (
                    <div key={l.id} className="flex items-center gap-2 group">
                      <div className="w-5 h-5 rounded-none bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <span className="text-[8px] font-body font-bold text-primary">{names.person1.slice(0, 1)}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <Link to={`/perfume?id=${l.perfume_id}`} className="text-xs font-body font-semibold truncate block hover:text-primary transition-colors">{l.perfume_name}</Link>
                        <p className="text-[9px] text-muted-foreground font-body">{l.brand_name} — {l.date}</p>
                      </div>
                      {l.mood && <span className="text-sm">{moodEmojis[l.mood]}</span>}
                      <button onClick={() => { setEditLog(l); setEditDialogOpen(true); }} className="text-muted-foreground hover:text-primary transition-colors opacity-0 group-hover:opacity-100">
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button onClick={() => deleteMutation.mutate(l.id)} className="text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-border" />
            <span className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">vs</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          {/* Person 2 section */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 px-1">
              <div className="w-2 h-2 rounded-none bg-violet-500" />
              <p className="text-xs font-body font-semibold text-violet-500">{names.person2}</p>
              <span className="text-[9px] text-muted-foreground font-body">{logs.filter((l) => l.person === "person2").length} logs</span>
            </div>
            <div className="bg-card rounded-none p-3 border border-border/60 space-y-2">
              <WearStats logs={logs.filter((l) => l.person === "person2")} perfumes={perfumes} />
            </div>
            {logs.filter((l) => l.person === "person2").length > 0 && (
              <div className="bg-card rounded-none p-3 border border-border/60 space-y-1.5">
                <p className="text-[10px] font-body font-medium text-muted-foreground">الأخيرة Recent</p>
                <div className="space-y-1.5">
                  {logs.filter((l) => l.person === "person2").slice(0, 5).map((l) => {
                    const moodEmojis = { amazing: "😍", happy: "😊", calm: "😌", confident: "😎", romantic: "💕", sexy: "🔥", sad: "😔", energetic: "⚡", thoughtful: "🤔", relaxing: "😴", unknown: "🤷", neutral: "😑" };
                    return (
                    <div key={l.id} className="flex items-center gap-2 group">
                      <div className="w-5 h-5 rounded-none bg-violet-100 flex items-center justify-center flex-shrink-0">
                        <span className="text-[8px] font-body font-bold text-violet-600">{names.person2.slice(0, 1)}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <Link to={`/perfume?id=${l.perfume_id}`} className="text-xs font-body font-semibold truncate block hover:text-primary transition-colors">{l.perfume_name}</Link>
                        <p className="text-[9px] text-muted-foreground font-body">{l.brand_name} — {l.date}</p>
                      </div>
                      {l.mood && <span className="text-sm">{moodEmojis[l.mood]}</span>}
                      <button onClick={() => { setEditLog(l); setEditDialogOpen(true); }} className="text-muted-foreground hover:text-primary transition-colors opacity-0 group-hover:opacity-100">
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button onClick={() => deleteMutation.mutate(l.id)} className="text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100">
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Analytics tab */}
        <TabsContent value="analytics" className="mt-3 space-y-3">
          <WearTrend logs={logs} names={names} />
          <MonthlyTop logs={logs} names={names} />
          <AllTimeTop logs={logs} names={names} />
          <SeasonalPrefs logs={logs} />
          <SeasonalRecommendationsTable perfumes={perfumes} logs={logs} />
          <MoodTrendChart logs={logs} perfumes={perfumes} />
          <TopRated perfumes={perfumes} />
        </TabsContent>

        {/* Notes tab */}
        <TabsContent value="notes" className="mt-3">
          <WearNotes logs={logs} names={names} />
        </TabsContent>

        {/* Dashboard tab */}
        <TabsContent value="dashboard" className="mt-3 space-y-3">
          <SeasonalSuggestions perfumes={perfumes} logs={logs} />
          <Tabs defaultValue="all">
            <TabsList className="w-full bg-secondary/50 p-0.5 rounded-none grid grid-cols-3 gap-0.5">
              <TabsTrigger value="all" className="rounded-none text-[10px] font-body data-[state=active]:bg-card data-[state=active]:shadow-sm">
                <Users className="w-3 h-3 mr-1" /> All
              </TabsTrigger>
              <TabsTrigger value="person1" className="rounded-none text-[10px] font-body data-[state=active]:bg-card data-[state=active]:shadow-sm">
                <User className="w-3 h-3 mr-1" /> {names.person1}
              </TabsTrigger>
              <TabsTrigger value="person2" className="rounded-none text-[10px] font-body data-[state=active]:bg-card data-[state=active]:shadow-sm">
                <User className="w-3 h-3 mr-1" /> {names.person2}
              </TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-2 space-y-3">
              <DashboardContent logs={logs} perfumes={perfumes} names={names} personFilter="all" />
            </TabsContent>
            <TabsContent value="person1" className="mt-2 space-y-3">
              <DashboardContent logs={logs.filter((l) => l.person === "person1" || !l.person)} perfumes={perfumes} names={names} personFilter="person1" />
            </TabsContent>
            <TabsContent value="person2" className="mt-2 space-y-3">
              <DashboardContent logs={logs.filter((l) => l.person === "person2")} perfumes={perfumes} names={names} personFilter="person2" />
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>

      {/* Day dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {selectedDay ? format(selectedDay, "EEEE, MMMM d") : ""}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Existing logs */}
            {selectedDayLogs.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "ارتُدي اليوم" : "Wore today"}</p>
                {selectedDayLogs.map((l) => {
                   const moodEmojis = { amazing: "😍", happy: "😊", calm: "😌", confident: "😎", romantic: "💕", sexy: "🔥", sad: "😔", energetic: "⚡", thoughtful: "🤔", relaxing: "😴", unknown: "🤷", neutral: "😑" };
                   return (
                   <div key={l.id} className="flex items-center gap-2 bg-secondary/50 rounded-none px-3 py-2">
                     <span className={`text-[10px] font-body font-bold rounded-none ${l.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                       {l.person === "person2" ? names.person2 : names.person1}
                     </span>
                     <div className="flex-1 min-w-0">
                       <Link to={`/perfume?id=${l.perfume_id}`} className="text-xs font-body font-medium truncate block hover:text-primary transition-colors">{l.perfume_name}</Link>
                       <p className="text-[9px] text-muted-foreground font-body truncate">{l.brand_name}</p>
                     </div>
                     {l.mood && <span className="text-base">{moodEmojis[l.mood]}</span>}
                     {l.id && (
                       <button onClick={() => deleteMutation.mutate(l.id)} className="text-muted-foreground hover:text-destructive">
                         <Trash2 className="w-3.5 h-3.5" />
                       </button>
                     )}
                   </div>
                 );
                 })}
              </div>
            )}

            {/* Add log */}
            <div className="space-y-3">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "سجّل عطراً" : "Log a perfume"}</p>

              {/* Person selector */}
              <div className="flex gap-2">
                <button
                  onClick={() => setLogPerson("person1")}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person1" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
                >
                  <User className="w-3.5 h-3.5" /> {names.person1}
                </button>
                <button
                  onClick={() => setLogPerson("person2")}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person2" ? "bg-violet-500 text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
                >
                  <User className="w-3.5 h-3.5" /> {names.person2}
                </button>
              </div>

              <PerfumePicker perfumes={perfumes} selected={pickedPerfume} onSelect={setPickedPerfume} />
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "المزاج" : "Mood"}</p>
                <div className="grid grid-cols-5 gap-1.5">
                  {[
                    { value: "amazing", emoji: "😍", label: "Amazing" },
                    { value: "happy", emoji: "😊", label: "Happy" },
                    { value: "calm", emoji: "😌", label: "Calm" },
                    { value: "confident", emoji: "😎", label: "Confident" },
                    { value: "romantic", emoji: "💕", label: "Romantic" },
                    { value: "sexy", emoji: "🔥", label: "Sexy" },
                    { value: "sad", emoji: "😔", label: "Sad" },
                    { value: "energetic", emoji: "⚡", label: "Energetic" },
                    { value: "thoughtful", emoji: "🤔", label: "Thoughtful" },
                    { value: "relaxing", emoji: "😴", label: "Relaxing" },
                    { value: "unknown", emoji: "🤷", label: "I don't Know" },
                    { value: "neutral", emoji: "😑", label: "I don't Care" },
                  ].map(({ value, emoji, label }) => (
                    <button
                      key={value}
                      onClick={() => setLogMood(logMood === value ? "" : value)}
                      className={`flex flex-col items-center gap-0.5 py-1.5 rounded-none border text-[9px] font-body font-medium transition-all ${logMood === value ? "bg-primary/10 border-primary shadow-sm" : "bg-secondary/40 border-border/50 hover:border-primary/30"}`}
                    >
                      <span className="text-base">{emoji}</span>
                      <span className="text-[8px]">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={isAr ? "ملاحظة اختياري" : "Optional note.."}
                className="rounded-none font-body text-xs min-h-[48px] resize-none"
              />
              <Button
                className="w-full h-10 rounded-none font-body text-sm"
                onClick={handleLog}
                disabled={createMutation.isPending || !pickedPerfume}
              >
                {createMutation.isPending ? "Saving.." : `Log for ${logPerson === "person2" ? names.person2 : names.person1}`}
              </Button>
            </div>
          </div>
        </DialogContent>
        </Dialog>

        {/* Edit log dialog */}
        {editLog && (
        <EditLogDialog
          log={editLog}
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          perfumes={perfumes}
          names={names}
        />
        )}
        </div>
        );
        }
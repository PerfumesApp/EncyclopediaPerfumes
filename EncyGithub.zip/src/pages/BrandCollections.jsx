import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import BackIcon from "@/components/shared/BackIcon";

// صفحة مستقلّة لكل مجموعات الماركة — تحميل كسول (دفعات)، بلا عدّ عطور.
export default function BrandCollections() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id") || "";
  const brandName = params.get("brand") || "";

  const { data: brand } = useQuery({
    queryKey: ["brand", id],
    queryFn: () => apphost.entities.Brand.get(id),
    enabled: !!id,
    staleTime: 1000 * 60,
  });

  const bname = brand?.name || brandName;

  const { data: perfumes = [], isLoading: pLoading, isFetching: pFetching } = useQuery({
    queryKey: ["perfumes-by-brand-collections", bname],
    queryFn: () => apphost.entities.Perfume.filter({ brand_name: bname }, "", 5000),
    enabled: !!bname,
    staleTime: 1000 * 60,
  });

  const { data: manual = [], isLoading: mLoading, isFetching: mFetching } = useQuery({
    queryKey: ["collections-by-brand", id],
    queryFn: () => apphost.entities.PerfumeCollection.filter({ brand_id: id }),
    enabled: !!id,
    staleTime: 1000 * 60,
  });

  // ما زال يُحمّل ما دامت الاستعلامات لم تستقرّ — حتى لا يظهر «لا مجموعات» قبل اكتمال الجلب
  const loading = !!id && (!bname || pLoading || pFetching || mLoading || mFetching);

  const collections = useMemo(() => {
    const manualNames = new Set((manual || []).map((c) => (c.name || "").trim().toLowerCase()).filter(Boolean));
    const autoNames = new Set();
    (perfumes || []).forEach((p) => {
      const c = (p.collection || "").trim();
      if (c && !manualNames.has(c.toLowerCase())) autoNames.add(c);
    });
    const auto = [...autoNames].sort((a, b) => a.localeCompare(b)).map((name) => ({ id: "auto:" + name, name, name_ar: "", auto: true }));
    return [...(manual || []), ...auto];
  }, [manual, perfumes]);

  const [shown, setShown] = useState(24);
  const list = collections.slice(0, shown);

  const open = (col) => navigate(`/brand-collection?id=${encodeURIComponent(col.id)}&brand=${encodeURIComponent(bname || "")}`);

  return (
    <div className="px-5 page-top pb-24 space-y-4">
      <div className="flex items-center gap-2">
        <button type="button" onClick={() => { if (window.history.length > 1) navigate(-1); else navigate(`/brand?id=${encodeURIComponent(id)}`); }}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity" aria-label={isAr ? "رجوع" : "Back"}>
          <BackIcon className={`w-5 h-5`} style={{ color: "var(--brand)" }} />
        </button>
        <h1 className="font-heading text-xl font-bold" style={{ color: "var(--brand)" }}>
          {isAr ? `مجموعات ${bname || "الماركة"}` : `${bname || "Brand"} collections`}
        </h1>
      </div>

      {loading ? (
        <div className="flex items-center justify-center gap-2 py-12">
          <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          <span className="text-sm text-muted-foreground font-body">{isAr ? "جاري التحميل" : "Loading"}</span>
        </div>
      ) : collections.length === 0 ? (
        <p className="text-sm text-muted-foreground font-body py-10 text-center">{isAr ? "لا مجموعات لهذه الماركة" : "No collections for this brand"}</p>
      ) : (
        <div className="space-y-2">
          {list.map((col) => (
            <button key={col.id} type="button" onClick={() => open(col)}
              className="w-full text-start bg-card/30 rounded-none p-3 border border-primary/20 hover:bg-card/50 transition-colors">
              <p className="text-sm font-body font-semibold">{isAr ? (col.name_ar || col.name) : col.name}</p>
              {isAr && col.name_ar && col.name && <p className="text-[10px] text-muted-foreground font-body">{col.name}</p>}
              {col.description && <p className="text-[10px] text-muted-foreground font-body mt-0.5">{col.description}</p>}
            </button>
          ))}
          {shown < collections.length && (
            <button type="button" onClick={() => setShown((n) => n + 24)}
              className="w-full text-center font-body text-xs font-semibold hover:opacity-70 transition-opacity pt-1" style={{ color: "var(--brand)" }}>
              {isAr ? "تحميل المزيد" : "Load more"}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

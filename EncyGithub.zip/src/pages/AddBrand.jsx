import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { compressImage } from "@/utils/imageCompressor";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Upload, X } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { BRAND_CATEGORIES, DEFAULT_BRAND_CATEGORY, brandCategoryKey } from "@/lib/brandCategories";
import BackIcon from "@/components/shared/BackIcon";

/**
 * AddBrand — صفحة موحّدة لإضافة البراند و تعديله (مصدر حقيقة واحد).
 * - /add-brand          → إضافة براند جديد.
 * - /add-brand?id=X     → تعديل البراند X بكل حقول الإضافة نفسها.
 * تعكس حقول حوار التعديل القديم في BrandDetail + نموذج الإضافة القديم في Brands
 * (الاتحاد الكامل)، مع ترحيل الحقول القديمة (innovation_notes / description_ar / bio).
 */

const EMPTY = {
  name: "", name_ar: "", country: "", year_established: "",
  owned_by: "", parent_company: "", website: "", in_business: true,
  description: "", logo_url: "",
  brand_category: DEFAULT_BRAND_CATEGORY,
  signature_notes_names: "", signature_notes_ids: "", innovation_notes: "",
};

export default function AddBrand() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const editId = searchParams.get("id");
  const isEdit = !!editId;
  const { isAr } = useLang();
  const queryClient = useQueryClient();

  const [form, setForm] = useState({ ...EMPTY });
  const [uploading, setUploading] = useState(false);
  const [showParentSuggestions, setShowParentSuggestions] = useState(false);
  const [loadedId, setLoadedId] = useState(null);

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });
  const { data: allNotes = [] } = useQuery({
    queryKey: ["perfume-notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  // تحميل براند التعديل + ترحيل الحقول القديمة (نفس منطق openEdit السابق في BrandDetail)
  useEffect(() => {
    if (!editId || loadedId === editId) return;
    let cancelled = false;
    (async () => {
      try {
        const rows = await apphost.entities.PerfumeBrand.filter({ id: editId });
        const brand = Array.isArray(rows) ? rows[0] : rows;
        if (!brand) { toast.error(isAr ? "البراند غير موجود" : "Brand not found"); return; }
        if (cancelled) return;

        // innovation_notes القديمة تُدمج في signature_notes_names
        let signatureNames = brand.signature_notes_names || "";
        if (brand.innovation_notes && brand.innovation_notes.trim()) {
          const existing = signatureNames.split(",").map((s) => s.trim()).filter(Boolean);
          const innovations = brand.innovation_notes.split(",").map((s) => s.trim()).filter(Boolean);
          const merged = [...existing];
          for (const n of innovations) if (!merged.includes(n)) merged.push(n);
          signatureNames = merged.join(",");
        }

        // description_ar + bio القديمتان تُدمجان في description الموحّد (بلا تكرار)
        const parts = [brand.description?.trim(), brand.description_ar?.trim(), brand.bio?.trim()].filter(Boolean);
        const seen = new Set();
        const uniqueParts = parts.filter((p) => {
          const key = p.toLowerCase().replace(/\s+/g, " ");
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });
        const mergedDescription = uniqueParts.join("\n\n");

        setForm({
          ...EMPTY,
          ...brand,
          signature_notes_names: signatureNames,
          innovation_notes: "",
          description: mergedDescription,
          description_ar: "",
          bio: "",
          brand_category: brandCategoryKey(brand),
        });
        setLoadedId(editId);
      } catch {
        toast.error(isAr ? "تعذّر تحميل البراند" : "Failed to load brand");
      }
    })();
    return () => { cancelled = true; };
  }, [editId, loadedId, isAr]);

  const handleUploadLogo = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      //  شعار البراند من المستخدم يضغط لحد أقصى 250KB
      const compressed = await compressImage(file, { maxWidth: 800, maxHeight: 800, quality: 0.85, maxKB: 250 });
      const result = await apphost.integrations.Core.UploadFile({ file: compressed });
      setForm((prev) => ({ ...prev, logo_url: result.file_url }));
      toast.success(isAr ? "رُفع الشعار" : "Logo uploaded");
    } catch {
      toast.error(isAr ? "فشل الرفع" : "Upload failed");
    }
    setUploading(false);
  };

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeBrand.create({ ...data, is_user: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      toast.success(isAr ? "أُضيف البراند" : "Brand added");
      navigate(-1);
    },
    onError: () => toast.error(isAr ? "فشل الحفظ" : "Save failed"),
  });

  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeBrand.update(editId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["brand", editId] });
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      toast.success(isAr ? "حُدّث البراند" : "Brand updated");
      navigate(-1);
    },
    onError: () => toast.error(isAr ? "فشل الحفظ" : "Save failed"),
  });

  const handleCastAway = async () => {
    try {
      await apphost.entities.PerfumeBrand.update(editId, { hidden: true });
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      toast.success(isAr ? "نُقل إلى المهملات" : "Moved to Cast Away");
      navigate("/brands");
    } catch {
      toast.error(isAr ? "تعذّر النقل" : "Failed");
    }
  };

  const handleDelete = async () => {
    if (!window.confirm(isAr ? "حذف هذا البراند نهائياً؟ لا يمكن التراجع." : "Delete this brand permanently? This cannot be undone.")) return;
    try {
      await apphost.entities.PerfumeBrand.delete(editId);
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      toast.success(isAr ? "تم الحذف" : "Deleted");
      navigate("/brands");
    } catch {
      toast.error(isAr ? "فشل الحذف" : "Delete failed");
    }
  };

  const saving = createMutation.isPending || updateMutation.isPending;
  const canSave = (form.name || "").trim().length > 0;

  return (
    <div className="px-5 page-top pb-10 space-y-5">
      <div className="flex items-center gap-3 mb-2">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
          <BackIcon className="w-5 h-5" />
        </button>
        <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">
          {isEdit ? (isAr ? "تعديل البراند" : "Edit Brand") : (isAr ? "إضافة براند" : "Add Brand")}
        </h1>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!canSave || saving || uploading) return;
          if (isEdit) updateMutation.mutate({ ...form });
          else createMutation.mutate({ ...form });
        }}
        className="space-y-4"
      >
        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "اسم البراند" : "Brand Name"}</Label>
          <Input value={form.name || ""} onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))} placeholder="e.g. Chanel" className="rounded-none h-11 font-body" />
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "الاسم العربي" : "Arabic Name"}</Label>
          <Input value={form.name_ar || ""} onChange={(e) => setForm((prev) => ({ ...prev, name_ar: e.target.value }))} placeholder={isAr ? "الاسم بالعربية" : "Arabic name"} className="rounded-none h-11 font-body" dir="rtl" />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "البلد" : "Country"}</Label>
            <Input value={form.country || ""} onChange={(e) => setForm((prev) => ({ ...prev, country: e.target.value }))} placeholder="e.g. France" className="rounded-none h-11 font-body" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "سنة التأسيس" : "Year Est."}</Label>
            <Input type="number" value={form.year_established || ""} onChange={(e) => setForm((prev) => ({ ...prev, year_established: Number(e.target.value) || undefined }))} className="rounded-none h-11 font-body" />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "الشركة الأم / القابضة" : "Parent Company / Holding"}</Label>
          <div className="relative">
            <Input
              value={form.owned_by || ""}
              onChange={(e) => { setForm((prev) => ({ ...prev, owned_by: e.target.value, parent_company: e.target.value })); setShowParentSuggestions(true); }}
              onFocus={() => setShowParentSuggestions(true)}
              onBlur={() => setTimeout(() => setShowParentSuggestions(false), 150)}
              placeholder={isAr ? "ابحث في البراندات أو اكتب اسماً (مثل LVMH)" : "Search brands or type a name (e.g. LVMH)"}
              className="rounded-none h-11 font-body"
              autoComplete="off"
            />
            {showParentSuggestions && (form.owned_by || "").trim() && (() => {
              const q = (form.owned_by || "").trim().toLowerCase();
              const pool = new Set();
              for (const b of brands) {
                if (isEdit && String(b.id) === String(editId)) continue;
                if (b.parent_company?.trim()) pool.add(b.parent_company.trim());
                if (b.name?.trim()) pool.add(b.name.trim());
              }
              const matches = [...pool]
                .filter((s) => s.toLowerCase().includes(q) && s.toLowerCase() !== q)
                .sort((a, b) => {
                  const ai = a.toLowerCase().startsWith(q) ? 0 : 1;
                  const bi = b.toLowerCase().startsWith(q) ? 0 : 1;
                  return ai - bi || a.localeCompare(b);
                })
                .slice(0, 8);
              if (matches.length === 0) return null;
              return (
                <div className="absolute z-50 left-0 right-0 mt-1 bg-popover border border-border rounded-none shadow-lg max-h-52 overflow-y-auto">
                  {matches.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onMouseDown={(e) => { e.preventDefault(); setForm((prev) => ({ ...prev, owned_by: s, parent_company: s })); setShowParentSuggestions(false); }}
                      className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              );
            })()}
          </div>
          <p className="text-[10px] text-muted-foreground font-body">{isAr ? "ابحث واختر من البراندات الموجودة، أو اكتب اسماً جديداً" : "Search & pick an existing brand, or type a new name"}</p>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "الموقع" : "Website"}</Label>
          <Input value={form.website || ""} onChange={(e) => setForm((prev) => ({ ...prev, website: e.target.value }))} placeholder="https://.." className="rounded-none h-11 font-body" />
        </div>

        <div className="flex items-center gap-3 px-1 py-2">
          <Label className="text-sm font-body flex-1">{isAr ? "ما زال يعمل" : "Currently In Business?"}</Label>
          <button
            type="button"
            onClick={() => setForm((prev) => ({ ...prev, in_business: !prev.in_business }))}
            className="w-10 h-6 rounded-none transition-colors"
            style={{ background: form.in_business !== false ? "var(--brand)" : "#e7dfc9" }}
          >
            <div className={`w-4 h-4 bg-white rounded-none shadow transition-transform mx-1 ${form.in_business !== false ? "translate-x-4" : "translate-x-0"}`} />
          </button>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "فئة البراند" : "Brand Category"}</Label>
          <div className="flex flex-wrap gap-2">
            {BRAND_CATEGORIES.map((c) => {
              const active = brandCategoryKey(form) === c.key;
              return (
                <button key={c.key} type="button" onClick={() => setForm((prev) => ({ ...prev, brand_category: c.key }))}
                  className="px-3 py-1.5 text-xs font-body rounded-none border transition-colors"
                  style={active ? { borderColor: "var(--brand)", background: "var(--brand)", color: "#fff" } : { borderColor: "#e7dfc9", color: "var(--mut,#6B6760)" }}>
                  {isAr ? c.ar : c.en}
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "حول البراند" : "About"}</Label>
          <Textarea value={form.description || ""} onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))} placeholder={isAr ? "الوصف والتاريخ" : "Description & history"} className="rounded-none font-body min-h-[100px]" />
        </div>

        {/* نوتات التوقيع — حقل حرّ يُعبّأ يدوياً (تختلف عن «الخلاصة» التلقائيّة) */}
        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "نوتات التوقيع" : "Signature Notes"}</Label>
          <Textarea
            value={form.signature_notes_names || ""}
            onChange={(e) => setForm((prev) => ({ ...prev, signature_notes_names: e.target.value }))}
            placeholder={isAr ? "Rose ورد, Oud عود, Amber عنبر" : "Rose ورد, Oud عود, Amber عنبر"}
            className="rounded-none font-body min-h-[80px]" dir="ltr" />
          <p className="text-[11px] text-muted-foreground font-body" dir={isAr ? "rtl" : "ltr"}>
            {isAr
              ? "نوتات التوقيع تُعبّأ يدوياً (افصل بفاصلة، صيغة: Rose ورد). تختلف عن نوتات الخلاصة التي تُستخلص من عطور الماركة."
              : "Signature notes are filled in manually (comma-separated, format: Rose ورد). Different from Essence notes, which are extracted from the brand's perfumes."}
          </p>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs font-body">{isAr ? "الشعار أو الصورة" : "Logo / Photo"}</Label>
          {form.logo_url ? (
            <div className="relative w-full h-24 rounded-none border border-border bg-secondary/50 flex items-center justify-center overflow-hidden">
              <img src={form.logo_url} alt="Logo" className="w-full h-full object-cover" />
              <button type="button" onClick={() => setForm((prev) => ({ ...prev, logo_url: "" }))} className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-none flex items-center justify-center hover:bg-red-600">
                <X className="w-3.5 h-3.5 text-white" />
              </button>
            </div>
          ) : (
            <label className="flex items-center justify-center gap-2 w-full h-24 rounded-none border-2 border-dashed border-border bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
              <Upload className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs font-body text-muted-foreground">{isAr ? "اضغط للرفع" : "Click to upload"}</span>
              <input type="file" onChange={handleUploadLogo} disabled={uploading} accept="image/*" className="hidden" />
            </label>
          )}
        </div>

        <div className="flex gap-2 pt-1">
          <Button type="button" variant="outline" onClick={() => navigate(-1)} className="flex-1 rounded-none h-11 font-body">
            {isAr ? "إلغاء" : "Cancel"}
          </Button>
          <Button type="submit" className="flex-1 rounded-none h-11 font-body bg-[var(--brand)] hover:bg-[#b08f29] text-white" disabled={!canSave || saving || uploading}>
            {saving
              ? (isAr ? "جارٍ الحفظ.." : "Saving..")
              : isEdit
                ? (isAr ? "حفظ التعديلات" : "Save Changes")
                : (isAr ? "إضافة البراند" : "Add Brand")}
          </Button>
        </div>

        {isEdit && (
          <div className="pt-2 space-y-1 border-t border-border/40">
            <Button type="button" variant="ghost" className="w-full rounded-none font-body" style={{ color: "#9a7b1f" }} onClick={handleCastAway}>
              {isAr ? "نقل إلى المهملات" : "Cast away"}
            </Button>
            <Button type="button" variant="ghost" className="w-full rounded-none font-body text-destructive hover:text-destructive" onClick={handleDelete}>
              {isAr ? "حذف البراند نهائياً" : "Delete permanently"}
            </Button>
          </div>
        )}
      </form>
    </div>
  );
}

import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import BackIcon from "@/components/shared/BackIcon";

const SINUS_LEVELS = [
  { value: "yes",       emoji: "😤", labelEn: "Yes",        labelAr: "نعم" },
  { value: "a_little",  emoji: "😕", labelEn: "A Little",   labelAr: "قليلاً" },
  { value: "no",        emoji: "😊", labelEn: "No",         labelAr: "لا" },
  { value: "dont_know", emoji: "😏", labelEn: "Don't know", labelAr: "لا أعلم" },
];

export default function SinusSensitivity() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { names } = usePersonNames();

  const { data: userPerfumes = [], isLoading } = useQuery({
    queryKey: ["user-perfumes-sinus"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  // Only entries with a sinus rating
  const rated = userPerfumes.filter(u => u.sinus_sensitivity);

  // Group by level
  const byLevel = SINUS_LEVELS.reduce((acc, l) => {
    acc[l.value] = rated.filter(u => u.sinus_sensitivity === l.value);
    return acc;
  }, {});

  const levelColors = {
    yes:      "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900",
    a_little: "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900",
    no:       "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900",
    dont_know: "bg-slate-50 dark:bg-slate-950/20 border-slate-200 dark:border-slate-800",
  };

  return (
    <div className="px-5 page-top pb-24 space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-secondary transition-colors">
          <BackIcon className={`w-5 h-5`} />
        </button>
        <div>
          <h1 className="font-heading text-xl font-bold">حساسية جيوب أنفية Sinus Sensitivity</h1>
          <p className="text-xs text-muted-foreground font-body">{rated.length} perfume{rated.length !== 1 ? "s" : ""} rated</p>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : rated.length === 0 ? (
        <div className="text-center py-16 space-y-2">
          <p className="text-4xl">👃</p>
          <p className="text-sm font-body text-muted-foreground">{isAr ? "لا تقييمات حساسية بعد" : "No sinus sensitivity ratings yet."}</p>
          <p className="text-xs font-body text-muted-foreground">{isAr ? "قيّم العطور في صفحة العطر" : "Rate perfumes in the perfume detail page."}</p>
        </div>
      ) : (
        <div className="space-y-6">
          {SINUS_LEVELS.filter(l => byLevel[l.value]?.length > 0).map(level => (
            <div key={level.value} className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-xl">{level.emoji}</span>
                <h2 className="font-heading font-semibold text-base">{level.labelAr} — {level.labelEn}</h2>
                <span className="text-xs text-muted-foreground font-body rounded-none">{byLevel[level.value].length}</span>
              </div>
              <div className="space-y-2">
                {byLevel[level.value].map(up => (
                  <button
                    key={up.id}
                    onClick={() => navigate(`/perfume?id=${up.perfume_id}`)}
                    className={`w-full flex items-center justify-between rounded-none p-4 shadow-sm border transition-all text-left ${levelColors[level.value]} hover:opacity-80`}
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-body font-semibold truncate">{up.perfume_name}</p>
                      <p className="text-xs text-muted-foreground font-body truncate">{up.brand_name}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-[10px] font-bold rounded-none ${up.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                        {up.person === "person2" ? names.person2 : names.person1}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
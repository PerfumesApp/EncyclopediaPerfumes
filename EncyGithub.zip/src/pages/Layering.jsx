import { useState, useMemo, useEffect } from "react";
import BackButton from "@/components/shared/BackButton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Layers, X } from "lucide-react";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import { useLang } from "@/lib/LanguageContext";
import PerfumePicker from "@/components/wearlog/PerfumePicker";
import LayerCard from "@/components/layering/LayerCard";
import { exportElementAsImage } from "@/lib/collectionExport";
import { perfumeFacets, buildBlendReport } from "@/lib/blendReport";
import { StrengthBar } from "@/components/perfume/StrengthIndicator";

export default function Layering() {
   const qc = useQueryClient();
   const { names, profiles } = usePersonNames();
   const { isAr } = useLang();
   const c1 = profiles?.person1?.color || "var(--brand)";
   const c2 = profiles?.person2?.color || "#8b5cf6";
   const personColor = (p) => (p === "person2" ? c2 : p === "both" ? "var(--brand)" : c1);
   const [dialogOpen, setDialogOpen] = useState(false);
  const [logDialogOpen, setLogDialogOpen] = useState(false);
  const [logTarget, setLogTarget] = useState(null);
  const [logDate, setLogDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [logPerson, setLogPerson] = useState("person1");
  const [logNote, setLogNote] = useState("");

  // Multi-perfume form state (up to 5)
  const [selectedPerfumes, setSelectedPerfumes] = useState([null, null]);
  const [comboName, setComboName] = useState("");
  const [comboNotes, setComboNotes] = useState("");
  const [comboRating, setComboRating] = useState(0);
  const [comboPerson, setComboPerson] = useState("person1");
  const [editId, setEditId] = useState(null);
  const [exportTarget, setExportTarget] = useState(null);
  const [exportVariant, setExportVariant] = useState("ar");
  const handleExport = (layer, variant) => { setExportVariant(variant); setExportTarget(layer); };
  useEffect(() => {
    if (!exportTarget) return;
    const t = setTimeout(async () => {
      try {
        const el = document.getElementById("layer-export-card");
        if (el) await exportElementAsImage(el, `blend-${exportVariant}-${Date.now()}.png`, "#ffffff");
      } catch { toast.error(isAr ? "تعذّر التصدير" : "Export failed"); }
      setExportTarget(null);
    }, 70);
    return () => clearTimeout(t);
  }, [exportTarget, exportVariant, isAr]);

  // المنتقي يبحث عبر الفهرس داخلياً (searchPerfumeIds) — لا تحميل ~130 ألف عطر هنا.

  const { data: layers = [], isLoading } = useQuery({
    queryKey: ["layers"],
    queryFn: () => apphost.entities.PerfumeLayer.list("-created_date"),
  });

  // فروق العطرين: جلب عطور كل المزجات دفعةً واحدة (أداء — لا جلب لكل بطاقة)
  const allPerfumeIds = useMemo(() => {
    const set = new Set();
    layers.forEach((l) => {
      (l.perfume_ids ? l.perfume_ids.split(",") : [l.perfume1_id, l.perfume2_id])
        .map((x) => String(x || "").trim()).filter(Boolean).forEach((id) => set.add(id));
    });
    return [...set];
  }, [layers]);

  const { data: blendPerfumes = [] } = useQuery({
    queryKey: ["layer-perfumes", allPerfumeIds.join(",")],
    queryFn: () => (allPerfumeIds.length ? apphost.entities.Perfume.getMany(allPerfumeIds) : []),
    enabled: allPerfumeIds.length > 0,
    staleTime: 1000 * 30,
  });
  const perfumeMap = useMemo(() => {
    const m = {};
    blendPerfumes.forEach((p) => { if (p && p.id != null) m[String(p.id)] = p; });
    return m;
  }, [blendPerfumes]);

  const createLayer = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeLayer.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["layers"] });
      toast.success((isAr ? "حُفظ المزج" : "Layer combo saved"));
      setDialogOpen(false);
      resetForm();
    },
  });

  const deleteLayer = useMutation({
    mutationFn: (id) => apphost.entities.PerfumeLayer.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["layers"] }); toast.success((isAr ? "أُزيل" : "Removed")); },
  });

  const updateLayer = useMutation({
    mutationFn: ({ id, data }) => apphost.entities.PerfumeLayer.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["layers"] }),
  });

  const createWearLog = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success((isAr ? "سُجّل لي و لنا" : "Logged to Me/We"));
      setLogDialogOpen(false);
      setLogNote("");
    },
  });

  const resetForm = () => {
    setSelectedPerfumes([null, null]);
    setComboName(""); setComboNotes("");
    setComboRating(0); setComboPerson("person1");
    setEditId(null);
  };

  const validPerfumes = selectedPerfumes.filter(Boolean);

  const handleCreate = () => {
    if (validPerfumes.length < 2) { toast.error((isAr ? "اختر عطرين على الأقل" : "Pick at least 2 perfumes")); return; }
    const uniqueIds = new Set(validPerfumes.map((p) => p.id));
    if (uniqueIds.size !== validPerfumes.length) { toast.error((isAr ? "اختر عطوراً مختلفة" : "Pick different perfumes")); return; }

    const ids = validPerfumes.map((p) => p.id).join(",");
    const names_ = validPerfumes.map((p) => p.name).join(",");
    const brands = validPerfumes.map((p) => p.brand_name || "").join(",");

    createLayer.mutate({
      perfume_ids: ids,
      perfume_names: names_,
      perfume_brands: brands,
      // keep legacy fields for compat with LayerCard
      perfume1_id: validPerfumes[0].id,
      perfume1_name: validPerfumes[0].name,
      perfume1_brand: validPerfumes[0].brand_name,
      perfume2_id: validPerfumes[1]?.id || "",
      perfume2_name: validPerfumes[1]?.name || "",
      perfume2_brand: validPerfumes[1]?.brand_name || "",
      name: comboName, notes: comboNotes, rating: comboRating, person: comboPerson, wear_count: 0,
    });
  };

  const handleEdit = (layer) => {
    setEditId(layer.id);
    setComboName(layer.name || "");
    setComboNotes(layer.notes || "");
    setComboRating(layer.rating || 0);
    setComboPerson(layer.person || "person1");
    setSelectedPerfumes([null, null]);
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (editId) {
      updateLayer.mutate({ id: editId, data: { name: comboName, notes: comboNotes, rating: comboRating, person: comboPerson } });
      toast.success((isAr ? "حُدّث المزج" : "Combo updated"));
      setDialogOpen(false);
      resetForm();
      return;
    }
    handleCreate();
  };

  const handleLogWear = (layer) => {
    setLogTarget(layer);
    setLogPerson("person1");
    setLogDate(format(new Date(), "yyyy-MM-dd"));
    setLogNote("");
    setLogDialogOpen(true);
  };

  const handleConfirmLog = () => {
    const allNames = logTarget.perfume_names
      ? logTarget.perfume_names.split(",").join(" + ")
      : `${logTarget.perfume1_name} + ${logTarget.perfume2_name}`;
    const comboLabel = logTarget.name || allNames;
    createWearLog.mutate({
      date: logDate,
      perfume_id: logTarget.perfume1_id,
      perfume_name: `[Layer] ${comboLabel}`,
      brand_name: logTarget.perfume1_brand,
      person: logPerson,
      note: logNote || `Layered: ${allNames}`,
    });
    updateLayer.mutate({
      id: logTarget.id,
      data: { wear_count: (logTarget.wear_count || 0) + 1, last_worn: logDate },
    });
  };

  const topRated = useMemo(() => [...layers].filter((l) => l.rating > 0).sort((a, b) => b.rating - a.rating).slice(0, 1), [layers]);
  const mostWorn = useMemo(() => [...layers].filter((l) => l.wear_count > 0).sort((a, b) => b.wear_count - a.wear_count).slice(0, 1), [layers]);

  // Helper: get display label for a layer
  const getLayerLabel = (layer) => {
    if (layer.name) return layer.name;
    if (layer.perfume_names) return layer.perfume_names.split(",").join(" + ");
    return `${layer.perfume1_name} + ${layer.perfume2_name}`;
  };

  const addSlot = () => {
    if (selectedPerfumes.length < 5) setSelectedPerfumes((prev) => [...prev, null]);
  };

  const removeSlot = (i) => {
    setSelectedPerfumes((prev) => prev.filter((_, idx) => idx !== i));
  };

  const setSlot = (i, perfume) => {
    setSelectedPerfumes((prev) => prev.map((p, idx) => (idx === i ? perfume : p)));
  };

  // IDs already selected (to exclude from pickers)
  const selectedIds = selectedPerfumes.filter(Boolean).map((p) => p.id);

  return (
    <div className="px-4 page-top pb-4 space-y-5">
      {/* Header — مربّع المستخدم في الأعلى */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/" />
        <SettingsSheet>
          <UserAvatarButton size={28} />
        </SettingsSheet>
      </div>
      <div className="space-y-0.5">
        <h1 className="font-heading text-2xl font-bold">{isAr ? 'مزج' : 'Blend'}</h1>
        <p className="text-xs text-muted-foreground font-body">{layers.length} {isAr ? 'تركيبات' : 'combinations'}</p>
      </div>

      {/* Highlights — بلا خلفية مختلفة و بلا إطارات */}
      {(topRated.length > 0 || mostWorn.length > 0) && (
      <div className="space-y-4">
        <div className="text-center">
          <h2 className="font-heading text-xl font-bold tracking-wide">{isAr ? 'مزج' : 'Layering'}</h2>
          <p className="text-xs text-muted-foreground font-body mt-0.5">{isAr ? 'اخلط و استمتع' : 'Mix It'}</p>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {topRated[0] && (
            <div className="space-y-1">
              <div style={{ height: 2, background: c1, opacity: 0.7, borderRadius: 1 }} />
              <p className="text-[10px] uppercase tracking-wider font-body font-medium" style={{ color: c1 }}>{isAr ? 'الأعلى تقييماً' : 'Top Rated'}</p>
              <p className="text-xs font-body font-semibold truncate">{getLayerLabel(topRated[0])}</p>
              <p className="text-[10px] text-muted-foreground font-body">{"◆".repeat(topRated[0].rating)}{"◇".repeat(5 - topRated[0].rating)}</p>
            </div>
          )}
          {mostWorn[0] && (
            <div className="space-y-1">
              <div style={{ height: 2, background: c2, opacity: 0.7, borderRadius: 1 }} />
              <p className="text-[10px] uppercase tracking-wider font-body font-medium" style={{ color: c2 }}>{isAr ? 'الأكثر استعمالاً' : 'Most Worn'}</p>
              <p className="text-xs font-body font-semibold truncate">{getLayerLabel(mostWorn[0])}</p>
              <p className="text-[10px] text-muted-foreground font-body">{mostWorn[0].wear_count}{isAr ? '× استعمال' : '× worn'}</p>
            </div>
          )}
        </div>
      </div>
      )}



      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}

      {!isLoading && layers.length === 0 && (
        <div className="text-center py-14 space-y-3">
          <div className="w-16 h-16 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <Layers className="w-8 h-8 text-primary/40" />
          </div>
          <p className="font-heading text-lg font-semibold">{isAr ? "لا مزجات بعد" : "No combos yet"}</p>
          <p className="text-xs text-muted-foreground font-body max-w-xs mx-auto">{isAr ? "اخلط من عطرين إلى خمسة عطور و قيّم تآلف روائحها معا" : "Mix 2–5 perfumes and rate how they smell together."}</p>
          <Button className="rounded-none font-body text-sm h-10" onClick={() => { resetForm(); setDialogOpen(true); }}>
            {isAr ? "أنشئ أول مزيج" : "Create First Combo"}
          </Button>
        </div>
      )}

      {layers.length > 0 && (
        <div className="space-y-3">
          {layers.map((layer) => (
            <LayerCard
              key={layer.id}
              layer={layer}
              names={names}
              personColor={personColor}
              perfumeMap={perfumeMap}
              isAr={isAr}
              onExport={(variant) => handleExport(layer, variant)}
              onEdit={() => handleEdit(layer)}
              onDelete={() => deleteLayer.mutate(layer.id)}
              onLogWear={() => handleLogWear(layer)}
              onRateUpdate={(rating) => updateLayer.mutate({ id: layer.id, data: { rating } })}
            />
          ))}
        </div>
      )}

      {/* زرّ إضافة مزيج — أسفل الصفحة، بلا إطار، يتبع لون المستخدم */}
      <button className="w-full rounded-none font-body h-11 text-sm font-medium transition-opacity hover:opacity-80"
        style={{ border: 0, color: c1 }}
        onClick={() => { resetForm(); setDialogOpen(true); }}>
        {isAr ? "اضف مزيج" : "Add Combo"}
      </button>

      {/* بطاقة تصدير مخفية — تُصيَّر صورةً عند اختيار تصدير مزج */}
      {exportTarget && (() => {
        const layer = exportTarget;
        const showEn = exportVariant === "aren" || exportVariant === "merged";
        const ids = (layer.perfume_ids ? layer.perfume_ids.split(",") : [layer.perfume1_id, layer.perfume2_id]).map((x) => String(x || "").trim()).filter(Boolean);
        const ps = ids.map((id) => perfumeMap[id]).filter(Boolean);
        const facets = ps.map((p) => perfumeFacets(p)).filter(Boolean);
        const fallbackNames = layer.perfume_names ? layer.perfume_names.split(",").map((n) => n.trim()).filter(Boolean) : [];
        const title = layer.name || (facets.length ? facets.map((f) => f.name).join("  +  ") : fallbackNames.join("  +  "));
        const report = buildBlendReport(ps);
        const C = { ink: "#1c1b19", body: "#3a3a37", soft: "#6b665d", faint: "#9a9489", line: "#efece6", gold: "#c8a02e" };
        const NoteLine = ({ lbl, arr, color }) => arr.length === 0 ? null : (
          <div dir="auto" style={{ fontSize: 11, color: C.soft, lineHeight: 1.55 }}>
            <span style={{ color, fontWeight: 600 }}>{lbl}</span>{"  "}{arr.slice(0, 6).join("، ")}
          </div>
        );
        return (
          <div id="layer-export-card" aria-hidden="true"
            style={{ position: "fixed", left: 0, top: 0, zIndex: -1, opacity: 1, pointerEvents: "none", width: 470, background: "#ffffff", padding: 28, boxSizing: "border-box" }}>
            {/* الترويسة */}
            <div style={{ borderBottom: `2px solid ${C.gold}`, paddingBottom: 10, marginBottom: 16 }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: C.ink, fontFamily: "'Spectral', 'Amiri', serif", lineHeight: 1.25 }} dir="auto">{title}</div>
              <div style={{ fontSize: 11, color: C.faint, letterSpacing: 2, marginTop: 4 }}>مزج عطور{showEn ? "   Perfume Blend" : ""}</div>
            </div>

            {/* كل عطر بطاقة كاملة — كأنك تتصفّح عدة عطور بوقت واحد */}
            {facets.length === 0 ? (
              fallbackNames.map((n, i) => (
                <div key={i} style={{ padding: "10px 0", borderBottom: `1px solid ${C.line}`, fontSize: 16, color: C.ink, fontFamily: "'Spectral', 'Amiri', serif" }} dir="auto">{n}</div>
              ))
            ) : facets.map((f, i) => (
              <div key={i} style={{ padding: "12px 0", borderBottom: `1px solid ${C.line}` }}>
                {/* الاسم — سطر كامل العرض بلا انضغاط */}
                <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
                  <span style={{ width: 11, height: 11, borderRadius: 3, background: f.dominant ? f.dominant.color : "#ddd", flexShrink: 0, alignSelf: "center" }} />
                  <span style={{ fontSize: 16, fontWeight: 600, color: C.ink, fontFamily: "'Spectral', 'Amiri', serif", lineHeight: 1.3 }} dir="auto">
                    {f.name}{f.brand ? `  —  ${f.brand}` : ""}
                  </span>
                </div>

                <div style={{ paddingInlineStart: 19, marginTop: 7, display: "flex", flexDirection: "column", gap: 6 }}>
                  {/* النوع + الكثافة و شريطها */}
                  {(f.typeText || f.strength) && (
                    <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: "4px 10px" }}>
                      {f.typeText && <span style={{ fontSize: 11.5, color: C.faint }} dir="auto">{f.typeText}</span>}
                      {f.strength && (
                        <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
                          <StrengthBar strength={f.strength} width={46} height={6} />
                          <span style={{ fontSize: 10.5, color: f.strengthColor }} dir="auto">{showEn ? `${f.strengthAr} / ${f.strengthEn}` : f.strengthAr}</span>
                        </span>
                      )}
                    </div>
                  )}

                  {/* الجنس و شريطه */}
                  {f.gender && (
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ display: "inline-block", width: 46, height: 6, background: "#ece7da", overflow: "hidden", flex: "0 0 auto" }}>
                        <span style={{ display: "block", height: "100%", width: f.gender.en === "Unisex" ? "50%" : "100%", background: f.gender.en === "Female" ? "#c98aa6" : f.gender.en === "Male" ? "#6f86b3" : "#b39ddb", marginInlineStart: f.gender.en === "Unisex" ? "25%" : 0 }} />
                      </span>
                      <span style={{ fontSize: 10.5, color: C.soft }} dir="auto">{showEn ? `${f.gender.ar} / ${f.gender.en}` : f.gender.ar}</span>
                    </div>
                  )}

                  {/* الأكوردات — الفرق بينها بالألوان */}
                  {f.accords.length > 0 && (
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "5px 6px" }}>
                      {f.accords.map((a, j) => (
                        <span key={j} style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 10.5, color: C.soft, border: `1px solid ${a.color}55`, borderRadius: 999, padding: "1px 7px" }} dir="auto">
                          <span style={{ width: 7, height: 7, borderRadius: 999, background: a.color, flexShrink: 0 }} />
                          {showEn ? `${a.ar} / ${a.en}` : a.ar}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* الهرم العطريّ — النوتات */}
                  {(f.top.length || f.heart.length || f.base.length) > 0 && (
                    <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
                      <NoteLine lbl={showEn ? "مقدمة Top" : "مقدمة"} arr={f.top} color="#3b82c4" />
                      <NoteLine lbl={showEn ? "قلب Heart" : "قلب"} arr={f.heart} color="#c4607f" />
                      <NoteLine lbl={showEn ? "أساس Base" : "أساس"} arr={f.base} color="#b08948" />
                    </div>
                  )}

                  {/* اليوم و المواسم — المناسبات */}
                  {f.occasions.length > 0 && (
                    <div style={{ fontSize: 12.5, color: C.body }} dir="auto">
                      {f.occasions.map((o) => `${o.emoji} ${showEn ? `${o.ar} / ${o.en}` : o.ar}`).join("   ")}
                    </div>
                  )}

                  {/* مؤشرات الصحة */}
                  {f.health.length > 0 && (
                    <div style={{ fontSize: 11, color: C.soft }} dir="auto">
                      {f.health.map((h) => `${h.emoji} ${showEn ? `${h.ar} / ${h.en}` : h.ar}`).join("   ")}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* التقرير المجهّز — الفروق و ما يميّز كل عطر */}
            {report.ar && (
              <div style={{ marginTop: 16, paddingTop: 13, borderTop: `1px solid #e7e3da` }}>
                <div style={{ fontSize: 11, color: C.gold, letterSpacing: 1.5, marginBottom: 6 }}>قراءة المزيج{showEn ? "   Blend reading" : ""}</div>
                <div dir="rtl" style={{ fontSize: 12.5, color: C.body, lineHeight: 1.75, whiteSpace: "pre-line" }}>{report.ar}</div>
                {showEn && <div dir="ltr" style={{ fontSize: 11.5, color: C.soft, lineHeight: 1.6, whiteSpace: "pre-line", marginTop: 9 }}>{report.en}</div>}
              </div>
            )}

            {layer.notes && (
              <div style={{ fontSize: 12.5, color: C.soft, fontStyle: "italic", marginTop: 12, lineHeight: 1.5 }} dir="auto">— {layer.notes}</div>
            )}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16 }}>
              <span style={{ fontSize: 13, color: C.gold, letterSpacing: 2 }}>{"◆".repeat(layer.rating || 0)}{"◇".repeat(5 - (layer.rating || 0))}</span>
              <span style={{ fontSize: 11, color: "#b3ac9f", letterSpacing: 1 }}>Perfume برفيوم</span>
            </div>
          </div>
        );
      })()}

      {/* Create dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-none w-screen h-[100dvh] max-h-[100dvh] rounded-none !top-0 !left-0 !translate-x-0 !translate-y-0 overflow-y-auto p-5 sm:p-6">
          <div className="mx-auto w-full max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading text-base flex items-center gap-2">
              <Layers className="w-4 h-4" style={{ color: personColor(comboPerson) }} /> {editId ? (isAr ? "عدّل المزيج" : "Edit Combo") : (isAr ? "اضف مزيج طبقات" : "Add Layer Combo")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {editId ? (
              <p className="text-[11px] text-muted-foreground font-body">{isAr ? "تعديل التفاصيل فقط — العطور تبقى كما هي" : "Editing details only — perfumes stay as they are"}</p>
            ) : (
            <>
            {/* Perfume slots */}
            {selectedPerfumes.map((slot, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                    {isAr ? "عطر" : "Perfume"} {i + 1} {i < 2 ? (isAr ? "(مطلوب)" : "(required)") : (isAr ? "(اختياري)" : "(optional)")}
                  </p>
                  {i >= 2 && (
                    <button onClick={() => removeSlot(i)} className="text-muted-foreground hover:text-destructive">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <PerfumePicker
                  excludeIds={selectedIds.filter((id) => id !== slot?.id)}
                  selected={slot}
                  onSelect={(p) => setSlot(i, p)}
                />
              </div>
            ))}

            {/* Add more perfume slot */}
            {selectedPerfumes.length < 5 && (
              <button onClick={addSlot} className="w-full flex items-center justify-center gap-2 py-2.5 rounded-none border border-dashed border-border text-xs font-body text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                {isAr ? "أضف عطرا آخر" : "Add another perfume"}
              </button>
            )}
            </>
            )}

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "اسم المزيج (اختياري)" : "Combo Name (optional)"}</p>
              <Input value={comboName} onChange={(e) => setComboName(e.target.value)} placeholder={isAr ? "مثال: غموض المساء" : 'e.g. "Evening Mystery"'} className="rounded-none h-9 font-body text-sm" />
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "كيف رائحتهما معاً" : "How do they smell together?"}</p>
              <Textarea value={comboNotes} onChange={(e) => setComboNotes(e.target.value)} placeholder="صف المزيج... / Describe the blend.." className="rounded-none font-body text-xs min-h-[64px] resize-none" />
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "التقييم" : "Rating"}</p>
              <div className="flex gap-1.5">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button key={s} onClick={() => setComboRating(comboRating === s ? 0 : s)}
                    className={`text-xl transition-all ${s <= comboRating ? "text-primary" : "text-border hover:text-primary/40"}`}>{s <= comboRating ? "◆" : "◇"}</button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "من جرّبه" : "Who tried it?"}</p>
              <div className="flex gap-2">
                {[
                  { val: "person1", label: names.person1 },
                  { val: "person2", label: names.person2 },
                  { val: "both", label: isAr ? "كلاهما" : "Both" },
                ].map(({ val, label }) => {
                  const active = comboPerson === val;
                  return (
                  <button key={val} onClick={() => setComboPerson(val)}
                    className="flex-1 py-2 rounded-none text-xs font-body font-medium transition-all"
                    style={active ? { background: personColor(val), color: "#fff" } : { color: personColor(val), border: `1px solid ${personColor(val)}`, opacity: 0.7 }}>
                    {label}
                  </button>
                  );
                })}
              </div>
            </div>

            <Button className="w-full h-10 rounded-none font-body" style={{ background: personColor(comboPerson), color: "#fff" }} onClick={handleSave} disabled={(!editId && validPerfumes.length < 2) || createLayer.isPending}>
              {editId
                ? (isAr ? "احفظ التعديل" : "Save Changes")
                : createLayer.isPending ? (isAr ? "يحفظ.." : "Saving..") : (isAr ? `احفظ المزيج (${validPerfumes.length} عطور)` : `Save Combo (${validPerfumes.length} perfumes)`)}
            </Button>
          </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Log wear dialog */}
      <Dialog open={logDialogOpen} onOpenChange={setLogDialogOpen}>
        <DialogContent className="max-w-xs rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">سجّل هذا المزج Log This Combo</DialogTitle>
          </DialogHeader>
          {logTarget && (
            <div className="space-y-4">
              <div className="bg-secondary/50 rounded-none p-3 text-center">
                <p className="text-xs font-body font-semibold">{getLayerLabel(logTarget)}</p>
                {logTarget.perfume_names && (
                  <p className="text-[10px] text-muted-foreground font-body mt-0.5">
                    {logTarget.perfume_names.split(",").length} perfumes
                  </p>
                )}
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "التاريخ" : "Date"}</p>
                {/* لا يمكن تسجيل ارتداء في المستقبل */}
                <Input type="date" max={format(new Date(), "yyyy-MM-dd")} value={logDate} onChange={(e) => setLogDate(e.target.value)} className="rounded-none h-9 font-body text-sm" />
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "من ارتداه" : "Who wore it?"}</p>
                <div className="flex gap-2">
                  <button onClick={() => setLogPerson("person1")}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person1" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                    {names.person1}
                  </button>
                  <button onClick={() => setLogPerson("person2")}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person2" ? "bg-violet-500 text-white shadow" : "bg-secondary text-muted-foreground"}`}>
                    {names.person2}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">Note (optional)</p>
                <Textarea value={logNote} onChange={(e) => setLogNote(e.target.value)} placeholder="كيف كانت الرائحة اليوم؟ How did it smell today?" className="rounded-none font-body text-xs min-h-[48px] resize-none" />
              </div>
              <Button className="w-full h-10 rounded-none font-body" onClick={handleConfirmLog} disabled={createWearLog.isPending}>
                {createWearLog.isPending ? (isAr ? "يسجّل.." : "Logging..") : (isAr ? "سجّل لـ أنا/نحن" : "Log to Me/We")}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
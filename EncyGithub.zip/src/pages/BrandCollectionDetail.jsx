import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Droplets } from "lucide-react";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import { useLang } from "@/lib/LanguageContext";
import BackIcon from "@/components/shared/BackIcon";

// المجموعات الآلية (auto:NAME) مشتقة من أسماء العطور — نفس قائمة الاشتقاق في صفحة البراند
const KNOWN_COLLECTIONS = [
  "Private Blend", "Signature", "Le Parfum", "Les Exclusifs", "La Collection",
  "Maison", "Exclusive Collection", "Prive", "Privé", "Collection Privée",
  "Atelier", "Heritage", "Reserve", "Limited Edition", "Extrait", "Absolu",
  "Oud Collection", "Water Collection", "Cologne Collection", "Replica",
  "Aqua", "Acqua", "Velvet Collection", "Noir Collection",
];
function deriveCollection(name) {
  if (!name) return "";
  for (const c of KNOWN_COLLECTIONS) {
    if (name.toLowerCase().includes(c.toLowerCase())) return c;
  }
  return "";
}

export default function BrandCollectionDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const collectionId = urlParams.get("id");
  const brandParam = urlParams.get("brand") || "";
  const isAuto = (collectionId || "").startsWith("auto:");
  const autoName = isAuto ? collectionId.slice(5) : "";
  const navigate = useNavigate();
  const { isAr } = useLang();

  const { data: storedCollection, isLoading: loadingCol } = useQuery({
    queryKey: ["collection", collectionId],
    queryFn: async () => {
      const res = await apphost.entities.PerfumeCollection.filter({ id: collectionId });
      return res?.[0] || null;
    },
    enabled: !!collectionId && !isAuto,
  });
  // مجموعة آلية: نركّب الكائن محلياً — لا سجل لها في القاعدة (كان هذا سبب «المجموعة غير موجودة»)
  const collection = isAuto ? { name: autoName, name_ar: "", auto: true } : storedCollection;

  const { data: storedPerfumes = [], isLoading: loadingStored } = useQuery({
    queryKey: ["perfumes-by-collection", collectionId, storedCollection?.brand_name || ""],
    queryFn: async () => {
      // collection_id غير مفهرس → الفلترة المباشرة تمسح 130 ألف عطر (دوّارة عالقة).
      // الحلّ: نفلتر بـbrand_name المفهرس (سريع) ثمّ نطابق collection_id بالذاكرة. .
      const bname = storedCollection?.brand_name;
      if (bname) {
        const byBrand = await apphost.entities.Perfume.filter({ brand_name: bname });
        return (byBrand || []).filter((p) => String(p.collection_id) === String(collectionId));
      }
      // fallback نادر (لا اسم براند): الفلترة المباشرة
      return apphost.entities.Perfume.filter({ collection_id: collectionId });
    },
    enabled: !!collectionId && !isAuto && !!storedCollection,
    staleTime: 1000 * 60 * 5,
  });
  const { data: autoPerfumes = [], isLoading: loadingAuto } = useQuery({
    queryKey: ["perfumes-by-auto-collection", brandParam, autoName],
    queryFn: async () => {
      const all = await apphost.entities.Perfume.filter({ brand_name: brandParam });
      return (all || []).filter((p) => (p.collection || deriveCollection(p.name_en || p.name || "")) === autoName);
    },
    enabled: isAuto && !!brandParam,
  });
  const perfumes = isAuto ? autoPerfumes : storedPerfumes;

  // Sort newest release year first, then by created_date
  const sorted = [...perfumes].sort((a, b) => {
    if (b.release_year && a.release_year) return b.release_year - a.release_year;
    if (b.release_year) return 1;
    if (a.release_year) return -1;
    return new Date(b.created_date) - new Date(a.created_date);
  });

  if (loadingCol && !isAuto) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (!collection) return (
    <div className="px-5 page-top text-center">
      <p className="text-muted-foreground font-body">{isAr ? "المجموعة غير موجودة" : "Collection not found"}</p>
    </div>
  );

  const displayName = isAr ? (collection.name_ar || collection.name) : collection.name;

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="relative bg-white px-5 page-top pb-8 border-b border-border">
        {collection.image_url ? (
          <div className="absolute inset-0 bg-cover bg-center opacity-10" style={{ backgroundImage: `url(${collection.image_url})` }} />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-slate-50 to-slate-100" />
        )}
        <div className="relative">
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-none bg-card shadow flex items-center justify-center mb-4"
          >
            <BackIcon className="w-4 h-4" />
          </button>
          <div>
            <button
              onClick={() => navigate(`/brand?id=${collection.brand_id}`)}
              className="text-xs text-primary font-body font-semibold uppercase tracking-widest mb-1 hover:underline"
            >
              {collection.brand_name}
            </button>
            <h1 className="font-heading text-2xl font-bold leading-tight">{displayName}</h1>
            {isAr && collection.name_ar && collection.name_ar !== collection.name && (
              <p className="text-sm text-muted-foreground font-body">{collection.name}</p>
            )}
            {collection.launch_year && (
              <p className="text-xs text-muted-foreground font-body mt-1">Est. {collection.launch_year}</p>
            )}
          </div>
        </div>
      </div>

      <div className="px-5 space-y-5 mt-5">
        {collection.description && (
          <div className="bg-card rounded-none p-4 shadow-sm">
            <p className="text-sm font-body text-foreground/80 leading-relaxed">{collection.description}</p>
          </div>
        )}

        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <h2 className="font-heading font-semibold">{isAr ? "العطور" : "Perfumes"}</h2>
            <span className="text-xs text-muted-foreground font-body flex items-center gap-1">
              <Droplets className="w-3.5 h-3.5" /> {sorted.length}
            </span>
          </div>

          {(loadingStored || loadingAuto) ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : sorted.length === 0 ? (
            <p className="text-sm text-muted-foreground font-body text-center py-6">{isAr ? "لا عطور في هذه المجموعة" : "No perfumes in this collection yet."}</p>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {sorted.map(p => {
                const modifiedPerfume = { ...p };
                if (!p.image_url) {
                  modifiedPerfume.image_url = "white";
                }
                return (
                <div key={p.id} className="relative">
                  <PerfumeCard perfume={modifiedPerfume} />
                  {p.release_year && (
                    <span className="absolute top-2 left-2 text-white text-[9px] font-bold rounded-none font-body">
                      {p.release_year}
                    </span>
                  )}
                  </div>
                  );
                  })}
                  </div>
                  )}
        </div>
      </div>
    </div>
  );
}
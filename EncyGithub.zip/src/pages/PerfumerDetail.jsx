import { hilalBorder } from "@/lib/hilalArt";
import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { Link, useNavigate } from "react-router-dom";
import PinButton from "@/components/shared/PinButton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Edit2, Droplets, Heart, HeartOff, X, ArchiveX } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";
import { useLang } from "@/lib/LanguageContext";
import { openExternalUrl } from "@/lib/exportHelper";
import DetailFooter from "@/components/shared/DetailFooter";

import { normPerfumerName, compareEnglish, rankName } from "@/lib/sortName";
import { searchIndexReady, searchPerfumeIds, normalizeSearch } from "@/lib/searchIndex";
import BackIcon from "@/components/shared/BackIcon";

// Defensive: a field may be a comma-string, an array, null, or even a number.
// Always yield a clean string array so .map/.split never throws (fixes
// `famous_works.split is not a function` crash on some records).
const toList = (v) =>
  Array.isArray(v)
    ? v.map((x) => String(x).trim()).filter(Boolean)
    : v == null || v === ""
    ? []
    : String(v).split(",").map((s) => s.trim()).filter(Boolean);

export default function PerfumerDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();
  const [editOpen, setEditOpen] = useState(false);
  const [photoOpen, setPhotoOpen] = useState(false); // تكبير صورة العطّار بالضغط — بلا أيقونات
  const [perfShown, setPerfShown] = useState(60);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const { names } = usePersonNames();
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    apphost.auth.me().then(setUserData).catch(() => {});
  }, []);

  const favPerfumersP1 = toList(userData?.fav_perfumers_p1);
  const favPerfumersP2 = toList(userData?.fav_perfumers_p2);
  const dislikePerfumersP1 = toList(userData?.dislike_perfumers_p1);
  const dislikePerfumersP2 = toList(userData?.dislike_perfumers_p2);

  const toggleOpinion = async (person, perfumerId, type) => {
    const favKey = person === "person1" ? "fav_perfumers_p1" : "fav_perfumers_p2";
    const dislikeKey = person === "person1" ? "dislike_perfumers_p1" : "dislike_perfumers_p2";
    const currentFav = person === "person1" ? favPerfumersP1 : favPerfumersP2;
    const currentDislike = person === "person1" ? dislikePerfumersP1 : dislikePerfumersP2;

    let newFav = currentFav;
    let newDislike = currentDislike;

    if (type === "fav") {
      newFav = currentFav.includes(perfumerId) ? currentFav.filter(p => p !== perfumerId) : [...currentFav.filter(p => p !== perfumerId), perfumerId];
      newDislike = currentDislike.filter(p => p !== perfumerId);
    } else {
      newDislike = currentDislike.includes(perfumerId) ? currentDislike.filter(p => p !== perfumerId) : [...currentDislike.filter(p => p !== perfumerId), perfumerId];
      newFav = currentFav.filter(p => p !== perfumerId);
    }

    const updates = { [favKey]: newFav.join(","), [dislikeKey]: newDislike.join(",") };
    await apphost.auth.updateMe(updates);
    setUserData({ ...userData, ...updates });
    toast.success("تم التحديث");
  };

  const { data: perfumer, isLoading } = useQuery({
    queryKey: ["perfumer", id],
    queryFn: () => apphost.entities.Perfumer.filter({ id }),
    select: (data) => data?.[0],
    enabled: !!id,
  });

  // تفاعل العطّار (4 إيموجي) — للشخص الفعّال، يتراكم عبر كل أعماله
  const perfReactPerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";
  const { data: perfumerReacts = [] } = useQuery({
    queryKey: ["user-perfumer", perfumer?.id],
    queryFn: () => apphost.entities.UserPerfumer.filter({ perfumer_id: perfumer.id }),
    enabled: !!perfumer?.id,
  });
  const myPerfumerReact = perfumerReacts.find((r) => r.person === perfReactPerson) || null;
  const upsertPerfumerReact = useMutation({
    mutationFn: async (value) => {
      const existing = perfumerReacts.find((r) => r.person === perfReactPerson);
      if (existing) return apphost.entities.UserPerfumer.update(existing.id, { list: value });
      return apphost.entities.UserPerfumer.create({ perfumer_id: perfumer.id, perfumer_name: perfumer.name, perfumer_name_ar: perfumer.name_ar || "", person: perfReactPerson, list: value });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["user-perfumer"] }); },
  });

  // All perfumers (A→Z) for footer prev/next navigation.
  const { data: allPerfumersList = [] } = useQuery({
    queryKey: ["all-perfumers-nav"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });
  const sortedPerfumers = [...allPerfumersList].sort((a, b) =>
    compareEnglish(a, b, 1)
  );

  // معرّفات عطور العطّار المخزّنة مسبقاً وقت الزراعة (مرحلة 3). إن وُجدت نجلب
  // العطور بالمعرّف عبر getMany — لا تحميل للكتالوج كاملاً (130 ألف).
  const linkedIds = toList(perfumer?.perfume_ids);
  const hasLinkedIds = linkedIds.length > 0;

  const { data: perfumesById = [] } = useQuery({
    queryKey: ["perfumer-perfumes", id, linkedIds.length],
    queryFn: () => apphost.entities.Perfume.getMany(linkedIds),
    enabled: hasLinkedIds,
  });

  // احتياط فقط للبيانات القديمة (لم يُعَد زرعها) أو لعطّار مُضاف يدوياً بلا perfume_ids:
  // عندها فقط نحمّل الكتالوج ونطابق بالاسم. بعد إعادة الزراعة لا يُفعّل هذا المسار.
  const needNameFallback = !!perfumer && !hasLinkedIds;
  const { data: allPerfumes = [] } = useAllPerfumes("-created_date", { enabled: needNameFallback });

  // العطور المرتبطة بهذا العطّار: المسار السريع (getMany) إن توفّرت المعرّفات،
  // وإلا المطابقة بالاسم (نفس تطبيع الزارع: شرطة←مسافة، إزالة تشكيل).
  const linkedPerfumes = useMemo(() => {
    if (!perfumer) return [];
    if (hasLinkedIds) return perfumesById;
    const targetName = normPerfumerName(perfumer.name);
    return allPerfumes.filter((p) => {
      if (p.perfumer_ids && String(p.perfumer_ids).split(",").map((s) => s.trim()).includes(id)) {
        return true;
      }
      if (targetName && p.perfumer_names) {
        const names = (Array.isArray(p.perfumer_names) ? p.perfumer_names.join(",") : String(p.perfumer_names)).split(",").map((n) => normPerfumerName(n));
        if (names.includes(targetName)) return true;
      }
      return false;
    });
  }, [hasLinkedIds, perfumesById, allPerfumes, perfumer, id]);

  // حلّ اسم عطر إلى كائنه من القائمة المرتبطة السريعة ثمّ الاحتياط — يصلح روابط الأعمال الشهيرة.
  const findPerfume = (nm) => {
    const t = String(nm || "").trim().toLowerCase();
    if (!t) return null;
    return [...linkedPerfumes, ...allPerfumes].find((p) => p && [p.name, p.name_en, p.name_ar].some((x) => String(x || "").trim().toLowerCase() === t)) || null;
  };

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: notes = [] } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  // Brands linked via perfumer_ids field
  const linkedBrands = brands.filter(b => {
    if (!b.perfumer_ids) return false;
    return (Array.isArray(b.perfumer_ids) ? b.perfumer_ids.join(",") : String(b.perfumer_ids)).split(",").map(s => s.trim()).includes(id);
  });

  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.Perfumer.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfumer", id] });
      queryClient.invalidateQueries({ queryKey: ["perfumers"] });
      toast.success("حُدّث المعطّر");
      setEditOpen(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => apphost.entities.Perfumer.delete(id),
    onSuccess: () => {
      toast.success("تم حذف العطار");
      navigate("/perfumers");
    },
  });

  const currentYear = new Date().getFullYear();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-green-200 border-t-green-800 rounded-full animate-spin" />
      </div>
    );
  }

  if (!perfumer) {
    return (
      <div className="px-5 page-top text-center">
        <p className="text-muted-foreground font-body">المعطّر غير موجود Perfumer not found</p>
        <Button variant="ghost" onClick={() => navigate("/perfumers")} className="mt-4">رجوع Go Back</Button>
      </div>
    );
  }

  const brandList = toList(perfumer.brand_names);
  const perfumeList = toList(perfumer.perfume_names);
  const famousList = toList(perfumer.famous_works);
  const favPerfumeList = toList(perfumer.favorite_perfumes);
  const favNoteList = toList(perfumer.favorite_notes);

  const isAlive = !perfumer.death_year;
  const age = perfumer.birth_year
    ? perfumer.death_year
      ? perfumer.death_year - perfumer.birth_year
      : currentYear - perfumer.birth_year
    : null;

  const isFemale = perfumer.gender === "Female";
  const heroBg = isFemale
    ? "bg-gradient-to-br from-pink-400 via-pink-600 to-rose-700"
    : "bg-white";

  return (
    <div className="pb-8">
      {/* Hero — same style as BrandDetail */}
      <div className="relative px-5 pt-6 pb-0" style={{ background: "linear-gradient(180deg, #ffffff, #f8f1db)" }}>
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" size="icon" className="rounded-none hover:bg-secondary/20" onClick={() => navigate(-1)}>
            <BackIcon className={`w-5 h-5`} />
          </Button>
          <span />
        </div>
        <div className="flex flex-col items-center gap-6 pb-8">
          {/* Photo */}
          <button type="button" onClick={() => perfumer.photo_url && setPhotoOpen(true)}
            className="w-40 h-40 rounded-none bg-white shadow-lg flex items-center justify-center flex-shrink-0 overflow-hidden p-0 cursor-pointer"
            style={{ border: hilalBorder(perfumer.name, perfumer.name_ar, "2px solid #d4af37") }}>
            {perfumer.photo_url ? (
              <img src={perfumer.photo_url} alt={perfumer.name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
            ) : (
              <div className="w-full h-full bg-white" />
            )}
          </button>
          <div className="text-center space-y-2">
            <h1 className="font-heading text-3xl font-bold leading-tight" style={{ color: "#9a7b1f" }}>{perfumer.name}</h1>
            {perfumer.name_ar && <p className="text-sm text-muted-foreground font-body" dir="rtl">{perfumer.name_ar}</p>}
            {!isAlive && <span className="text-xs rounded-none text-muted-foreground font-body">†</span>}
            {/* تفاعل العطّار — 4 إيموجي (يتراكم تفضيلك للعطّارين) */}
            <div className="flex items-center justify-center gap-4 pt-1">
              {[["favorite", "❤️"], ["recommend", "👍"], ["dislike", "👎"], ["wtf", "😱"]].map(([val, em]) => {
                const active = myPerfumerReact?.list === val;
                return (
                  <button key={val} type="button" onClick={() => upsertPerfumerReact.mutate(active ? null : val)} disabled={upsertPerfumerReact.isPending}
                    aria-label={val} className="transition-all" style={{ fontSize: 22, opacity: active ? 1 : 0.35, transform: active ? "scale(1.15)" : "none" }}>
                    {em}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="px-5 space-y-4 mt-5">

        {/* بطاقة واحدة لكل معلومات العطّار */}
        <div className="bg-card rounded-none shadow-sm border border-[var(--brand)] divide-y divide-[var(--brand)]/15">
        {/* Bio — bilingual with metadata */}
        {(perfumer.bio || perfumer.nationality || perfumer.gender || perfumer.birth_year) && (
          <div className="p-5 space-y-3">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>السيرة الذاتية Biography</h2>
            
            {/* Metadata */}
            {(perfumer.nationality || perfumer.gender || perfumer.birth_year) && (
              <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs font-body text-muted-foreground pb-3 border-b border-border/30">
                {perfumer.nationality && (
                  <Link
                    to={`/search-results?q=${encodeURIComponent(perfumer.nationality)}`}
                    className="hover:opacity-70 transition-opacity"
                    title={`@${perfumer.nationality}`}
                  >
                    {perfumer.nationality}
                  </Link>
                )}
                {perfumer.gender && (
                  <span>{perfumer.gender === "Female" ? "♀ Female" : "♂ Male"}</span>
                )}
                {perfumer.birth_year && (
                  <span>
                    {perfumer.birth_year}
                    {perfumer.death_year ? ` – ${perfumer.death_year}` : ` – present`}
                    {age && ` — ${age} ${isAlive ? "years old" : "years"}`}
                  </span>
                )}
              </div>
            )}
            
            {perfumer.bio && (
              <p className="text-sm font-body text-foreground/75 leading-relaxed">{perfumer.bio}</p>
            )}
          </div>
        )}

        {/* Famous Works */}
        {famousList.length > 0 && (
          <div className="p-5 space-y-3">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>
              الأعمال الشهيرة Famous Works
            </h2>
            <div className="flex flex-wrap gap-2">
              {famousList.map((work) => {
                const perfume = findPerfume(work);
                return perfume ? (
                  <Link key={work} to={`/perfume?id=${perfume.id}`} className=" rounded-none text-[#9a7b1f] dark:text-[var(--brand)] text-xs font-body font-medium transition-colors">
                    {work}
                  </Link>
                ) : (
                  <span key={work} className=" rounded-none text-[#9a7b1f] dark:text-[var(--brand)] text-xs font-body font-medium ">
                    {work}
                  </span>
                );
              })}
            </div>
          </div>
        )}

        {/* المفضّلات */}
          <div className="p-5 space-y-3">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>
              العطور المفضلة Favorite Perfumes
            </h2>
            {favPerfumeList.length === 0 ? (
              <p className="text-xs text-muted-foreground font-body">لا عطور مفضّلة عدّل لإضافتها No favorite perfumes listed. Edit to add some.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {favPerfumeList.map((name) => {
                  const perfume = findPerfume(name);
                  return perfume ? (
                    <Link key={name} to={`/perfume?id=${perfume.id}`} className=" rounded-none text-rose-700 dark:text-rose-400 text-xs font-body font-medium transition-colors flex items-center gap-1">
                      <Droplets className="w-3 h-3" /> {name}
                    </Link>
                  ) : (
                    <span key={name} className=" rounded-none text-rose-600 dark:text-rose-400 text-xs font-body font-medium ">
                      {name}
                    </span>
                  );
                })}
              </div>
            )}
          </div>

          <div className="p-5 space-y-3">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>
              النوتات المفضلة Favorite Notes
            </h2>
            {favNoteList.length === 0 ? (
              <p className="text-xs text-muted-foreground font-body">لا نوتات مفضّلة عدّل لإضافتها No favorite notes listed. Edit to add some.</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {favNoteList.map((note) => {
                  const noteObj = notes.find(n => n.name?.toLowerCase() === note.toLowerCase());
                  return noteObj ? (
                    <Link key={note} to={`/note?id=${noteObj.id}`}
                      className=" rounded-none text-green-800 dark:text-green-400 text-xs font-body font-medium transition-colors">
                      {note}
                    </Link>
                  ) : (
                    <span key={note} className=" rounded-none text-green-600 dark:text-green-400 text-xs font-body font-medium ">
                      {note}
                    </span>
                  );
                })}
              </div>
            )}
          </div>

        {/* Brands — linked via perfumer_ids (DB-based) */}
        {linkedBrands.length > 0 && (
          <div className="p-5 space-y-3">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>العلامات التجارية Associated Brands</h2>
            <div className="flex flex-wrap gap-2">
              {linkedBrands.map(b => (
                <Link key={b.id} to={`/brand?id=${b.id}`}
                  className="flex items-center gap-2 rounded-none text-primary text-xs font-body font-medium transition-colors">
                  {b.logo_url && <img src={b.logo_url} className="w-4 h-4 rounded-none object-cover" alt="" />}
                  {b.name}
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Website */}
        {perfumer.website && (
          <div className="p-5 space-y-2">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>الموقع الإلكتروني Website</h2>
            <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(perfumer.website); }}className="text-primary text-xs font-body hover:underline break-all">
              {perfumer.website}
            </button>
          </div>
        )}

        {/* Education */}
        {perfumer.education && (
          <div className="p-5 space-y-2">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>التعليم Education</h2>
            <p className="text-xs font-body text-foreground/75 leading-relaxed">{perfumer.education}</p>
          </div>
        )}

        {/* Brands from text field (legacy) — only if no DB-linked brands */}
        {linkedBrands.length === 0 && brandList.length > 0 && (
          <div className="p-5 space-y-3">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>العلامات التجارية Associated Brands</h2>
            <div className="flex flex-wrap gap-2">
              {brandList.map((bName) => {
                const brand = brands.find(b => b.name === bName);
                return brand ? (
                  <Link key={bName} to={`/brand?id=${brand.id}`} className=" rounded-none text-primary text-xs font-body font-medium transition-colors">
                    {bName}
                  </Link>
                ) : (
                  <span key={bName} className=" rounded-none text-muted-foreground text-xs font-body">{bName}</span>
                );
              })}
            </div>
          </div>
        )}

        </div>

        {/* Perfumes — linked via perfumer_ids (DB-based) */}
        {linkedPerfumes.length > 0 && (
          <div className="bg-card rounded-none p-5 shadow-sm border border-[var(--brand)] space-y-3">
            <div className="flex items-center gap-2">
              <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>العطور المُنتجة Perfumes Created</h2>
              <span className="text-[10px] text-[#9a7b1f] dark:text-[var(--brand)] rounded-none font-body font-bold ml-auto">{linkedPerfumes.length}</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {linkedPerfumes.slice(0, perfShown).map(p => (
                <Link
                  key={p.id}
                  to={`/perfume?id=${p.id}`}
                  className="flex flex-col gap-1.5 text-left hover:opacity-80 transition-opacity group"
                >
                  <div className="w-full aspect-square rounded-none bg-white overflow-hidden flex items-center justify-center border border-[var(--brand)]">
                    {p.image_url ? (
                      <img src={p.image_url} alt={p.name_en || p.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-white" />
                    )}
                  </div>
                  <div className="px-0.5 space-y-0.5">
                    <p className="text-[11px] font-body font-bold text-foreground line-clamp-2 leading-tight group-hover:underline">{p.name_en || p.name_ar}</p>
                    <p className="text-[9px] text-muted-foreground font-body">{p.brand_name}</p>
                    {p.release_year && <span className="inline-block text-[9px] bg-secondary px-1.5 py-0.5 rounded font-body">{p.release_year}</span>}
                  </div>
                </Link>
              ))}
            </div>
            {linkedPerfumes.length > perfShown && (
              <button
                type="button"
                onClick={() => setPerfShown((n) => n + 60)}
                className="w-full text-center text-xs font-body font-semibold py-2 hover:opacity-70 transition-opacity"
                style={{ color: "var(--brand)" }}
              >
                {isAr ? "اضغط للمزيد" : "Click For More"}
              </button>
            )}
          </div>
        )}

        {/* Perfumes from name field (legacy) — show only if no linked perfumes */}
        {linkedPerfumes.length === 0 && perfumeList.length > 0 && (
          <div className="bg-card rounded-none p-5 shadow-sm border border-[var(--brand)] space-y-3">
            <h2 className="font-heading font-semibold text-sm" style={{ color: "#9a7b1f" }}>العطور المُنتجة Perfumes Created</h2>
            <div className="flex flex-wrap gap-2">
              {perfumeList.map((pName) => {
                const perf = findPerfume(pName);
                return perf ? (
                  <Link key={pName} to={`/perfume?id=${perf.id}`} className=" rounded-none text-[#9a7b1f] dark:text-[var(--brand)] text-xs font-body transition-colors">
                    {pName}
                  </Link>
                ) : (
                  <span key={pName} className=" rounded-none text-muted-foreground text-xs font-body">{pName}</span>
                );
              })}
            </div>
          </div>
        )}

        {/* الإعجاب وعدم الإعجاب — أسفل الصفحة، بلا جداول ولا أطر: ألوان فقط */}
        <div className="space-y-2 pt-1">
          {[
            { person: "person1", label: names.person1, favList: favPerfumersP1, dislikeList: dislikePerfumersP1, favColor: "text-primary", dislikeColor: "text-red-500" },
            { person: "person2", label: names.person2, favList: favPerfumersP2, dislikeList: dislikePerfumersP2, favColor: "text-violet-600", dislikeColor: "text-red-500" },
          ].map(({ person, label, favList, dislikeList, favColor, dislikeColor }) => {
            const isFav = favList.includes(id);
            const isDislike = dislikeList.includes(id);
            return (
              <div key={person} className="space-y-0.5">
                <p className="text-[10px] text-muted-foreground font-body font-semibold uppercase tracking-wide px-0.5">{label}</p>
                <div className="grid grid-cols-2">
                  <button onClick={() => toggleOpinion(person, id, "fav")}
                    style={{ border: "none" }}
                    className={`flex items-center justify-center gap-1.5 py-2 text-xs font-body font-semibold transition-all ${favColor} ${isFav ? "bg-current/10" : "bg-transparent opacity-50 hover:opacity-80"}`}>
                    <Heart className={`w-3.5 h-3.5 ${isFav ? "fill-current" : ""}`} />
                    Favorite
                  </button>
                  <button onClick={() => toggleOpinion(person, id, "dislike")}
                    style={{ border: "none" }}
                    className={`flex items-center justify-center gap-1.5 py-2 text-xs font-body font-semibold transition-all ${dislikeColor} ${isDislike ? "bg-current/10" : "bg-transparent opacity-50 hover:opacity-80"}`}>
                    <HeartOff className="w-3.5 h-3.5" />
                    Don't Like
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer: copy + cast-away icon + notebook + prev/next perfumer */}
        <DetailFooter
          items={sortedPerfumers}
          currentId={perfumer.id}
          pathFor={(p) => `/perfumer?id=${p.id}`}
          labelFor={(p) => p.name || p.name_ar || ""}
          extraActions={
            <>
            <PinButton kind="perfumer" id={id} />
            <button
              type="button"
              title={isAr ? "تعديل العطّار" : "Edit perfumer"}
              aria-label={isAr ? "تعديل العطّار" : "Edit perfumer"}
              onClick={() => setEditOpen(true)}
              className="flex items-center justify-center w-[34px] h-[34px] bg-transparent hover:opacity-70 transition-opacity"
              style={{ color: "#9a7b1f" }}
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              title={isAr ? "نقل إلى المهملات" : "Cast away"}
              aria-label={isAr ? "نقل إلى المهملات" : "Cast away"}
              onClick={async () => { try { await apphost.entities.Perfumer.update(id, { hidden: true }); queryClient.invalidateQueries({ queryKey: ["perfumers"] }); toast.success("نُقل إلى المهملات Moved to Cast Away"); navigate("/perfumers"); } catch (e) { toast.error("تعذّر النقل"); } }}
              className="flex items-center justify-center w-[34px] h-[34px] bg-transparent hover:opacity-70 transition-opacity"
              style={{ color: "#d97706" }}
            >
              <ArchiveX className="w-4 h-4" />
            </button>
            </>
          }
          bookmark={{
            item_type: "perfumer",
            item_id: perfumer.id,
            title_en: perfumer.name || "",
            title_ar: perfumer.name_ar || "",
            subtitle: perfumer.nationality || "",
            path: `/perfumer?id=${perfumer.id}`,
          }}
        />
      </div>

      {/* منبثقة تكبير الصورة — تظهر بالضغط على صورة العطّار فقط */}
      {perfumer.photo_url && (
        <Dialog open={photoOpen} onOpenChange={setPhotoOpen}>
          <DialogContent className="p-0 max-w-[92vw] rounded-none border-0 bg-black/95">
            <img src={perfumer.photo_url} alt={perfumer.name} className="w-full h-auto object-contain max-h-[80vh]" />
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Dialog (delete is offered inside it) */}
      {editOpen && (
        <EditPerfumerDialog
          perfumer={perfumer}
          onSave={(data) => updateMutation.mutate(data)}
          isSaving={updateMutation.isPending}
          onClose={() => setEditOpen(false)}
          onDelete={() => { setEditOpen(false); setDeleteConfirm(true); }}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {deleteConfirm && (
        <Dialog open onOpenChange={setDeleteConfirm}>
          <DialogContent className="max-w-sm rounded-none">
            <DialogHeader>
              <DialogTitle className="font-heading text-red-600">تأكيد الحذف</DialogTitle>
            </DialogHeader>
            <p className="text-sm font-body text-foreground/75">هل أنت متأكد من حذف "{perfumer.name}"؟ هذا الإجراء لا يمكن التراجع عنه.</p>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" className="rounded-none" onClick={() => setDeleteConfirm(false)}>
                إلغاء
              </Button>
              <Button className="rounded-none bg-red-600 hover:bg-red-700" onClick={() => {
                deleteMutation.mutate();
                setDeleteConfirm(false);
              }} disabled={deleteMutation.isPending}>
                {deleteMutation.isPending ? "جاري الحذف.." : "حذف"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function EditPerfumerDialog({ perfumer, onSave, isSaving, onClose, onDelete }) {
  const [form, setForm] = useState({ ...perfumer });
  const [brandSearch, setBrandSearch] = useState("");
  const [showBrandDropdown, setShowBrandDropdown] = useState(false);
  const [perfumeSearch, setPerfumeSearch] = useState("");
  const [showPerfumeDropdown, setShowPerfumeDropdown] = useState(false);
  const [notesSearch, setNotesSearch] = useState("");
  const [showNotesDropdown, setShowNotesDropdown] = useState(false);
  const [searchType, setSearchType] = useState(null);

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfume-pick", perfumeSearch],
    enabled: !!perfumeSearch.trim(),
    staleTime: 1000 * 60 * 5,
    queryFn: async () => {
      const term = perfumeSearch.trim();
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(term);
        return ids.length ? apphost.entities.Perfume.getMany(ids.slice(0, 30)) : [];
      }
      const t = normalizeSearch(term);
      const prefix = String(rankName(t)) + t;
      const { items } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", { lower: prefix, upper: prefix + "\uffff" }, 0, 30, "next", false
      );
      return items || [];
    },
  });

  const { data: notes = [] } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  const selectedBrands = toList(form.brand_names);
  const filteredBrands = brandSearch ? brands.filter(b => b.name.toLowerCase().includes(brandSearch.toLowerCase())) : [];

  const selectedFamous = toList(form.famous_works);
  const filteredFamous = perfumeSearch ? perfumes.filter(p => normalizeSearch([p.name_en, p.name_ar, p.name].filter(Boolean).join(" ")).includes(normalizeSearch(perfumeSearch))) : [];

  const selectedFavPerfumes = toList(form.favorite_perfumes);

  const selectedFavNotes = toList(form.favorite_notes);
  const filteredNotes = notesSearch ? notes.filter(n => n.name.toLowerCase().includes(notesSearch.toLowerCase())) : [];

  const selectedCreated = toList(form.perfume_names);

  const addBrand = (brand) => {
    if (!selectedBrands.includes(brand.name)) {
      setForm({ ...form, brand_names: selectedBrands.length > 0 ? `${form.brand_names || ""}, ${brand.name}` : brand.name });
    }
    setBrandSearch("");
    setShowBrandDropdown(false);
  };

  const removeBrand = (brandName) => {
    const updated = selectedBrands.filter(b => b !== brandName).join(", ");
    setForm({ ...form, brand_names: updated });
  };

  const addFamous = (perfume) => {
    const name = perfume.name_en || perfume.name_ar;
    if (!selectedFamous.includes(name)) {
      setForm({ ...form, famous_works: selectedFamous.length > 0 ? `${form.famous_works || ""}, ${name}` : name });
    }
    setPerfumeSearch("");
    setShowPerfumeDropdown(false);
  };

  const removeFamous = (workName) => {
    const updated = selectedFamous.filter(w => w !== workName).join(", ");
    setForm({ ...form, famous_works: updated });
  };

  const addFavPerfume = (perfume) => {
    const name = perfume.name_en || perfume.name_ar;
    if (!selectedFavPerfumes.includes(name)) {
      setForm({ ...form, favorite_perfumes: selectedFavPerfumes.length > 0 ? `${form.favorite_perfumes || ""}, ${name}` : name });
    }
    setPerfumeSearch("");
    setShowPerfumeDropdown(false);
  };

  const removeFavPerfume = (perfName) => {
    const updated = selectedFavPerfumes.filter(p => p !== perfName).join(", ");
    setForm({ ...form, favorite_perfumes: updated });
  };

  const addFavNote = (note) => {
    if (!selectedFavNotes.includes(note.name)) {
      setForm({ ...form, favorite_notes: selectedFavNotes.length > 0 ? `${form.favorite_notes || ""}, ${note.name}` : note.name });
    }
    setNotesSearch("");
    setShowNotesDropdown(false);
  };

  const removeFavNote = (noteName) => {
    const updated = selectedFavNotes.filter(n => n !== noteName).join(", ");
    setForm({ ...form, favorite_notes: updated });
  };

  const addCreated = (perfume) => {
    const name = perfume.name_en || perfume.name_ar;
    if (!selectedCreated.includes(name)) {
      setForm({ ...form, perfume_names: selectedCreated.length > 0 ? `${form.perfume_names || ""}, ${name}` : name });
    }
    setPerfumeSearch("");
    setShowPerfumeDropdown(false);
  };

  const removeCreated = (perfName) => {
    const updated = selectedCreated.filter(p => p !== perfName).join(", ");
    setForm({ ...form, perfume_names: updated });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-sm rounded-none max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading">Edit {perfumer.name}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-body">الاسم بالإنجليزية Name (EN)</Label>
              <Input value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} className="rounded-none font-body" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">الاسم (AR)</Label>
              <Input value={form.name_ar || ""} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} className="rounded-none font-body" dir="rtl" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-body">الجنسية Nationality</Label>
              <Input value={form.nationality || ""} onChange={(e) => setForm({ ...form, nationality: e.target.value })} className="rounded-none font-body" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">سنة الميلاد Birth Year</Label>
              <Input type="number" value={form.birth_year || ""} onChange={(e) => setForm({ ...form, birth_year: Number(e.target.value) || undefined })} className="rounded-none font-body" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-body">سنة الوفاة Death Year</Label>
              <Input type="number" value={form.death_year || ""} onChange={(e) => setForm({ ...form, death_year: Number(e.target.value) || undefined })} placeholder="(optional)" className="rounded-none font-body" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">الفئة Gender</Label>
              <div className="flex gap-1">
                {["Male", "Female"].map((g) => (
                  <button key={g} type="button" onClick={() => setForm({ ...form, gender: g })}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${form.gender === g ? (g === "Female" ? "bg-pink-500 text-white" : "bg-blue-900 text-white") : "bg-secondary text-muted-foreground"}`}>
                    {g}
                  </button>
                ))}
              </div>
            </div>
          </div>
          {/* Famous Works with search */}
          <div className="space-y-1.5">
            <Label className="text-xs font-body">أشهر الأعمال Famous Works</Label>
            <div className="relative">
              <div className="flex gap-1 flex-wrap mb-2 p-2 bg-secondary/30 rounded-none min-h-[36px]">
                {selectedFamous.map(w => (
                  <span key={w} className="flex items-center gap-1 text-amber-900 text-xs rounded-none font-body">
                    {w}
                    <button type="button" onClick={() => removeFamous(w)} className="hover:opacity-70">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                <input name="PerfumerDetail-1"
                  type="text"
                  value={searchType === 'famous' ? perfumeSearch : ""}
                  onChange={(e) => {
                    setPerfumeSearch(e.target.value);
                    setSearchType('famous');
                    setShowPerfumeDropdown(true);
                  }}
                  onFocus={() => {
                    setSearchType('famous');
                    setShowPerfumeDropdown(true);
                  }}
                  placeholder="ابحث عن عطر... / Search perfumes.."
                  className="flex-1 bg-transparent text-xs outline-none font-body"
                />
              </div>
              {showPerfumeDropdown && searchType === 'famous' && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-none shadow-lg max-h-48 overflow-y-auto z-50">
                  {filteredFamous.length > 0 ? (
                    filteredFamous.map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => addFamous(p)}
                        className="w-full text-left px-3 py-2 hover:bg-secondary/50 text-xs font-body flex items-center gap-2 border-b border-border/30"
                      >
                        {p.image_url && <img src={p.image_url} alt="" className="w-4 h-4 rounded object-cover" />}
                        {p.name_en || p.name_ar}
                      </button>
                    ))
                  ) : (
                    <div className="px-3 py-2 text-xs text-muted-foreground font-body">لا عطور No perfumes found</div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Favorite Perfumes with search */}
          <div className="space-y-1.5">
            <Label className="text-xs font-body">⭐ Favorite Perfumes</Label>
            <div className="relative">
              <div className="flex gap-1 flex-wrap mb-2 p-2 bg-secondary/30 rounded-none min-h-[36px]">
                {selectedFavPerfumes.map(p => (
                  <span key={p} className="flex items-center gap-1 text-rose-900 text-xs rounded-none font-body">
                    {p}
                    <button type="button" onClick={() => removeFavPerfume(p)} className="hover:opacity-70">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                <input name="PerfumerDetail-2"
                  type="text"
                  value={searchType === 'favorite' ? perfumeSearch : ""}
                  onChange={(e) => {
                    setPerfumeSearch(e.target.value);
                    setSearchType('favorite');
                    setShowPerfumeDropdown(true);
                  }}
                  onFocus={() => {
                    setSearchType('favorite');
                    setShowPerfumeDropdown(true);
                  }}
                  placeholder="ابحث عن عطر... / Search perfumes.."
                  className="flex-1 bg-transparent text-xs outline-none font-body"
                />
              </div>
              {showPerfumeDropdown && searchType === 'favorite' && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-none shadow-lg max-h-48 overflow-y-auto z-50">
                  {filteredFamous.length > 0 ? (
                    filteredFamous.map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => addFavPerfume(p)}
                        className="w-full text-left px-3 py-2 hover:bg-secondary/50 text-xs font-body flex items-center gap-2 border-b border-border/30"
                      >
                        {p.image_url && <img src={p.image_url} alt="" className="w-4 h-4 rounded object-cover" />}
                        {p.name_en || p.name_ar}
                      </button>
                    ))
                  ) : (
                    <div className="px-3 py-2 text-xs text-muted-foreground font-body">لا عطور No perfumes found</div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Favorite Notes with search */}
          <div className="space-y-1.5">
            <Label className="text-xs font-body">✨ Favorite Notes</Label>
            <div className="relative">
              <div className="flex gap-1 flex-wrap mb-2 p-2 bg-secondary/30 rounded-none min-h-[36px]">
                {selectedFavNotes.map(n => (
                  <span key={n} className="flex items-center gap-1 text-green-900 text-xs rounded-none font-body">
                    {n}
                    <button type="button" onClick={() => removeFavNote(n)} className="hover:opacity-70">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                <input name="PerfumerDetail-3"
                  type="text"
                  value={searchType === 'notes' ? notesSearch : ""}
                  onChange={(e) => {
                    setNotesSearch(e.target.value);
                    setSearchType('notes');
                    setShowNotesDropdown(true);
                  }}
                  onFocus={() => {
                    setSearchType('notes');
                    setShowNotesDropdown(true);
                  }}
                  placeholder="ابحث عن نوتات Search notes.."
                  className="flex-1 bg-transparent text-xs outline-none font-body"
                />
              </div>
              {showNotesDropdown && searchType === 'notes' && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-none shadow-lg max-h-48 overflow-y-auto z-50">
                  {filteredNotes.length > 0 ? (
                    filteredNotes.map(n => (
                      <button
                        key={n.id}
                        type="button"
                        onClick={() => addFavNote(n)}
                        className="w-full text-left px-3 py-2 hover:bg-secondary/50 text-xs font-body border-b border-border/30"
                      >
                        {n.name}
                      </button>
                    ))
                  ) : (
                    <div className="px-3 py-2 text-xs text-muted-foreground font-body">لا نوتات No notes found</div>
                  )}
                </div>
              )}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">البراندات Brands</Label>
            <div className="relative">
              <div className="flex gap-1 flex-wrap mb-2 p-2 bg-secondary/30 rounded-none min-h-[36px]">
                {selectedBrands.map(b => (
                  <span key={b} className="flex items-center gap-1 text-primary text-xs rounded-none font-body">
                    {b}
                    <button type="button" onClick={() => removeBrand(b)} className="hover:opacity-70">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                <input name="PerfumerDetail-4"
                  type="text"
                  value={brandSearch}
                  onChange={(e) => {
                    setBrandSearch(e.target.value);
                    setShowBrandDropdown(true);
                  }}
                  onFocus={() => setShowBrandDropdown(true)}
                  placeholder="ابحث عن براندات Search brands.."
                  className="flex-1 bg-transparent text-xs outline-none font-body"
                />
              </div>
              {showBrandDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-none shadow-lg max-h-48 overflow-y-auto z-50">
                  {filteredBrands.length > 0 ? (
                    filteredBrands.map(b => (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => addBrand(b)}
                        className="w-full text-left px-3 py-2 hover:bg-secondary/50 text-xs font-body flex items-center gap-2 border-b border-border/30"
                      >
                        {b.logo_url && <img src={b.logo_url} alt="" className="w-4 h-4 rounded-none object-cover" />}
                        {b.name}
                      </button>
                    ))
                  ) : (
                    <div className="px-3 py-2 text-xs text-muted-foreground font-body">لا براندات No brands found</div>
                  )}
                </div>
              )}
            </div>
          </div>
          {/* Perfumes Created with search */}
          <div className="space-y-1.5">
            <Label className="text-xs font-body">العطور المنشأة Perfumes Created</Label>
            <div className="relative">
              <div className="flex gap-1 flex-wrap mb-2 p-2 bg-secondary/30 rounded-none min-h-[36px]">
                {selectedCreated.map(p => (
                  <span key={p} className="flex items-center gap-1 text-amber-900 text-xs rounded-none font-body">
                    {p}
                    <button type="button" onClick={() => removeCreated(p)} className="hover:opacity-70">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
                <input name="PerfumerDetail-5"
                  type="text"
                  value={searchType === 'created' ? perfumeSearch : ""}
                  onChange={(e) => {
                    setPerfumeSearch(e.target.value);
                    setSearchType('created');
                    setShowPerfumeDropdown(true);
                  }}
                  onFocus={() => {
                    setSearchType('created');
                    setShowPerfumeDropdown(true);
                  }}
                  placeholder="ابحث عن عطر... / Search perfumes.."
                  className="flex-1 bg-transparent text-xs outline-none font-body"
                />
              </div>
              {showPerfumeDropdown && searchType === 'created' && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-none shadow-lg max-h-48 overflow-y-auto z-50">
                  {filteredFamous.length > 0 ? (
                    filteredFamous.map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => addCreated(p)}
                        className="w-full text-left px-3 py-2 hover:bg-secondary/50 text-xs font-body flex items-center gap-2 border-b border-border/30"
                      >
                        {p.image_url && <img src={p.image_url} alt="" className="w-4 h-4 rounded object-cover" />}
                        {p.name_en || p.name_ar}
                      </button>
                    ))
                  ) : (
                    <div className="px-3 py-2 text-xs text-muted-foreground font-body">لا عطور No perfumes found</div>
                  )}
                </div>
              )}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">نبذة Bio</Label>
            <Textarea value={form.bio || ""} onChange={(e) => setForm({ ...form, bio: e.target.value })} className="rounded-none font-body min-h-[72px]" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">🌐 Website (optional)</Label>
            <Input value={form.website || ""} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://.." className="rounded-none font-body" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">🎓 Education (optional)</Label>
            <Textarea value={form.education || ""} onChange={(e) => setForm({ ...form, education: e.target.value })} placeholder="e.g. ISIPCA, apprentice of.." className="rounded-none font-body min-h-[56px]" />
          </div>
          <div className="space-y-2">
            <Button className="w-full rounded-none font-body bg-green-800 hover:bg-green-900" onClick={() => onSave(form)} disabled={isSaving}>
              {isSaving ? "Saving.." : "Save Changes"}
            </Button>
            <button 
              type="button"
              onClick={onDelete}
              className="w-full rounded-none text-xs font-body font-medium text-red-600 dark:text-red-400 dark:hover:bg-red-900/50 transition-colors"
            >
              حذف العطار
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
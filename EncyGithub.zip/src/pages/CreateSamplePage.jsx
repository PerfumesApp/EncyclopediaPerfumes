import { useState, useMemo, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Plus, Trash2, Search, X, ChevronRight, Save } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { accordColor } from "@/lib/accordColors";
import BackIcon from "@/components/shared/BackIcon";

/**
 * /create-sample — in-app perfume composition ("Create Perfume").
 * Standalone (not tied to a perfumer). Structure:
 *   Project (perfume name) → many samples → each sample is a list of notes
 *   with phase (top/heart/base) + percentage + ml, plus free notes and an
 *   "invented note". Notes are pulled from the PerfumeNote database (fetched
 *   once, filtered client-side to avoid per-keystroke DB load). The accord/
 *   harmony is computed from the chosen notes' odor families. Every sample
 *   and edit is persisted in localStorage, so the user can return and revise.
 */
const KEY = "perfumeProjects";
const loadProjects = () => { try { return JSON.parse(localStorage.getItem(KEY) || "[]"); } catch { return []; } };
const saveProjects = (arr) => { try { localStorage.setItem(KEY, JSON.stringify(arr)); } catch (e) { console.error(e); } };
const uid = (p) => `${p}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

const PHASES = [
  { key: "top",   ar: "مقدمة", en: "Top",   color: "#185FA5", bg: "#E6F1FB" },
  { key: "heart", ar: "قلب",      en: "Heart", color: "#993556", bg: "#FBEAF0" },
  { key: "base",  ar: "أساس",     en: "Base",  color: "#854F0B", bg: "#FAEEDA" },
];
// Researched pyramid templates (top/heart/base % targets).
const TEMPLATES = [
  { key: "general",  ar: "عام",   top: 30, heart: 45, base: 25 },
  { key: "citrus",   ar: "حمضي",  top: 40, heart: 40, base: 20 },
  { key: "oriental", ar: "شرقي",  top: 20, heart: 35, base: 45 },
  { key: "fougere",  ar: "فوجير", top: 30, heart: 20, base: 50 },
];

export default function CreateSamplePage() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [projects, setProjects] = useState(loadProjects);
  const [activeProjectId, setActiveProjectId] = useState(null);
  const [activeSampleId, setActiveSampleId] = useState(null);
  const [search, setSearch] = useState("");

  // Fetch all notes ONCE; filter client-side (no per-keystroke DB query).
  const { data: allNotes = [] } = useQuery({
    queryKey: ["perfume-notes-for-create"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 10 * 60 * 1000,
  });

  useEffect(() => { saveProjects(projects); }, [projects]);

  const activeProject = projects.find((p) => p.id === activeProjectId) || null;
  const activeSample = activeProject?.samples?.find((s) => s.id === activeSampleId) || null;

  // ---- Project ops ----
  const addProject = () => {
    const name = prompt(isAr ? "اسم العطر / المشروع" : "Perfume / project name");
    if (!name) return;
    const proj = { id: uid("proj"), name: name.trim(), created_at: new Date().toISOString(), samples: [] };
    setProjects((p) => [proj, ...p]);
    setActiveProjectId(proj.id);
  };
  const deleteProject = (id) => {
    if (!confirm(isAr ? "حذف المشروع وكل عيّناته؟" : "Delete project and all samples?")) return;
    setProjects((p) => p.filter((x) => x.id !== id));
    if (activeProjectId === id) setActiveProjectId(null);
  };

  // ---- Sample ops ----
  const addSample = () => {
    const n = (activeProject.samples?.length || 0) + 1;
    const sample = {
      id: uid("smp"),
      label: isAr ? `العينة ${n}` : `Sample ${n}`,
      notes: [], invented_note: "", notes_text: "",
      created_at: new Date().toISOString(), updated_at: new Date().toISOString(),
    };
    setProjects((ps) => ps.map((p) => p.id === activeProjectId ? { ...p, samples: [sample, ...(p.samples || [])] } : p));
    setActiveSampleId(sample.id);
  };
  const deleteSample = (sid) => {
    if (!confirm(isAr ? "حذف العيّنة؟" : "Delete sample?")) return;
    setProjects((ps) => ps.map((p) => p.id === activeProjectId ? { ...p, samples: p.samples.filter((s) => s.id !== sid) } : p));
    if (activeSampleId === sid) setActiveSampleId(null);
  };
  const updateSample = (patch) => {
    setProjects((ps) => ps.map((p) => p.id === activeProjectId ? {
      ...p,
      samples: p.samples.map((s) => s.id === activeSampleId ? { ...s, ...patch, updated_at: new Date().toISOString() } : s),
    } : p));
  };

  // ---- Note ops within active sample ----
  const addNote = (note, phase) => {
    const entry = { id: uid("n"), name: note.name, name_ar: note.name_ar || "", odor_family: note.odor_family || "", phase, percent: 0, ml: 0 };
    updateSample({ notes: [...(activeSample.notes || []), entry] });
    setSearch("");
  };
  const updateNote = (nid, patch) => {
    updateSample({ notes: activeSample.notes.map((n) => n.id === nid ? { ...n, ...patch } : n) });
  };
  const removeNote = (nid) => updateSample({ notes: activeSample.notes.filter((n) => n.id !== nid) });

  // ---- Search notes (client-side) ----
  const searchResults = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return [];
    return allNotes.filter((n) =>
      (n.name || "").toLowerCase().includes(q) || (n.name_ar || "").includes(search)
    ).slice(0, 12);
  }, [search, allNotes]);

  // ---- Accord (harmony) computed from notes' odor families ----
  const accord = useMemo(() => {
    if (!activeSample?.notes?.length) return [];
    const map = {};
    activeSample.notes.forEach((n) => {
      const fam = (n.odor_family || "").split(",")[0].trim();
      if (!fam) return;
      map[fam] = (map[fam] || 0) + (Number(n.percent) || 1);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [activeSample]);

  const phaseTotals = useMemo(() => {
    const t = { top: 0, heart: 0, base: 0 };
    (activeSample?.notes || []).forEach((n) => { t[n.phase] = (t[n.phase] || 0) + (Number(n.percent) || 0); });
    return t;
  }, [activeSample]);

  // ============ RENDER ============

  // --- Sample editor ---
  if (activeProject && activeSample) {
    const maxAccord = Math.max(1, ...accord.map(([, v]) => v));
    return (
      <div className="px-4 pt-10 pb-16 max-w-full">
        <div className="flex items-center gap-2 mb-4">
          <button onClick={() => setActiveSampleId(null)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40"><BackIcon className="w-5 h-5" /></button>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] text-muted-foreground font-body truncate">{activeProject.name}</p>
            <input name="CreateSamplePage-1" value={activeSample.label} onChange={(e) => updateSample({ label: e.target.value })}
              className="font-heading text-lg font-bold bg-transparent border-0 focus:outline-none w-full" />
          </div>
          <button onClick={() => deleteSample(activeSample.id)} className="w-8 h-8 rounded-none flex items-center justify-center text-red-500 hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
        </div>

        {/* Pyramid template hints */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {TEMPLATES.map((t) => (
            <span key={t.key} className="text-[10px] font-body rounded-none text-muted-foreground">
              {t.ar}: {t.top}/{t.heart}/{t.base}
            </span>
          ))}
        </div>

        {/* Note search */}
        <div className="relative mb-2">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input name="CreateSamplePage-2" value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder={isAr ? "ابحث عن نوتة لإضافتها" : "Search a note to add"}
            className="w-full pl-10 pr-9 h-11 rounded-none font-body bg-secondary/50 border-0 text-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand)]/40" />
          
        </div>
        {searchResults.length > 0 && (
          <div className="mb-3 rounded-none border border-border/60 overflow-hidden">
            {searchResults.map((n) => (
              <div key={n.id} className="flex items-center justify-between px-3 py-2 border-b border-border/40 last:border-0">
                <span className="text-sm font-body">{n.name}{n.name_ar ? ` — ${n.name_ar}` : ""}</span>
                <div className="flex gap-1">
                  {PHASES.map((ph) => (
                    <button key={ph.key} onClick={() => addNote(n, ph.key)}
                      className="text-[10px] font-body px-2 py-1 rounded-none" style={{ background: ph.bg, color: ph.color }}>
                      + {ph.ar}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Notes by phase with percent + ml */}
        {PHASES.map((ph) => {
          const notes = (activeSample.notes || []).filter((n) => n.phase === ph.key);
          if (!notes.length) return null;
          return (
            <div key={ph.key} className="mb-3">
              <p className="text-xs font-body font-bold mb-1.5" style={{ color: ph.color }}>{ph.ar} — {phaseTotals[ph.key]}%</p>
              <div className="space-y-1.5">
                {notes.map((n) => (
                  <div key={n.id} className="flex items-center gap-2 rounded-none px-2 py-1.5" style={{ background: ph.bg + "55" }}>
                    <span className="flex-1 text-xs font-body truncate">{n.name}{n.name_ar ? ` — ${n.name_ar}` : ""}</span>
                    <input name="CreateSamplePage-3" type="number" value={n.percent || ""} onChange={(e) => updateNote(n.id, { percent: e.target.value })} placeholder="%"
                      className="w-12 h-8 rounded-none bg-white/70 border border-border/50 text-xs text-center focus:outline-none" />
                    <input name="CreateSamplePage-4" type="number" value={n.ml || ""} onChange={(e) => updateNote(n.id, { ml: e.target.value })} placeholder="ml"
                      className="w-12 h-8 rounded-none bg-white/70 border border-border/50 text-xs text-center focus:outline-none" />
                    <button onClick={() => removeNote(n.id)} className="text-red-400 hover:text-red-600"><X className="w-4 h-4" /></button>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Computed accord / harmony */}
        {accord.length > 0 && (
          <div className="mb-3">
            <p className="text-xs font-body font-bold text-muted-foreground mb-2">{isAr ? "التناغم المحسوب" : "Computed Harmony"}</p>
            <div className="space-y-1.5">
              {accord.map(([fam, v]) => (
                <div key={fam} className="flex items-center gap-2">
                  <span className="w-16 text-[10px] font-body truncate" style={{ color: accordColor(fam) }}>{fam}</span>
                  <span className="h-2 rounded-none" style={{ width: `${(v / maxAccord) * 70}%`, background: accordColor(fam) }} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Invented note */}
        <div className="mb-3">
          <label className="text-xs font-body font-bold text-muted-foreground">{isAr ? "النوتة المبتكرة" : "Invented Note"}</label>
          <input name="CreateSamplePage-5" value={activeSample.invented_note || ""} onChange={(e) => updateSample({ invented_note: e.target.value })}
            placeholder={isAr ? "اسم نوتتك المبتكرة" : "Your invented note name"}
            className="w-full mt-1 h-10 rounded-none font-body bg-secondary/50 border-0 px-3 text-sm focus:outline-none" />
        </div>

        {/* Notes / remarks */}
        <div className="mb-3">
          <label className="text-xs font-body font-bold text-muted-foreground">{isAr ? "ملاحظات" : "Notes"}</label>
          <textarea name="CreateSamplePage-tex1" value={activeSample.notes_text || ""} onChange={(e) => updateSample({ notes_text: e.target.value })}
            placeholder={isAr ? "ملاحظاتك على العيّنة" : "Your remarks on the sample"}
            className="w-full mt-1 rounded-none font-body bg-secondary/50 border-0 px-3 py-2 text-sm min-h-[70px] focus:outline-none" />
        </div>

        <p className="text-[10px] text-center text-muted-foreground font-body flex items-center justify-center gap-1">
          <Save className="w-3 h-3" /> {isAr ? "يُحفظ تلقائياً" : "Auto-saved"}
        </p>
      </div>
    );
  }

  // --- Samples list of a project ---
  if (activeProject) {
    return (
      <div className="px-4 pt-10 pb-16">
        <div className="flex items-center gap-2 mb-4">
          <button onClick={() => setActiveProjectId(null)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40"><BackIcon className="w-5 h-5" /></button>
          <h1 className="font-heading text-xl font-bold flex-1 min-w-0 truncate">{activeProject.name}</h1>
          <button onClick={addSample} className="text-xs font-body px-3 py-1.5 rounded-none bg-[var(--brand)] text-white flex items-center gap-1"><Plus className="w-3 h-3" /> {isAr ? "عيّنة" : "Sample"}</button>
        </div>
        {(activeProject.samples || []).length === 0 ? (
          <p className="text-center text-sm text-muted-foreground font-body py-16">{isAr ? "لا عيّنات بعد" : "No samples yet"}</p>
        ) : (
          <div className="space-y-2">
            {activeProject.samples.map((s) => (
              <button key={s.id} onClick={() => setActiveSampleId(s.id)}
                className="w-full flex items-center justify-between px-4 py-3 rounded-none bg-secondary/40 hover:bg-secondary/70 transition-colors text-right">
                <div className="min-w-0">
                  <p className="text-sm font-body font-medium truncate">{s.label}</p>
                  <p className="text-[10px] text-muted-foreground font-body">{(s.notes || []).length} {isAr ? "نوتة" : "notes"}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground rtl:rotate-180" />
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  // --- Projects list ---
  return (
    <div className="px-4 pt-10 pb-16">
      <div className="flex items-center gap-2 mb-4">
        <button onClick={() => navigate("/perfumers")} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40"><BackIcon className="w-5 h-5" /></button>
        <h1 className="font-heading text-xl font-bold flex-1 flex items-center gap-2">{isAr ? "صناعة العطر" : "Create Perfume"}</h1>
        <button onClick={addProject} className="text-xs font-body px-3 py-1.5 rounded-none bg-[var(--brand)] text-white flex items-center gap-1"><Plus className="w-3 h-3" /> {isAr ? "مشروع" : "Project"}</button>
      </div>
      {projects.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground font-body py-16">{isAr ? "ابدأ بإنشاء مشروع عطر" : "Start by creating a perfume project"}</p>
      ) : (
        <div className="space-y-2">
          {projects.map((p) => (
            <div key={p.id} className="flex items-center gap-2">
              <button onClick={() => setActiveProjectId(p.id)}
                className="flex-1 flex items-center justify-between px-4 py-3 rounded-none bg-secondary/40 hover:bg-secondary/70 transition-colors text-right min-w-0">
                <div className="min-w-0">
                  <p className="text-sm font-body font-medium truncate">{p.name}</p>
                  <p className="text-[10px] text-muted-foreground font-body">{(p.samples || []).length} {isAr ? "عيّنة" : "samples"}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground rtl:rotate-180" />
              </button>
              <button onClick={() => deleteProject(p.id)} className="w-8 h-8 rounded-none flex items-center justify-center text-red-400 hover:bg-red-50"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

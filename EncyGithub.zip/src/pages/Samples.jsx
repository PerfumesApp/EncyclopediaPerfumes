import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Download } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { useLang } from "@/lib/LanguageContext";
import { cn } from "@/lib/utils";
import { openHtmlReport } from "@/lib/exportHelper";
import BackIcon from "@/components/shared/BackIcon";

export default function Samples() {
  const urlParams = new URLSearchParams(window.location.search);
  const defaultPerson = urlParams.get("person") || "all";
  const [activePerson, setActivePerson] = useState(defaultPerson);
  const [showSamples, setShowSamples] = useState(25);
  const [showBottles, setShowBottles] = useState(25);
  const [sortBy, setSortBy] = useState("newest");
  const navigate = useNavigate();
  const { names, profiles } = usePersonNames();
  const { formatPrice } = useCurrency();
  const { isAr } = useLang();

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: purchases = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
  });

  const personData = activePerson === "all" ? userPerfumes : userPerfumes.filter((u) => u.person === activePerson);
  const personPurchases = activePerson === "all" ? purchases : purchases.filter((p) => p.person === activePerson);
  
  const sortedPurchases = useMemo(() => {
    const sorted = [...personPurchases];
    if (sortBy === "newest") sorted.sort((a, b) => new Date(b.purchase_date) - new Date(a.purchase_date));
    else if (sortBy === "oldest") sorted.sort((a, b) => new Date(a.purchase_date) - new Date(b.purchase_date));
    else if (sortBy === "highest") sorted.sort((a, b) => b.cost - a.cost);
    else if (sortBy === "lowest") sorted.sort((a, b) => a.cost - b.cost);
    return sorted;
  }, [personPurchases, sortBy]);
  
  const samplePurchases = sortedPurchases.filter((p) => p.type === "sample");
  const bottlePurchases = sortedPurchases.filter((p) => p.type === "bottle");
  
  const totalSampleVolume = samplePurchases.reduce((sum, p) => sum + (p.ml || 0), 0);
  const totalSampleCost = samplePurchases.reduce((sum, p) => sum + (p.cost || 0), 0);
  
  const totalBottleVolume = bottlePurchases.reduce((sum, p) => sum + (p.ml || 0), 0);
  const totalBottleCost = bottlePurchases.reduce((sum, p) => sum + (p.cost || 0), 0);
  
  const combinedTotalVolume = totalSampleVolume + totalBottleVolume;
  const combinedTotalCost = totalSampleCost + totalBottleCost;
  const avgCostPerMl = combinedTotalVolume > 0 ? (combinedTotalCost / combinedTotalVolume).toFixed(2) : 0;

  // تصدير مخصّص للعينات — بلا إطارات/خلفيات، بلون ملف المستخدم، بلا أيقونات
  const handleExportSamples = async () => {
    const root = typeof getComputedStyle !== "undefined" ? getComputedStyle(document.documentElement) : null;
    const brand = ((root && root.getPropertyValue("--brand")) || "#C8A02E").trim() || "#C8A02E";
    const p1 = profiles?.person1?.color || brand;
    const p2 = profiles?.person2?.color || "#9D174D";
    const colorOf = (person) => profiles?.[person]?.color || brand;
    const accent = activePerson === "person1" ? p1 : activePerson === "person2" ? p2 : brand;
    const who = activePerson === "all" ? (isAr ? "جميع الملفات" : "All Profiles") : activePerson === "person1" ? names.person1 : names.person2;
    const rows = (list, kindAr, kindEn) => list.map((p) => {
      const c = colorOf(p.person);
      return `<tr>
      <td>
        <span class="nm" style="color:${c}">${p.perfume_name || ""}</span>
        ${p.brand_name ? '<span class="br">' + p.brand_name + "</span>" : ""}
      </td>
      <td class="ctr">${isAr ? kindAr : kindEn}</td>
      <td class="ctr">${p.ml || 0}ml</td>
      <td class="ctr">${formatPrice((p.cost || 0).toFixed(0))}</td>
      <td class="ctr">${p.ml ? formatPrice((p.cost / p.ml).toFixed(2)) : "-"}</td>
      <td class="ctr">${p.purchase_date ? new Date(p.purchase_date).toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "numeric" }) : "-"}</td>
    </tr>`;
    }).join("");
    const head = `<tr><th>${isAr ? "العطر Perfume" : "Perfume"}</th><th>${isAr ? "النوع" : "Type"}</th><th>${isAr ? "الحجم" : "Volume"}</th><th>${isAr ? "التكلفة" : "Cost"}</th><th>${isAr ? "للمل" : "/ml"}</th><th>${isAr ? "التاريخ" : "Date"}</th></tr>`;
    await openHtmlReport(`<!DOCTYPE html>
<html dir="${isAr ? "rtl" : "ltr"}" lang="${isAr ? "ar" : "en"}">
<head>
  <meta charset="utf-8"/>
  <title>Samples العينات</title>
  <style>
    @font-face { font-family: 'Cairo'; src: url('/fonts/Cairo.woff') format('woff'); font-weight: 400 800; font-display: swap; }
    @font-face { font-family: 'Amiri'; src: url('/fonts/Amiri.woff') format('woff'); font-weight: 400 700; font-display: swap; }
    * { box-sizing: border-box; }
    body { font-family: 'Cairo','Segoe UI',Arial,sans-serif; direction: ${isAr ? "rtl" : "ltr"}; padding: 32px; color: #2a2926; background: #fff; font-size: 13px; line-height: 1.7; }
    h1 { font-size: 24px; font-weight: 800; text-align: center; margin-bottom: 2px; color: ${accent}; letter-spacing: -0.3px; }
    .subtitle { text-align: center; color: ${accent}; opacity: .75; margin-bottom: 22px; font-size: 12px; }
    .secttl { margin: 22px 0 2px; font-size: 14px; font-weight: 800; color: ${accent}; }
    table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 4px; }
    th { padding: 7px 12px; text-align: ${isAr ? "right" : "left"}; font-weight: 700; font-size: 11px; color: ${accent}; opacity: .8; }
    td { padding: 7px 12px; vertical-align: top; }
    .ctr { text-align: center; white-space: nowrap; }
    .nm { font-weight: 700; font-size: 13px; display: block; }
    .br { color: #8a8580; font-size: 11px; display: block; margin-top: 1px; }
    .tot { margin-top: 8px; font-size: 12px; color: #555; text-align: ${isAr ? "left" : "right"}; }
    .tot b { color: ${accent}; }
    @media print { body { padding: 18px; } @page { margin: 1.2cm; size: A4; } }
  </style>
</head>
<body>
<h1>${isAr ? "العينات" : "Samples"}</h1>
<div class="subtitle">${who} — ${isAr ? "العينات و القنينات" : "Samples & Bottles"}</div>
${samplePurchases.length ? `<div class="secttl">${isAr ? "العينات" : "Samples"} (${samplePurchases.length})</div><table>${head}${rows(samplePurchases, "عينة", "Sample")}</table>
<div class="tot">${isAr ? "إجمالي العينات" : "Samples total"}: <b>${formatPrice(totalSampleCost.toFixed(0))}</b> — ${totalSampleVolume}ml</div>` : ""}
${bottlePurchases.length ? `<div class="secttl">${isAr ? "القنينات" : "Bottles"} (${bottlePurchases.length})</div><table>${head}${rows(bottlePurchases, "قنينة", "Bottle")}</table>
<div class="tot">${isAr ? "إجمالي القنينات" : "Bottles total"}: <b>${formatPrice(totalBottleCost.toFixed(0))}</b> — ${totalBottleVolume}ml</div>` : ""}
<div class="tot" style="margin-top:16px;font-size:13px;">${isAr ? "الإجمالي الكلي" : "Grand total"}: <b>${formatPrice(combinedTotalCost.toFixed(0))}</b> — ${combinedTotalVolume}ml — ${isAr ? "للمل" : "per ml"} ${formatPrice(avgCostPerMl)}</div>
</body></html>`, "samples");
  };

  const colorOf = (person) => profiles?.[person]?.color || "var(--brand)";
  const PurchaseLine = ({ p }) => (
    <button type="button" onClick={() => navigate(`/perfume?id=${p.perfume_id}`)} className="flex items-start gap-3 py-2 w-full text-start bg-transparent hover:opacity-70 transition-opacity">
      <span aria-hidden style={{ display: "inline-block", width: 20, height: 3, background: colorOf(p.person), flexShrink: 0, marginTop: 9 }} />
      <span style={{ minWidth: 0 }}>
        <span className="font-heading block" style={{ fontSize: 15, color: "var(--foreground, #2A2024)", lineHeight: 1.3 }}>{p.perfume_name}</span>
        {(p.brand_name || p.ml || p.cost) && (
          <span className="font-body block" style={{ fontSize: 11, color: "#A98B97", marginTop: 1 }}>
            {[p.brand_name, p.ml ? `${p.ml}ml` : "", p.cost ? formatPrice(Number(p.cost).toFixed(0)) : ""].filter(Boolean).join(" · ")}
          </span>
        )}
      </span>
    </button>
  );

  return (
    <div className="pb-4">
      {/* Header */}
      <div className="px-4 page-top pb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 flex items-center justify-center bg-transparent hover:opacity-70 transition-opacity"
          >
            <BackIcon className="w-4 h-4" />
          </button>
          <div>
            <h1 className="font-heading text-xl font-bold">{isAr ? "عينات" : "Samples"}</h1>
          </div>
        </div>
        <button
          onClick={handleExportSamples}
          aria-label={isAr ? "تصدير العينات" : "Export Samples"}
          className="flex items-center justify-center hover:opacity-70 transition-opacity bg-transparent"
          style={{ color: "var(--brand)" }}
        >
          <Download className="w-5 h-5" />
        </button>
      </div>

      {/* Person Selector */}
      <div className="px-4 flex gap-2 mb-3">
        {["person1", "person2", "all"].map((person) => (
          <button
            key={person}
            onClick={() => setActivePerson(person)}
            className={cn(
              "flex-1 py-2 text-sm font-body font-medium transition-all bg-transparent",
              activePerson === person
                ? "font-bold"
                : "text-muted-foreground hover:text-foreground opacity-70"
            )}
            style={activePerson === person ? { color: "var(--brand)" } : undefined}
          >
            {person === "person1" ? names.person1 : person === "person2" ? names.person2 : "All"}
          </button>
        ))}
      </div>

      {/* Sort Options */}
      <div className="px-4 mb-5 flex gap-2">
        <select name="Samples-sel1"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="flex-1 px-3 py-2 rounded-none border-0 bg-transparent text-xs font-body"
        >
          <option value="newest">{isAr ? "الأحدث" : "Newest"}</option>
          <option value="oldest">{isAr ? "الأقدم" : "Oldest"}</option>
          <option value="highest">{isAr ? "الأعلى سعر" : "Highest Cost"}</option>
          <option value="lowest">{isAr ? "الأقل سعر" : "Lowest Cost"}</option>
        </select>
      </div>



      {/* Stats — احصائيات العيّنات (غرض الصفحة، تبقى) */}
      <div className="px-4 mb-5 space-y-3">
        <div className="grid grid-cols-4 gap-2">
          <div className="rounded-none p-2 text-center">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "إجمالي العناصر" : "Total Items"}</p>
            <p className="font-heading font-semibold text-sm">{personPurchases.length}</p>
          </div>
          <div className="rounded-none p-2 text-center">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "الحجم الكلي" : "Total Volume"}</p>
            <p className="font-heading font-semibold text-sm">{combinedTotalVolume}ml</p>
          </div>
          <div className="rounded-none p-2 text-center">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "التكلفة الكلية" : "Total Cost"}</p>
            <p className="font-heading font-semibold text-sm">{formatPrice(combinedTotalCost.toFixed(0))}</p>
          </div>
          <div className="rounded-none p-2 text-center">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "التكلفة للمل" : "Cost/ml"}</p>
            <p className="font-heading font-semibold text-sm">{formatPrice(avgCostPerMl)}</p>
          </div>
        </div>
        <div className="rounded-none pt-2">
          <p className="text-[10px] font-body mb-2 uppercase tracking-wider font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "العيّنات" : "Samples"}</p>
          <div className="grid grid-cols-3 gap-2">
            <div><p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "الحجم" : "Volume"}</p><p className="font-heading font-semibold text-xs">{totalSampleVolume}ml</p></div>
            <div><p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "التكلفة" : "Cost"}</p><p className="font-heading font-semibold text-xs">{formatPrice(totalSampleCost.toFixed(0))}</p></div>
            <div><p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "العناصر" : "Items"}</p><p className="font-heading font-semibold text-xs">{samplePurchases.length}</p></div>
          </div>
        </div>
        <div className="rounded-none pt-2 border-t border-border/40">
          <p className="text-[10px] font-body mb-2 uppercase tracking-wider font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "القنينات" : "Bottles"}</p>
          <div className="grid grid-cols-3 gap-2">
            <div><p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "الحجم" : "Volume"}</p><p className="font-heading font-semibold text-xs">{totalBottleVolume}ml</p></div>
            <div><p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "التكلفة" : "Cost"}</p><p className="font-heading font-semibold text-xs">{formatPrice(totalBottleCost.toFixed(0))}</p></div>
            <div><p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "العناصر" : "Items"}</p><p className="font-heading font-semibold text-xs">{bottlePurchases.length}</p></div>
          </div>
        </div>
      </div>

      {/* Purchases List — خطوط ملوّنة بنمط تفاعل (بلا جدول/أيقونات) */}
      <div className="px-4">
        {samplePurchases.length > 0 && (
          <div className="mb-5">
            <h2 className="font-heading font-semibold text-sm px-1 mb-1" style={{ color: "var(--brand)" }}>{isAr ? "عيّنات" : "Samples"}</h2>
            {samplePurchases.slice(0, showSamples).map((p) => <PurchaseLine key={p.id} p={p} />)}
            {samplePurchases.length > showSamples && (
              <button type="button" onClick={() => setShowSamples((n) => n + 25)} className="text-xs font-body py-2 bg-transparent" style={{ color: "var(--brand)" }}>{isAr ? "تحميل المزيد" : "Load more"}</button>
            )}
          </div>
        )}
        {bottlePurchases.length > 0 && (
          <div className="mb-5">
            <h2 className="font-heading font-semibold text-sm px-1 mb-1" style={{ color: "var(--brand)" }}>{isAr ? "قنينات" : "Bottles"}</h2>
            {bottlePurchases.slice(0, showBottles).map((p) => <PurchaseLine key={p.id} p={p} />)}
            {bottlePurchases.length > showBottles && (
              <button type="button" onClick={() => setShowBottles((n) => n + 25)} className="text-xs font-body py-2 bg-transparent" style={{ color: "var(--brand)" }}>{isAr ? "تحميل المزيد" : "Load more"}</button>
            )}
          </div>
        )}
        {personPurchases.length === 0 && (
          <p className="text-sm text-muted-foreground font-body text-center py-8">{isAr ? "لا مشتريات بعد" : "No purchases yet"}</p>
        )}
      </div>
    </div>
  );
}
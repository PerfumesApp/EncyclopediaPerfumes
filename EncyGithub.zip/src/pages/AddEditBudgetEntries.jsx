import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { Trash2, Edit2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import BackIcon from "@/components/shared/BackIcon";

const TABS = [
  { id: "income", label: "💵 Income" },
  { id: "expenses", label: "💸 Expenses" },
  { id: "obligations", label: "📋 Obligations" },
  { id: "recurring", label: "🔄 Recurring" },
];

const PERSON_OPTIONS = [
  { val: "person1", label: "A" },
  { val: "person2", label: "B" },
  { val: "family", label: "Family" },
];

export default function AddEditBudgetEntries() {
  const [confirmDialog, setConfirmDialog] = useState(null);
  const { names } = usePersonNames();
  const { currency } = useCurrency();
  const qc = useQueryClient();

  const [activeTab, setActiveTab] = useState("income");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null); // null = add mode
  const [formData, setFormData] = useState({});
  const [selectedPerson, setSelectedPerson] = useState("all");

  // Queries
  const { data: incomes = [] } = useQuery({ queryKey: ["budget-incomes"], queryFn: () => apphost.entities.BudgetIncome.list("-date") });
  const { data: expenses = [] } = useQuery({ queryKey: ["budget-expenses"], queryFn: () => apphost.entities.BudgetExpense.list("-date") });
  const { data: obligations = [] } = useQuery({ queryKey: ["budget-obligations"], queryFn: () => apphost.entities.BudgetObligation.list("-end_date") });
  const { data: recurring = [] } = useQuery({ queryKey: ["recurring-expenses"], queryFn: () => apphost.entities.RecurringExpense.list("-start_date") });

  // Mutations for each entity
  const entityMap = {
    income: { entity: apphost.entities.BudgetIncome, queryKey: "budget-incomes" },
    expenses: { entity: apphost.entities.BudgetExpense, queryKey: "budget-expenses" },
    obligations: { entity: apphost.entities.BudgetObligation, queryKey: "budget-obligations" },
    recurring: { entity: apphost.entities.RecurringExpense, queryKey: "recurring-expenses" },
  };

  const createM = useMutation({
    mutationFn: async (data) => {
      return entityMap[activeTab].entity.create(data);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: [entityMap[activeTab].queryKey] }); closeDialog(); toast.success("تمت الإضافة"); },
    onError: (err) => toast.error(err?.message || "Error saving"),
  });

  const updateM = useMutation({
    mutationFn: async ({ id, data }) => {
      return entityMap[activeTab].entity.update(id, data);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: [entityMap[activeTab].queryKey] }); closeDialog(); toast.success("تم التحديث"); },
    onError: (err) => toast.error(err?.message || "Error updating"),
  });

  const deleteM = useMutation({
    mutationFn: (id) => entityMap[activeTab].entity.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: [entityMap[activeTab].queryKey] }); toast.success("تم الحذف"); },
  });

  const openAdd = () => { setEditingItem(null); setFormData(defaultForm()); setDialogOpen(true); };
  const openEdit = (item) => { setEditingItem(item); setFormData({ ...item }); setDialogOpen(true); };
  const closeDialog = () => { setDialogOpen(false); setEditingItem(null); setFormData({}); };

  const defaultForm = () => {
    if (activeTab === "income") return { date: today(), amount: "", type: "salary", person: "person1", description: "" };
    if (activeTab === "expenses") return { date: today(), amount: "", category: "other", person: "person1", description: "" };
    if (activeTab === "obligations") return { title: "", total_amount: "", monthly_payment: "", paid_amount: "0", end_date: "", person: "person1" };
    if (activeTab === "recurring") return { title: "", amount: "", frequency: "monthly", start_date: today(), person: "person1" };
    return {};
  };

  const handleSave = () => {
    const parsed = buildPayload();
    if (!parsed) return;
    if (editingItem) {
      updateM.mutate({ id: editingItem.id, data: parsed });
    } else {
      createM.mutate(parsed);
    }
  };

  const buildPayload = () => {
    if (activeTab === "income") {
      if (!formData.amount || !formData.date) { toast.error("املأ كل الحقول"); return null; }
      return { date: formData.date, amount: parseFloat(formData.amount), type: formData.type || "salary", person: formData.person || "person1", description: formData.description || "" };
    }
    if (activeTab === "expenses") {
      if (!formData.amount || !formData.date) { toast.error("املأ الحقول المطلوبة"); return null; }
      return { date: formData.date, amount: parseFloat(formData.amount), category: formData.category || "other", person: formData.person || "person1", description: formData.description || "", type: formData.type || "essential" };
    }
    if (activeTab === "obligations") {
      if (!formData.title || !formData.total_amount || !formData.monthly_payment || !formData.end_date) { toast.error("املأ كل الحقول المطلوبة"); return null; }

      return { title: formData.title, person: formData.person || "person1", total_amount: parseFloat(formData.total_amount), paid_amount: parseFloat(formData.paid_amount) || 0, monthly_payment: parseFloat(formData.monthly_payment), end_date: formData.end_date, status: formData.status || "active", notes: formData.notes || "" };
    }
    if (activeTab === "recurring") {
      if (!formData.title || !formData.amount || !formData.start_date) { toast.error("املأ كل الحقول المطلوبة"); return null; }
      return { title: formData.title, amount: parseFloat(formData.amount), person: formData.person || "person1", frequency: formData.frequency || "monthly", category: formData.category || "other", start_date: formData.start_date, is_active: true, auto_generate: true };
    }
    return null;
  };

  const items = { income: incomes, expenses, obligations, recurring }[activeTab] || [];
  const filtered = selectedPerson === "all" ? items : items.filter(i => i.person === selectedPerson);

  const personLabel = (p) => p === "person1" ? names.person1 || "A" : p === "person2" ? names.person2 || "B" : p === "family" ? "Family" : p;

  return (
    <div className="px-4 page-top pb-20 space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link to="/budget" className="p-2 hover:bg-secondary rounded-none">
          <BackIcon className="w-5 h-5" />
        </Link>
        <h1 className="font-heading text-xl font-bold flex-1">إضافة و تعديل مدخلات الميزانية Add & Edit Budget Entries</h1>
        <Button size="sm" className="rounded-none text-xs h-9" onClick={openAdd}>
          Add
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-border overflow-x-auto pb-0">
        {TABS.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => { setActiveTab(id); setSelectedPerson("all"); }}
            className={`text-xs font-body pb-2 px-3 whitespace-nowrap transition-all ${activeTab === id ? "border-b-2 border-primary text-primary font-semibold" : "text-muted-foreground"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Person filter */}
      <div className="flex gap-2 overflow-x-auto">
        {[{ val: "all", label: "All" }, { val: "person1", label: names.person1 || "A" }, { val: "person2", label: names.person2 || "B" }, { val: "family", label: "Family" }].map(({ val, label }) => (
          <button
            key={val}
            onClick={() => setSelectedPerson(val)}
            className={`flex-shrink-0 rounded-none text-xs font-body transition-all ${selectedPerson === val ? " text-primary-foreground" : " text-muted-foreground"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <p className="text-center text-xs text-muted-foreground py-8">لا مدخلات بعد اضغط إضافة No entries yet. Tap Add to create one.</p>
      ) : (
        <div className="space-y-2">
          {filtered.map((item) => (
            <EntryRow
              key={item.id}
              item={item}
              tab={activeTab}
              currency={currency}
              personLabel={personLabel}
              onEdit={() => openEdit(item)}
              onDelete={() => { if (confirm("Delete this entry")) deleteM.mutate(item.id); }}
            />
          ))}
        </div>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={closeDialog}>
        <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {editingItem ? "Edit" : "Add"} {TABS.find(t => String(t.id) === String(activeTab))?.label}
            </DialogTitle>
          </DialogHeader>
          <EntryForm tab={activeTab} formData={formData} setFormData={setFormData} names={names} />
          <Button className="w-full rounded-none h-10 mt-2" onClick={handleSave} disabled={createM.isPending || updateM.isPending}>
            {createM.isPending || updateM.isPending ? "Saving.." : editingItem ? "Update" : "Add"}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function EntryRow({ item, tab, currency, personLabel, onEdit, onDelete }) {
  const title = tab === "income" ? (item.description || item.type)
    : tab === "expenses" ? (item.description || item.category)
    : item.title;
  const amount = tab === "income" ? item.amount
    : tab === "expenses" ? item.amount
    : tab === "obligations" ? item.monthly_payment
    : item.amount;
  const sub = tab === "income" ? `${item.type} — ${item.date}`
    : tab === "expenses" ? `${item.category} — ${item.date}`
    : tab === "obligations" ? `Until ${item.end_date} — ${item.status}`
    : `${item.frequency} — from ${item.start_date}`;

  return (
    <div className="bg-card rounded-none p-3 border border-border/50 flex items-center gap-3">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-body font-semibold truncate">{title}</p>
        <p className="text-[10px] text-muted-foreground mt-0.5">{sub}</p>
        <p className="text-[10px] text-muted-foreground">{personLabel(item.person)}</p>
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <p className={`text-sm font-bold ${tab === "income" ? "text-[var(--brand)]" : "text-red-500"}`}>
          {(amount || 0).toFixed(0)} {currency}
        </p>
        <button onClick={onEdit} className="p-1.5 rounded-none hover:bg-accent transition-colors text-muted-foreground hover:text-foreground">
          <Edit2 className="w-3.5 h-3.5" />
        </button>
        <button onClick={() => { if (confirm("Delete?")) onDelete(); }} className="p-1.5 rounded-none hover:bg-destructive/10 transition-colors text-muted-foreground hover:text-destructive">
         <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

function EntryForm({ tab, formData, setFormData, names }) {
  const f = formData;
  const set = (k, v) => setFormData({ ...f, [k]: v });

  const personOptions = [
    { val: "person1", label: names.person1 || "A" },
    { val: "person2", label: names.person2 || "B" },
    { val: "family", label: "Family" },
  ];

  const PersonSelect = () => (
    <Select value={f.person || "person1"} onValueChange={v => set("person", v)}>
      <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
      <SelectContent>
        {personOptions.map(p => <SelectItem key={p.val} value={p.val}>{p.label}</SelectItem>)}
      </SelectContent>
    </Select>
  );

  if (tab === "income") return (
    <div className="space-y-3">
      <Input type="date" value={f.date || ""} onChange={e => set("date", e.target.value)} className="rounded-none h-10" />
      <Input type="number" placeholder="المبلغ Amount" value={f.amount || ""} onChange={e => set("amount", e.target.value)} className="rounded-none h-10" />
      <Select value={f.type || "salary"} onValueChange={v => set("type", v)}>
        <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="salary">راتب Salary</SelectItem>
          <SelectItem value="business">عمل Business</SelectItem>
          <SelectItem value="investment">استثمار Investment</SelectItem>
          <SelectItem value="other">أخرى Other</SelectItem>
        </SelectContent>
      </Select>
      <PersonSelect />
      <Textarea placeholder="الوصف اختياري Description (optional)" value={f.description || ""} onChange={e => set("description", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px]" />
    </div>
  );

  if (tab === "expenses") return (
    <div className="space-y-3">
      <Input type="date" value={f.date || ""} onChange={e => set("date", e.target.value)} className="rounded-none h-10" />
      <Input type="number" placeholder="المبلغ Amount" value={f.amount || ""} onChange={e => set("amount", e.target.value)} className="rounded-none h-10" />
      <Select value={f.category || "other"} onValueChange={v => set("category", v)}>
        <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
        <SelectContent>
          {["food","transportation","utilities","shopping","entertainment","health","education","perfume","other"].map(c => (
            <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <PersonSelect />
      <Textarea placeholder="الوصف اختياري Description (optional)" value={f.description || ""} onChange={e => set("description", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px]" />
    </div>
  );

  if (tab === "obligations") return (
    <div className="space-y-3">
      <Input placeholder="عنوان الالتزام Obligation Title" value={f.title || ""} onChange={e => set("title", e.target.value)} className="rounded-none h-10" />
      <Input type="number" placeholder="المبلغ الكلي Total Amount" value={f.total_amount || ""} onChange={e => set("total_amount", e.target.value)} className="rounded-none h-10" />
      <Input type="number" placeholder="الدفعة الشهرية Monthly Payment" value={f.monthly_payment || ""} onChange={e => set("monthly_payment", e.target.value)} className="rounded-none h-10" />
      <Input type="number" placeholder="المدفوع سابقاً Already Paid" value={f.paid_amount || ""} onChange={e => set("paid_amount", e.target.value)} className="rounded-none h-10" />
      <Input type="date" value={f.end_date || ""} onChange={e => set("end_date", e.target.value)} className="rounded-none h-10" />
      <PersonSelect />
      <Select value={f.status || "active"} onValueChange={v => set("status", v)}>
        <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="active">نشط Active</SelectItem>
          <SelectItem value="paid_off">مسدّد Paid Off</SelectItem>
          <SelectItem value="paused">متوقّف Paused</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );

  if (tab === "recurring") return (
    <div className="space-y-3">
      <Input placeholder="العنوان Title" value={f.title || ""} onChange={e => set("title", e.target.value)} className="rounded-none h-10" />
      <Input type="number" placeholder="المبلغ Amount" value={f.amount || ""} onChange={e => set("amount", e.target.value)} className="rounded-none h-10" />
      <Input type="date" value={f.start_date || ""} onChange={e => set("start_date", e.target.value)} className="rounded-none h-10" />
      <Select value={f.frequency || "monthly"} onValueChange={v => set("frequency", v)}>
        <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
        <SelectContent>
          {["daily","weekly","monthly","quarterly","yearly"].map(fr => (
            <SelectItem key={fr} value={fr} className="capitalize">{fr}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <PersonSelect />
    </div>
  );

  return null;
}
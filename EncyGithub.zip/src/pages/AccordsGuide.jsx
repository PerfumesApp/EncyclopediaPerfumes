import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ChevronDown, FlaskConical } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { accordColor } from "@/lib/accordColors";
import ACCORDS from "@/data/builtin_database/accords_builtin.json";

const GOLD = "var(--brand)";

/**
 * AccordsGuide — صفحة معرفية تفاعلية عن التناغمات العطرية — Accords.
 * - الأكورد يُسمّى تناغماً بالعربية في كل الإشارات.
 * - مبدّل لغة داخل الصفحة، افتراضه لغة المستخدم المحدّدة (isAr).
 * - ترابط مع قاعدة البيانات: ألوان التناغمات الحقيقية (accordColors + accords_builtin)
 *   ومفتاح كامل لكل 92 تناغماً كما تظهر على قنينات الكاتلوج، ورابط لشرح القنينة.
 */

// تناغمات شائعة (مصدرها المعرفة العطرية) — اللون من نظام التطبيق نفسه.
const COMMON = [
  { en: "Citrus", ar: "حمضيات", key: "citrus",
    cEn: "Lemon, bergamot, mandarin", cAr: "ليمون، برغموت، ماندرين",
    iEn: "Fresh, lively, radiant — summer energy", iAr: "منعش، حيوي، فوّاح — طاقة صيفية" },
  { en: "Amber", ar: "عنبر", key: "amber",
    cEn: "Vanilla, labdanum, benzoin", cAr: "فانيليا، لابدانوم، بنزوين",
    iEn: "Warm, oriental, sweet — rich and deep", iAr: "دافئ، شرقي، حلو — غنيّ وعميق" },
  { en: "Floral", ar: "زهور", key: "floral",
    cEn: "Jasmine, rose, rose musk", cAr: "ياسمين، ورد، مسك ورد",
    iEn: "Soft, delicate, feminine, romantic", iAr: "ناعم، رقيق، أنثوي، رومانسي" },
  { en: "Woody", ar: "خشبية", key: "woody",
    cEn: "Sandalwood, cedar, patchouli", cAr: "خشب صندل، خشب أرز، باتشولي",
    iEn: "Earthy, dry, warm — lends longevity", iAr: "ترابي، جاف، دافئ — يمنح العطر ثباتاً" },
  { en: "Gourmand", ar: "نَّهِم — مأكولات", key: "gourmand",
    cEn: "Chocolate, caramel, coffee, vanilla", cAr: "شوكولاتة، كراميل، قهوة، فانيليا",
    iEn: "Sweet, warm, inviting — dessert-like", iAr: "حلو، دافئ، جذّاب — يُذكّر بالحلويات" },
  { en: "Fougère", ar: "فوّاح — سرخسي", key: "fougere",
    cEn: "Lavender, oakmoss, coumarin", cAr: "خزامى (لافندر)، طحلب بلوط، كومارين",
    iEn: "Herbal, classic, masculine and clean", iAr: "عشبي، كلاسيكي، رجالي ونظيف" },
  { en: "Chypre", ar: "شيبر", key: "chypre",
    cEn: "Bergamot, oakmoss, patchouli", cAr: "برغموت، طحلب بلوط، باتشولي",
    iEn: "Mysterious, earthy with a sharp citrus edge", iAr: "غامض، ترابي مع لمحة حمضية حادّة" },
  { en: "Aquatic / Marine", ar: "مائي / بحري", key: "aquatic",
    cEn: "Calone, sea salt, seaweed", cAr: "كالون، ملح بحر، أعشاب بحرية",
    iEn: "Clean — like sea breeze or rain", iAr: "نقيّ — يشبه نسيم البحر أو المطر" },
  { en: "Leather", ar: "جلود", key: "leather",
    cEn: "Birch tar, tobacco, saffron", cAr: "قطران بيرش، تبغ، زعفران",
    iEn: "Luxurious, smoky, sharp — power and opulence", iAr: "فخم، مدخّن، حادّ — قوّة ورفاهية" },
];

// تناغمات نادرة وتجريبية — خمس عائلات ابتكارية.
const RARE = [
  { en: "Industrial & Urban", ar: "صناعية ومدنية", items: [
    { en: "Gasoline / Tarmac", ar: "بنزين / قطران", dEn: "Fuel stations or hot asphalt.", dAr: "محطّات الوقود أو الإسفلت الساخن." },
    { en: "Metallic", ar: "معدني", dEn: "Cold, sharp — iron or blood — special aldehydes.", dAr: "باردة حادّة كالحديد أو الدم — ألدهيدات خاصة." },
    { en: "Vinyl / Plastic", ar: "فينيل / بلاستيك", dEn: "Old records or new plastic toys.", dAr: "أسطوانات قديمة أو دمى بلاستيكية جديدة." },
    { en: "Concrete / Asphalt", ar: "خرسانة / إسفلت", dEn: "Dry, dusty — modern buildings after rain.", dAr: "ترابية جافة كمبانٍ حديثة بعد المطر." },
    { en: "Industrial Glue / Burnt Rubber", ar: "غراء / مطاط محروق", dEn: "Pungent, rebellious — winter niche.", dAr: "كيميائية نفّاذة، طابع متمرّد لنيش شتوي." },
  ]},
  { en: "Provocative & Bodily", ar: "حيوانية صادمة", items: [
    { en: "Blood", ar: "دم", dEn: "Provocative, metallic — iron-like.", dAr: "معدنية مستفزّة تشبه حديد الدم." },
    { en: "Sweat / Bodily", ar: "عرق / سوائل حيوية", dEn: "Salty, warm — raw human skin.", dAr: "مالحة دافئة تحاكي الجلد البشري الخام." },
    { en: "Castoreum / Civet", ar: "كاستوريوم / زباد", dEn: "Pungent, warm — animal fur — old fixatives.", dAr: "لاذعة دافئة كفرو الحيوان — مثبّتات قديمة." },
  ]},
  { en: "Atmospheric & Earthy", ar: "بيئية وترابية نادرة", items: [
    { en: "Petrichor", ar: "بتريكور", dEn: "Dry earth at the first drops of rain.", dAr: "رائحة الأرض الجافة لحظة أوّل المطر." },
    { en: "Wet Dirt / Mud", ar: "طين مبلّل", dEn: "Damp, earthy — a rainforest floor.", dAr: "ترابية رطبة كأرض غابة مطيرة." },
    { en: "Gunpowder / Ash", ar: "بارود / رماد", dEn: "Sulfurous, smoky, dry.", dAr: "كبريتية مدخّنة جافة." },
    { en: "Paper / Old Books", ar: "ورق / كتب قديمة", dEn: "Warm, woody, faint vanilla.", dAr: "خشبية دافئة بلمحة فانيليا." },
    { en: "Raw Wool", ar: "صوف خام", dEn: "Warm, woolly — stored winter coats.", dAr: "دافئة برّية كمعاطف الشتاء المخزّنة." },
  ]},
  { en: "Unusual Savory & Green", ar: "غذائية غير تقليدية", items: [
    { en: "Rice / Basmati", ar: "أرز مسلوق", dEn: "Starchy, soft, comforting.", dAr: "نشوية ناعمة مريحة." },
    { en: "Mushroom / Truffle", ar: "فطر / ترافل", dEn: "Earthy, damp — dark luxury.", dAr: "ترابية رطبة فطرية، فخامة مظلمة." },
    { en: "Oatmeal / Toasted Grain", ar: "شوفان محمّص", dEn: "Warm, milky, lightly toasted.", dAr: "دافئة حليبية محمّصة قليلاً." },
    { en: "Vegetal / Green", ar: "نباتية مالحة", dEn: "Tomato leaf, cucumber, peas — sharp green.", dAr: "ورق الطماطم، الخيار، البازلاء — حادّة عشبية." },
  ]},
  { en: "Medicinal & Narcotic", ar: "طبية ومخدّرة", items: [
    { en: "Band-Aid / Iodine", ar: "ضمادات / يود", dEn: "Sterile, sharp — appears in fine ouds.", dAr: "معقّمة نفّاذة تظهر في عود فاخر." },
    { en: "Hemp / Cannabis", ar: "قنّب", dEn: "Herbal, smoky, heavy green.", dAr: "عشبية مدخّنة خضراء ثقيلة." },
  ]},
];

const WHY = [
  { en: "Creating scents that can't be extracted in nature", ar: "صناعة روائح لا تُستخلَص طبيعياً",
    dEn: "No natural oil exists for amber, leather, or rain — they're invented by blending components that evoke the impression.",
    dAr: "لا يوجد زيت طبيعي للعنبر أو الجلد أو رائحة المطر؛ تُبتكَر بدمج مكوّنات تعطي الإيحاء الشمّي." },
  { en: "Building the perfume's skeleton", ar: "بناء هيكل العطر",
    dEn: "The accord is the backbone; once set, the perfumer adds secondary notes to embellish the scent.",
    dAr: "التناغم هو العمود الفقري؛ بعد ضبطه يضيف العطّار نوتات ثانوية تزيّن الرائحة." },
];

import { PRIMARY_TYPES, OTHER_TYPE_GROUPS, TYPE_FAMILIES, typeDisplay, strengthOf, strengthInfo } from "@/lib/perfumeTypes";
import { StrengthCells, StrengthTrack } from "@/components/perfume/StrengthIndicator";
import BackIcon from "@/components/shared/BackIcon";

export default function AccordsGuide() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [openAccord, setOpenAccord] = useState(null);
  const [openFamily, setOpenFamily] = useState(0);

  const ar = isAr;
  const L = (en, arr) => (ar ? arr : en);

  // كل التناغمات الـ92 كما في قاعدة البيانات (للمفتاح اللوني).
  const allAccords = Object.values(ACCORDS).sort((a, b) => (a.en || "").localeCompare(b.en || ""));

  // سطر شرح موجز لكل نوع
  const TYPE_EXPLAIN = {
    "Eau de Cologne": ["الأخفّ والأنعش، يدوم ساعتين تقريباً", "Lightest and freshest, lasts about two hours"],
    "Eau Fraîche": ["ماء معطّر خفيف جداً للانتعاش السريع", "A very light scented water for a quick refresh"],
    "Body Mist": ["رذاذ جسم خفيف لرائحة لطيفة عابرة", "A light body spray for a soft, fleeting scent"],
    "After Shave": ["خفيف يُستعمل بعد الحلاقة لتهدئة البشرة", "Light, applied after shaving to soothe the skin"],
    "Eau de Toilette": ["الأكثر شيوعاً للنهار، اعتدال وثبات معقول", "The everyday daytime staple, moderate and reasonably lasting"],
    "Parfum Cologne": ["كولونيا أغنى تركيزاً من المعتاد", "A cologne richer in concentration than usual"],
    "Eau de Parfum": ["تركيز متوسط قويّ، الأكثر انتشاراً اليوم", "A strong medium concentration, the most common today"],
    "Eau de Parfum Intense": ["نسخة مكثّفة أثقل من أو دو بارفان", "A heavier, intensified version of Eau de Parfum"],
    "Parfum": ["تركيز عالٍ وثبات طويل وفوحان أقوى", "High concentration, long wear and stronger projection"],
    "Extrait de Parfum": ["أعلى تركيز عطريّ، ثقيل ويدوم طويلاً جداً", "The highest concentration, heavy and very long-lasting"],
    "Perfume Oil": ["دهن مركّز جداً، طبقة رقيقة تكفي", "A very concentrated oil, a thin layer suffices"],
    "Undefined": ["نوع غير محدّد في المصدر", "Type not specified in the source"],
  };

  return (
    <div dir={ar ? "rtl" : "ltr"} className="px-5 page-top pb-16 space-y-8">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors shrink-0" dir="ltr">
          <BackIcon className="w-5 h-5" />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="font-heading text-2xl font-bold" style={{ color: GOLD }}>
            {L("Perfume Accords", "التناغمات العطرية")}
          </h1>
          <p className="text-xs text-muted-foreground font-body mt-0.5">{L("A knowledge guide", "دليل معرفي")}</p>
        </div>
      </div>

      {/* زرّ صفحة جدول الأكورد */}
      <button
        onClick={() => navigate("/accord-table")}
        className="w-full flex items-center justify-between px-1 py-3 hover:bg-amber-50/50 transition-colors"
        dir={ar ? "rtl" : "ltr"}
      >
        <span className="flex flex-col items-start">
          <span className="font-heading font-bold text-base" style={{ color: "#9D174D" }}>{L("Accord Table", "جدول الأكورد")}</span>
          <span className="text-[11px] text-muted-foreground font-body">{L("Every accord, explained", "كل أكورد و معناه")}</span>
        </span>
        <span style={{ width: 12, height: 12, transform: "rotate(45deg)", background: "var(--brand)", flex: "none" }} />
      </button>

      {/* Intro paragraphs (heading removed per spec) */}
      <section className="space-y-2">
        <p className="text-sm font-body text-foreground/90 leading-relaxed">
          {L(
            "An accord is a harmonious blend of two or more aromatic materials that merge into a brand-new, independent scent — different from any single ingredient on its own.",
            "التناغم (Accord) مزيجٌ متناغم من مكوّنين أو أكثر من الزيوت العطرية، يندمجون معاً لإنتاج رائحة جديدة ومستقلّة تماماً، تختلف عن رائحة كلّ مكوّن بمفرده."
          )}
        </p>
        <p className="text-sm font-body text-muted-foreground leading-relaxed">
          {L(
            "The idea is borrowed from music: just as several notes blend into a single chord, fragrance notes blend into one unified accord.",
            "المفهوم مستوحى من الموسيقى؛ فمثلما تمتزج عدّة نوتات لتُشكّل وتراً متناسقاً، تمتزج النوتات العطرية لتُشكّل تناغماً موحّداً."
          )}
        </p>
      </section>

      {/* Common accords — interactive cards */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg" style={{ color: GOLD }}>{L("Common Accords", "تناغمات شائعة")}</h2>
        <p className="text-xs text-muted-foreground font-body">{L("Tap a harmony to reveal its components and impression.", "اضغط على تناغمٍ لكشف مكوّناته وإحساسه.")}</p>
        <div className="divide-y divide-border/40">
          {COMMON.map((a) => {
            const c = accordColor(a.key);
            const open = openAccord === a.key;
            return (
              <div key={a.key}>
                <button
                  onClick={() => setOpenAccord(open ? null : a.key)}
                  className="w-full flex items-center gap-3 py-3 text-start hover:bg-secondary/30 transition-colors px-1 rounded-none"
                >
                  <span className="w-3.5 h-3.5 rounded-none shrink-0 ring-1 ring-black/10" style={{ background: c }} />
                  <span className="flex-1 min-w-0">
                    <span className="text-sm font-body font-semibold text-foreground">{L(a.en, a.ar)}</span>
                    <span className="text-[11px] text-muted-foreground font-body block">{ar ? a.en : a.ar}</span>
                  </span>
                  <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform shrink-0 ${open ? "rotate-180" : ""}`} />
                </button>
                {open && (
                  <div className="pb-3 ps-7 pe-1 space-y-1.5">
                    <p className="text-xs font-body">
                      <span className="font-semibold" style={{ color: c }}>{L("Components", "المكوّنات")}: </span>
                      <span className="text-foreground/85">{L(a.cEn, a.cAr)}</span>
                    </p>
                    <p className="text-xs font-body">
                      <span className="font-semibold" style={{ color: c }}>{L("Impression", "الإحساس")}: </span>
                      <span className="text-foreground/85">{L(a.iEn, a.iAr)}</span>
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Why accords */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg" style={{ color: GOLD }}>{L("Why perfumers use accords", "لماذا يستخدم العطّار التناغم")}</h2>
        <div className="space-y-3">
          {WHY.map((w, i) => (
            <div key={i} className="flex gap-3">
              <span className="font-heading font-bold text-lg shrink-0" style={{ color: GOLD }}>{i + 1}</span>
              <div className="space-y-0.5">
                <p className="text-sm font-body font-semibold text-foreground">{L(w.en, w.ar)}</p>
                <p className="text-xs text-muted-foreground font-body leading-relaxed">{L(w.dEn, w.dAr)}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Rare & experimental accords — accordion families */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <FlaskConical className="w-4 h-4" style={{ color: GOLD }} />
          <h2 className="font-heading font-bold text-lg" style={{ color: GOLD }}>{L("Rare & Experimental", "تناغمات نادرة وتجريبية")}</h2>
        </div>
        <p className="text-xs text-muted-foreground font-body">
          {L("Niche, conceptual harmonies — built to evoke unusual moods or bold, unconventional perfume art.",
             "تناغمات نيش وتجريبية، تُصنع لإثارة مشاعر غريبة أو لتقديم فنّ عطري جريء خارج المألوف.")}
        </p>
        <div className="divide-y divide-border/40">
          {RARE.map((fam, fi) => {
            const open = openFamily === fi;
            return (
              <div key={fi}>
                <button
                  onClick={() => setOpenFamily(open ? -1 : fi)}
                  className="w-full flex items-center gap-2 py-3 text-start hover:bg-secondary/30 transition-colors px-1 rounded-none"
                >
                  <span className="flex-1 min-w-0">
                    <span className="block text-sm font-body font-semibold text-foreground">{L(fam.en, fam.ar)}</span>
                    <span className="block text-[11px] text-muted-foreground font-body">{ar ? fam.en : fam.ar}</span>
                  </span>
                  <span className="text-[10px] text-muted-foreground font-body">{fam.items.length}</span>
                  <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform shrink-0 ${open ? "rotate-180" : ""}`} />
                </button>
                {open && (
                  <div className="pb-3 ps-2 pe-1 space-y-2.5">
                    {fam.items.map((it, ii) => (
                      <div key={ii} className="leading-relaxed">
                        <p className="text-xs font-body font-semibold text-foreground/90">{L(it.en, it.ar)}</p>
                        <p className="text-[10px] text-muted-foreground font-body">{ar ? it.en : it.ar}</p>
                        <p className="text-[11px] text-muted-foreground font-body">{L(it.dEn, it.dAr)}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Perfume Types — أنواع العطور */}
      <section className="space-y-4">
        <h2 className="font-heading font-bold text-lg" style={{ color: GOLD }}>{L("Perfume Types", "أنواع العطور")}</h2>
        <p className="text-xs text-muted-foreground font-body">
          {L("Concentration types carry a strength scale — light (green) to very heavy harsh (dark brown). Other families are listed by name.",
             "أنواع التركيز تحمل سلّم قوّة — من الخفيف (أخضر) إلى الثقيل المزعج جداً (بنّي غامق). أمّا العائلات الأخرى فتُسرد بأسمائها.")}
        </p>

        {/* عائلة التركيز — الشكلان: خلايا + مسار + نسبة + شرح */}
        <h3 className="font-heading font-semibold text-sm" style={{ color: GOLD }}>{ar ? TYPE_FAMILIES.concentration.ar : TYPE_FAMILIES.concentration.en}</h3>
        <div className="space-y-3">
          {PRIMARY_TYPES.map((t) => {
            const st = strengthOf(t.value);
            const info = st ? strengthInfo(st) : null;
            return (
              <div key={t.value} className="space-y-1 pb-2" style={{ borderBottom: "1px solid rgba(200,160,46,0.2)" }}>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm font-body font-semibold">{typeDisplay(t.value, ar ? "ar" : "both")}</span>
                  {t.pct && <span className="text-[11px] text-muted-foreground font-body" style={{ fontFamily: "monospace" }}>{t.pct}</span>}
                </div>
                {st && (
                  <div className="flex items-center gap-3 flex-wrap">
                    <StrengthCells strength={st} />
                    <StrengthTrack strength={st} />
                    {info && <span className="text-[11px] font-body font-bold" style={{ color: info.color }}>{ar ? info.ar : info.en}</span>}
                  </div>
                )}
                <p className="text-[11px] text-muted-foreground font-body leading-relaxed">
                  {ar ? (TYPE_EXPLAIN[t.value]?.[0] || "") : (TYPE_EXPLAIN[t.value]?.[1] || "")}
                </p>
              </div>
            );
          })}
        </div>

        {/* العائلات الأخرى — أسماء فقط مجمّعة */}
        {OTHER_TYPE_GROUPS.map((grp) => (
          <div key={grp.family} className="space-y-1.5">
            <h3 className="font-heading font-semibold text-sm" style={{ color: GOLD }}>{ar ? grp.ar : grp.en}</h3>
            <div className="grid grid-cols-2 gap-x-4 gap-y-1">
              {grp.items.map((t) => (
                <span key={t.value} className="text-xs font-body text-foreground/85 truncate">{ar ? t.label_ar : t.label_en}</span>
              ))}
            </div>
          </div>
        ))}
      </section>

      {/* All-accords color key — ties to the catalog flacons */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg" style={{ color: GOLD }}>{L("All Accord Colors", "مفتاح كلّ التناغمات")}</h2>
        <p className="text-xs text-muted-foreground font-body">
          {L("The exact colors used on every flacon in the catalog — each accord's signature hue.",
             "الألوان نفسها المستخدمة على كلّ قنينة في الكاتلوج — لون كلّ تناغمٍ المميّز.")}
        </p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
          {allAccords.map((a, i) => (
            <div key={i} className="flex items-center gap-2 min-w-0">
              <span className="w-3.5 h-3.5 rounded-none shrink-0 ring-1 ring-black/10" style={{ background: a.bar }} />
              <span className="text-xs font-body text-foreground/85 truncate">{ar ? (a.ar || a.en) : (a.en || a.ar)}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Interlink to the flacon guide */}
      <Link
        to="/guide"
        className="flex items-center justify-between py-3 px-1 border-t border-border/40 hover:bg-secondary/30 transition-colors"
      >
        <span className="text-sm font-body font-semibold" style={{ color: GOLD }}>
          {L("Features Definition", "تعريف المميزات")}
        </span>
        <span className="text-xs text-muted-foreground font-body">{L("Definition Guide", "دليل المميزات")}</span>
      </Link>
    </div>
  );
}

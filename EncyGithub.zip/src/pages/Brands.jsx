import { useState, useMemo, useEffect } from "react";
import { decadeFromYear } from "@/lib/decade";
import { enSortName, rankName } from "@/lib/sortName";
import { useQuery } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { Search, Building2, Tally4, AArrowUp, AArrowDown, ChevronLeft, ChevronRight, Pin } from "lucide-react";

// أيقونة سكاتر مخصّصة — محاور + نقاط مربّعة بزوايا حادّة (بدل دوائر lucide).
import { Link, useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import BrandsIndex from "@/components/brands/BrandsIndex";
import BrandsAnalytics from "@/components/brands/BrandsAnalytics";
import { usePins } from "@/lib/usePins";
import BackIcon from "@/components/shared/BackIcon";
export default function Brands() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const _sp = new URLSearchParams(typeof window !== "undefined" ? window.location.search : "");
  const [sortBy, setSortBy] = useState(_sp.get("sort") === "perfumeCount" ? "perfumeCount" : "name");
  const [nameAsc, setNameAsc] = useState(true);
  const [view, setView] = useState(_sp.get("view") === "analytics" ? "analytics" : "list"); // "list" | "index" | "analytics"
  const [page, setPage] = useState(1);
  const BRANDS_PER_PAGE = 50;

  const { data: brands = [], isLoading} = useQuery({
    queryKey: ["brands"],
    // queryFn آمن: إن لم يكن apphost/الكيان جاهزاً (أوّل إقلاع) يعيد [] بدل أن يرمي
    // خطأ يوقف الصفحة، فيعيد الاستطلاع المحاولة تلقائياً.
    queryFn: async () => {
      if (!apphost?.entities?.PerfumeBrand) return [];
      try { return await apphost.entities.PerfumeBrand.list("name"); } catch { return []; }
    },
    staleTime: Infinity,
    refetchOnMount: "always",
    retry: 2,
    // الحلّ الجذريّ: استطلاع ذاتيّ كل ثانية و خُمس ما دامت القائمة فارغة (زرع لم
    // يكتمل أو apphost لم يجهز)، و يتوقّف فور وصول البيانات — فلا تبقى الصفحة فارغة
    // و لا تحتاج إلى الرجوع و الدخول مجدداً مهما كان توقيت الزرع.
    refetchInterval: (query) => {
      const d = query?.state?.data;
      const empty = Array.isArray(d) ? d.length === 0 : !d;
      // استطلع ما دامت فارغة لالتقاط الزرع، لكن توقّف بعد ~١٢ محاولة حتى تستقرّ
      // القاعدة الفارغة فعلاً على حالة فارغة نظيفة بدل استطلاع لا نهائي.
      return (empty && (query?.state?.dataUpdateCount || 0) < 150) ? 1200 : false;
    },
    refetchIntervalInBackground: false,
  });

  // عدد عطور كل براند يُقرأ من perfume_ids المملوءة وقت الزرع — بلا تحميل
  // الكتالوج (130 ألف) إطلاقاً، فتظهر الصفحة والعدّادات فوراً دون تعليق.

  // الكتالوج الكامل يُحمَّل فقط عند فتح تبويب التحليلات (لا في قائمة البراندات).
  const { data: perfumes = [] } = useAllPerfumes("-created_date", { enabled: view === "analytics" });

  // إجمالي عدد العطور للتذييل — عدّ IndexedDB الأصلي (رخيص، بلا قراءة السجلات).
  // مفتاح "perfumes-total" لا "perfumes,count": الأخير يبدأ بـ"perfumes" فكان
  // إبطال 1.812 الموجّه (يستثني queryKey[0]==='perfumes') يتخطّاه فلا يتحدث؛
  // و هذا المفتاح المنفصل يبطل و يتحدث طبيعياً بعد دورة الزرع.
  const { data: totalPerfumes = 0 } = useQuery({
    queryKey: ["perfumes-total"],
    queryFn: () => apphost.entities.Perfume.count(),
    staleTime: Infinity,
  });

  // Holding companies — group brands by parent_company
  const holdingGroups = useMemo(() => {
    const groups = {};
    brands.forEach(b => {
      if (b.parent_company) {
        if (!groups[b.parent_company]) groups[b.parent_company] = [];
        groups[b.parent_company].push(b);
      }
    });
    return groups;
  }, [brands]);

  const filtered = useMemo(() => brands.filter((b) => {
    if (b.hidden) return false;
    // لا فلترة حية: الكتابة لا تجلب نتائج — الأيقونة/Enter تفتح صفحة النتائج
    return true;
  }), [brands]);

  // خريطة عدّ العطور لكل براند — من perfume_ids المملوءة وقت الزرع (طول القائمة)،
  // بلا تحميل الكتالوج. براند بلا perfume_ids يظهر صفراً (لا تعليق).
  const perfumeCountMap = useMemo(() => {
    const m = new Map();
    for (const b of brands) {
      if (!b || !b.name) continue;
      const n = String(b.perfume_ids || "").split(",").filter(Boolean).length;
      m.set(b.name, n);
    }
    return m;
  }, [brands]);
  const getPerfumeCount = (brandName) => perfumeCountMap.get(brandName) || 0;

  // مجموعة أسماء البراندات التي لديها عطر «أفضل عقد» (لإظهار التاج) — مسحة واحدة.
  const bestOfDecadeBrands = useMemo(() => {
    const s = new Set();
    for (const p of perfumes) {
      if (p && p.best_of_decade && p.brand_name && decadeFromYear(p.release_year) !== null) s.add(p.brand_name);
    }
    return s;
  }, [perfumes]);

  // مقارِن Intl واحد مُعاد استخدامه (localeCompare كان ينشئ مقارِناً جديداً في كل مقارنة).
  const collator = useMemo(() => new Intl.Collator("en", { sensitivity: "base", numeric: true }), []);

  // فرز البراندات: نحسب (المرتبة + الاسم) مرّة واحدة لكل براند بدل حسابها في كل مقارنة —
  // كان compareEnglish يشغّل rankName (NFD+regex) مرّتين + localeCompare لكل مقارنة، فيبطئ
  // فرز آلاف البراندات و يتكرّر مع كل تحديث ربط (سبب رندر /brands البطيء الذي رصده A).
  const sorted = useMemo(() => {
    if (sortBy === "perfumeCount") {
      return [...filtered].sort((a, b) => getPerfumeCount(b.name) - getPerfumeCount(a.name));
    }
    const withKey = filtered.map((b) => { const n = enSortName(b); return { b, r: rankName(n), n }; });
    withKey.sort((x, y) => (x.r !== y.r ? x.r - y.r : collator.compare(x.n, y.n)));
    if (!nameAsc) withKey.reverse();
    return withKey.map((x) => x.b);
  }, [filtered, sortBy, perfumeCountMap, nameAsc, collator]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / BRANDS_PER_PAGE));
  const paginated = useMemo(
    () => sorted.slice((page - 1) * BRANDS_PER_PAGE, page * BRANDS_PER_PAGE),
    [sorted, page]
  );
  useEffect(() => { if (page > totalPages) setPage(1); }, [totalPages, page]);

  // البراندات المثبّتة (حتى ٦) — من القائمة المحمَّلة، بترتيب التثبيت.
  const { pinnedIds: pinnedBrandIds } = usePins("brand");
  // تأجيل تثبيت البراند إلى ما بعد تحميل الصفحة (تفادي التعليق): لا نبني خريطة
  // البراندات و لا نعرض القسم المثبّت إلا بعد اكتمال التحميل و إفساح أوّل رسم.
  const [pinnedReady, setPinnedReady] = useState(false);
  useEffect(() => {
    if (isLoading || pinnedReady) return;
    const id = requestAnimationFrame(() => setPinnedReady(true));
    return () => cancelAnimationFrame(id);
  }, [isLoading, pinnedReady]);
  const pinnedBrands = useMemo(() => {
    if (!pinnedReady) return [];
    const byId = {};
    brands.forEach((b) => { byId[String(b.id)] = b; });
    return pinnedBrandIds.map((bid) => byId[String(bid)]).filter((b) => b && !b.hidden);
  }, [pinnedReady, brands, pinnedBrandIds]);

  // أيقونتا الفرز (All · A↑) — تُوضعان في صفّ التثبيت قبل الدبّوس مباشرة
  const sortIcons = (
    <span className="flex items-center gap-2 flex-shrink-0">
      <span title={isAr ? "كل الماركات" : "All Brands"}
        className="flex items-center justify-center">
        <Tally4 className="w-5 h-5" style={{ color: view === "list" ? "var(--brand)" : "#9a7b1f" }} />
      </span>
      <button type="button"
        onClick={() => { setView("list"); if (sortBy === "name") setNameAsc((v) => !v); else setSortBy("name"); }}
        title={isAr ? "أبجدي (A إلى #)" : "A to #"}
        className="flex items-center justify-center hover:opacity-70 transition-opacity">
        {sortBy === "name" && !nameAsc
          ? <AArrowDown className="w-5 h-5" style={{ color: (view === "list" && sortBy === "name") ? "var(--brand)" : "#9a7b1f" }} />
          : <AArrowUp className="w-5 h-5" style={{ color: (view === "list" && sortBy === "name") ? "var(--brand)" : "#9a7b1f" }} />}
      </button>
    </span>
  );

  // شارة أفضل العقد: ٥ معيّنات صغيرة جداً بلون التخصيص (بدل التاج)
  const Diamonds = () => (
    <span className="inline-flex flex-shrink-0" style={{ gap: 2 }} aria-hidden="true">
      {[0,1,2,3,4].map((i) => <span key={i} style={{ width: 4, height: 4, background: "var(--brand)", transform: "rotate(45deg)", display: "block" }} />)}
    </span>
  );

  return (
    <div className="px-5 page-top pb-4 space-y-5">
      {/* الترويسة: زرّ التنقّل قبل العنوان */}
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => { if (typeof window !== "undefined" && window.history.length > 1) navigate(-1); else navigate("/"); }}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity flex-shrink-0"
          aria-label={isAr ? "رجوع" : "Back"}
        >
          <BackIcon className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>{isAr ? "ماركات" : "Brands"}</h1>
      </div>

      {/* البحث أسفل الهيدر مباشرة */}
      <div className="relative flex items-center h-11 bg-white" dir={isAr ? "rtl" : "ltr"}>
        <div aria-hidden="true" className="w-px h-5 mx-3 flex-shrink-0" style={{ background: "var(--brand)" }} />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && search.trim()) navigate(`/search-results?q=${encodeURIComponent(search.trim())}`); }}
          placeholder=""
          dir={isAr ? "rtl" : "ltr"}
          className="flex-1 h-11 bg-transparent outline-none text-sm font-body px-1"
        />
        <button type="button" aria-label="search"
          onClick={() => { if (search.trim()) navigate(`/search-results?q=${encodeURIComponent(search.trim())}`); }}
          className="px-3 flex-shrink-0 hover:opacity-70 transition-opacity">
          <Search className="w-4 h-4" style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {/* A–Z Index View */}
      {view === "index" && <BrandsIndex brands={brands} isAr={isAr} />}

      {/* Analytics View */}
      {view === "analytics" && <BrandsAnalytics brands={brands} perfumes={perfumes} />}

      {/* List View */}
      {view === "list" && (
        <div className="space-y-3">
          {/* المثبّتة — أيقونتا الفرز (All · A↑) في صفّ أوّل مثبّت قبل الدبّوس مباشرة */}
          {pinnedBrands.length > 0 ? (
            <div className="space-y-1">
              {pinnedBrands.map((brand, idx) => {
                const bod = bestOfDecadeBrands.has(brand.name);
                const ar = brand.name_ar && brand.name_ar.trim();
                return (
                  <div key={`pin-${brand.id}`} className="flex items-center gap-2" dir={isAr ? "rtl" : "ltr"}>
                    {idx === 0 && sortIcons}
                    <Link to={`/brand?id=${brand.id}`}
                      className="flex items-center gap-2 flex-1 min-w-0 py-1.5 hover:opacity-70 transition-opacity">
                      <Pin className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "#B76E79" }} fill="#B76E79" />
                      {bod && <Diamonds />}
                      <span className="font-body text-sm min-w-0" style={{ overflowWrap: "anywhere" }}>
                        {ar && <span className="font-semibold">{brand.name_ar}</span>}
                        {ar && brand.name ? <span className="opacity-50"> .. </span> : null}
                        {brand.name && <span style={{ letterSpacing: "0.02em" }}>{brand.name}</span>}
                      </span>
                    </Link>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="flex items-center gap-2" dir={isAr ? "rtl" : "ltr"}>{sortIcons}</div>
          )}

          {(isLoading && brands.length === 0) ? (
            <div className="flex justify-center py-16">
              <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "color-mix(in srgb, var(--brand) 30%, transparent)", borderTopColor: "var(--brand)" }} />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <div className="w-16 h-16 bg-secondary rounded-none flex items-center justify-center mx-auto">
                <Building2 className="w-8 h-8 text-primary/30" />
              </div>
              <p className="text-muted-foreground font-body text-sm">{isAr ? "لا براندات" : "No brands found"}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-x-4 gap-y-0">
              {paginated.map((brand) => {
                const ar = brand.name_ar && brand.name_ar.trim();
                const bod = bestOfDecadeBrands.has(brand.name);
                return (
                  <Link key={brand.id} to={`/brand?id=${brand.id}`}
                    className="relative flex flex-col gap-0.5 py-2.5 px-0.5 min-w-0 hover:opacity-70 transition-opacity"
                    style={{ borderBottom: "1px solid var(--brand)" }}>
                    {/* أفضل العقد: معيّنات في الجهة المقابلة للنصّ (نفس السطر، بلا صفّ إضافي) */}
                    {bod && <span className="absolute top-2" style={{ insetInlineEnd: 2 }}><Diamonds /></span>}
                    {ar && <span className="font-body text-sm font-semibold" style={{ color: "var(--brand)", overflowWrap: "anywhere" }}>{brand.name_ar}</span>}
                    {brand.name && <span className="font-body text-[13px]" style={{ letterSpacing: "0.02em", overflowWrap: "anywhere" }}>{brand.name}</span>}
                  </Link>
                );
              })}
            </div>
          )}

          {/* السطر المدمج: ترقيم + عدّ البراندات + عدّ العطور + سهما تالي/سابق — بعد الصندوق */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-5 pt-3" dir="ltr">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="text-muted-foreground disabled:opacity-25 p-2 -m-1"
                aria-label={isAr ? "السابق" : "Previous"}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-[9px] text-muted-foreground font-body tabular-nums">
                {(page - 1) * BRANDS_PER_PAGE + 1}-{Math.min(page * BRANDS_PER_PAGE, sorted.length)}
              </span>
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="text-muted-foreground disabled:opacity-25 p-2 -m-1"
                aria-label={isAr ? "التالي" : "Next"}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* روابط ملوّنة بلا إطارات — بعد العدّاد */}
          <div className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 mt-3 font-body font-semibold text-sm">
            <Link to="/collection-search" style={{ color: "#B76E79" }} className="hover:opacity-70 transition-opacity">{isAr ? "بحث مجموعتك" : "Collection Search"}</Link>
            <Link to="/marketing-card" style={{ color: "#059669" }} className="hover:opacity-70 transition-opacity">{isAr ? "بطاقة تسويق" : "Create Marketing Card"}</Link>
            <Link to="/compare-card" style={{ color: "#0284C7" }} className="hover:opacity-70 transition-opacity">{isAr ? "بطاقة عطور" : "Perfume Comparison Card"}</Link>
            <Link to="/add-brand" className="text-emerald-600 hover:opacity-70 transition-opacity">{isAr ? "إضافة" : "Add"}</Link>
            <Link to="/net" style={{ color: "#2563EB" }} className="hover:opacity-70 transition-opacity">{isAr ? "شبكة عطور و ماركات" : "Perfume and Brand Net"}</Link>
            <Link to="/healthy-index" style={{ color: "#EA580C" }} className="hover:opacity-70 transition-opacity">{isAr ? "فهرس صحي" : "Healthy Index"}</Link>
            <Link to="/brandperfume-index" style={{ color: "var(--brand)" }} className="hover:opacity-70 transition-opacity">{isAr ? "فهرس" : "Index"}</Link>
          </div>

          {/* Holding Companies Section */}
          {Object.keys(holdingGroups).length > 0 && (
            <div className="bg-card rounded-none p-5 shadow-sm space-y-3 mt-6">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-8 h-8 bg-primary/10 rounded-none flex items-center justify-center">
                  <Building2 className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h2 className="font-heading font-semibold text-base">{isAr ? "شركات العطور القابضة" : "Holding Companies"}</h2>
                  <p className="text-xs text-muted-foreground font-body">{isAr ? "الشركات الأم و دورها العطري" : "Parent companies & their fragrance brands"}</p>
                </div>
              </div>
              <div className="space-y-3">
                {Object.entries(holdingGroups).map(([company, compBrands]) => (
                  <div key={company} className="bg-secondary/40 rounded-none p-3">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm font-body font-bold">{company}</p>
                      <span className="text-[10px] text-primary rounded-none font-body font-semibold">
                        {compBrands.length} {isAr ? "دار" : "brand" + (compBrands.length !== 1 ? "s" : "")}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {compBrands.map(b => (
                        <Link key={b.id} to={`/brand?id=${b.id}`}
                          className="text-xs rounded-none font-body transition-colors">
                          {b.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          </div>
          )}

          {/* عدّ العطور الآن مدمج في سطر الترقيم أعلاه (تحت صندوق «بحث مجموعتك») */}
          </div>
          );
          }
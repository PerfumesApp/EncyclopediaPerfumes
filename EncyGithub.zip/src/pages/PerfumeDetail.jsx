import { useState } from "react";
import { emojiSizeClass } from "@/lib/bigEmojis";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { searchIndexReady, perfumeIdsLinkingTo } from "@/lib/searchIndex";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { User, Camera, SprayCan, Edit2 } from "lucide-react";
import PerfumeSprayIcon from "@/components/icons/PerfumeSprayIcon";
import { accordColor, accordChipStyle } from "@/lib/accordColors";
import AccordBars from "@/components/perfume/AccordBars";
import StarRating from "@/components/perfume/StarRating";
import FragranceNotesGrid from "@/components/perfume/FragranceNotesGrid";
import ListBadge from "@/components/perfume/ListBadge";
import DefaultBottleImage from "@/components/perfume/DefaultBottleImage";
import ZoomableImage from "@/components/shared/ZoomableImage";
import PerfumeCardBox from "@/components/perfume/PerfumeCardBox";
import AccordFlaconCard from "@/components/perfume/AccordFlaconCard";
import { decadeLabel } from "@/lib/decade";
import { looseBrandKey } from "@/lib/sortName";
import { dominantAccord } from "@/components/perfume/AccordFlacon";
import { scentClassAr } from "@/lib/crowdLabels";
import StoreSelector from "@/components/store/StoreSelector";
import { ensureUnassignedStore } from "@/lib/unassignedStore";
import EditPurchaseDialog from "@/components/purchase/EditPurchaseDialog";
import { format } from "date-fns";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { FORM_PERFUME_TYPES as PERFUME_TYPES, typeDisplay, strengthOf } from "@/lib/perfumeTypes";
import { StrengthTrack } from "@/components/perfume/StrengthIndicator";
import HealthRatingSection from "@/components/perfume/HealthRatingSection";
import CareSafetySection from "@/components/perfume/CareSafetySection";
import { perfumeLabels, analyzePerfume, strictHealth, MECH } from "@/lib/headacheRisk";
import { OCCASIONS as OCCASIONS_LIB, occasionInfo } from "@/lib/occasions";
import { useOccasionMode, fmtOcc } from "@/lib/useOccasionMode";
import PerfumersSection from "@/components/perfume/PerfumersSection";
import SimilarPerfumes from "@/components/perfume/SimilarPerfumes";
import WearScheduleSection from "@/components/perfume/WearScheduleSection";
import ExportHistoryList from "@/components/export/ExportHistoryList";
import EraserIcon from "@/components/icons/EraserIcon";
import CopyMenu from "@/components/shared/CopyMenu";
import BookmarkButton from "@/components/shared/BookmarkButton";
import PinButton from "@/components/shared/PinButton";
import { perfumeDbText, perfumeFullText } from "@/lib/copyData";
import IndexLinksRow from "@/components/shared/IndexLinksRow";
import { addCastawayPerfumeId } from "@/lib/castawayPerfumes";
import BackIcon from "@/components/shared/BackIcon";

export default function PerfumeDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  // إبعاد هذا العطر مباشرةً (إخفاؤه) مع تأكيد — صفحة المهملات تبقى في الإعدادات.
  const handleCastAwayPerfume = async () => {
    if (!id) return;
    const ok = window.confirm(isAr ? "نقل هذا العطر إلى المهملات؟" : "Move this perfume to Cast Away?");
    if (!ok) return;
    try {
      await apphost.entities.Perfume.update(id, { hidden: true });
      addCastawayPerfumeId(id);
      queryClient.invalidateQueries({ queryKey: ["castaway-perfumes"] });
      toast.success(isAr ? "نُقل إلى المهملات" : "Moved to Cast Away");
      navigate(-1);
    } catch {
      toast.error(isAr ? "تعذّر النقل" : "Failed");
    }
  };
  const { isAr } = useLang();
  const { names, profiles } = usePersonNames();
  const [occMode] = useOccasionMode("perfume");
  const [userOccMode] = useOccasionMode("user");
  const personColor = (pp) => (pp === "person2" ? profiles?.person2?.color : profiles?.person1?.color) || (pp === "person2" ? "#ec4899" : "#10b981");
  const { formatPrice } = useCurrency();
  const [wearDialogOpen, setWearDialogOpen] = useState(false);
  const [wearNote, setWearNote] = useState("");
  const [wearPerson, setWearPerson] = useState("person1");
  const [wearMood, setWearMood] = useState("");
  const [activePerson, setActivePerson] = useState("person1");
  const [editNotes, setEditNotes] = useState(false);
  const [notes, setNotes] = useState("");
  const [editSampleMl, setEditSampleMl] = useState(false);
  const [sampleMl, setSampleMl] = useState("");
  const [editSampleCost, setEditSampleCost] = useState(false);
  const [sampleCost, setSampleCost] = useState("");
  const [purchaseType, setPurchaseType] = useState("sample");
  const [selectedStore, setSelectedStore] = useState("");
  const [showImageDialog, setShowImageDialog] = useState(false);

  const [wishDialogOpen, setWishDialogOpen] = useState(false);
  const [wishPrice, setWishPrice] = useState("");
  const [wishPriority, setWishPriority] = useState("medium");
  const [wishNotes, setWishNotes] = useState("");

  // Shared perfume data (app database)
  const { data: perfume, isLoading } = useQuery({
    queryKey: ["perfume", id],
    queryFn: () => apphost.entities.Perfume.filter({ id }),
    select: (data) => data?.[0],
    enabled: !!id,
  });

  // Per-person user data
  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfume", id],
    queryFn: () => apphost.entities.UserPerfume.filter({ perfume_id: id }),
    enabled: !!id,
  });

  const userDataP1 = userPerfumes.find((u) => u.person === "person1") || null;
  const userDataP2 = userPerfumes.find((u) => u.person === "person2") || null;
  const activeUserData = activePerson === "person1" ? userDataP1 : userDataP2;
  


  const { data: wearLogs = [] } = useQuery({
    queryKey: ["wear-logs-perfume", id],
    queryFn: () => apphost.entities.WearLog.filter({ perfume_id: id }),
    enabled: !!id,
  });

  // Fetch ALL purchases for this perfume (both persons)
  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records", id],
    queryFn: () => apphost.entities.PurchaseRecord.filter({ perfume_id: id }, "-created_date"),
    enabled: !!id,
  });

  // سجلّ موحّد: مشتريات + ارتداءات مرتّبة بالتاريخ تنازليّاً (لجدول واحد)
  const mergedHistory = [
    ...purchaseRecords.map((r) => ({ kind: "purchase", key: `p-${r.id}`, date: r.purchase_date || "", raw: r })),
    ...wearLogs.map((l) => ({ kind: "wear", key: `w-${l.id}`, date: l.date || "", raw: l })),
  ].sort((a, b) => String(b.date).localeCompare(String(a.date)));

  const { data: stores = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
  });

  // For edit dialog: fetch categories and odor families from DB

  // For export: fetch all note records to match by name
  const { data: allNoteRecords = [] } = useQuery({
    queryKey: ["all-perfume-notes-export"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 1000 * 60 * 10,
  });
  const noteRecordsForExport = {};
  allNoteRecords.forEach(n => { noteRecordsForExport[n.name?.toLowerCase()] = n; });

  // (أزيل تحميل كل العطّارين «للتصدير» — كان كوداً ميتاً: الخريطة لم تكن تُستهلك
  // في أي موضع، و كانت تكلف ٣٠٧١ سجلاً عند كل فتح للصفحة.)

  // Fetch all perfumes ONLY when this perfume actually has related links.
  // العطور الجديدة (130 ألف) بلا روابط → لا نحمّل القائمة الكاملة فتفتح الصفحة فوراً.
  // العطور المرتبطة (الاتجاهان) عبر الفهرس بدل تحميل 130 ألفاً:
  //  • المباشرة: getMany لمعرّفات related_perfume_ids.
  //  • العكسية: دلو rel:<id> ← getMany.
  // سقوط: إن لم يكتمل الفهرس بعد، نحمّل القائمة الكاملة (المسلك القديم) مؤقتاً.
  const indexReady = searchIndexReady();
  const fwdIds = String(perfume?.related_perfume_ids || "").split(",").map(s => s.trim()).filter(Boolean);

  const { data: relatedFwd = [] } = useQuery({
    queryKey: ["perfume-related-fwd", perfume?.id, fwdIds.length],
    queryFn: () => apphost.entities.Perfume.getMany(fwdIds),
    staleTime: Infinity,
    enabled: indexReady && fwdIds.length > 0,
  });

  const { data: relatedRev = [] } = useQuery({
    queryKey: ["perfume-related-rev", perfume?.id],
    queryFn: async () => {
      const { ids } = await perfumeIdsLinkingTo(perfume.id);
      return ids.length ? apphost.entities.Perfume.getMany(ids) : [];
    },
    staleTime: Infinity,
    enabled: indexReady && !!perfume,
  });

  // سقوط للقائمة الكاملة فقط حين لا يكون الفهرس جاهزاً بعد.
  const { data: allPerfumesFallback = [] } = useAllPerfumes("-created_date", { enabled: !indexReady && !!perfume });

  // مصدران موحّدان للعرض: المباشرة والعكسية (يختاران بين الفهرس والسقوط).
  const relatedForward = indexReady
    ? relatedFwd
    : allPerfumesFallback.filter(p => fwdIds.includes(String(p.id)));
  const relatedReverse = indexReady
    ? relatedRev
    : allPerfumesFallback.filter(p => p.related_perfume_ids?.split(",").some(rid => rid.trim() === id));



  const wearMutation = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["wear-logs-perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success((isAr ? "سُجّل في سجل الارتداء" : "Logged to wear history"));
      setWearDialogOpen(false);
      setWearNote("");
      setWearMood("");
      setWearPerson("person1");
    },
  });

  // Fetch perfume-related ShopBrands to find linked brand
  const { data: shopBrands = [] } = useQuery({
    queryKey: ["shop-brands-light"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const recordPurchaseEverywhere = async ({ perfume, activePerson, purchaseType, mlVal, costVal, selectedStore, stores, activeUserData }) => {
    console.log("🛒 START purchase:", { perfumeName: perfume.name_en, mlVal, costVal, selectedStore });
    const store = selectedStore ? stores.find((s) => String(s.id) === String(selectedStore)) : null;
    // المتجر اختياريّ؛ إن لم يُحدَّد يُنسب الشراء لمتجر «غير محدد» الحقيقيّ (لا متجر المثال)
    let storeIdFinal = selectedStore || null;
    let storeNameFinal = store?.name || null;
    if (!storeIdFinal) {
      const ua = await ensureUnassignedStore();
      if (ua?.id) { storeIdFinal = ua.id; storeNameFinal = ua.name; }
    }
    const today = format(new Date(), "yyyy-MM-dd");
    const perfumeName = perfume.name_en || perfume.name || "";

    // 0. Ensure UserPerfume exists (required for purchase tracking)
    let userPerfumeId = activeUserData?.id;
    if (!userPerfumeId) {
      const existing = await apphost.entities.UserPerfume.filter({ perfume_id: perfume.id, person: activePerson });
      if (existing.length > 0) {
        userPerfumeId = existing[0].id;
      } else {
        const created = await apphost.entities.UserPerfume.create({
          perfume_id: perfume.id,
          perfume_name: perfumeName,
          brand_name: perfume.brand_name || "",
          person: activePerson,
          sample_ml: 0,
          sample_cost: 0,
        });
        userPerfumeId = created.id;
      }
    }

    console.log("UserPerfume ready, id:", userPerfumeId);
    // 1. Create PurchaseRecord
    const pr = await apphost.entities.PurchaseRecord.create({
      user_perfume_id: userPerfumeId,
      perfume_id: perfume.id,
      perfume_name: perfumeName,
      brand_name: perfume.brand_name || "",
      person: activePerson,
      type: purchaseType,
      ml: mlVal,
      cost: costVal,
      purchase_date: today,
      store_id: storeIdFinal,
      store_name: storeNameFinal,
    });

    console.log("PurchaseRecord created:", pr?.id);
    // 2. Find or create ShopProduct linked to this perfume
    const personVal = activePerson === "person1" ? "person1" : "person2";
    const existingProducts = await apphost.entities.ShopProduct.filter({ linked_perfume_id: perfume.id, person: personVal });
    const linkedShopBrand = shopBrands.find(b => b.linked_perfume_brand_id === perfume.brand_id);

    if (existingProducts.length > 0) {
      // Update existing ShopProduct cost
      const sp = existingProducts[0];
      await apphost.entities.ShopProduct.update(sp.id, {
        cost: (sp.cost || 0) + costVal,
        ml: (sp.ml || 0) + mlVal,
        purchase_date: today,
        purchase_type: purchaseType,
        store_id: selectedStore || sp.store_id || storeIdFinal,
        store_name: (selectedStore ? stores.find(s => String(s.id) === String(selectedStore))?.name : null) || sp.store_name || storeNameFinal,
      });
    } else {
      // Create new ShopProduct
      const store = selectedStore ? stores.find((s) => String(s.id) === String(selectedStore)) : null;
      await apphost.entities.ShopProduct.create({
        name: perfumeName,
        name_ar: perfume.name_ar || "",
        brand_id: linkedShopBrand?.id || null,
        brand_name: linkedShopBrand?.name || perfume.brand_name || "",
        category_id: "cat_fragrance",
        category_name_en: "Perfumes & Fragrances",
        category_name_ar: "العطور و الروائح",
        linked_perfume_id: perfume.id,
        linked_perfume_name: perfumeName,
        cost: costVal,
        purchase_date: today,
        purchase_type: purchaseType,
        ml: mlVal,
        person: personVal,
        status: "active",
        store_id: storeIdFinal,
        store_name: storeNameFinal,
      });
    }

    console.log("ShopProduct done");
    // ملاحظة: لا نُنشئ BudgetExpense هنا — الشراء يُسجَّل كـShopProduct ويُحتسب
    // ضمن «المشتريات» (totalPurchases) في الميزانية. إنشاء BudgetExpense إضافي
    // كان يحتسب نفس المبلغ مرّتين (22 → 44). [إصلاح Dior]
    // 4. Update UserPerfume totals (sample_ml + sample_cost)
    const upResults = await apphost.entities.UserPerfume.filter({ perfume_id: perfume.id, person: activePerson });
    const up = upResults?.[0];
    if (up) {
      await apphost.entities.UserPerfume.update(up.id, {
        sample_ml: (parseFloat(up.sample_ml || 0) + mlVal),
        sample_cost: (parseFloat(up.sample_cost || 0) + costVal),
      });
    }

    console.log("Purchase complete!");
    return pr;
  };

  const purchaseMutation = useMutation({
    mutationFn: (data) => recordPurchaseEverywhere(data),
    onError: (error) => {
      console.error("Purchase failed:", error);
      toast.error(`فشل التسجيل: ${error.message || error}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["purchase-records", id] });
      queryClient.invalidateQueries({ queryKey: ["purchase-records"] });
      queryClient.invalidateQueries({ queryKey: ["shop-products"] });
      queryClient.invalidateQueries({ queryKey: ["shop-products-by-category"] });
      toast.success((isAr ? "سُجّل الشراء" : "Purchase recorded"));
    },
  });

  // Upsert user perfume data (create or update)
  const upsertUserData = useMutation({
    mutationFn: async ({ person, field, value }) => {
      const existing = person === "person1" ? userDataP1 : userDataP2;
      const personName = person === "person1" ? names.person1 : names.person2;
      const dataToSave = { [field]: value };
      if (existing) {
        return apphost.entities.UserPerfume.update(existing.id, { ...dataToSave, person_name: personName });
      } else {
        return apphost.entities.UserPerfume.create({
          perfume_id: id,
          perfume_name: perfume?.name_en || perfume?.name_ar || "",
          brand_name: perfume?.brand_name || "",
          brand_id: perfume?.brand_id || "",
          person,
          person_name: personName,
          in_collection: 0,
          ...dataToSave,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["user-perfumes"] });
      toast.success((isAr ? "تم التحديث" : "Updated"));
    },
  });

  // عضوية المجموعة = علامة in_collection (لا حذف): السجلّات القديمة بلا العلامة تُعدّ ضمن المجموعة.
  const inCollection = !!activeUserData && activeUserData.in_collection !== 0;
  const setCollection = (value) => upsertUserData.mutate({ person: activePerson, field: "in_collection", value: value ? 1 : 0 });

  // مجموعة الكتالوج (خط البراند) التي ينتمي إليها العطر — لعرض اسمها «ضيافة و قيم» كرابط للبراند.
  const { data: catalogCollection = null } = useQuery({
    queryKey: ["perfume-catalog-collection", perfume?.collection_id, perfume?.collection, perfume?.brand_name],
    queryFn: async () => {
      try {
        const nm = (perfume?.collection || "").trim();
        if (!nm) return null;
        const rows = await apphost.entities.PerfumeCollection.filter({ name: nm });
        const hit = (rows || []).find((c) => String(c.id) === String(perfume?.collection_id ?? "")) ||
          (rows || []).find((c) => !perfume?.brand_name || String(c.brand_name || "") === String(perfume.brand_name || "")) ||
          (rows || [])[0];
        return hit || null;
      } catch { return null; }
    },
    enabled: !!(perfume?.collection),
  });
  const catalogCollectionName = catalogCollection ? (isAr ? (catalogCollection.name_ar || catalogCollection.name) : (catalogCollection.name || catalogCollection.name_ar)) : (perfume?.collection || "");

  // Fetch user mark
  const { data: userData } = useQuery({
    queryKey: ["current-user"],
    queryFn: () => apphost.auth.me(),
  });

  // Update perfume image
  const updatePerfumeMutation = useMutation({
    mutationFn: (data) => apphost.entities.Perfume.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfume", id] });
      toast.success((isAr ? "حُدّثت الصورة" : "Image updated"));
    },
  });

  // تقييم العطر (يُخزَّن على سجلّ العطر — هو ما يُظهر المعيّنات الذهبية في البطاقة)
  const ratingMutation = useMutation({
    mutationFn: (rating) => apphost.entities.Perfume.update(id, { rating }),
    onMutate: async (rating) => {
      await queryClient.cancelQueries({ queryKey: ["perfume", id] });
      const prev = queryClient.getQueryData(["perfume", id]);
      queryClient.setQueryData(["perfume", id], (old) =>
        Array.isArray(old) ? old.map((p) => ({ ...p, rating })) : old
      );
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev !== undefined) queryClient.setQueryData(["perfume", id], ctx.prev);
      toast.error(isAr ? "تعذّر حفظ التقييم" : "Couldn't save rating");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["perfumes"] });
    },
  });



  // Add to wishlist
  const addToWishlist = useMutation({
    mutationFn: () => apphost.entities.Wishlist.create({
      perfume_id: id,
      perfume_name: perfume.name_en || perfume.name_ar || "",
      brand_name: perfume.brand_name || "",
      brand_id: perfume.brand_id || "",
      image_url: perfume.image_url || "",
      estimated_price: parseFloat(wishPrice) || 0,
      person: activePerson,
      priority: wishPriority,
      notes: wishNotes,
      added_date: format(new Date(), "yyyy-MM-dd"),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["wishlists"] });
      toast.success(isAr ? "تمت إضافة الرغبة" : "Added to wishlist!");
      setWishDialogOpen(false);
      setWishPrice("");
      setWishPriority("medium");
      setWishNotes("");
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!perfume) {
    return (
      <div className="px-5 page-top text-center">
        <p className="text-muted-foreground font-body">{isAr ? "العطر غير موجود" : "Perfume not found"}</p>
        <Button variant="ghost" onClick={() => navigate("/")} className="mt-4">{isAr ? "الرئيسية" : "Go Home"}</Button>
      </div>
    );
  }



  const handleNoteClick = (note) => {
    navigate(`/explore?noteSearch=${encodeURIComponent(note)}`);
  };

  const handleAttrClick = (attr, value) => {
    const params = new URLSearchParams();
    if (attr === "gender") params.set("genderFilter", value);
    if (attr === "type") params.set("typeFilter", value);
    navigate(`/explore?${params.toString()}`);
  };

  const handleNoteSave = () => {
    updatePerfumeMutation.mutate({ 
      personal_notes: notes,
      rating: perfume.rating
    });
    setEditNotes(false);
  };

  return (
    <div className="pb-4 bg-[var(--page-bg,#fff)] min-h-screen max-w-full overflow-x-hidden">
      {/* Hero Image — حدّ ذهبي كالجداول + مسافة تحتها، الضغط يكبّر بلا زرّ */}
      <div className="px-5 pt-6 relative">
         {perfume.image_url && perfume.image_url !== "white" ? (
           <div className="bg-[var(--page-bg,#fff)] p-1.5" style={{ marginTop: 20 }}>
             <ZoomableImage
               src={perfume.image_url}
               alt={perfume.name_en || perfume.name || ""}
               bare
               hideZoomBadge
               inlineMaxHeight="300px"
               className="w-full flex items-center justify-center [&_img]:max-h-[300px]"
             />
           </div>
         ) : (
           <div className="bg-transparent p-2 flex items-center justify-center" style={{ minHeight: 220, marginTop: 20 }}>
             <DefaultBottleImage perfume={perfume} height={280} style={{ margin: "0 auto" }} />
           </div>
         )}
         <div className="absolute top-9 left-8">
           <Button variant="ghost" size="icon" className="rounded-none hover:bg-transparent" onClick={() => navigate(-1)}>
             <BackIcon className="w-5 h-5" />
           </Button>
         </div>
       </div>

      <div className="px-5 mt-5 relative space-y-5">

         {/* الاسم والبراند — عرض حرّ بلا جدول: الإنجليزي يسار، والبراند+العربي يمين (ثابت مهما كانت اللغة) */}
         {/* الاسم: العربي فوق الإنجليزي (مثل ترتيب وردمارك البراند)، خطّ أصغر؛ البراند يبقى يميناً مكانه */}
         <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            {perfume.name_ar && (
              <p className="font-heading text-sm font-semibold leading-tight break-words" dir="rtl" style={{ color: "#9D174D" }}>{perfume.name_ar}</p>
            )}
            {perfume.name_en ? (
              <h1 className="font-heading text-lg font-bold leading-tight break-words" style={{ color: "#9a7b1f" }}>{perfume.name_en}</h1>
            ) : (!perfume.name_ar && perfume.name ? (
              <h1 className="font-heading text-lg font-bold leading-tight break-words" style={{ color: "#9a7b1f" }}>{perfume.name}</h1>
            ) : null)}
          </div>
          <div className="flex flex-col items-end gap-1.5 shrink-0 text-right max-w-[45%]">
            {perfume.best_of_decade && decadeLabel(perfume.release_year) && (
              <span title={isAr ? "أفضل عطر في العقد" : "Best of decade"} style={{ display: "inline-flex" }}>
                <svg viewBox="0 0 40 16" width={17} height={7} aria-hidden="true" style={{ transform: "rotate(-22deg)" }}>
                  <path d="M8 13 l2-7 4 4 6-7 6 7 4-4 2 7z" fill="var(--brand)" stroke="#9a7b1f" strokeWidth="0.4" />
                </svg>
              </span>
            )}
            {perfume.brand_name && (
              <button
                onClick={async () => {
                  const goByName = () => navigate(`/brand?name=${encodeURIComponent(perfume.brand_name || "")}`);
                  try {
                    if (perfume.brand_id) {
                      navigate(`/brand?id=${encodeURIComponent(perfume.brand_id)}`);
                      return;
                    }
                    if (!perfume.brand_name) return;
                    // مطابقة دقيقة أولاً، ثم مطابقة متسامحة (تتجاوز اختلاف المسافات حول & والحالة)
                    let matches = await apphost.entities.PerfumeBrand.filter({ name: perfume.brand_name });
                    let hit = matches?.[0];
                    if (!hit?.id) {
                      const want = looseBrandKey(perfume.brand_name);
                      const all = await apphost.entities.PerfumeBrand.list("name", 1000000);
                      hit = (all || []).find((b) => looseBrandKey(b.name) === want);
                    }
                    if (hit?.id) {
                      navigate(`/brand?id=${encodeURIComponent(hit.id)}`);
                    } else {
                      goByName();
                    }
                  } catch {
                    goByName();
                  }
                }}
                className="text-[10px] text-primary font-body uppercase tracking-widest font-medium hover:underline cursor-pointer">
                {perfume.brand_name}
              </button>
            )}
            {/* المجموعة نُقلت بعد الوصف بلا بادئة */}
          </div>
        </div>
        {activeUserData?.list === "favorite" ? (
          <div className="flex justify-end -mt-2">
            <span className="text-[12px] font-body font-semibold flex items-center gap-1.5" style={{ color: "#C2253B" }}>
              <span>❤️</span>{isAr ? "مفضل" : "Favorite"}
            </span>
          </div>
        ) : activeUserData?.list ? (
          <div className="flex justify-end -mt-2"><ListBadge list={activeUserData.list} /></div>
        ) : null}

        {/* عن العطر About — النوع/التركيز/السنة بعد الوصف */}
        {(perfume.about_en || perfume.about_ar || perfume.scent_class || perfume.type || perfume.concentration || perfume.release_year || perfume.discontinued) && (
          <div className="p-5 space-y-3">
            <p className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest">About عن العطر</p>
            {perfume.about_en && (
              <p className="text-sm font-body text-foreground/90 leading-relaxed">{perfume.about_en}</p>
            )}
            {perfume.about_ar && (
              <p className="text-sm font-body text-foreground/90 leading-relaxed text-right" dir="rtl">{perfume.about_ar}</p>
            )}
            {perfume.care_profile && <CareSafetySection perfume={perfume} />}
            {strengthOf(perfume.type || perfume.concentration) && (
              <div className="flex justify-center pt-1">
                <StrengthTrack strength={strengthOf(perfume.type || perfume.concentration)} width={170} />
              </div>
            )}
            <div className="flex items-center gap-2.5 flex-wrap pt-1">
              {perfume.scent_class && (
                <span dir="rtl" className="text-xs font-body px-3 py-1" style={{ color: "#9a7b1f" }}>
                  {scentClassAr(perfume.scent_class)} {perfume.scent_class}
                </span>
              )}
              {perfume.type && (
                <span dir={isAr ? "rtl" : "ltr"} className="text-xs font-body px-3 py-1 inline-flex items-center gap-2" style={{ color: "#9a7b1f" }}>
                  {typeDisplay(perfume.type, isAr ? "ar" : "both")}
                </span>
              )}
              {perfume.concentration && (() => {
                const typeObj = PERFUME_TYPES.find(t => t.value === perfume.concentration);
                const label = typeObj ? `${typeObj.label_ar} ${perfume.concentration}` : perfume.concentration;
                return <span dir="rtl" className="text-xs font-body px-3 py-1" style={{ color: "#9a7b1f" }}>{label}</span>;
              })()}
              {perfume.release_year && (
                <span className="text-xs font-body px-3 py-1" style={{ color: "#9a7b1f" }}>{perfume.release_year}</span>
              )}
              {perfume.discontinued && <span className="px-3 py-1 text-xs font-body font-medium text-red-600 dark:text-red-400">{isAr ? "متوقّف" : "Discontinued"}</span>}
            </div>
          </div>
        )}

        {/* المجموعة بعد الوصف مباشرة، بلا «In Collections» */}
        {perfume.collection && (perfume.brand_name || perfume.brand_id) && (
          <button
            onClick={() => {
              if (perfume.brand_id) { navigate(`/brand?id=${encodeURIComponent(perfume.brand_id)}`); return; }
              if (perfume.brand_name) navigate(`/brand?name=${encodeURIComponent(perfume.brand_name)}`);
            }}
            className="block px-5 -mt-1 text-xs font-body font-medium hover:underline cursor-pointer text-center"
            style={{ color: "var(--brand)" }}>
            {catalogCollectionName}
          </button>
        )}

        {/* بطاقة العطر الإضافية — بلا ليبل/إطار/اسم/براند، خلفية شفافة لتندمج مع الصفحة */}
        <div className="py-1">
          <div className="max-w-[170px] mx-auto">
            <div className="relative aspect-square bg-transparent overflow-hidden flex items-center justify-center">
              <AccordFlaconCard perfume={perfume} bestOfDecade={!!perfume.best_of_decade} className="w-full h-full" />
            </div>
          </div>
          {perfume.best_of_decade && decadeLabel(perfume.release_year) && (
            <p className="text-center text-[11px] font-body mt-1.5" style={{ color: "#3B6D11" }}>
              {isAr ? `أفضل العقد — ${decadeLabel(perfume.release_year)}` : `Best of decade — ${decadeLabel(perfume.release_year)}`}
            </p>
          )}
          {(() => {
            const dom = dominantAccord(perfume.accords);
            // الشارات على نفس سطر النوتة المسيطرة: منقطع (بنّي) — مجموعة (ذهبي) — نوتة مقيّدة (أحمر)
            const RESTRICTED_RE = /\b(?:grey ambergris|white ambergris|ambergris|benzyl benzoate|cinnamaldehyde|civet absolute|civettone|civetone|civet|coumarin|deer musk|eugenol|indian sandalwood|lilial|lyral|peru balsam|pine tar)\b/i;
            const noteTxt = `${perfume.top_notes || ""} ${perfume.heart_notes || ""} ${perfume.base_notes || ""}`;
            const restricted = RESTRICTED_RE.test(noteTxt);
            const discontinued = perfume.discontinued === true || perfume.discontinued === "true" || perfume.discontinued === 1;
            const inCollection = !!(perfume.collection && String(perfume.collection).trim());
            const sq = (color, title) => <span key={title} title={title} className="inline-block w-2.5 h-2.5 flex-shrink-0" style={{ background: color }} />;
            if (!dom && !restricted && !discontinued && !inCollection) return null;
            return (
              <div className="flex items-center justify-center gap-2 mt-1 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
                {restricted && sq("#dc2626", isAr ? "نوتة مقيّدة" : "Restricted note")}
                {discontinued && sq("#8a5a2b", isAr ? "منقطع" : "Discontinued")}
                {inCollection && sq("var(--brand)", isAr ? "ضمن مجموعة" : "In a collection")}
                {dom && (
                  <>
                    <span className="inline-block w-2.5 h-2.5 flex-shrink-0" style={{ background: dom.bar }} />
                    <span className="text-xs font-body font-semibold text-foreground/80">{String(dom.en || "").toUpperCase()} {dom.ar}</span>
                  </>
                )}
              </div>
            );
          })()}
        </div>

        {/* بطاقة العطر — رأي الجمهور المستورد */}
        <PerfumeCardBox perfume={perfume} />

        {/* Odor Family — العائلة العطرية */}
        {perfume.accords ? (
          <AccordBars accords={perfume.accords} strength={strengthOf(perfume.type || perfume.concentration)} />
        ) : perfume.odor_family && (
          <div className="bg-[var(--page-bg,#fff)] rounded-none px-5 py-4">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest ml-0 mr-2">العائلة العطرية Odor Family</span>
              {strengthOf(perfume.type || perfume.concentration) && <StrengthTrack strength={strengthOf(perfume.type || perfume.concentration)} width={120} />}
              {perfume.odor_family.split(",").map(f => f.trim()).filter(Boolean).map(f => (
                <Link
                  key={f}
                  to={`/search-results?q=${encodeURIComponent(f)}`}
                  className="inline-flex items-center gap-1.5 border px-3 py-1 rounded-none text-xs font-body font-medium text-foreground/80 uppercase transition-opacity hover:opacity-70"
                  style={accordChipStyle(f)}
                  title={`@${f}`}
                >
                  <span className="w-2 h-2 rounded-none flex-shrink-0" style={{ background: accordColor(f) }} />
                  {f}
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Health indicator — مؤشر الصحة (يُولَّد تلقائياً من نوتات العطر) */}
        {(() => {
          const hLabels = perfumeLabels(perfume);
          const { groups } = analyzePerfume(perfume);
          const famCount = groups.length;
          const heavy = /parfum|extrait|مركّز/i.test(`${perfume.concentration || ""} ${perfume.type || ""}`);
          const score = famCount + (heavy ? 1 : 0);
          let level;
          if (famCount === 0) level = { ar: "مناسب للحسّاسين", en: "Sensitive-friendly", bg: "#EAF3DE", fg: "#3B6D11", dot: "#639922" };
          else if (score <= 2) level = { ar: "منخفض", en: "Low", bg: "#EAF3DE", fg: "#3B6D11", dot: "#639922" };
          else if (score <= 4) level = { ar: "متوسط", en: "Medium", bg: "#FAEEDA", fg: "#854F0B", dot: "#BA7517" };
          else level = { ar: "مرتفع", en: "High", bg: "#FCEBEB", fg: "#791F1F", dot: "#E24B4A" };
          const countFor = (m) => (hLabels.find((l) => l.mech === m)?.groups.length) || 0;
          const allergyLabel = hLabels.find((l) => l.mech === "allergy");
          const squares = (n) => (
            <span className="inline-flex gap-1">
              {[0, 1, 2, 3].map((i) => (
                <span key={i} style={{ width: 9, height: 9, background: i < n ? "var(--brand)" : "transparent", border: "1px solid var(--brand)", display: "inline-block" }} />
              ))}
            </span>
          );
          return (
            <div className="px-5 py-4 space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest">مؤشر الصحة Health</span>
                <span className="inline-flex items-center gap-1.5 text-xs font-body font-medium" style={{ color: level.fg }}>
                  <span style={{ width: 9, height: 9, borderRadius: 0, background: level.dot, display: "inline-block" }} />
                  {level.ar} {level.en}
                </span>
              </div>
              {famCount > 0 ? (
                <div className="space-y-1.5">
                  {["neuro", "sinus", "allergy"].map((m) => (
                    <div key={m} className="flex items-center justify-between">
                      <span className="text-[13px] font-body text-foreground">{MECH[m].emoji} {MECH[m].ar} <span className="text-muted-foreground">{MECH[m].en}</span></span>
                      {squares(Math.min(countFor(m), 4))}
                    </div>
                  ))}
                  {allergyLabel && (
                    <p className="text-xs font-body pt-1 border-t border-border/40">
                      <span className="text-muted-foreground">محسِّسات معروفة Known sensitisers: </span>
                      <span className="text-foreground/80">{allergyLabel.groups.map((g) => `${g.ar} ${g.en}`).join(" - ")}</span>
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground font-body">لا وسوم خطر بارزة من نوتاته No prominent risk labels from its notes</p>
              )}
            </div>
          );
        })()}

        {/* مؤشر متشدد (صفر تسامح) — منفصل عن الافتراضي و عن تقييم المستخدم */}
        {(() => {
          const s = strictHealth(perfume);
          return (
            <div className="px-5 pb-4 -mt-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest">مؤشر متشدد Strict</span>
                <span className="inline-flex items-center gap-1.5 text-[9px] font-body font-medium" style={{ color: s.risky ? "#C0392B" : "#3B6D11" }}>
                  <span style={{ width: 8, height: 8, background: s.risky ? "#C0392B" : "#639922", display: "inline-block" }} />
                  {s.risky ? "تجنّبه إن كنت حسّاساً Avoid if sensitive" : "بلا مثيرات No triggers"}
                </span>
              </div>
            </div>
          );
        })()}

        {/* Perfume Occasions — أموجي مع نص بلا إطارات */}
         {perfume.occasions && (
          <div className="px-5 py-4" style={{ borderRadius: 0 }}>
            <div className="mb-2">
              <p className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest">Best For مناسبات العطر</p>
            </div>
            <div dir="rtl" className="flex flex-wrap gap-x-5 gap-y-1.5 text-sm font-body text-foreground/90">
              {perfume.occasions.split(",").map(o => o.trim()).filter(Boolean).map(o => {
                const info = occasionInfo(o);
                return (
                  <button key={o} type="button" onClick={() => navigate(`/occasion?o=${encodeURIComponent(o)}`)}
                    className="bg-transparent p-0 hover:opacity-70 transition-opacity"
                    style={{ border: "none", color: "inherit", font: "inherit", cursor: "pointer", textDecoration: "none" }}>
                    {info ? fmtOcc(info, occMode, { bilingual: true }) : o}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Fragrance Notes — grid with images */}
        <FragranceNotesGrid perfume={perfume} isAr={isAr} />

        {/* العطّارون وعطور مشابهة معاً في المقدمة — لكلٍّ مساحته */}
        <PerfumersSection perfume={perfume} />
        <SimilarPerfumes perfume={perfume} isAr={isAr} />

        {/* Personal Section — per person — NOSE — خلفية لون خفيفة لكل شخص */}
        <div className="rounded-none border border-[var(--brand)] p-5 shadow-sm space-y-5 mt-8" style={{ background: (personColor(activePerson) || "var(--brand)") + "12" }}>
          <div className="flex items-center gap-2.5 flex-wrap pb-2 border-b border-[#EADFB4]">
            <span className="font-heading font-bold text-base tracking-wider">{isAr ? "الأنف" : "NOSE"}</span>
            <button
              onClick={() => { setActivePerson("person1"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person1" ? "" : "text-muted-foreground hover:text-foreground"}`} style={activePerson === "person1" ? { color: personColor("person1") } : undefined}>
              {names.person1}
            </button>
            <button
              onClick={() => { setActivePerson("person2"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person2" ? "" : "text-muted-foreground hover:text-foreground"}`} style={activePerson === "person2" ? { color: personColor("person2") } : undefined}>
              {names.person2}
            </button>
          </div>

          {/* انطباعك + تفاعلك جنباً لجنب، عنوان ثمّ صفّ أسفله */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "انطباعك" : "Your Impression"}</p>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { value: "great", emoji: "😍", label: isAr ? "رائع" : "Great" },
                  { value: "neutral", emoji: "😐", label: isAr ? "عادي" : "Neutral" },
                  { value: "not_great", emoji: "😕", label: isAr ? "لا بأس" : "Not Great" },
                ].map(({ value, emoji, label }) => {
                  const active = activeUserData?.impression === value;
                  return (
                    <button
                      key={value}
                      onClick={() => upsertUserData.mutate({ person: activePerson, field: "impression", value: active ? null : value })}
                      className={`flex flex-col items-center gap-1 py-2 text-[11px] font-body transition-all ${active ? "font-bold text-primary" : "text-muted-foreground hover:text-foreground"}`}
                    >
                      <span className={emojiSizeClass(emoji, "text-2xl", "text-lg")}>{emoji}</span>
                      <span>{label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "تفاعلك" : "Your Reaction"}</p>
              <div className="grid grid-cols-2 gap-1">
                {[
                  { value: "favorite", emoji: "❤️", label: isAr ? "مفضّل" : "Fav", activeColor: "text-rose-500" },
                  { value: "recommend", emoji: "👍", label: isAr ? "إعجاب" : "Like", activeColor: "text-amber-600" },
                  { value: "dislike", emoji: "👎", label: isAr ? "نفور" : "Dislike", activeColor: "text-slate-600" },
                  { value: "wtf", emoji: "😱", label: isAr ? "ماذا" : "WTF", activeColor: "text-purple-600" },
                ].map(({ value, emoji, label, activeColor }) => {
                  const active = activeUserData?.list === value;
                  return (
                    <button
                      key={value}
                      onClick={() => upsertUserData.mutate({ person: activePerson, field: "list", value: active ? "none" : value })}
                      className={`flex flex-col items-center gap-1 py-2 text-[11px] font-body transition-all ${active ? `font-bold ${activeColor}` : "text-muted-foreground hover:text-foreground"}`}
                    >
                      <span className={emojiSizeClass(emoji, "text-2xl", "text-lg")}>{emoji}</span>
                      <span>{label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Rating */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "تقييم" : "Rating"}</p>
            <StarRating
              rating={activeUserData?.rating || 0}
              onChange={(rating) => upsertUserData.mutate({ person: activePerson, field: "rating", value: rating })}
              size="lg"
            />
          </div>

          {/* === Detailed rating: scent — longevity — sillage — bottle === */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "تقييم تفصيلي" : "Detailed Rating"}</p>
            <div className="space-y-2">
              {[
                { field: "r_scent",     ar: "الرائحة", en: "Scent" },
                { field: "r_longevity", ar: "الثبات",  en: "Longevity" },
                { field: "r_sillage",   ar: "الفوحان", en: "Sillage" },
                { field: "r_bottle",    ar: "الزجاجة", en: "Bottle" },
                { field: "rate_originality", ar: "الأصالة",  en: "Originality" },
                { field: "rate_consistency", ar: "الاتساق",  en: "Consistency" },
                { field: "rate_value",       ar: "القيمة",   en: "Value" },
                { field: "rate_craft",       ar: "الحرفية",  en: "Craftsmanship" },
              ].map(({ field, ar, en }) => (
                <div key={field} className="flex items-center justify-between gap-2 py-1.5 px-1">
                  <span className="text-xs font-body font-medium text-muted-foreground uppercase tracking-wide">{isAr ? ar : en}</span>
                  <StarRating rating={activeUserData?.[field] || 0} onChange={(v) => upsertUserData.mutate({ person: activePerson, field, value: v })} size="sm" />
                </div>
              ))}
            </div>
          </div>

          {/* === Recommend to others === */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "ترشيح العطر للآخرين" : "Recommend to others"}</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: "no",    emoji: "🚫", ar: "لا",           en: "No",           activeColor: "text-slate-600" },
                { value: "women", emoji: "🌸", ar: "نعم — نساء",   en: "Yes — Women",  activeColor: "text-rose-500" },
                { value: "men",   emoji: "🔷", ar: "نعم — رجال",   en: "Yes — Men",    activeColor: "text-sky-600" },
                { value: "any",   emoji: "✌🏻", ar: "نعم — للجميع", en: "Yes — Anyone", activeColor: "text-amber-600" },
              ].map(({ value, emoji, ar, en, activeColor }) => {
                const active = activeUserData?.recommend_to === value;
                return (
                  <button
                    key={value}
                    onClick={() => upsertUserData.mutate({ person: activePerson, field: "recommend_to", value: active ? null : value })}
                    className={`flex items-center justify-center gap-1.5 py-2.5 text-xs font-body transition-all ${active ? `font-bold ${activeColor}` : "text-muted-foreground hover:text-foreground"}`}
                  >
                    <span className={emojiSizeClass(emoji, "text-3xl", "text-base")}>{emoji}</span>
                    <span>{isAr ? ar : en}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* === Note-phase impressions: top — heart — base === */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "انطباع المراحل" : "Note Phases"}</p>
            <div className="space-y-2">
              {[
                { field: "note_top",   ar: "مقدمة", en: "Top" },
                { field: "note_heart", ar: "قلب",      en: "Heart" },
                { field: "note_base",  ar: "أساس",     en: "Base" },
              ].map(({ field, ar, en }) => {
                const v = activeUserData?.[field];
                return (
                  <div key={field} className="flex items-center justify-between gap-2 py-1.5 px-1">
                    <span className="text-xs font-body font-medium text-muted-foreground">{isAr ? ar : en}</span>
                    <div className="flex gap-2">
                      <button onClick={() => upsertUserData.mutate({ person: activePerson, field, value: v === "like" ? null : "like" })} className={`w-9 h-8 rounded-none text-sm transition-all ${v === "like" ? "bg-amber-100 shadow-sm" : "opacity-50 hover:opacity-100"}`}>👍</button>
                      <button onClick={() => upsertUserData.mutate({ person: activePerson, field, value: v === "dislike" ? null : "dislike" })} className={`w-9 h-8 rounded-none text-sm transition-all ${v === "dislike" ? "bg-slate-100 shadow-sm" : "opacity-50 hover:opacity-100"}`}>👎</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Other Rating */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "انطباع الآخرين" : "Others' Impression"}</p>
            <div className="grid grid-cols-4 gap-2">
              {[
                { value: "love_it", emoji: "🥰", label: "Love it" },
                { value: "like_it", emoji: "😍", label: "Like it" },
                { value: "neutral", emoji: "😐", label: "Neutral" },
                { value: "hate_it", emoji: "😠", label: "Hate it" },
              ].map(({ value, emoji, label }) => {
                const active = activeUserData?.other_rating === value;
                return (
                  <button
                    key={value}
                    onClick={() => upsertUserData.mutate({ person: activePerson, field: "other_rating", value: active ? null : value })}
                    className={`flex flex-col items-center gap-1.5 py-2.5 rounded-none text-[10px] font-body font-medium transition-all ${active ? "bg-primary/10 shadow-sm text-primary" : "text-muted-foreground hover:text-foreground"}`}
                  >
                    <span className={emojiSizeClass(emoji, "text-3xl", "text-xl")}>{emoji}</span>
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Occasions — unlimited multi-select. Stored as CSV in `occasions`;
              falls back to legacy occasion/occasion2 fields for older records. */}
           <div className="space-y-2">
             {(() => {
               const parseOccasions = (ud) => {
                 if (!ud) return [];
                 if (ud.occasions) return ud.occasions.split(",").map((s) => s.trim()).filter(Boolean);
                 const arr = [];
                 if (ud.occasion && ud.occasion !== "none") arr.push(ud.occasion);
                 if (ud.occasion2 && ud.occasion2 !== "none") arr.push(ud.occasion2);
                 return arr;
               };
               const selected = parseOccasions(activeUserData);
               const OCCASIONS = OCCASIONS_LIB.map((o) => ({ value: o.value, emoji: o.emoji, en: o.en, ar: o.ar }));
               return (
                 <>
                   <div className="flex items-center gap-2">
                     <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "أفضل المناسبات" : "Best Occasions"}</p>
                     <span className="text-[10px] text-muted-foreground font-body">({selected.length})</span>
                   </div>
                   <div className="grid grid-cols-2 gap-2">
                     {OCCASIONS.map(({ value, emoji, en, ar }) => {
                       const active = selected.includes(value);
                       return (
                         <button
                           key={value}
                           onClick={() => {
                             const next = active ? selected.filter((v) => v !== value) : [...selected, value];
                             upsertUserData.mutate({ person: activePerson, field: "occasions", value: next.join(",") });
                           }}
                           className={`flex flex-col items-center gap-1 py-2 rounded-none text-[10px] font-body font-medium transition-all ${active ? "font-bold text-primary" : "text-muted-foreground hover:text-foreground"}`} style={{ border: "none", background: "transparent" }}
                         >
                           {userOccMode !== "text" && <span className={emojiSizeClass(emoji, "text-3xl", "text-base")}>{emoji}</span>}
                           {userOccMode !== "emoji" && <span>{isAr ? ar : en}</span>}
                         </button>
                       );
                     })}
                   </div>
                 </>
               );
             })()}
           </div>

          {/* Health Ratings */}
          <HealthRatingSection
            activeUserData={activeUserData}
            activePerson={activePerson}
            onUpdate={(field, value) => upsertUserData.mutate({ person: activePerson, field, value })}
          />

          {/* Related Perfumes — user-added (shown FIRST) */}
          {perfume.related_perfume_ids && perfume.related_perfume_ids.trim() && (
            <div className="bg-transparent rounded-none space-y-2">
              <h3 className="font-heading font-semibold text-sm px-1">{isAr ? "متقارب" : "Similar"}</h3>

              <div className="space-y-2">
                {perfume.related_perfume_ids.split(",").map((relId, idx) => {
                  const relName = perfume.related_perfume_names?.split(",")[idx]?.trim();
                  const trimmedRelId = relId.trim();
                  if (!trimmedRelId || !relName) return null;

                  const relPerfume = relatedForward.find(p => String(p.id) === String(trimmedRelId));

                  return (
                    <Link
                      key={trimmedRelId}
                      to={`/perfume?id=${trimmedRelId}`}
                      className="flex items-center gap-3 group"
                    >
                      <div className="w-16 h-16 rounded-none border-2 border-amber-500/70 bg-white/80 flex items-center justify-center overflow-hidden shadow-sm group-hover:shadow-md transition-all flex-shrink-0">
                        {relPerfume?.image_url ? (
                          <img src={relPerfume.image_url} alt={relName} className="w-full h-full object-contain p-0.5" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-2xl opacity-20">🧴</div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-body font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1">
                          {relName}
                        </p>
                        {relPerfume?.brand_name && (
                          <p className="text-[9px] text-muted-foreground font-body line-clamp-1 mb-0.5">
                            {relPerfume.brand_name}
                          </p>
                        )}
                        {relPerfume?.top_notes || relPerfume?.heart_notes || relPerfume?.base_notes ? (
                          <div className="flex gap-1 flex-wrap">
                            {[relPerfume?.top_notes, relPerfume?.heart_notes, relPerfume?.base_notes]
                              .filter(Boolean)
                              .flatMap((notes, idx) => 
                                notes.split(",").slice(0, 2).map(n => n.trim()).filter(Boolean).map((n, i) => (
                                  <span key={`${idx}-${i}`} className="text-[8px] text-amber-700 dark:text-amber-400 rounded-none font-body">
                                    {n}
                                  </span>
                                ))
                              )}
                          </div>
                        ) : null}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          )}

          {/* Similar Perfumes منقولة للمقدمة بجانب العطّارين */}

          {/* Reverse Related — Linked By / Connected With */}
          {relatedReverse.length > 0 && (
            <div className="bg-[var(--page-bg,#fff)] rounded-none border border-[var(--brand)] p-5 shadow-sm space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-base">🔗</span>
                <h3 className="font-heading font-semibold text-sm">{isAr ? "تم ربطه مع  عطور ترتبط به" : "Linked By  Connected With"}</h3>
              </div>

              <div className="space-y-2">
                {relatedReverse.map((relPerfume) => (
                  <Link
                    key={relPerfume.id}
                    to={`/perfume?id=${relPerfume.id}`}
                    className="flex items-center gap-3 p-2.5 rounded-none border border-blue-200/50 bg-white/50 dark:bg-slate-950/30 hover:border-blue-300 transition-colors group"
                  >
                    <span className="text-lg">←</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-heading font-semibold text-xs group-hover:opacity-70 transition-opacity">
                        {relPerfume.name_en || relPerfume.name_ar}
                      </p>
                    </div>
                    <span className="text-blue-600/40 dark:text-blue-400/40 text-xs">←</span>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Lists — multi-select chips */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "القوائم" : "Lists"}</p>
            <ListMultiSelect activeUserData={activeUserData} activePerson={activePerson} upsertUserData={upsertUserData} />
          </div>

          {/* Notes, Category, ML, Price */}
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-2">
              {perfume.category && (
                <div className="rounded-none p-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "الفئة" : "Category"}</p>
                  <p className="text-xs font-body font-medium">{perfume.category}</p>
                </div>
              )}
              {perfume.ml && (
                <div className="rounded-none p-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "الحجم" : "Volume"}</p>
                  <p className="text-xs font-body font-medium">{perfume.ml}ml</p>
                </div>
              )}
              {perfume.price && (
                <div className="rounded-none p-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "السعر" : "Price"}</p>
                  <p className="text-xs font-body font-medium">{formatPrice(perfume.price)}</p>
                </div>
              )}
            </div>

            {/* Personal Review — per-person (stored in UserPerfume.review) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground font-body uppercase tracking-wider font-bold">📝 {isAr ? "مراجعتك" : "Your Review"}</p>
                {!editNotes && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => {
                      setEditNotes(true);
                      setNotes(activeUserData?.review || "");
                    }}
                  >
                    {activeUserData?.review ? "✏️ Edit" : "✏️ Add"}
                  </Button>
                )}
              </div>

              {!editNotes && (
                <div className="rounded-none p-4">
                  {activeUserData?.review ? (
                    <p className="text-sm font-body text-foreground/85 whitespace-pre-wrap leading-relaxed">{activeUserData.review}</p>
                  ) : (
                    <p className="text-xs italic text-muted-foreground">{isAr ? "لا مراجعة بعد" : "No review yet"}</p>
                  )}
                </div>
              )}
            </div>

            {/* Edit Review — saves to the active person's UserPerfume.review */}
            {editNotes && (
              <div className="rounded-none p-4 space-y-3">
                <p className="text-xs text-muted-foreground font-body uppercase tracking-wider font-bold">✏️ {isAr ? "اكتب مراجعتك" : "Write Your Review"}</p>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="rounded-none font-body min-h-[100px]" placeholder={isAr ? "شارك خواطرك" : "Share your thoughts.."} />
                <div className="flex gap-2">
                  <Button size="sm" className="rounded-none font-body" onClick={() => { upsertUserData.mutate({ person: activePerson, field: "review", value: notes }); setEditNotes(false); }}>
                    {isAr ? "تم" : "Done"}
                  </Button>
                  <Button size="sm" variant="ghost" className="rounded-none font-body" onClick={() => { setNotes(activeUserData?.review || ""); setEditNotes(false); }}>{isAr ? "إلغاء" : "Cancel"}</Button>
                </div>
              </div>
            )}

            {/* Sample/Collection */}
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">Sample / Collection</p>
              <div className="rounded-none p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "الحجم الكلي" : "Total Volume"}</p>
                    <p className="text-sm font-body font-medium">{activeUserData?.sample_ml ? `${activeUserData.sample_ml}ml` : "—"}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "التكلفة الكلية" : "Total Cost"}</p>
                    <p className="text-sm font-body font-medium">{activeUserData?.sample_cost ? formatPrice(activeUserData.sample_cost) : "—"}</p>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-none font-body text-xs h-9"
                  style={{ color: "#3B6D11", borderColor: "#3B6D11" }}
                  onClick={() => {
                    setEditSampleMl(true);
                    setSampleMl("");
                    setEditSampleCost(true);
                    setSampleCost("");
                    setPurchaseType("sample");
                  }}
                >
                  🛍️ {isAr ? "اشتريت" : "I Bought"}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-none font-body text-xs h-9 bg-pink-50 dark:bg-pink-950/30 text-pink-600 dark:text-pink-400 border-pink-200 dark:border-pink-800"
                  onClick={() => setWishDialogOpen(true)}
                >
                  💕 {isAr ? "أرغب بالشراء" : "I Want To Buy"}
                </Button>
              </div>
              {editSampleMl && editSampleCost && (
                <div className="space-y-2 bg-accent/30 rounded-none p-3">
                  <div className="flex gap-2 mb-2">
                    <button
                      onClick={() => setPurchaseType("sample")}
                      className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${purchaseType === "sample" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
                    >
                      {isAr ? "عيّنة" : "Sample"}
                    </button>
                    <button
                      onClick={() => setPurchaseType("bottle")}
                      className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${purchaseType === "bottle" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
                    >
                      {isAr ? "قنينة" : "Bottle"}
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input name="PerfumeDetail-1"
                      type="number"
                      min="1"
                      step="1"
                      placeholder={isAr ? "مل" : "ML"}
                      value={sampleMl}
                      onChange={(e) => setSampleMl(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-none border border-input bg-transparent text-xs font-body"
                    />
                    <input name="PerfumeDetail-2"
                      type="number"
                      min="0"
                      step="0.1"
                      placeholder={isAr ? "التكلفة" : "Cost"}
                      value={sampleCost}
                      onChange={(e) => setSampleCost(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-none border border-input bg-transparent text-xs font-body"
                    />
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">{isAr ? "المتجر (اختياري)" : "Store (optional)"}</p>
                    <StoreSelector
                      value={selectedStore}
                      onChange={setSelectedStore}
                    />
                  </div>
                  {/* Who is buying indicator */}
                  <div className="flex items-center justify-center gap-2 py-1">
                    <span className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">{isAr ? "القائم بالشراء" : "Buyer"}</span>
                    <button
                      onClick={() => setActivePerson("person1")}
                      className={`text-xs font-body font-bold rounded-none transition-all ${activePerson === "person1" ? "" : " text-muted-foreground"}`} style={activePerson === "person1" ? { color: personColor("person1") } : undefined}
                    >
                      {names.person1}
                    </button>
                    <button
                      onClick={() => setActivePerson("person2")}
                      className={`text-xs font-body font-bold rounded-none transition-all ${activePerson === "person2" ? "" : " text-muted-foreground"}`} style={activePerson === "person2" ? { color: personColor("person2") } : undefined}
                    >
                      {names.person2}
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="flex-1 rounded-none font-body text-xs h-8"
                      onClick={() => {
                        const mlVal = parseFloat(sampleMl || 0);
                        const costVal = parseFloat(sampleCost || 0);
                        if (mlVal < 1 || Number.isNaN(mlVal) || costVal < 0 || Number.isNaN(costVal)) {
                          toast.error((isAr ? "المل يبدأ من 1 (التكلفة تقبل صفراً)" : "ML starts at 1 (cost can be 0)"));
                          return;
                        }
                        const newMl = (parseFloat(activeUserData?.sample_ml || 0) + mlVal);
                        const newCost = (parseFloat(activeUserData?.sample_cost || 0) + costVal);

                        // Record the purchase everywhere (totals updated in onSuccess)
                        purchaseMutation.mutate({
                          perfume,
                          activePerson,
                          purchaseType,
                          mlVal,
                          costVal,
                          selectedStore,
                          stores,
                          activeUserData,
                        });
                        setEditSampleMl(false);
                        setEditSampleCost(false);
                        setSampleMl("");
                        setSampleCost("");
                        setSelectedStore("");
                      }}
                    >
                      Add {purchaseType === "sample" ? "Sample" : "Bottle"}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="flex-1 rounded-none font-body text-xs h-8"
                      onClick={() => {
                        setEditSampleMl(false);
                        setEditSampleCost(false);
                        setSampleMl("");
                        setSampleCost("");
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>


          </div>

          </div>

          {/* Image Management — moved beside Edit in footer */}


          {/* تعديل العطر نُقل إلى فوتر الصفحة (بعد جدولة الارتداء) */}

          {/* التصدير — زر واحد بلا إطارات يفتح صفحة البطاقة الموحّدة */}
          <div className="space-y-2">
            <button
              onClick={() => navigate(`/export-card?id=${id}`)}
              className="w-full py-3 rounded-none font-body text-base font-semibold bg-transparent text-[#B76E79] hover:text-[var(--brand)] active:text-[var(--brand)] transition-colors inline-flex items-center justify-center gap-2"
            >
              <PerfumeSprayIcon className="w-7 h-7" /> {isAr ? "تصدير بطاقة العطر" : "Export Perfume Card"}
            </button>
          </div>

          {/* أزرار التفاعل عادت أعلى مع الانطباع */}





          {/* السجل الموحّد — شراء + ارتداء + جدولة في صندوق واحد */}
        <div className="rounded-none space-y-4 pt-2">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-heading font-semibold">{isAr ? "السجل" : "History"}</h2>
              <p className="text-xs text-muted-foreground font-body">
                {purchaseRecords.length} {isAr ? "شراء" : (purchaseRecords.length === 1 ? "purchase" : "purchases")} {"—"} {wearLogs.length} {isAr ? "ارتداء" : (wearLogs.length === 1 ? "wear" : "wears")}
              </p>
            </div>
<Button size="sm" style={{ backgroundColor: "#22c55e", color: "#fff" }} className="rounded-none font-body h-9 px-4 min-w-[104px] hover:opacity-90" onClick={() => setWearDialogOpen(true)}>{isAr ? "تسجيل ارتداء" : "Log wear"}</Button>
          </div>

          {mergedHistory.length === 0 ? (
            <p className="text-xs text-muted-foreground font-body">{isAr ? "لا سجلات بعد" : "No records yet."}</p>
          ) : (
            <div className="divide-y divide-border/40">
              {mergedHistory.map((row) => {
                if (row.kind === "purchase") {
                  const record = row.raw;
                  return (
                    <div key={row.key} className="flex flex-col gap-1.5 py-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[9px] font-bold" style={{ color: personColor(record.person) }}>
                            {record.person === "person2" ? names.person2 : names.person1}
                          </span>
                          <span className="text-[10px] font-body font-bold text-foreground/70">{record.type === "sample" ? "Sample" : "Bottle"}</span>
                          <span className="text-xs text-muted-foreground font-body">{record.purchase_date}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="text-right">
                            <p className="text-xs font-body font-medium">{record.ml}ml</p>
                            <p className="text-[10px] text-muted-foreground font-body">{formatPrice(record.cost)}</p>
                          </div>
                          <EditPurchaseDialog
                            record={record}
                            perfumeId={id}
                            activePerson={record.person}
                            stores={stores}
                            onSuccess={() => { queryClient.invalidateQueries({ queryKey: ["purchase-records", id] }); queryClient.invalidateQueries({ queryKey: ["purchase-records"] }); }}
                          />
                        </div>
                      </div>
                      {record.store_name && (
                        <button onClick={() => navigate(`/store?id=${record.store_id}`)} className="text-xs font-body text-primary hover:underline w-fit">
                          🏪 {record.store_name}
                        </button>
                      )}
                    </div>
                  );
                }
                const l = row.raw;
                const moodEmojis = { amazing: "\ud83d\ude0d", happy: "\ud83d\ude0a", calm: "\ud83d\ude0c", confident: "\ud83d\ude0e", romantic: "\ud83d\udc95", sexy: "\ud83d\udd25", sad: "\ud83d\ude14", energetic: "\u26a1", thoughtful: "\ud83e\udd14", relaxing: "\ud83d\ude34", unknown: "\ud83e\udd37", neutral: "\ud83d\ude11" };
                return (
                  <div key={row.key} className="flex items-center gap-2 text-xs font-body py-2.5 ps-2" style={{ borderInlineStart: "2px solid #f97316" }}>
                    <span className="text-[9px] font-bold" style={{ color: personColor(l.person) }}>
                      {l.person === "person2" ? names.person2 : names.person1}
                    </span>
                    <span className="text-[10px] font-body font-bold" style={{ color: "#f97316" }}>{isAr ? "ارتداء" : "Worn"}</span>
                    <span className="text-muted-foreground">{l.date}</span>
                    {l.mood && <span className="text-base">{moodEmojis[l.mood]}</span>}
                    {l.note && <span className="text-foreground/70 truncate">— {l.note}</span>}
                  </div>
                );
              })}
            </div>
          )}

          {/* جدولة الارتداء (المستقبل) — ضمن نفس الصندوق، محاذاة بداية/نهاية مع السجل */}
          <div className="mt-3 pt-3 border-t border-border/40">
            <WearScheduleSection perfume={perfume} activePerson={activePerson} names={names} />
          </div>
          <ExportHistoryList type="perfume" refId={id} title={isAr ? "بطاقات العطر المحفوظة" : "Saved Perfume Cards"} />
        </div>

        {/* فوتر الصفحة — تعديل العطر منفصل تماماً */}
        <div className="mt-6 pt-4" style={{ borderTop: "1px solid var(--brand)" }}>
          <div className="grid grid-cols-2 gap-2 items-stretch">
            <Dialog>
                        <DialogTrigger asChild>
                          <Button className="w-full h-9 rounded-none font-body gap-1.5 text-[11px]" style={{ background: "#FBE4EC", color: "#9D2C5B" }}>
                            <Camera className="w-4 h-4" /> {perfume.image_url ? (isAr ? "تغيير صورة العطر" : "Change Perfume Image") : (isAr ? "إضافة صورة عطر" : "Add Perfume Image")}
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-sm rounded-none">
                          <DialogHeader>
                            <DialogTitle className="font-heading">{perfume.image_url ? (isAr ? "تغيير صورة العطر" : "Change Perfume Image") : (isAr ? "إضافة صورة عطر" : "Add Perfume Image")}</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-3">
                            <input
                              type="file"
                              accept="image/*"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                
                                // Validate file type
                                const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf'];
                                if (!allowedTypes.includes(file.type)) {
                                  toast.error('Only images (JPG, PNG, WebP, GIF) and PDF files are allowed');
                                  return;
                                }
                                
                                // Validate file size (max 5MB)
                                const maxSize = 5 * 1024 * 1024;
                                if (file.size > maxSize) {
                                  toast.error('File size must be less than 5MB');
                                  return;
                                }
                                
                                try {
                                  const { file_url } = await apphost.integrations.Core.UploadFile({ file });
                                  await apphost.entities.Perfume.update(id, { image_url: file_url });
                                  queryClient.invalidateQueries({ queryKey: ["perfume", id] });
                                  toast.success((isAr ? "حُدّثت الصورة" : "Image updated"));
                                } catch (error) {
                                  toast.error((isAr ? "فشل الرفع" : "Upload failed:") + error.message);
                                }
                              }}
                              className="w-full px-3 py-2 border border-input rounded-none text-sm font-body"
                            />
                          </div>
                        </DialogContent>
                      </Dialog>
            <Button className="w-full h-9 rounded-none font-body gap-1.5 text-[11px]" style={{ background: "#FBE4EC", color: "#9D2C5B" }} onClick={() => navigate(`/add?id=${perfume.id}`)}>
              <Edit2 className="w-4 h-4" /> {isAr ? "تعديل العطر" : "Edit Perfume"}
            </Button>
          </div>
          <div className="text-center pt-3">
            {(() => {
              const u = activeUserData || {};
              const reviewed = !!(u.rating || ["favorite", "recommend", "dislike", "wtf"].includes(u.list) || (u.personal_notes && String(u.personal_notes).trim()) || u.recommend_to || u.r_scent || u.r_longevity || u.r_sillage || u.r_bottle || u.rate_originality || u.rate_consistency || u.rate_value || u.rate_craft);
              if (reviewed) return null;
              return (
                <button type="button" onClick={() => upsertUserData.mutate({ person: activePerson, field: "review_scheduled", value: !u.review_scheduled })} disabled={upsertUserData.isPending}
                  className="text-[11px] font-body hover:opacity-70 transition-opacity" style={{ color: "var(--brand)", fontWeight: u.review_scheduled ? 700 : 400 }}>
                  {u.review_scheduled ? (isAr ? "مجدوَل للمراجعة ✓" : "Scheduled ✓") : (isAr ? "جدول العطر للمراجعة" : "Schedule Perfume for Review")}
                </button>
              );
            })()}
          </div>
        </div>

          {/* الأيقونات الوظيفية — نُقلت لأسفل الصفحة بعد السجل */}
            <div className="flex items-center justify-center gap-5 pt-1">
              {/* أيقونة عطر — أضف/أزل من مجموعتي (وردي خارجها، ذهبي فيها) */}
              <button
                onClick={() => setCollection(!inCollection)}
                disabled={upsertUserData.isPending}
                title={inCollection ? (isAr ? "في مجموعتي" : "In my collection") : (isAr ? "أضف لمجموعتي" : "Add to my collection")}
                aria-label={inCollection ? "In my collection" : "Add to my collection"}
                className="flex items-center justify-center w-9 h-9 bg-transparent transition-opacity hover:opacity-70"
                style={{ color: inCollection ? "var(--brand)" : "#B76E79" }}
              >
                <SprayCan className="w-[20px] h-[20px]" strokeWidth={1.75} fill={inCollection ? "var(--brand)" : "none"} fillOpacity={inCollection ? 0.33 : 0} />
              </button>
              <BookmarkButton descriptor={{
                item_type: "perfume",
                item_id: id,
                title_en: perfume.name_en || perfume.name || "",
                title_ar: perfume.name_ar || "",
                subtitle: perfume.brand_name || "",
                path: `/perfume?id=${id}`,
              }} />
              <PinButton kind="perfume" id={id} />
              {/* كاست أواي — أيقونة ممحاة موحّدة (وردي → ذهبي عند التمرير) */}
              <button
                onClick={handleCastAwayPerfume}
                title={isAr ? "نقل إلى المهملات" : "Cast Away"}
                aria-label={isAr ? "كاست أواي" : "Cast Away"}
                className="flex items-center justify-center w-9 h-9 bg-transparent transition-colors text-[#B76E79] hover:text-[var(--brand)]"
              >
                <EraserIcon className="w-[20px] h-[20px]" />
              </button>
              <CopyMenu
                entity="perfume"
                dbText={perfumeDbText(perfume)}
                fullText={perfumeFullText(perfume, {
                  activeUserData,
                  wearLogs,
                  purchases: purchaseRecords,
                  personName: names?.[activePerson] || "",
                })}
              />
            </div>

        {/* Wishlist Dialog */}
        <Dialog open={wishDialogOpen} onOpenChange={setWishDialogOpen}>
          <DialogContent className="max-w-sm rounded-none">
            <DialogHeader>
              <DialogTitle className="font-heading">💕 {isAr ? "أرغب بالشراء" : "I Want To Buy"}</DialogTitle>
            </DialogHeader>
          <div className="space-y-3">
            <div className="bg-secondary/40 rounded-none p-3">
              <p className="text-xs font-body font-bold">{perfume.name_en || perfume.name_ar || ""}</p>
              <p className="text-[10px] text-muted-foreground">{perfume.brand_name}</p>
            </div>

            <div>
              <p className="text-xs font-body font-medium mb-1">{isAr ? "السعر المتوقع" : "Estimated Price"}</p>
              <Input
                type="number"
                step="0.1"
                placeholder="0.00"
                value={wishPrice}
                onChange={(e) => setWishPrice(e.target.value)}
                className="rounded-none h-9 text-xs"
              />
            </div>

            <div>
              <p className="text-xs font-body font-medium mb-1">{isAr ? "الأولوية" : "Priority"}</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { val: "high", emoji: "🔴", label: "High", ar: "مرتفعة" },
                  { val: "medium", emoji: "🟡", label: "Medium", ar: "متوسطة" },
                  { val: "low", emoji: "🔵", label: "Low", ar: "منخفضة" },
                ].map(({ val, emoji, label, ar }) => (
                  <button
                    key={val}
                    onClick={() => setWishPriority(val)}
                    className={`py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                      wishPriority === val
                        ? "bg-primary text-primary-foreground shadow"
                        : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {emoji} {isAr ? ar : label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-xs font-body font-medium mb-1">{isAr ? "ملاحظات" : "Notes"}</p>
              <Textarea
                value={wishNotes}
                onChange={(e) => setWishNotes(e.target.value)}
                placeholder={isAr ? "مثلاً: أفضل تركيب، رائحة دافئة.." : "E.g., love the scent, warm fragrance.."}
                className="rounded-none text-xs min-h-[60px] resize-none font-body"
              />
            </div>

            <Button
              className="w-full h-10 rounded-none font-body"
              onClick={() => addToWishlist.mutate()}
              disabled={addToWishlist.isPending}
            >
              {addToWishlist.isPending ? (isAr ? "جاري.." : "Adding..") : (isAr ? "💕 أرغب بالشراء" : "💕 I Want To Buy")}
            </Button>
          </div>
        </DialogContent>
        </Dialog>

        {/* Log wear dialog */}
        <Dialog open={wearDialogOpen} onOpenChange={setWearDialogOpen}>
          <DialogContent className="max-w-sm rounded-none">
            <DialogHeader>
              <DialogTitle className="font-heading text-base">تسجيل ارتداء  Log Wear</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <p className="text-sm font-body text-muted-foreground">
                Logging <span className="font-semibold text-foreground">{perfume?.name}</span>
              </p>
              <div className="flex gap-2">
                <button onClick={() => setWearPerson("person1")}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${wearPerson === "person1" ? "text-white shadow" : "bg-secondary text-muted-foreground"}`} style={wearPerson === "person1" ? { background: personColor("person1") } : undefined}>
                  <User className="w-3.5 h-3.5" /> {names.person1}
                </button>
                <button onClick={() => setWearPerson("person2")}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${wearPerson === "person2" ? "text-white shadow" : "bg-secondary text-muted-foreground"}`} style={wearPerson === "person2" ? { background: personColor("person2") } : undefined}>
                  <User className="w-3.5 h-3.5" /> {names.person2}
                </button>
              </div>
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "المزاج" : "Mood"}</p>
                <div className="grid grid-cols-5 gap-2">
                  {[
                    { value: "amazing", emoji: "😍", label: "Amazing" },
                    { value: "happy", emoji: "😊", label: "Happy" },
                    { value: "calm", emoji: "😌", label: "Calm" },
                    { value: "confident", emoji: "😎", label: "Confident" },
                    { value: "romantic", emoji: "💕", label: "Romantic" },
                    { value: "sexy", emoji: "🔥", label: "Sexy" },
                    { value: "sad", emoji: "😔", label: "Sad" },
                    { value: "energetic", emoji: "⚡", label: "Energetic" },
                    { value: "thoughtful", emoji: "🤔", label: "Thoughtful" },
                    { value: "relaxing", emoji: "😴", label: "Relaxing" },
                    { value: "unknown", emoji: "🤷", label: "I don't Know" },
                    { value: "neutral", emoji: "😑", label: "I don't Care" },
                  ].map(({ value, emoji, label }) => (
                    <button
                      key={value}
                      onClick={() => setWearMood(wearMood === value ? "" : value)}
                      className={`flex flex-col items-center gap-1 py-2 rounded-none border text-[10px] font-body font-medium transition-all ${wearMood === value ? "bg-primary/10 border-primary shadow-sm" : "bg-secondary/40 border-border/50 hover:border-primary/30"}`}
                    >
                      <span className={emojiSizeClass(emoji, "text-3xl", "text-lg")}>{emoji}</span>
                      <span className="text-[9px]">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <Textarea
                value={wearNote}
                onChange={(e) => setWearNote(e.target.value)}
                placeholder={isAr ? "ملاحظة اختياري" : "Optional note.."}
                className="rounded-none font-body text-sm min-h-[64px] resize-none"
              />
              <Button
                className="w-full h-10 rounded-none font-body"
                onClick={() => wearMutation.mutate({
                    date: format(new Date(), "yyyy-MM-dd"),
                    perfume_id: id,
                    perfume_name: perfume.name_en || perfume.name_ar || perfume.name || "",
                    brand_name: perfume.brand_name || "",
                    person: wearPerson,
                    mood: wearMood || null,
                    note: wearNote,
                  })}
                disabled={wearMutation.isPending}
              >
                {wearMutation.isPending ? "Saving.." : `Log for ${wearPerson === "person2" ? names.person2 : names.person1}`}
              </Button>
            </div>
          </DialogContent>
          </Dialog>

          {/* Delete moved to the Edit Perfume page (/add?id=) */}
          <IndexLinksRow />
          </div>
          </div>
          );
          }

function InfoChip({ icon: Icon, label }) {
  return (
    <div className="flex items-center gap-1.5 bg-secondary/60 rounded-none px-3 py-1">
      <Icon className="w-3.5 h-3.5 text-primary/70" />
      <span className="text-xs font-body font-medium">{label}</span>
    </div>
  );
}

function ListMultiSelect({ activeUserData, activePerson, upsertUserData }) {
  const { isAr } = useLang();
  const { data: allLists = [], refetch } = useQuery({
    queryKey: ["custom-lists"],
    queryFn: () => apphost.entities.CustomList.list("name"),
  });

  const qc = useQueryClient();
  const perfumeId = new URLSearchParams(window.location.search).get("id");

  // Separate system lists from user custom lists
  const SYSTEM = ["📦 Own", "🛒 Wishlist"];
  const systemLists = allLists.filter(l => SYSTEM.includes(`${l.icon} ${l.name}`));
  const customLists = allLists.filter(l => !SYSTEM.includes(`${l.icon} ${l.name}`));

  const isInList = (list) => {
    if (!list.perfume_ids || !perfumeId) return false;
    return list.perfume_ids.split(",").map(id => id.trim()).includes(perfumeId);
  };

  const toggleList = (list) => {
    const ids = list.perfume_ids ? list.perfume_ids.split(",").map(id => id.trim()).filter(Boolean) : [];
    const inList = ids.includes(perfumeId);
    const newIds = inList ? ids.filter(id => id !== perfumeId) : [...ids, perfumeId];
    apphost.entities.CustomList.update(list.id, { perfume_ids: newIds.join(",") })
      .then(() => qc.invalidateQueries({ queryKey: ["custom-lists"] }));
  };

  const chipClass = (active) =>
    `flex items-center gap-1.5 rounded-none text-xs font-body font-medium transition-all ${active ? " text-primary " : " text-muted-foreground hover:text-foreground"}`;

  if (allLists.length === 0) {
    return <p className="text-xs text-muted-foreground font-body">{isAr ? "لا قوائم بعد أنشئها في صفحة القوائم" : "No lists yet. Create lists in the Lists page."}</p>;
  }

  return (
    <div className="flex flex-wrap gap-2">
      {systemLists.map((list) => (
        <button key={list.id} onClick={() => toggleList(list)} className={chipClass(isInList(list))}>
          <span>{list.icon || "📋"}</span> {list.name}
        </button>
      ))}
      {customLists.map((list) => (
        <button key={list.id} onClick={() => toggleList(list)} className={chipClass(isInList(list))}>
          <span>{list.icon || "📋"}</span> {list.name}
        </button>
      ))}
    </div>
  );
}

function NoteRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-none bg-secondary/60 flex items-center justify-center flex-shrink-0 mt-0.5">
        {Icon && <Icon className="w-4 h-4 text-primary/60" />}
      </div>
      <div>
        <p className="text-xs font-body font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="text-sm font-body">{value}</p>
      </div>
    </div>
  );
}
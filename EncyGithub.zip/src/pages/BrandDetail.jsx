import { useState, useEffect, useMemo } from "react";
import { emojiSizeClass } from "@/lib/bigEmojis";
import ExportHistoryList from "@/components/export/ExportHistoryList";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { occasionInfo } from "@/lib/occasions";
import { brandCategoryLabel } from "@/lib/brandCategories";
import { RATING_AXES } from "@/lib/ratingAxes";
import { useOccasionMode, fmtOcc } from "@/lib/useOccasionMode";
import { decadeFromYear } from "@/lib/decade";
import { useNavigate, Link, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Building2, Globe, Edit2, Heart, HeartOff, AArrowUp, AArrowDown, SprayCan, Crown, ChevronLeft, ChevronRight } from "lucide-react";
import PerfumeSprayIcon from "@/components/icons/PerfumeSprayIcon";
import BrandLogo from "@/components/brand/BrandLogo";
import AccordFlacon, { dominantAccord } from "@/components/perfume/AccordFlacon";
import StarRating from "@/components/perfume/StarRating";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { looseBrandKey } from "@/lib/sortName";
import { useCurrency } from "@/lib/useCurrency";
import EditPurchaseDialog from "@/components/purchase/EditPurchaseDialog";
import HealthRatingSection from "@/components/perfume/HealthRatingSection";
import BrandPerfumersSection from "@/components/brand/BrandPerfumersSection";
import BrandCore from "@/components/brand/BrandCore";
import { openExternalUrl } from "@/lib/exportHelper";
import CopyMenu from "@/components/shared/CopyMenu";
import { brandDbText, brandFullText } from "@/lib/copyData";
import BookmarkButton from "@/components/shared/BookmarkButton";
import PinButton from "@/components/shared/PinButton";
import EraserIcon from "@/components/icons/EraserIcon";
import IndexLinksRow from "@/components/shared/IndexLinksRow";
import BackIcon from "@/components/shared/BackIcon";

// Brand collections are derived automatically from the perfume name
// (e.g. "Private Blend Tobacco Vanille" → "Private Blend"). These are brand
// lines/collections, distinct from a user's personal lists.
const KNOWN_COLLECTIONS = [
  "Private Blend", "Signature", "Le Parfum", "Les Exclusifs", "La Collection",
  "Maison", "Exclusive Collection", "Prive", "Privé", "Collection Privée",
  "Atelier", "Heritage", "Reserve", "Limited Edition", "Extrait", "Absolu",
  "Oud Collection", "Water Collection", "Cologne Collection", "Replica",
  "Aqua", "Acqua", "Velvet Collection", "Noir Collection",
];
function deriveCollection(name) {
  if (!name) return "";
  for (const c of KNOWN_COLLECTIONS) {
    if (name.toLowerCase().includes(c.toLowerCase())) return c;
  }
  return "";
}

// لون إطار الصندوق حسب الجنس — نفس ألوان صفحة /explore (PerfumeCard).
// يدعم تسميتي البيانات: Men/Male، Women/Female، Unisex.
const GENDER_BORDER = {
  Men: "#22c55e", Male: "#22c55e",
  Women: "#f472b6", Female: "#f472b6",
  Unisex: "#fcd34d",
};
// اختصار بنقطتين «..» (لا ثلاث نقاط) عند طول النص.
function clip2(s, n) {
  const t = String(s || "");
  return t.length > n ? t.slice(0, n).replace(/\s+$/, "") + ".." : t;
}
// اختصار نوع العطر للزاوية (كثير من عطور القاعدة الجديدة بلا نوع → فارغ).
function shortType(t) {
  if (!t) return "";
  const s = String(t);
  if (/edp|de parfum/i.test(s)) return "EDP";
  if (/edt|de toilette/i.test(s)) return "EDT";
  if (/edc|de cologne/i.test(s)) return "EDC";
  if (/extrait/i.test(s)) return "Extrait";
  if (/fra[iî]che/i.test(s)) return "Fraîche";
  if (/parfum/i.test(s)) return "Parfum";
  return s.length > 8 ? s.slice(0, 8) : s;
}

// ذاكرة مؤقّتة على مستوى الوحدة: قائمة البراندات تُجلب مرّة واحدة فقط للجلسة بدل
// مسح ثقيل (list 1000000) عند كلّ فتح براند بالاسم — يزيل بطء صفحة البراند و القفز.
let _brandListCache = null;
async function getAllBrandsCached() {
  if (_brandListCache) return _brandListCache;
  try { _brandListCache = await apphost.entities.PerfumeBrand.list("name", 1000000); }
  catch { _brandListCache = []; }
  return _brandListCache;
}

export default function BrandDetail() {
  // معرّف تفاعليّ عبر useSearchParams — قراءة window.location.search مرّة كانت تبقى
  // فارغة لو ركّبت الصفحة قبل تحديث الـURL (فراغ أوّل فتح حتى إعادة الدخول).
  const [searchParams] = useSearchParams();
  const id = searchParams.get("id");
  const nameParam = searchParams.get("name");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();
  // إبعاد البراند الحاليّ مباشرةً (إخفاؤه) مع تأكيد — صفحة المهملات تبقى في الإعدادات.
  const handleCastAwayBrand = async () => {
    if (!id) return;
    const ok = window.confirm(isAr ? "نقل هذا البراند إلى المهملات؟" : "Move this brand to Cast Away?");
    if (!ok) return;
    try {
      await apphost.entities.PerfumeBrand.update(id, { hidden: true });
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      queryClient.invalidateQueries({ queryKey: ["castaway-brands"] });
      toast.success(isAr ? "نُقل إلى المهملات" : "Moved to Cast Away");
      navigate("/brands");
    } catch {
      toast.error(isAr ? "تعذّر النقل" : "Failed");
    }
  };
  const [occMode] = useOccasionMode();
  const { names } = usePersonNames();
  const { formatPrice } = useCurrency();
  const [userData, setUserData] = useState(null);
  const [activePerson, setActivePerson] = useState("person1");
  const [pSortMode, setPSortMode] = useState("year"); // year | gender | season | alpha
  // نوتات التوقيع تُعرض الآن بعد العطّارين بلا طيّ — لا حاجة لحالة الطيّ.
  const [pPage, setPPage] = useState(0);
  const PERFUMES_PER_PAGE = 50;
  const [editNotes, setEditNotes] = useState(false);
  const [notesValue, setNotesValue] = useState("");
  // نوتات التوقيع مطويّة افتراضيًّا
  const [sigNotesOpen, setSigNotesOpen] = useState(false);

  useEffect(() => {
    apphost.auth.me().then(setUserData).catch(() => {});
  }, []);

  // ── Fav / Dislike ──
  const favBrandsP1 = userData?.fav_brands_p1 ? userData.fav_brands_p1.split(",").map(s => s.trim()).filter(Boolean) : [];
  const favBrandsP2 = userData?.fav_brands_p2 ? userData.fav_brands_p2.split(",").map(s => s.trim()).filter(Boolean) : [];
  const dislikeBrandsP1 = userData?.dislike_brands_p1 ? userData.dislike_brands_p1.split(",").map(s => s.trim()).filter(Boolean) : [];
  const dislikeBrandsP2 = userData?.dislike_brands_p2 ? userData.dislike_brands_p2.split(",").map(s => s.trim()).filter(Boolean) : [];

  const toggleOpinion = async (person, brandId, type) => {
    const favKey = person === "person1" ? "fav_brands_p1" : "fav_brands_p2";
    const dislikeKey = person === "person1" ? "dislike_brands_p1" : "dislike_brands_p2";
    const currentFav = person === "person1" ? favBrandsP1 : favBrandsP2;
    const currentDislike = person === "person1" ? dislikeBrandsP1 : dislikeBrandsP2;
    let newFav = currentFav;
    let newDislike = currentDislike;
    if (type === "fav") {
      newFav = currentFav.includes(brandId) ? currentFav.filter(b => b !== brandId) : [...currentFav.filter(b => b !== brandId), brandId];
      newDislike = currentDislike.filter(b => b !== brandId);
    } else {
      newDislike = currentDislike.includes(brandId) ? currentDislike.filter(b => b !== brandId) : [...currentDislike.filter(b => b !== brandId), brandId];
      newFav = currentFav.filter(b => b !== brandId);
    }
    const updates = { [favKey]: newFav.join(","), [dislikeKey]: newDislike.join(",") };
    await apphost.auth.updateMe(updates);
    setUserData({ ...userData, ...updates });
    toast.success((isAr ? "تم التحديث" : "Updated"));
  };

  // ── Brand data ──
  const { data: brand, isLoading, isFetching: brandFetching } = useQuery({
    queryKey: ["brand", id],
    queryFn: async () => {
      // getMany بالمعرّف الأساسيّ أوثق من filter أوّل تحميل (filter قد يمسح قبل جهوزيّة المخزن
      // فيرجع فارغاً → صفحة فارغة حتى إعادة الفتح). نجرّب getMany ثم filter احتياطاً.
      let r = null;
      try { const m = await apphost.entities.PerfumeBrand.getMany([id]); r = (m && m[0]) || null; } catch { /* تجاهل */ }
      if (!r) { try { const f = await apphost.entities.PerfumeBrand.filter({ id }); r = (f && f[0]) || null; } catch { /* تجاهل */ } }
      return r;
    },
    enabled: !!id,
    staleTime: Infinity,
    // نفس علّة /brands: refetchOnMount:false كان يخزّن null عند أوّل دخول قبل جهوزية
    // المخزن فتبقى صفحة البراند فارغة حتى ترجع و تدخل. "always" يضمن جلب البراند عند
    // كل دخول للصفحة (استعلام مفرد رخيص) فلا تبقى فارغة.
    refetchOnMount: "always",
    retry: 2,
  });

  // وصول عبر ?name= (روابط البراند القديمة/عطور البذرة بلا brand_id): نحلّ الاسم إلى
  // معرّف البراند الحقيقي بمطابقة متسامحة ثم نعيد التوجيه إلى ?id= فيعمل بقيّة المنطق كما هو.
  useEffect(() => {
    if (id || !nameParam) return;
    let cancelled = false;
    (async () => {
      let hit = null;
      try {
        const exact = await apphost.entities.PerfumeBrand.filter({ name: nameParam });
        hit = exact?.[0] || null;
        if (!hit?.id) {
          const want = looseBrandKey(nameParam);
          const all = await getAllBrandsCached();
          hit = (all || []).find((b) =>
            looseBrandKey(b.name) === want ||
            (b.name_ar && looseBrandKey(b.name_ar) === want)
          ) || null;
        }
      } catch { /* ignore */ }
      if (!cancelled && hit?.id) navigate(`/brand?id=${encodeURIComponent(hit.id)}`, { replace: true });
    })();
    return () => { cancelled = true; };
  }, [id, nameParam, navigate]);

  // ── Perfumes by brand ──
  // المسار السريع: إن خُزّنت perfume_ids للبراند وقت الزراعة، نجلب بالمعرّف عبر
  // getMany — بلا مسح 130 ألف. وإلا نرجع لمسار filter القديم (نفس النتيجة) للبيانات
  // القديمة أو البراندات غير المطابقة.
  const brandPerfumeIds = brand?.perfume_ids
    ? brand.perfume_ids.split(",").map((s) => s.trim()).filter(Boolean)
    : [];
  const hasBrandIds = brandPerfumeIds.length > 0;
  const { data: perfumes = [], isFetching: perfumesFetching } = useQuery({
    queryKey: ["perfumes-by-brand", brand?.name, hasBrandIds, brandPerfumeIds.length],
    queryFn: async () => {
      if (!hasBrandIds) {
        // تجنّب مسح ١٣٠ ألف عطر (filter بالاسم) قبل اكتمال ربط perfume_ids في الخلفيّة —
        // كان يجمّد صفحة البراند أوّل إقلاع. إن لم يكتمل الربط نرجع فارغاً (الصفحة تُبنى بلا
        // تجميد)، و العطور تظهر عند إعادة الزيارة بعد اكتمال الربط (proc_links_done=1).
        try { if (typeof localStorage !== "undefined" && localStorage.getItem("proc_links_done") !== "1") return []; } catch { /* تجاهل */ }
        return apphost.entities.Perfume.filter({ brand_name: brand.name });
      }
      // المسار السريع: عطور البذرة بالمعرّف، ثم نضمّ إليها أيّ عطر مُضاف حديثاً
      // (is_user) بنفس اسم البراند عبر فهرس brand_name — كي يظهر فوراً تحت البراند.
      const base = await apphost.entities.Perfume.getMany(brandPerfumeIds);
      const seen = new Set((base || []).map((p) => String(p.id)));
      try {
        const byName = await apphost.entities.Perfume.filter({ brand_name: brand.name });
        for (const p of byName) if (p?.is_user && !seen.has(String(p.id))) { base.push(p); seen.add(String(p.id)); }
      } catch { /* تجاهل */ }
      return base;
    },
    enabled: !!brand?.name,
    refetchOnMount: "always",
  });

  // ── Collections by brand ──
  // جلب متين: بالمعرّف أوّلاً، و إن لم يُرجِع شيئاً (تباين معرّف/وصول بالاسم) نرجع للاسم.
  const { data: collections = [] } = useQuery({
    queryKey: ["collections-by-brand", id, brand?.name],
    queryFn: async () => {
      let rows = [];
      if (id) { try { rows = await apphost.entities.PerfumeCollection.filter({ brand_id: id }); } catch { rows = []; } }
      if ((!rows || !rows.length) && brand?.name) { try { rows = await apphost.entities.PerfumeCollection.filter({ brand_name: brand.name }); } catch { rows = []; } }
      return rows || [];
    },
    enabled: !!id || !!brand?.name,
  });

  // مجموعات تلقائية مُشتقّة من حقل `collection` في العطر نفسه (مثل Versace → Eros).
  // تُدمج مع المجموعات اليدوية حتى تظهر مجموعات القاعدة وعطورها داخل البراند.
  const displayCollections = useMemo(() => {
    const manual = collections || [];
    const manualNames = new Set(manual.map((c) => (c.name || "").trim().toLowerCase()).filter(Boolean));
    const autoMap = {};
    (perfumes || []).forEach((p) => {
      const c = (p.collection || "").trim();
      if (!c || manualNames.has(c.toLowerCase())) return;
      (autoMap[c] = autoMap[c] || []).push(p);
    });
    const auto = Object.keys(autoMap)
      .sort((a, b) => a.localeCompare(b))
      .map((name) => ({ id: "auto:" + name, name, name_ar: "", auto: true }));
    return [...manual, ...auto];
  }, [collections, perfumes]);

  // تجميع مناسبات البراند مرّة واحدة (كان inline في الرندر يُعاد على كل رندر لكل العطور)
  const brandOccasions = useMemo(() => Array.from(new Set(
    (perfumes || []).filter((p) => p.occasions).flatMap((p) => p.occasions.split(",").map((o) => o.trim()))
  )).filter(Boolean), [perfumes]);

  const getCollectionPerfumes = (col) => {
    const list = col.auto
      ? (perfumes || []).filter((p) => (p.collection || "").trim() === col.name)
      : (perfumes || []).filter((p) => String(p.collection_id ?? "") === String(col.id ?? "") || (p.collection || "").trim() === (col.name || "").trim());
    return [...list].sort((a, b) => {
      if (b.release_year && a.release_year) return b.release_year - a.release_year;
      if (b.release_year) return 1;
      if (a.release_year) return -1;
      return new Date(b.created_date) - new Date(a.created_date);
    });
  };

  const [showAddCollection, setShowAddCollection] = useState(false);
  const [newCollection, setNewCollection] = useState({ name: "", name_ar: "", description: "" });
  const [savingCollection, setSavingCollection] = useState(false);

  const handleAddCollection = async () => {
    if (!newCollection.name) { toast.error((isAr ? "اسم المجموعة مطلوب" : "Collection name required")); return; }
    setSavingCollection(true);
    await apphost.entities.PerfumeCollection.create({ ...newCollection, brand_id: id, brand_name: brand.name });
    queryClient.invalidateQueries({ queryKey: ["collections-by-brand", id] });
    setNewCollection({ name: "", name_ar: "", description: "" });
    setShowAddCollection(false);
    setSavingCollection(false);
    toast.success((isAr ? "أُضيفت المجموعة" : "Collection added"));
  };

  // ── UserBrand per person ──
  const { data: userBrands = [] } = useQuery({
    queryKey: ["user-brand", id],
    queryFn: () => apphost.entities.UserBrand.filter({ brand_id: id }),
    enabled: !!id,
  });
  const userDataP1 = userBrands.find(u => u.person === "person1") || null;
  const userDataP2 = userBrands.find(u => u.person === "person2") || null;

  const activeUserData = activePerson === "person1" ? userDataP1 : userDataP2;

  // ── Sibling brands (same owned_by / parent_company) ──
  // تُحمَّل القائمة فقط إذا كان للبراند مالك فعلاً (قسم «يملكه» لا يظهر بدونه)
  const { data: allBrands = [] } = useQuery({
    queryKey: ["brands-light"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    staleTime: Infinity,
    gcTime: Infinity,
    refetchOnMount: false,
    enabled: !!brand?.owned_by,
  });

  // ── Purchase records linked to any perfume of this brand ──
  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records-brand", brand?.name],
    queryFn: () => apphost.entities.PurchaseRecord.filter({ brand_name: brand.name }, "-created_date"),
    enabled: !!brand?.name,
  });

  // متاجر التسوّق (ShopBrand) — كيان المتاجر الموحّد المستخدم في المشتريات والتسوّق.
  // (أُزيل استعلام Store القديم؛ التوحيد على ShopBrand.)
  const { data: shopBrands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
  });
  const brandStore = brand
    ? shopBrands.find(
        (s) =>
          String(s.source_brand_id || "") === String(brand.id) ||
          ((s.name || "") === (brand.name || "") && s.type === "perfume_store")
      )
    : null;
  const [storeToggling, setStoreToggling] = useState(false);
  const toggleBrandStore = async () => {
    if (!brand || storeToggling) return;
    setStoreToggling(true);
    try {
      if (brandStore) {
        await apphost.entities.ShopBrand.delete(brandStore.id);
        toast.success(isAr ? "أُزيل من المتاجر" : "Removed from stores");
      } else {
        await apphost.entities.ShopBrand.create({
          name: brand.name,
          name_ar: brand.name_ar || "",
          type: "perfume_store",
          logo_url: brand.logo_url || null,
          website: brand.website || null,
          country: brand.country || "",
          person: "family",
          category_name_en: "Perfume",
          category_name_ar: "عطور",
          source: "from_brand",
          source_brand_id: String(brand.id),
        });
        toast.success(isAr ? "أُضيف للمتاجر — التسوّق ← المتاجر ← العطور" : "Added to stores — Shopping > Stores > Perfume");
      }
      await queryClient.invalidateQueries({ queryKey: ["shop-brands"] });
    } catch (e) {
      toast.error(isAr ? "تعذّر التحديث" : "Update failed");
    } finally {
      setStoreToggling(false);
    }
  };

  // (أزيل تحميل كل العطّارين «للتصدير» — كود ميت: الخريطة لم تكن تُستهلك،
  // و كانت تكلف ٣٠٧١ سجلاً عند كل فتح لصفحة البراند.)

  // ── Unified description (merges legacy description_ar + bio fields) ──
  const unifiedDescription = (() => {
    if (!brand) return "";
    const parts = [
      brand.description?.trim(),
      brand.description_ar?.trim(),
      brand.bio?.trim(),
    ].filter(Boolean);
    const seen = new Set();
    return parts.filter(p => {
      const key = p.toLowerCase().replace(/\s+/g, ' ');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).join("\n\n");
  })();

  // ── Signature Notes ──
  const { data: allNotes = [] } = useQuery({
    queryKey: ["perfume-notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: Infinity,            // كتالوج ثابت بالجلسة — لا تُعد تحميل ٢٨٠٠ نوتة كل فتح براند
    refetchOnWindowFocus: false,
  });
  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["bd-all-perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
    staleTime: Infinity,
    refetchOnWindowFocus: false,
  });

  // Get signature notes data
  // نوتات التوقيع حقلٌ حرّ يُعبّأ يدوياً (مثل ARABIAN ١٥٩ نوتة) — مرتّبة أبجدياً،
  // بلا صور، حتى ٢٠٠ نوتة. (تختلف عن «النوتات/الخلاصة» التي تُستخلص من العطور.) .
  const signatureNotes = (brand?.signature_notes_names || "")
    .split(",").map((s) => s.trim()).filter(Boolean)
    .map((item) => {
      const m = item.match(/^([^\u0600-\u06FF]+?)\s*([\u0600-\u06FF].*)?$/);
      const en = (m && m[1] ? m[1] : item).trim();
      const ar = (m && m[2] ? m[2] : "").trim();
      return { en, ar };
    }).filter((n) => n.en || n.ar)
    .sort((a, b) => (a.en || a.ar).localeCompare((b.en || b.ar), "en", { sensitivity: "base" }))
    .slice(0, 200);

  // فهرس النوتات (إنجليزي + عربي مطبّعَين) لجلب صورة كل نوتة توقيع — يصلح
  // «صور النوتات لا تظهر»: كانت تُعرض نصًّا فقط بلا صور. .
  const sigNorm = (s) => String(s || "").toLowerCase()
    .replace(/[\u064B-\u0652\u0670\u0640]/g, "").replace(/[إأآٱ]/g, "ا")
    .replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/(^|\s)ال/g, "$1")
    .replace(/[^a-z0-9\u0600-\u06FF ]/g, "").replace(/\s+/g, " ").trim();
  const sigNoteIndex = useMemo(() => {
    const m = {};
    // لا نبني فهرس ٢٨٠٠ نوتة إطلاقاً إن لم يكن للبراند نوتات توقيع (أغلب البراندات) —
    // و نحسبه مرّة واحدة (useMemo) لا على كل رندر. كان بناؤه المتكرّر يجمّد الصفحة.
    if (!signatureNotes.length) return m;
    for (const n of allNotes || []) {
      for (const k of [n.name_en, n.name, n.name_ar]) {
        const kk = sigNorm(k);
        if (kk && !(kk in m)) m[kk] = n;
      }
    }
    return m;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allNotes, signatureNotes.length]);
  const findSigNote = (n) => sigNoteIndex[sigNorm(n.en)] || sigNoteIndex[sigNorm(n.ar)] || null;

  // ── Upsert UserBrand ──
  const upsertUserBrand = useMutation({
    mutationFn: async ({ person, field, value }) => {
      const existing = person === "person1" ? userDataP1 : userDataP2;
      const dataToSave = { [field]: value };
      if (existing) {
        return apphost.entities.UserBrand.update(existing.id, dataToSave);
      } else {
        return apphost.entities.UserBrand.create({
          brand_id: id,
          brand_name: brand?.name,
          person,
          ...dataToSave,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-brand", id] });
    },
  });

  // ── Brand edit ──

  // ── Export ──

  if (isLoading || (nameParam && !id)) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (!brand && brandFetching) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (!brand) return (
    <div className="px-5 page-top text-center space-y-4">
      <p className="text-muted-foreground font-body">{isAr ? "البراند غير موجود" : "Brand not found"}</p>
      <Button variant="ghost" onClick={() => navigate("/brands")}>{isAr ? "رجوع" : "Go Back"}</Button>
    </div>
  );

  const hasBestOfDecade = (perfumes || []).some((p) => p.best_of_decade && decadeFromYear(p.release_year) !== null);
  const displayCountry = isAr ? (brand.country_ar || brand.country) : brand.country;

  // Show all purchases (both persons), sorted by date
  const activePurchases = purchaseRecords;
  const totalSpent = activePurchases.reduce((s, r) => s + (r.cost || 0), 0);
  const totalMl = activePurchases.reduce((s, r) => s + (r.ml || 0), 0);

  return (
    <div className="pb-8 max-w-full overflow-x-hidden">
      {/* Header */}
      <div className="relative bg-[var(--page-bg,#fff)] px-5 pt-6 pb-0">
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" size="icon" className="rounded-none hover:bg-white/20" onClick={() => navigate("/perfumes")}>
            <BackIcon className="w-5 h-5" />
          </Button>
          {/* Bookmark + Copy moved to the bottom of the page */}
        </div>
        <div className="flex flex-col items-center gap-6 pb-8">
           <div className="flex items-center justify-center px-4 w-full" style={{ minHeight: 96 }}>
             <BrandLogo
               brand={brand}
               bestOfDecade={hasBestOfDecade}
               enSize={17}
               arSize={11}
               logoMaxH={84}
               crownSize={16}
             />
           </div>
         </div>
      </div>

      <div className="px-5 space-y-5 mt-5">

        {/* About — description first, then meta row below */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
          {unifiedDescription && (
            <p dir="auto" className="text-sm font-body text-foreground/80 leading-relaxed whitespace-pre-line" style={{ textAlign: "start" }}>{unifiedDescription}</p>
          )}
          {/* meta row: website globe + country + est + activity status */}
          <div className="flex flex-wrap items-center gap-3 text-xs font-body pt-1">
            <button type="button" onClick={() => { const q = brandCategoryLabel(brand, false) || brandCategoryLabel(brand, isAr); if (q) navigate(`/search-results?q=${encodeURIComponent(q)}`); }}
              className="font-medium hover:underline cursor-pointer" style={{ color: "var(--brand)" }}>{brandCategoryLabel(brand, isAr)}</button>
            {brand.website && (
              <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(brand.website); }}
                aria-label={isAr ? "موقع البراند" : "Brand website"} title={brand.website}
                className="text-sky-600 hover:text-sky-700 transition-colors">
                <Globe className="w-4 h-4" />
              </button>
            )}
            {displayCountry && (
              <Link
                to={`/search-results?q=${encodeURIComponent(brand.country || displayCountry)}`}
                className="text-muted-foreground hover:opacity-70 transition-opacity"
                title={`@${brand.country || displayCountry}`}
              >
                {displayCountry}
              </Link>
            )}
            {brand.year_established && <span className="text-muted-foreground">{brand.year_established}</span>}
            <span className="text-muted-foreground inline-flex items-center gap-1 text-[9px]">
              <span className="text-[10px] leading-none">{(typeof localStorage !== "undefined" && localStorage.getItem("userMark")) || "🧴"}</span>
              {perfumes.length} {isAr ? "عطر" : (perfumes.length === 1 ? "perfume" : "perfumes")}
            </span>
            <span className={brand.in_business !== false ? "text-emerald-600 font-medium" : "text-red-500 font-medium"}>
              {brand.in_business !== false ? (isAr ? "نشِط" : "Active") : (isAr ? "متوقّف" : "Closed")}
            </span>
          </div>
          {/* الجوهر Essence — داخل جدول الوصف، خلاصة الدار محسوبة من كل عطورها */}
          <BrandCore perfumes={perfumes} allNotes={allNotes} perfumers={allPerfumers} />
        </div>

        {/* Perfumes by brand - Grid */}
        <div className="space-y-3 bg-card rounded-none p-3 shadow-sm">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h2 className="font-heading font-semibold">{isAr ? "العطور" : "Perfumes"}</h2>
            {/* sort options — text pills + alphabetical asc/desc as icon-only
                buttons (AArrowUp / AArrowDown), matching the sort control used
                on the Glossary page. */}
            <div className="flex items-center gap-1.5">
              {[
                { id: "year", ar: "الإصدار", en: "Release" },
                { id: "gender", ar: "الجنس", en: "Gender" },
                { id: "season", ar: "الموسم", en: "Season" },
              ].map((s) => (
                <button key={s.id} onClick={() => { setPSortMode(s.id); setPPage(0); }}
                  className={`text-[10px] rounded-none inline-flex items-center gap-1 ${pSortMode === s.id ? " text-background" : " text-muted-foreground"}`}>
                  {isAr ? s.ar : s.en}
                </button>
              ))}
              {[
                { id: "alpha_asc", Icon: AArrowUp, ar: "أبجدي تصاعدي", en: "A → Z" },
                { id: "alpha_desc", Icon: AArrowDown, ar: "أبجدي تنازلي", en: "Z → A" },
              ].map((s) => (
                <button key={s.id} onClick={() => { setPSortMode(s.id); setPPage(0); }}
                  title={isAr ? s.ar : s.en} aria-label={isAr ? s.ar : s.en}
                  className={`p-1 rounded-none transition-colors ${pSortMode === s.id ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                  <s.Icon className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>
          {perfumes.length === 0
            ? (perfumesFetching
                ? <div className="flex justify-center py-6"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>
                : <p className="text-sm text-muted-foreground font-body text-center py-6">{isAr ? "لا عطور بعد لهذا البراند." : "No perfumes added yet for this brand."}</p>)
            : (() => {
                const sorted = [...perfumes].sort((a, b) => {
                  if (pSortMode === "alpha_asc" || pSortMode === "alpha_desc") {
                    const an = (a.name_en || a.name || "").trim(), bn = (b.name_en || b.name || "").trim();
                    const isEng = (s) => /^[A-Za-z]/.test(s);
                    const ar = isEng(an) ? 0 : 1, br = isEng(bn) ? 0 : 1;
                    if (ar !== br) return ar - br; // keep the English block first in both directions
                    const cmp = an.localeCompare(bn, "en", { sensitivity: "base", numeric: true });
                    return pSortMode === "alpha_desc" ? -cmp : cmp;
                  }
                  if (pSortMode === "gender") return (a.gender || "").localeCompare(b.gender || "");
                  if (pSortMode === "season") return (a.season || "").localeCompare(b.season || "");
                  // year (default)
                  if (b.release_year && a.release_year) return b.release_year - a.release_year;
                  if (b.release_year) return 1;
                  if (a.release_year) return -1;
                  return new Date(b.created_date) - new Date(a.created_date);
                });
                const totalPages = Math.ceil(sorted.length / PERFUMES_PER_PAGE);
                const pageItems = sorted.slice(pPage * PERFUMES_PER_PAGE, (pPage + 1) * PERFUMES_PER_PAGE);
                return (
                  <>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                      {pageItems.map(p => {
                        // مجموعة البراند (تلقائياً من اسم العطر، مثل "Private Blend")
                        const coll = p.collection || deriveCollection(p.name_en || p.name || "");
                        const dom = dominantAccord(p.accords);
                        const accName = dom ? (isAr ? (dom.ar || dom.en) : dom.en) : "";
                        const accColor = dom ? dom.bar : "#94a3b8";
                        const gColor = GENDER_BORDER[p.gender] || "rgba(120,120,120,0.35)";
                        const isBest = p.best_of_decade && decadeFromYear(p.release_year) !== null;
                        const sh = "0 1px 2px rgba(255,255,255,0.95)";
                        const ty = shortType(p.type);
                        return (
                          <button key={p.id} onClick={() => navigate(`/perfume?id=${p.id}`)}
                            className="flex flex-col text-left hover:opacity-80 transition-opacity">
                            {/* علبة العطر: زوايا حادّة، إطار بلون الجنس، قنينة ملوّنة بالأكورد */}
                            <div className="relative w-full aspect-square bg-white overflow-hidden flex items-center justify-center"
                              style={{ border: isBest ? `3px solid var(--brand)` : `1.5px solid ${gColor}`, borderRadius: 0 }}>
                              {p.image_url
                                ? <img src={p.image_url} alt={p.name_en || p.name} loading="lazy" className="w-full h-full object-cover" />
                                : <AccordFlacon accords={p.accords} style={{ maxWidth: "62%", height: "100%" }} />}
                              {/* أربع زوايا: المجموعة • السنة (صغيرة) • الأكورد المسيطر • النوع */}
                              {coll && (
                                <span className="absolute top-1 left-1 text-[8px] font-body font-bold" style={{ color: "var(--brand)", textShadow: sh }}>{clip2(coll, 13)}</span>
                              )}
                              {p.release_year && !isBest && (
                                <span className="absolute top-1 right-1 text-[7px] font-body font-bold" style={{ color: "#1864ab", textShadow: sh }}>{p.release_year}</span>
                              )}
                              {isBest && (
                                <span className="absolute top-1 right-1" title={isAr ? "أفضل العقد" : "Best of decade"}
                                  style={{ color: "var(--brand)", filter: "drop-shadow(0 1px 1.5px rgba(255,255,255,0.95))", lineHeight: 0 }}>
                                  <Crown size={19} strokeWidth={2.2} />
                                </span>
                              )}
                              {accName && (
                                <span className="absolute bottom-1 left-1 text-[8px] font-body font-semibold" style={{ color: accColor, textShadow: sh }}>{accName}</span>
                              )}
                              {ty && (
                                <span className="absolute bottom-1 right-1 text-[8px] font-body font-semibold" style={{ color: "#5f5e5a", textShadow: sh }}>{ty}</span>
                              )}
                            </div>
                            {/* الاسم: سطران ثابتان، إنجليزي فقط، اختصار بنقطتين «..» */}
                            <p className="mt-1 text-[11px] font-body font-bold text-foreground"
                              style={{ lineHeight: 1.25, height: 28, overflow: "hidden" }}>
                              {clip2(p.name_en || p.name, 40)}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                    {/* pagination */}
                    {totalPages > 1 && (
                      <div className="flex items-center justify-center gap-4 pt-3">
                        <button disabled={pPage === 0} onClick={() => setPPage((n) => Math.max(0, n - 1))}
                          className="disabled:opacity-30 transition-opacity" style={{ color: "var(--brand)" }} aria-label={isAr ? "السابق" : "Prev"}>
                          <ChevronLeft className="w-5 h-5" />
                        </button>
                        <span className="text-xs font-body" style={{ color: "var(--brand)" }}>{pPage + 1} / {totalPages}</span>
                        <button disabled={pPage >= totalPages - 1} onClick={() => setPPage((n) => Math.min(totalPages - 1, n + 1))}
                          className="disabled:opacity-30 transition-opacity" style={{ color: "var(--brand)" }} aria-label={isAr ? "التالي" : "Next"}>
                          <ChevronRight className="w-5 h-5" />
                        </button>
                      </div>
                    )}
                  </>
                );
              })()
          }
        </div>

        {/* ─── Perfumers linked to this brand ─── */}
        <BrandPerfumersSection brand={brand} />

        {/* ─── نوتات التوقيع — مطويّة افتراضيًّا، كلّها روابط بلا صور ─── */}
        {signatureNotes.length > 0 && (
          <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
            <button
              type="button"
              onClick={() => setSigNotesOpen((v) => !v)}
              className="w-full flex items-center justify-between gap-2 bg-transparent p-0 border-0 cursor-pointer"
              aria-expanded={sigNotesOpen}
            >
              <h2 className="font-heading font-semibold text-sm">
                {isAr ? "نوتات التوقيع" : "Signature Notes"} <span className="text-muted-foreground font-body text-[11px]">{isAr ? "Signature Notes" : "نوتات التوقيع"}</span>
              </h2>
            </button>
            {sigNotesOpen && (
              <div
                dir={isAr ? "rtl" : "ltr"}
                className="flex flex-wrap gap-x-2 gap-y-1.5 text-[12px] font-body leading-relaxed"
              >
                {signatureNotes.map((n, i) => {
                  const rec = findSigNote(n);
                  const label = isAr ? (n.ar || n.en) : (n.en || n.ar);
                  if (!label) return null;
                  return (
                    <span key={i} className="inline-flex items-center">
                      {i > 0 && <span className="text-muted-foreground/50 mx-1">—</span>}
                      <button
                        type="button"
                        onClick={() => rec ? navigate(`/note?id=${rec.id}`) : navigate(`/note?name=${encodeURIComponent(n.en || n.ar)}`)}
                        className="hover:opacity-70 transition-opacity bg-transparent p-0 border-0 cursor-pointer font-semibold"
                        style={{ color: "var(--brand)" }}
                        title={`${n.en}${n.ar ? " " + n.ar : ""}`}
                      >
                        {label}
                      </button>
                    </span>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ─── Occasion/Occasions — Best For ─── */}
        {brandOccasions.length > 0 && (
          <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
            <h2 className="font-heading font-semibold">{isAr ? "أفضل المناسبات" : "Best For"}</h2>
            <div className="flex flex-wrap gap-x-4 gap-y-2">
              {brandOccasions.map(occasion => {
                const label = occasionInfo(occasion);
                return (
                  <button key={occasion}
                    onClick={() => navigate(`/occasion?o=${encodeURIComponent(occasion)}`)}
                    className="text-xs font-body font-medium text-cyan-700 dark:text-cyan-400 hover:text-cyan-500 transition-colors">
                    {label ? fmtOcc(label, occMode, { isAr }) : occasion}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── Collections ─── */}

        <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-heading font-semibold">{isAr ? "المجموعات" : "Collections"}</h2>
            </div>
            <Button size="sm" variant="outline" className="rounded-none h-8 gap-1 text-xs" onClick={() => setShowAddCollection(!showAddCollection)}>
              Add
            </Button>
          </div>

          {showAddCollection && (
            <div className="bg-primary/5 border border-primary/20 rounded-none p-3 space-y-2">
              <Input value={newCollection.name} onChange={e => setNewCollection({...newCollection, name: e.target.value})} placeholder={isAr ? "اسم المجموعة بالإنجليزية" : "Collection name (EN)"} className="rounded-none h-10 font-body text-sm" />
              <Input value={newCollection.name_ar} onChange={e => setNewCollection({...newCollection, name_ar: e.target.value})} placeholder="اسم المجموعة (عربي)" className="rounded-none h-10 font-body text-sm" dir="rtl" />
              <Input value={newCollection.description} onChange={e => setNewCollection({...newCollection, description: e.target.value})} placeholder={isAr ? "الوصف اختياري" : "Description (optional)"} className="rounded-none h-10 font-body text-sm" />
              <div className="flex gap-2">
                <Button size="sm" className="rounded-none flex-1 text-xs" onClick={handleAddCollection} disabled={savingCollection}>
                  {savingCollection ? "Saving.." : "Save Collection"}
                </Button>
                <Button size="sm" variant="ghost" className="rounded-none text-xs" onClick={() => setShowAddCollection(false)}>{isAr ? "إلغاء" : "Cancel"}</Button>
              </div>
            </div>
          )}

          {displayCollections.length === 0 ? (
            <p className="text-xs text-muted-foreground font-body text-center py-3">{isAr ? "لا مجموعات بعد أضف واحدة أعلاه" : "No collections yet. Add one above."}</p>
          ) : (
            <div className="space-y-2">
              {displayCollections.slice(0, 4).map(col => (
                <button key={col.id} type="button"
                  onClick={() => navigate(`/brand-collection?id=${encodeURIComponent(col.id)}&brand=${encodeURIComponent(brand?.name || "")}`)}
                  className="w-full text-start bg-card/30 rounded-none p-3 border border-primary/20 cursor-pointer hover:bg-card/50 transition-colors">
                  <p className="text-sm font-body font-semibold">{isAr ? (col.name_ar || col.name) : col.name}</p>
                  {isAr && col.name_ar && col.name && <p className="text-[10px] text-muted-foreground font-body">{col.name}</p>}
                  {col.description && <p className="text-[10px] text-muted-foreground font-body mt-0.5">{col.description}</p>}
                </button>
              ))}
              {displayCollections.length > 4 && (
                <button type="button"
                  onClick={() => navigate(`/brand-collections?id=${encodeURIComponent(id)}&brand=${encodeURIComponent(brand?.name || "")}`)}
                  className="w-full text-center font-body text-xs font-semibold hover:opacity-70 transition-opacity pt-1" style={{ color: "var(--brand)" }}>
                  {isAr ? `شاهد جميع مجموعات ${brand?.name || "الماركة"}` : `See all ${brand?.name || "brand"} collections`}
                </button>
              )}
            </div>
          )}
          </div>

          {/* Add Perfume Button */}
          <Button 
          onClick={() => navigate(`/add?brand=${brand.id}`)} 
          className="w-full h-10 rounded-none font-body gap-2 bg-primary hover:bg-primary/90"
          >
          Add Perfume to {brand.name}
          </Button>

          {/* ─── Opinion buttons ─── */}
        <div className="space-y-2">
          {[
            { person: "person1", label: names.person1, favList: favBrandsP1, dislikeList: dislikeBrandsP1, favColor: "text-primary", dislikeColor: "text-red-500" },
            { person: "person2", label: names.person2, favList: favBrandsP2, dislikeList: dislikeBrandsP2, favColor: "text-violet-600", dislikeColor: "text-red-500" },
          ].map(({ person, label, favList, dislikeList, favColor, dislikeColor }) => {
            const isFav = favList.includes(id);
            const isDislike = dislikeList.includes(id);
            return (
              <div key={person} className="space-y-0.5">
                <p className="text-[10px] text-muted-foreground font-body font-semibold uppercase tracking-wide px-0.5">{label}</p>
                <div className="grid grid-cols-2">
                  <button onClick={() => toggleOpinion(person, id, "fav")}
                    style={{ border: "none" }}
                    className={`flex items-center justify-center gap-1 py-1.5 text-[10px] font-body font-semibold transition-all ${favColor} ${isFav ? "bg-current/10" : "bg-transparent opacity-50 hover:opacity-80"}`}>
                    <Heart className={`w-3.5 h-3.5 ${isFav ? "fill-current" : ""}`} />
                    Favorite
                  </button>
                  <button onClick={() => toggleOpinion(person, id, "dislike")}
                    style={{ border: "none" }}
                    className={`flex items-center justify-center gap-1 py-1.5 text-[10px] font-body font-semibold transition-all ${dislikeColor} ${isDislike ? "bg-current/10" : "bg-transparent opacity-50 hover:opacity-80"}`}>
                    <HeartOff className="w-3.5 h-3.5" />
                    Don't Like
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* ─── NOSE — Personal Review Section ─── */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-5">
          {/* Person switcher */}
          <div className="flex items-center gap-2.5 flex-wrap pb-2 border-b border-border/40">
            <span className="font-heading font-bold text-base tracking-wider">{isAr ? "الأنف" : "NOSE"}</span>
            <span className="text-muted-foreground text-sm">—</span>
            <button onClick={() => { setActivePerson("person1"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person1" ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              {names.person1}
            </button>
            <span className="text-muted-foreground text-sm">—</span>
            <button onClick={() => { setActivePerson("person2"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person2" ? "text-violet-500" : "text-muted-foreground hover:text-foreground"}`}>
              {names.person2}
            </button>
          </div>

          {/* تفاعلك — موحّد مع العطر: 4 إيموجي على UserBrand.list (استُبدل الانطباع/other_rating). بياناتك لكلّ شخص. */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "تفاعلك" : "Your Reaction"}</p>
            <div className="grid grid-cols-2 gap-1">
              {[
                { value: "favorite", emoji: "❤️", label: isAr ? "مفضّل" : "Fav", activeColor: "text-rose-500" },
                { value: "recommend", emoji: "👍", label: isAr ? "إعجاب" : "Like", activeColor: "text-amber-600" },
                { value: "dislike", emoji: "👎", label: isAr ? "نفور" : "Dislike", activeColor: "text-slate-600" },
                { value: "wtf", emoji: "😱", label: isAr ? "ماذا" : "WTF", activeColor: "text-purple-600" },
              ].map(({ value, emoji, label, activeColor }) => {
                const active = activeUserData?.list === value;
                return (
                  <button key={value}
                    onClick={() => upsertUserBrand.mutate({ person: activePerson, field: "list", value: active ? "none" : value })}
                    className={`flex flex-col items-center gap-1 py-2 text-[11px] font-body transition-all ${active ? `font-bold ${activeColor}` : "text-muted-foreground hover:text-foreground"}`} style={{ border: "none", background: "transparent" }}>
                    <span className={emojiSizeClass(emoji, "text-2xl", "text-lg")}>{emoji}</span>
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Rating */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "التقييم" : "Rating"}</p>
            <StarRating
              rating={activeUserData?.rating || 0}
              onChange={v => upsertUserBrand.mutate({ person: activePerson, field: "rating", value: v })}
              size="lg"
            />
          </div>

          {/* محاور التقييم — أربعة أبعاد، معينات، خطوط صغيرة، بلا عنوان Axes */}
          <div className="space-y-2.5">
            {RATING_AXES.map((ax) => (
              <div key={ax.key} className="space-y-0.5">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[12px] font-body font-semibold">{isAr ? ax.ar : ax.en} <span className="text-muted-foreground text-[9px] font-normal">{isAr ? ax.en : ax.ar}</span></span>
                  <StarRating rating={activeUserData?.[ax.key] || 0} onChange={v => upsertUserBrand.mutate({ person: activePerson, field: ax.key, value: v })} size="sm" />
                </div>
                <p className="text-[9px] text-muted-foreground font-body leading-snug">{isAr ? ax.descAr : ax.descEn}</p>
              </div>
            ))}
          </div>

          {/* Health Ratings */}
          <HealthRatingSection
            activeUserData={activeUserData}
            activePerson={activePerson}
            onUpdate={(field, value) => upsertUserBrand.mutate({ person: activePerson, field, value })}
          />

          {/* Personal Notes */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "مراجعتي" : "My Review"}</p>
              {!editNotes && (
                <Button variant="ghost" size="sm" className="text-xs font-body h-7"
                  onClick={() => { setEditNotes(true); setNotesValue(activeUserData?.personal_notes || ""); }}>
                  Edit
                </Button>
              )}
            </div>
            {editNotes ? (
               <div className="space-y-2">
                 <Textarea value={notesValue} onChange={e => setNotesValue(e.target.value)}
                   className="rounded-none font-body min-h-[80px]" placeholder={isAr ? "خواطرك عن هذا البراند" : "Your thoughts about this brand.."} />
                 <div className="flex gap-2">
                   <Button size="sm" className="rounded-none font-body" onClick={() => {
                     upsertUserBrand.mutate({ person: activePerson, field: "personal_notes", value: notesValue });
                     setEditNotes(false);
                   }}>{isAr ? "حفظ" : "Save"}</Button>
                  <Button size="sm" variant="ghost" className="rounded-none font-body" onClick={() => setEditNotes(false)}>{isAr ? "إلغاء" : "Cancel"}</Button>
                </div>
              </div>
            ) : (
              <p className="text-sm font-body text-foreground/80 whitespace-pre-wrap">{activeUserData?.personal_notes || "No review yet"}</p>
            )}
          </div>
        </div>

        {/* ─── Purchase History (perfumes of this brand) ─── */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-border/40">
            <div>
              <h2 className="font-heading font-semibold">{isAr ? "سجل الشراء" : "Purchase History"}</h2>
              <p className="text-xs text-muted-foreground font-body">{activePurchases.length} purchase{activePurchases.length !== 1 ? "s" : ""}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-primary font-heading">{formatPrice(totalSpent)}</p>
              <p className="text-[9px] text-muted-foreground font-body">{totalMl}ml total</p>
            </div>
          </div>

          {activePurchases.length === 0 ? (
            <p className="text-xs text-muted-foreground font-body text-center py-4">{isAr ? "لا مشتريات مسجّلة لهذا البراند" : "No purchases recorded for this brand."}</p>
          ) : (
            <div className="space-y-2">
              {activePurchases.map(record => (
                <div key={record.id} className="flex flex-col gap-2 bg-secondary/40 rounded-none p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-[9px] font-bold rounded-none ${record.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                        {record.person === "person2" ? names.person2 : names.person1}
                      </span>
                      <span className="text-[10px] font-body font-bold rounded-none text-foreground/70">
                        {record.type === "sample" ? "Sample" : "Bottle"}
                      </span>
                      <span className="text-[10px] font-body font-semibold text-foreground/80 truncate max-w-[100px]">{record.perfume_name}</span>
                      <span className="text-[9px] text-muted-foreground font-body">{record.purchase_date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <p className="text-xs font-body font-medium">{record.ml}ml</p>
                        <p className="text-[10px] text-muted-foreground font-body">{formatPrice(record.cost)}</p>
                      </div>
                      <EditPurchaseDialog
                        record={record}
                        perfumeId={record.perfume_id}
                        activePerson={activePerson}
                        stores={shopBrands}
                        onSuccess={() => {
                          queryClient.invalidateQueries({ queryKey: ["purchase-records-brand", brand?.name] });
                          queryClient.invalidateQueries({ queryKey: ["purchase-records"] });
                        }}
                      />
                    </div>
                  </div>
                  {record.store_name && (
                    <button onClick={() => navigate(`/store?id=${record.store_id}`)}
                      className="text-xs font-body text-primary hover:underline w-fit">
                      🏪 {record.store_name}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ─── Owned By (show only if linked) ─── */}
        {brand.owned_by && (() => {
          const ownerKey = brand.owned_by.trim().toLowerCase();
          const siblingBrands = allBrands.filter(b =>
            b.id !== id && (
              b.owned_by?.trim().toLowerCase() === ownerKey ||
              b.parent_company?.trim().toLowerCase() === ownerKey ||
              b.name?.trim().toLowerCase() === ownerKey
            )
          );
          return (
            <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-primary/10 rounded-none flex items-center justify-center flex-shrink-0">
                  <Building2 className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">{isAr ? "يملكه" : "Owned By"}</p>
                  <button
                    onClick={() => navigate(`/owner-group?name=${encodeURIComponent(brand.owned_by)}`)}
                    className="text-sm font-body font-bold text-primary hover:underline text-left"
                  >
                    {brand.owned_by}
                  </button>
                </div>
              </div>
              {siblingBrands.length > 0 && (
                <div className="pt-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-2">العلامات المملوكة لنفس المجموعة</p>
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5">
                    {siblingBrands.map(b => (
                      <button
                        key={b.id}
                        onClick={() => navigate(`/brand?id=${b.id}`)}
                        className="text-xs font-body font-medium text-teal-700 dark:text-teal-400 hover:text-teal-500 transition-colors"
                      >
                        {b.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* ─── Bookmark + Copy (centered, bottom) ─── */}
        <div className="flex justify-center items-center gap-3 pt-2">
          <BookmarkButton descriptor={{
            item_type: "brand",
            item_id: id,
            title_en: brand.name,
            title_ar: brand.name_ar || "",
            subtitle: brand.country || "",
            path: `/brand?id=${id}`,
          }} />
          <PinButton kind="brand" id={id} />
          {/* زر مجموعتي — أيقونة براند بجانب النوتبوك */}
          <button
            onClick={() => upsertUserBrand.mutate({ person: activePerson, field: "in_collection", value: !activeUserData?.in_collection })}
            disabled={upsertUserBrand.isPending}
            title={activeUserData?.in_collection ? (isAr ? "في مجموعتي" : "In my collection") : (isAr ? "أضف لمجموعتي" : "Add to my collection")}
            aria-label={isAr ? "مجموعتي" : "My collection"}
            className="flex items-center justify-center w-8 h-8 bg-transparent transition-opacity hover:opacity-70"
            style={{ color: activeUserData?.in_collection ? "var(--brand)" : "#B76E79" }}
          >
            <SprayCan className="w-[18px] h-[18px]" strokeWidth={1.75} fill={activeUserData?.in_collection ? "var(--brand)22" : "none"} />
          </button>
          <button
            onClick={handleCastAwayBrand}
            title={isAr ? "نقل إلى المهملات" : "Cast Away"}
            aria-label={isAr ? "نقل إلى المهملات" : "Cast Away"}
            className="flex items-center justify-center w-8 h-8 bg-transparent transition-colors text-[#B76E79] hover:text-[var(--brand)]"
          >
            <EraserIcon className="w-[18px] h-[18px]" />
          </button>
          <CopyMenu
            entity="brand"
            dbText={brandDbText(brand)}
            fullText={brandFullText(brand, {
              perfumes,
              favorite:      activeUserData?.list === "favorite",
              rating:        activeUserData?.rating,
              personalNotes: activeUserData?.notes || "",
              purchases:     purchaseRecords?.map((r) => ({
                purchase_date: r.purchase_date,
                perfume_name:  r.perfume_name,
                ml:            r.ml,
                cost:          r.cost,
              })) || [],
              personName: names?.[activePerson] || "",
            })}
          />
          {/* أيقونة تعديل البراند — منقولة لصفّ الأزرار مع النوتبوك/كاست أواي */}
          <button onClick={() => navigate(`/add-brand?id=${id}`)} title={isAr ? "تعديل البراند" : "Edit Brand"} aria-label={isAr ? "تعديل البراند" : "Edit Brand"} className="flex items-center justify-center w-8 h-8 bg-transparent transition-colors text-[#B76E79] hover:text-[var(--brand)]">
            <Edit2 className="w-[18px] h-[18px]" />
          </button>
        </div>

         {/* بطاقة البراند الجديدة (صفحة مستقلّة) */}
         <button
           onClick={() => navigate(`/export-card?brand=${id}`)}
           className="w-full py-3 rounded-none font-body text-base font-semibold bg-transparent text-[#B76E79] hover:text-[var(--brand)] active:text-[var(--brand)] transition-colors inline-flex items-center justify-center gap-2"
         >
           <PerfumeSprayIcon className="w-7 h-7" /> {isAr ? "تصدير بطاقة البراند" : "Export Brand Card"}
         </button>

         <ExportHistoryList type="brand" refId={id} title={isAr ? "بطاقات البراند المحفوظة" : "Saved Brand Cards"} />

         {/* ─── أضِف/أزِل البراند من متاجر التسوّق (بإرادة المستخدم) ─── */}
         {/* ─── جدول الماركة للمراجعة (يختفي إن روجعت أيّ حقل) + أضِف للمتاجر — صفّ واحد ─── */}
         <div className="flex items-center gap-2">
           {(() => {
             const b = activeUserData || {};
             const reviewed = !!(b.rating || ["favorite", "recommend", "dislike", "wtf"].includes(b.list) || (b.personal_notes && String(b.personal_notes).trim()) || RATING_AXES.some((ax) => b[ax.key]));
             if (reviewed) return null;
             return (
               <Button variant="outline" className="flex-1 h-10 rounded-none text-[11px] font-body" onClick={() => upsertUserBrand.mutate({ person: activePerson, field: "review_scheduled", value: !b.review_scheduled })}
                 style={{ color: "var(--brand)", fontWeight: b.review_scheduled ? 700 : 400 }}>
                 {b.review_scheduled ? (isAr ? "مجدوَل ✓" : "Scheduled ✓") : (isAr ? "جدول الماركة للمراجعة" : "Schedule Brand for Review")}
               </Button>
             );
           })()}
           <Button size="icon" variant="outline" className="flex-1 h-10 rounded-none gap-2" onClick={toggleBrandStore} disabled={storeToggling}>
             <Building2 className="w-4 h-4" />
             {brandStore ? (isAr ? "في المتاجر — إزالة" : "In Stores — Remove") : (isAr ? "أضِف للمتاجر" : "Add To Stores")}
           </Button>
         </div>

         <IndexLinksRow />

        </div>

      {/* ─── Export Dialog ─── */}

    </div>
  );
}

// Small helper: render an innovation note card using pre-fetched allNotes
function InnovationNoteCard({ name, navigate, allNotes = [] }) {
  const record = allNotes.find(n => n.name?.toLowerCase() === name.toLowerCase());
  return (
    <button
      onClick={() => record ? navigate(`/note?id=${record.id}`) : navigate(`/explore?noteSearch=${encodeURIComponent(name)}`)}
      className="flex flex-col gap-2 text-left hover:opacity-80 transition-opacity group"
    >
      <div className="w-full aspect-square rounded-none overflow-hidden flex items-center justify-center border border-border/50 bg-white">
        {record?.image_url ? (
          <img src={record.image_url} alt={name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-white" />
        )}
      </div>
      <div className="px-1">
        <p className="text-[10px] font-body font-semibold text-foreground line-clamp-2 group-hover:underline leading-tight">{name}</p>
      </div>
    </button>
  );
}
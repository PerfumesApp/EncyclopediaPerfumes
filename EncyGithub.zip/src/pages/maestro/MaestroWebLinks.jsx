// ماسح روابط الويب (A 1.810) — «أين أجد الـ166KB بالتطبيق»:
// يفحص كل الجداول التي تحمل حقول صور/وسائط و يخرج قائمة بكل قيمة تبدأ بـhttp(s)
// — هذه وحدها ما كان يجلب من الشبكة قبل قطع CSP (1.809)، و بعدها تظهر فارغة.
// كل صف يفتح سجله مباشرة لاستبدال الرابط بصورة محلية (data URL من المعرض).
import { useState } from "react";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import BackIcon from "@/components/shared/BackIcon";

const REMOTE = /^https?:\/\//i;

// الجداول و حقولها و مسار فتح السجل — الفحص عام: نص واحد أو مصفوفة نصوص.
const TARGETS = [
  { entity: "Perfume", label_ar: "العطور", label_en: "Perfumes", fields: ["image_url"], nameOf: (r) => r.name_en || r.name || "", path: (r) => `/perfume?id=${r.id}` },
  { entity: "PerfumeBrand", label_ar: "البراندات", label_en: "Brands", fields: ["logo_url"], nameOf: (r) => r.name || "", path: (r) => `/brand?id=${r.id}` },
  { entity: "Perfumer", label_ar: "العطّارون", label_en: "Perfumers", fields: ["photo_url"], nameOf: (r) => r.name || "", path: (r) => `/perfumer?id=${r.id}` },
  { entity: "PerfumeNote", label_ar: "النوتات", label_en: "Notes", fields: ["image_url"], nameOf: (r) => r.name || "", path: (r) => `/note?id=${r.id}` },
  { entity: "ShopBrand", label_ar: "متاجر التسوق", label_en: "Shop stores", fields: ["logo_url"], nameOf: (r) => r.name || "", path: () => `/shopping` },
  { entity: "ShopProduct", label_ar: "منتجات التسوق", label_en: "Shop products", fields: ["image_url", "photo_url"], nameOf: (r) => r.name || r.title || "", path: () => `/shopping` },
  { entity: "BlogPost", label_ar: "المدونة", label_en: "Blog", fields: ["media_urls", "media_links", "cover_url"], nameOf: (r) => r.title || "", path: (r) => `/blog-detail?id=${r.id}` },
  { entity: "PurchaseRecord", label_ar: "سجلات الشراء", label_en: "Purchases", fields: ["receipt_url", "image_url"], nameOf: (r) => r.store_name || String(r.id), path: (r) => r.perfume_id ? `/perfume?id=${r.perfume_id}` : `/shopping` },
];

// روابط المواقع (website) — نصية تفتح بالضغط فقط و لا تجلب تلقائيا أبدا؛ تعرض
// في مجموعة منفصلة اختيارية كي لا تختلط بمصادر الجلب التلقائي (الصور/الوسائط).
const WEBSITE_TARGETS = [
  { entity: "PerfumeBrand", label_ar: "مواقع البراندات", label_en: "Brand websites", fields: ["website"], nameOf: (r) => r.name || "", path: (r) => `/brand?id=${r.id}` },
  { entity: "Perfumer", label_ar: "مواقع العطّارين", label_en: "Perfumer websites", fields: ["website"], nameOf: (r) => r.name || "", path: (r) => `/perfumer?id=${r.id}` },
  { entity: "ShopBrand", label_ar: "مواقع المتاجر", label_en: "Store websites", fields: ["website"], nameOf: (r) => r.name || "", path: () => `/shopping` },
];

function remoteValuesOf(rec, field) {
  const v = rec?.[field];
  if (!v) return [];
  if (typeof v === "string") return REMOTE.test(v.trim()) ? [v.trim()] : [];
  if (Array.isArray(v)) return v.filter((x) => typeof x === "string" && REMOTE.test(x.trim())).map((x) => x.trim());
  return [];
}

export default function MaestroWebLinks() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [state, setState] = useState("idle"); // idle | scanning | done
  const [progress, setProgress] = useState("");
  const [hits, setHits] = useState([]); // {entity, label, id, name, field, url, path}
  const [scanned, setScanned] = useState(0);
  const [includeWebsites, setIncludeWebsites] = useState(false);

  const scan = async () => {
    setState("scanning");
    setHits([]);
    const out = [];
    let total = 0;
    const list = includeWebsites ? [...TARGETS, ...WEBSITE_TARGETS] : TARGETS;
    for (const t of list) {
      if (!apphost?.entities?.[t.entity]) continue;
      setProgress(isAr ? `جاري فحص ${t.label_ar}…` : `Scanning ${t.label_en}…`);
      let rows = [];
      try { rows = await apphost.entities[t.entity].list("-created_date", 1000000); } catch { rows = []; }
      total += rows.length;
      for (const r of rows) {
        for (const f of t.fields) {
          for (const url of remoteValuesOf(r, f)) {
            out.push({ entity: t.entity, label: isAr ? t.label_ar : t.label_en, id: r.id, name: t.nameOf(r), field: f, url, path: t.path(r) });
          }
        }
      }
      // فسحة للواجهة بين الجداول (جدول العطور ثقيل)
      await new Promise((res) => setTimeout(res, 0));
    }
    setScanned(total);
    setHits(out);
    setState("done");
    setProgress("");
  };

  return (
    <div className="max-w-2xl mx-auto px-4 page-top pb-24 space-y-4">
      <button onClick={() => navigate("/maestro")} className="flex items-center gap-1.5 text-sm font-body text-muted-foreground hover:text-foreground transition-colors">
        <BackIcon className={`w-4 h-4`} /> Maestro
      </button>

      <div className="space-y-1">
        <h1 className="font-heading font-bold text-lg">{isAr ? "روابط الويب في السجلات" : "Web links in records"}</h1>
        <p className="text-xs text-muted-foreground font-body leading-relaxed">
          {isAr
            ? "هذه القائمة هي مصدر أي استهلاك شبكة سابق: حقول صور/وسائط محفوظة كروابط http داخل سجلاتك. بعد قطع 1.809 لم تعد تجلب — تظهر فارغة — و الحل الدائم استبدالها بصور محلية من المعرض."
            : "This list is the source of any past network usage: image/media fields stored as http links inside your records. Since the 1.809 cutoff they no longer fetch — they render blank — replace them with local gallery images."}
        </p>
      </div>

      <label className="flex items-center gap-2 text-xs font-body text-muted-foreground select-none cursor-pointer">
        <input type="checkbox" checked={includeWebsites} onChange={(e) => setIncludeWebsites(e.target.checked)} />
        {isAr ? "اشمل روابط المواقع (نصية — تفتح بالضغط فقط، لا تجلب تلقائيا)" : "Include website links (text-only, tap-to-open, never auto-fetched)"}
      </label>

      <button
        onClick={scan}
        disabled={state === "scanning"}
        className="px-4 py-2 text-sm font-body rounded-none border border-[var(--brand)] text-[#9a7b1f] hover:bg-[var(--brand)] hover:text-white transition-colors disabled:opacity-50"
      >
        {state === "scanning" ? (progress || (isAr ? "جاري الفحص…" : "Scanning…")) : (isAr ? "افحص الآن" : "Scan now")}
      </button>

      {state === "done" && (
        <div className="space-y-3">
          <p className="text-sm font-body">
            {isAr
              ? `فحص ${scanned.toLocaleString("en-US")} سجلا — روابط ويب: ${hits.length}`
              : `Scanned ${scanned.toLocaleString("en-US")} records — web links: ${hits.length}`}
          </p>
          {hits.length === 0 ? (
            <p className="text-sm text-muted-foreground font-body">{isAr ? "نظيف تماما — لا رابط ويب في أي سجل" : "Fully clean — no web link in any record"}</p>
          ) : (
            <div className="space-y-2">
              {hits.slice(0, 300).map((h, i) => (
                <button
                  key={i}
                  onClick={() => navigate(h.path)}
                  className="w-full text-start bg-card border border-border/60 rounded-none px-3 py-2 hover:border-[var(--brand)]/60 transition-colors"
                >
                  <p className="text-xs font-body font-semibold">{h.label} — {h.name || h.id}</p>
                  <p className="text-[10px] text-muted-foreground font-body">{h.field}</p>
                  <p className="text-[10px] font-body break-all" dir="ltr" style={{ color: "#9a7b1f" }}>{h.url}</p>
                </button>
              ))}
              {hits.length > 300 && (
                <p className="text-[11px] text-muted-foreground font-body">{isAr ? `و ${hits.length - 300} أخرى…` : `and ${hits.length - 300} more…`}</p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

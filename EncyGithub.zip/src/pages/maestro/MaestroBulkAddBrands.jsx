import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { Save, Trash2, CheckCircle2, Upload } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import BackIcon from "@/components/shared/BackIcon";

const emptyBrand = () => ({ name: "", name_ar: "", country: "", year_established: "", website: "", description: "", bio: "" });

export default function MaestroBulkAddBrands() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [rows, setRows] = useState(() => Array.from({ length: 20 }, emptyBrand));
  const [savedRows, setSavedRows] = useState({});
  const [saving, setSaving] = useState({});

  const setField = (idx, field, val) => {
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));
  };

  const handleSaveRow = async (idx) => {
    const row = rows[idx];
    if (!row.name) { toast.error(isAr ? "الاسم مطلوب" : "Name is required"); return; }
    setSaving((p) => ({ ...p, [idx]: true }));
    await apphost.entities.PerfumeBrand.create({
      ...row,
      year_established: row.year_established ? Number(row.year_established) : undefined,
      is_default: true,
      in_business: true,
    });
    setSaving((p) => ({ ...p, [idx]: false }));
    setSavedRows((p) => ({ ...p, [idx]: true }));
    qc.invalidateQueries({ queryKey: ["maestro-brands"] });
    toast.success(isAr ? `تم حفظ السطر ${idx + 1} بنجاح في قاعدة بيانات التطبيق` : `Row ${idx + 1} saved successfully to app database`);
  };

  const handleSaveAll = async () => {
    const valid = rows.filter((r, i) => r.name && !savedRows[i]);
    if (!valid.length) { toast.error(isAr ? "لا توجد صفوف جديدة للحفظ" : "No new rows to save"); return; }
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].name && !savedRows[i]) await handleSaveRow(i);
    }
    toast.success(isAr ? "تم حفظ جميع الشركات بنجاح" : "All brands saved successfully");
  };

  const handleJsonImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const items = Array.isArray(data) ? data : [data];
      
      let imported = 0;
      for (const item of items) {
        if (item.name) {
          await apphost.entities.PerfumeBrand.create({
            ...item,
            year_established: item.year_established ? Number(item.year_established) : undefined,
            is_default: true,
            in_business: item.in_business !== false,
          });
          imported++;
        }
      }
      qc.invalidateQueries({ queryKey: ["maestro-brands"] });
      toast.success(isAr ? `تم استيراد ${imported} شركة` : `Imported ${imported} brands`);
      e.target.value = "";
    } catch (err) {
      toast.error(isAr ? "خطأ في الملف" : "Invalid JSON file");
    }
  };

  const addRow = () => setRows((p) => [...p, emptyBrand()]);
  const removeRow = (idx) => setRows((p) => p.filter((_, i) => i !== idx));

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro/brands" className="p-2 hover:bg-secondary rounded-none">
          <BackIcon className={`w-5 h-5`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🏛️ {isAr ? "إضافة شركات دفعة واحدة" : "Bulk Add Brands"}</h1>
          <p className="text-xs text-muted-foreground">{isAr ? "أضف حتى 20 شركة مرة واحدة إلى قاعدة بيانات التطبيق" : "Add up to 20 brands at once to the app database"}</p>
        </div>
      </div>

      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-none p-3 mb-4">
        <p className="text-xs text-amber-800 dark:text-amber-300 font-body">
          {isAr ? "⚠️ كل شركة تُحفظ مباشرة في قاعدة بيانات التطبيق بمجرد الضغط على زر الحفظ" : "⚠️ Each brand is saved directly to the built-in app database when you click Save"}
        </p>
      </div>

      <div className="flex gap-2 mb-4">
        <Button className="flex-1 rounded-none" onClick={handleSaveAll}>
          <Save className="w-4 h-4 mr-2" />
          {isAr ? "حفظ الجميع" : "Save All"}
        </Button>
        <label className="flex-1">
          <Button type="button" variant="outline" className="w-full rounded-none" asChild>
            <div className="cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              {isAr ? "استيراد JSON" : "Import JSON"}
            </div>
          </Button>
          <input type="file" accept=".json" onChange={handleJsonImport} className="hidden" />
        </label>
      </div>

      <div className="space-y-4">
        {rows.map((row, idx) => (
          <div key={idx} className={`border rounded-none p-4 space-y-2 transition-colors ${savedRows[idx] ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-300 dark:border-emerald-700" : "bg-card border-border/50"}`}>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-body font-bold text-muted-foreground">#{idx + 1}</span>
                {savedRows[idx] && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                {savedRows[idx] && <span className="text-[10px] text-emerald-600 font-body font-semibold">{isAr ? "تم الحفظ في قاعدة البيانات" : "Saved to database"}</span>}
              </div>
              <button onClick={() => removeRow(idx)} className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Input placeholder={isAr ? "الاسم (إنجليزي)*" : "Name (EN)*"} value={row.name} onChange={(e) => setField(idx, "name", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
              <Input placeholder={isAr ? "الاسم (عربي)" : "Name (AR)"} value={row.name_ar} onChange={(e) => setField(idx, "name_ar", e.target.value)} className="h-9 rounded-none text-xs" dir="rtl" disabled={savedRows[idx]} />
              <Input placeholder={isAr ? "الدولة" : "Country"} value={row.country} onChange={(e) => setField(idx, "country", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
              <Input placeholder={isAr ? "سنة التأسيس" : "Year Founded"} type="number" value={row.year_established} onChange={(e) => setField(idx, "year_established", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
              <Input placeholder={isAr ? "الموقع" : "Website"} value={row.website} onChange={(e) => setField(idx, "website", e.target.value)} className="h-9 rounded-none text-xs col-span-2" disabled={savedRows[idx]} />
               <Textarea placeholder={isAr ? "حول البراند (وصف + تاريخ)" : "About Brand (EN + AR)"} value={row.description} onChange={(e) => setField(idx, "description", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px] col-span-2" disabled={savedRows[idx]} />
            </div>
            {!savedRows[idx] && (
              <Button size="sm" className="w-full h-8 rounded-none text-xs" onClick={() => handleSaveRow(idx)} disabled={saving[idx]}>
                <Save className="w-3 h-3 mr-1" />
                {saving[idx] ? (isAr ? "جاري الحفظ.." : "Saving..") : (isAr ? "💾 حفظ هذا السطر" : "💾 Save this row")}
              </Button>
            )}
          </div>
        ))}
      </div>

      <Button variant="outline" className="w-full mt-4 rounded-none" onClick={addRow}>
        {isAr ? "إضافة سطر جديد" : "Add Row"}
      </Button>
    </div>
  );
}
import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Download, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useLang } from "@/lib/LanguageContext";
import { downloadBlob } from "@/lib/exportHelper";

const APP_INFO = {
  en: {
    name: "Perfume & Finance Hub",
    tagline: "Personal fragrance and financial management ecosystem",
    description: "A comprehensive bilingual platform for managing perfume collections, financial records, shopping, and personal insights with military-grade AES-256 encryption for sensitive data.",
    
    features: [
      { icon: "🌹", name: "Perfume Catalog", desc: "Manage brands, perfumes, notes, perfumers, and collections" },
      { icon: "💰", name: "Financial Tracking", desc: "Budget, income, expenses, obligations, recurring payments, assets" },
      { icon: "🛍️", name: "Shopping Manager", desc: "Track purchases, stores, products, categories, and analytics" },
      { icon: "📖", name: "Blog & Notes", desc: "Personal entries, thoughts, poetry with media attachments" },
      { icon: "💧", name: "Wear Logs", desc: "Track fragrance usage, seasonal suggestions, mood tracking" },
      { icon: "🎯", name: "Goals & Tasks", desc: "Personal and financial goals with progress tracking" },
      { icon: "📖", name: "Encyclopedia", desc: "Stories, glossary, quotes & symbolism — unified" },
      { icon: "📊", name: "Advanced Analytics", desc: "Charts, reports, trends analysis, forecasting" },
    ],

    security: {
      title: "Security & Privacy",
      level: "🔒 Enterprise Grade",
      practices: [
        "AES-256-GCM encryption for sensitive financial and personal data",
        "Client-side encryption before database transmission",
        "Field-level encryption for: income amounts, expenses, obligations, assets, purchase costs",
        "No plain-text storage of sensitive numbers",
        "Secure local storage for user preferences and authentication tokens",
        "Local, device-only storage — no accounts or servers",
        "Role-based access control (Admin/User roles)",
      ]
    },

    encryption: {
      title: "Encryption Coverage",
      fields: [
        { entity: "BudgetIncome", fields: "amount" },
        { entity: "BudgetExpense", fields: "amount" },
        { entity: "BudgetObligation", fields: "total_amount, paid_amount, monthly_payment, interest_rate" },
        { entity: "RecurringExpense", fields: "amount" },
        { entity: "Asset", fields: "initial_cost, current_value, annual_return_rate, annual_cost" },
        { entity: "PurchaseRecord", fields: "ml, cost" },
        { entity: "ShopProduct", fields: "cost, ml" },
        { entity: "BlogPost", fields: "title, body, personal_notes" },
        { entity: "PerfumeDetail (UserPerfume)", fields: "personal_notes, private_notes" },
        { entity: "BrandDetail (UserBrand)", fields: "personal_notes" },
      ]
    },

    pages: [
      { 
        route: "/", 
        name: "Perfumes Hub", 
        desc: "Main dashboard for perfume management, collections, ratings, and personal favorites" 
      },
      { 
        route: "/explore", 
        name: "Explore", 
        desc: "Discover perfumes by odor families, pyramid layers, seasons, occasions, and create custom blends" 
      },
      { 
        route: "/add", 
        name: "Add & Perfume", 
        desc: "Add new perfumes to your collection with detailed metadata and ratings" 
      },
      { 
        route: "/lists", 
        name: "Lists & Sets", 
        desc: "Manage your custom named lists — create, rename, and delete. For viewing favorites, collections, and lists together, use the unified Lists & Sets page" 
      },
      { 
        route: "/brands", 
        name: "Brands", 
        desc: "Browse perfume houses with their history, signature notes, collections, and your reviews. Tap a brand to see its perfumes, purchase history, and the perfumers behind it." 
      },
      { 
        route: "/perfumers", 
        name: "Perfumers", 
        desc: "Explore the noses behind the scents — biographies, signature works, and the notes they favor. Filter by first letter and pin the ones you follow." 
      },
      { 
        route: "/notes", 
        name: "Notes Catalog", 
        desc: "The full notes library. Browse alphabetically or by Pyramid (Top/Heart/Base), see each note Catalog level (Main/Sub/Low), odor family, restrictions, and health flags. Open a note to find every perfume that uses it." 
      },
      { 
        route: "/encyclopedia", 
        name: "Encyclopedia", 
        desc: "A cultural library: Stories, Quotes, Marking (iconic-perfume symbolism), Vocabulary, Poems, Library, Perfumes Era, and Figures. Each section opens to its categories first, then entries. Pin favorites and search across everything." 
      },
      { 
        route: "/make-perfume", 
        name: "The Mixer", 
        desc: "Build an imaginary fragrance by choosing top, heart, and base notes. See the pyramid take shape and save your blend to revisit or compare later." 
      },
      { 
        route: "/budget", 
        name: "Budget", 
        desc: "Your full money dashboard. Add income and expenses, track recurring obligations, list assets, and see forecasts. Each entry can be tagged so perfume spending is visible separately. Sensitive figures are encrypted. Open Budget Entries for the detailed ledger." 
      },
      { 
        route: "/shopping", 
        name: "Shopping", 
        desc: "Record every purchase with store, price, and category. Manage your stores and product reviews, then read analytics on where and how much you spend. Links to perfumes so cost-per-ml flows into your collection." 
      },
      { 
        route: "/progress", 
        name: "Wear History", 
        desc: "Log perfume usage, view wear calendars, seasonal recommendations, mood tracking" 
      },
      { 
        route: "/blog", 
        name: "Blog", 
        desc: "Personal journal entries with media, linked to perfumes, brands, perfumers, notes" 
      },
      { 
        route: "/goals", 
        name: "Goals", 
        desc: "Set personal or financial goals (e.g. a savings target or a number of perfumes to try) and watch progress bars update as you log activity." 
      },
      { 
        route: "/layering", 
        name: "Layering", 
        desc: "Explore fragrance layering combinations and complementary scents" 
      },
      { 
        route: "/compare", 
        name: "Compare", 
        desc: "Side-by-side comparison of multiple perfumes" 
      },
      { 
        route: "/top-rated", 
        name: "Top Rated", 
        desc: "Discover best-rated perfumes and rankings" 
      },
      { 
        route: "/samples", 
        name: "Samples Tracker", 
        desc: "Track sample volumes and costs, calculate efficiency" 
      },
      { 
        route: "/wishlist", 
        name: "Wishlist", 
        desc: "Save perfumes you want to buy with priority levels and estimated costs" 
      },
      { 
        route: "/my-perfumes", 
        name: "My Collection", 
        desc: "View owned perfumes with detailed information and purchase history" 
      },
      {
        route: "/collection-view",
        name: "Lists & Sets (Unified)",
        desc: "One hub for everything you keep: Favorites (perfumes you love), Collections (what you own), My Lists (your custom named groupings), Wear (schedule + log), and Wishlist. A top search filters whatever tab you are in. Encyclopedia favorites appear under Favorites. Tip: Collections fill automatically from what you own, while My Lists are groupings you create yourself."
      },
      {
        route: "/note",
        name: "Note Page",
        desc: "Open any note to see its bilingual name, Catalog level (Main/Sub/Low), Pyramid position (Top/Heart/Base), odor family, and every perfume that uses it. Use Browse more to page through perfumes."
      },
      {
        route: "/care-guide",
        name: "Care & Storage",
        desc: "How to store, protect, and extend the life of your fragrances — light, heat, and humidity guidance."
      },
      {
        route: "/flacon-guide",
        name: "Flacon Guide",
        desc: "Understand bottle types, concentrations, and how to read a flacon label."
      },
      {
        route: "/accords-guide",
        name: "Accords Guide",
        desc: "Learn fragrance accords and how families blend, with examples."
      },
      {
        route: "/reading-guide",
        name: "Reading Guide",
        desc: "A guided path through the Encyclopedia — where to start and how the sections connect."
      },
      {
        route: "/net",
        name: "Perfume and Brand Net",
        desc: "A discovery hub that maps the whole library across five dimensions — occasions, types and categories, notes, countries, and encyclopedia sections. Each dimension opens on demand and loads lazily; tapping any value gathers every matching perfume, brand, or entry without scanning the full catalog."
      },
      {
        route: "/statistics",
        name: "Statistics",
        desc: "See totals and breakdowns across your collection, spending, and wear activity."
      },
    ],

    tech: {
      title: "Technology Stack",
      frontend: [
        "React 18.2 with TypeScript",
        "Tailwind CSS for responsive design",
        "shadcn/ui component library",
        "Lucide React icons",
        "TanStack React Query for data management",
        "Framer Motion for animations",
        "jsPDF & html2canvas for exports",
        "React Hook Form for forms",
        "React Router DOM for navigation",
      ],
      backend: [
        "Offline local storage (IndexedDB)",
        "Deno for serverless functions",
        "Entity-based data management",
        "Automated scheduled tasks",
        "Real-time subscriptions via WebSockets",
      ],
      security: [
        "Web Crypto API (SubtleCrypto) for AES-256-GCM",
        "Client-side encryption before transmission",
        "Environment-based secrets management",
        "OAuth for third-party integrations",
      ]
    },

    limitations: {
      title: "Limits & Guidelines",
      rules: [
        "Max 50 items per query by default (configurable per page)",
        "Image files max 5MB (validated by upload component)",
        "Entity bulk operations limited to 100 items",
        "Search queries case-insensitive with regex support",
        "Date range filtering uses ISO 8601 format",
        "Currency supported: USD, SAR, custom",
      ]
    },
  },

  ar: {
    name: "مركز العطور و المالية",
    tagline: "نظام شامل لإدارة مجموعات العطور و السجلات المالية الشخصية",
    description: "منصة ثنائية اللغة شاملة لإدارة مجموعات العطور و السجلات المالية و المشتريات و الرؤى الشخصية مع تشفير AES-256 من المستوى العسكري للبيانات الحساسة.",

    features: [
      { icon: "🌹", name: "كتالوج العطور", desc: "إدارة الماركات و العطور و النوتات و العطارين و المجموعات" },
      { icon: "💰", name: "تتبع المالية", desc: "الميزانية والدخل و المصاريف و الالتزامات و الأصول" },
      { icon: "🛍️", name: "مدير المشتريات", desc: "تتبع الفواتير و المتاجر و المنتجات و التحليلات" },
      { icon: "📖", name: "المدونة و الملاحظات", desc: "إدخالات شخصية مع وسائط متعددة" },
      { icon: "💧", name: "سجل الاستخدام", desc: "تتبع استخدام العطور و المقترحات الموسمية" },
      { icon: "🎯", name: "الأهداف و المهام", desc: "تتبع الأهداف الشخصية و المالية" },
      { icon: "📖", name: "الموسوعة", desc: "القصص و المعجم و الاقتباسات و الرمزيات موحّدة" },
      { icon: "📊", name: "التحليلات", desc: "الرسوم البيانية و التقارير و التنبؤات" },
    ],

    security: {
      title: "الأمان و الخصوصية",
      level: "🔒 مستوى المؤسسات",
      practices: [
        "تشفير AES-256-GCM للبيانات المالية و الشخصية الحساسة",
        "تشفير من جانب العميل قبل نقل قاعدة البيانات",
        "تشفير على مستوى الحقول للمبالغ و النفقات و الالتزامات و الأصول",
        "عدم تخزين الأرقام بصيغة نصية عادية",
        "تخزين محلي آمن لتفضيلات المستخدم و الرموز",
        "بيانات محليّة على الجهاز فقط — بلا حسابات أو خوادم",
        "التحكم في الوصول على أساس الأدوار",
      ]
    },

    encryption: {
      title: "تغطية التشفير",
      fields: [
        { entity: "BudgetIncome", fields: "amount" },
        { entity: "BudgetExpense", fields: "amount" },
        { entity: "BudgetObligation", fields: "total_amount, paid_amount, monthly_payment, interest_rate" },
        { entity: "RecurringExpense", fields: "amount" },
        { entity: "Asset", fields: "initial_cost, current_value, annual_return_rate, annual_cost" },
        { entity: "PurchaseRecord", fields: "ml, cost" },
        { entity: "ShopProduct", fields: "cost, ml" },
        { entity: "BlogPost", fields: "title, body, personal_notes" },
        { entity: "PerfumeDetail (UserPerfume)", fields: "personal_notes, private_notes" },
        { entity: "BrandDetail (UserBrand)", fields: "personal_notes" },
      ]
    },

    pages: [
      { route: "/", name: "مركز العطور", desc: "لوحة التحكم الرئيسية لإدارة العطور و المجموعات و التقييمات" },
      { route: "/explore", name: "استكشاف", desc: "اكتشف العطور حسب العائلات و الهرم و المواسم" },
      { route: "/add", name: "إضافة عطر", desc: "أضف عطور جديدة إلى مجموعتك" },
      { route: "/lists", name: "القوائم و المجموعات", desc: "إنشء قوائم مخصصة (المفضلات، عدم الإعجاب، الموصيات)" },
      { route: "/brands", name: "الماركات", desc: "استعرض بيوت العطور بتاريخها و نوتاتها المميّزة و مجموعاتها و مراجعاتك. افتح ماركة لترى عطورها و سجل الشراء و صنّاعها." },
      { route: "/perfumers", name: "صنّاع العطور", desc: "استكشف الأنوف خلف العطور — سير و أعمال مميّزة و النوتات المفضّلة لديهم. صفّ بالحرف الأول و ثبّت من تتابع." },
      { route: "/notes", name: "النوتات", desc: "مكتبة النوتات الكاملة. تصفّح أبجدياً أو بالهرم (افتتاحية/قلب/أساس)، اعرض كاتلوج كل نوتة (رئيسية/فرعية/ثانوية) و عائلتها و قيودها و تنبيهات الصحة. افتح نوتة لتجد كل عطر يستخدمها." },
      { route: "/encyclopedia", name: "الموسوعة", desc: "مكتبة ثقافية: قصص و اقتباسات و علامة (رمزية العطور الأيقونية) و مصطلحات و قصائد و مكتبة و أطوار العطور و شخصيات. كل قسم يفتح على تصنيفاته أولاً ثمّ المدخلات، مع تثبيت و بحث شامل." },
      { route: "/make-perfume", name: "محضر العطور", desc: "ابنِ عطراً متخيّلاً باختيار نوتات الافتتاحية و القلب و الأساس، شاهد الهرم يتشكّل و احفظ تركيبتك لتعود إليها أو تقارنها." },
      { route: "/budget", name: "الميزانية", desc: "لوحة أموالك الكاملة. أضف الدخل و المصروفات و تتبّع الالتزامات المتكرّرة و اعرض الأصول و التوقّعات. كل مدخل يُوسم فيظهر إنفاق العطور منفصلاً. الأرقام الحسّاسة مشفّرة. افتح «مدخلات الميزانية» للسجل التفصيلي." },
      { route: "/shopping", name: "التسوق", desc: "سجّل كل عملية شراء بالمتجر و السعر و الفئة. أدر متاجرك و مراجعات المنتجات ثمّ اقرأ تحليلات أين و كم تنفق. مرتبط بالعطور فتتدفّق تكلفة المل لمجموعتك." },
      { route: "/progress", name: "سجل الاستخدام", desc: "سجّل ما ترتديه يومياً، اعرض تقويم الارتداء، و احصل على مقترحات موسمية و حسب المزاج من سجلّك." },
      { route: "/blog", name: "المدونة", desc: "مدخلات يوميات شخصية مع صور، تُربط بالعطور و الماركات و صنّاع العطور و النوتات، و يمكن تصديرها." },
      { route: "/goals", name: "الأهداف", desc: "حدّد أهدافاً شخصية أو مالية (هدف ادّخار أو عدد عطور لتجربتها) و تابع أشرطة التقدّم تتحدّث مع نشاطك." },
      { route: "/layering", name: "الطبقات", desc: "جرّب دمج عطرين أو أكثر طبقةً فوق طبقة و احفظ التركيبات الناجحة لتعيدها." },
      { route: "/compare", name: "مقارنة", desc: "ضع عدّة عطور جنباً إلى جنب لمقارنة النوتات و الأسعار و تقييماتك، و صدّر بطاقة مقارنة." },
      { route: "/top-rated", name: "الأفضل تقييماً", desc: "اكتشف أفضل العطور" },
      { route: "/samples", name: "العينات", desc: "تتبع عينات العطور" },
      { route: "/wishlist", name: "قائمة الرغبات", desc: "احفظ العطور التي تريد شراءها" },
      { route: "/my-perfumes", name: "مجموعتي", desc: "عرض العطور المملوكة" },
      { route: "/collection-view", name: "قوائم و مجموعات (موحّدة)", desc: "مركز واحد لكل ما تحتفظ به: المفضّلة (ما تحبّه) و المجموعات (ما تملكه) و قوائمي (تجميعاتك المسمّاة) و الارتداء (الجدولة و السجل) و الرغبات. بحث علويّ يصفّي أيّ تبويب أنت فيه، و مفضّلة الموسوعة تظهر أسفل المفضّلة. ملحوظة: المجموعات تمتلئ تلقائياً ممّا تملك، و قوائمي تجميعات تصنعها بنفسك." },
      { route: "/note", name: "صفحة النوتة", desc: "افتح أيّ نوتة لترى اسمها ثنائي اللغة و الكاتلوج (رئيسية/فرعية/ثانوية) و موضعها في الهرم (افتتاحية/قلب/أساس) و عائلتها العطرية و كلّ عطر يستخدمها. استخدم «تصفح أكثر» للتنقل بين العطور." },
      { route: "/care-guide", name: "العناية و التخزين", desc: "كيف تخزّن عطورك و تحميها و تطيل عمرها — إرشادات الضوء و الحرارة و الرطوبة." },
      { route: "/flacon-guide", name: "دليل القنينة", desc: "افهم أنواع القنينات و التركيزات و كيف تقرأ ملصق القنينة." },
      { route: "/accords-guide", name: "دليل التناغم", desc: "تعلّم التناغمات العطرية و كيف تمتزج العائلات بأمثلة." },
      { route: "/reading-guide", name: "موجِّهة القراءة", desc: "مسار مرشد عبر الموسوعة — من أين تبدأ و كيف تترابط الأقسام." },
      { route: "/net", name: "شبكة عطور و ماركات", desc: "مركز استكشاف يربط المكتبة عبر خمسة أبعاد: المناسبات و الأنواع و الفئات و النوتات و الدول و أقسام الموسوعة. كل بُعد يُفتح عند الطلب و يُحمّل كسولاً، و نقر أي قيمة يجمع كل ما يطابقها من عطور و ماركات و مدخلات بلا مسح الكتالوج كاملاً." },
      { route: "/statistics", name: "الإحصاءات", desc: "إجماليّات و تفصيلات عبر مجموعتك و إنفاقك و نشاط ارتدائك." },
    ],

    tech: {
      title: "المنصات و المكاتب المستخدمة",
      frontend: [
        "React 18.2 مع TypeScript",
        "Tailwind CSS للتصميم المتجاوب",
        "مكتبة shadcn/ui للمكونات",
        "Lucide React للرموز",
        "TanStack React Query لإدارة البيانات",
        "Framer Motion للرسومات المتحركة",
        "jsPDF و html2canvas للتصدير",
        "React Hook Form للنماذج",
        "React Router DOM للملاحة",
      ],
      backend: [
        "Offline local storage (IndexedDB)",
        "Deno للدوال بدون خادم",
        "إدارة البيانات القائمة على الكيانات",
        "المهام المجدولة التلقائية",
        "الاشتراكات في الوقت الفعلي",
      ],
      security: [
        "Web Crypto API (SubtleCrypto) لـ AES-256-GCM",
        "التشفير من جانب العميل",
        "إدارة الأسرار",
        "OAuth للتكاملات",
      ]
    },

    limitations: {
      title: "الحدود و القواعد",
      rules: [
        "50 عنصر كحد أقصى لكل استعلام",
        "ملفات الصور بحد أقصى 5 ميجابايت",
        "عمليات الكيانات محدودة بـ 100 عنصر",
        "البحث غير حساس لحالة الأحرف",
        "تنسيق التواريخ ISO 8601",
        "العملات المدعومة: USD, SAR, مخصصة",
      ]
    },
  }
};

export default function MaestroAppFeatures() {
  const { lang, isAr } = useLang();
  const t = APP_INFO[lang === "ar" ? "ar" : "en"];
  const [showDetails, setShowDetails] = useState(false);

  // Fetch entity statistics - separate queries
  const perfumesQ = useQuery({ queryKey: ["perfumes-count"], queryFn: () => apphost.entities.Perfume.count(), select: (d) => d || 0 });
  const brandsQ = useQuery({ queryKey: ["brands-count"], queryFn: () => apphost.entities.PerfumeBrand.count(), select: (d) => d || 0 });
  const notesQ = useQuery({ queryKey: ["notes-count"], queryFn: () => apphost.entities.PerfumeNote.count(), select: (d) => d || 0 });
  const perfumersQ = useQuery({ queryKey: ["perfumers-count"], queryFn: () => apphost.entities.Perfumer.list("id"), select: (d) => d?.length || 0 });
  const userPerfumesQ = useQuery({ queryKey: ["userPerfumes-count"], queryFn: () => apphost.entities.UserPerfume.list("id"), select: (d) => d?.length || 0 });
  const incomesQ = useQuery({ queryKey: ["incomes-count"], queryFn: () => apphost.entities.BudgetIncome.list("id"), select: (d) => d?.length || 0 });
  const expensesQ = useQuery({ queryKey: ["expenses-count"], queryFn: () => apphost.entities.BudgetExpense.list("id"), select: (d) => d?.length || 0 });
  const obligationsQ = useQuery({ queryKey: ["obligations-count"], queryFn: () => apphost.entities.BudgetObligation.list("id"), select: (d) => d?.length || 0 });
  const assetsQ = useQuery({ queryKey: ["assets-count"], queryFn: () => apphost.entities.Asset.list("id"), select: (d) => d?.length || 0 });
  const purchasesQ = useQuery({ queryKey: ["purchases-count"], queryFn: () => apphost.entities.PurchaseRecord.list("id"), select: (d) => d?.length || 0 });
  const shopProductsQ = useQuery({ queryKey: ["shopProducts-count"], queryFn: () => apphost.entities.ShopProduct.list("id"), select: (d) => d?.length || 0 });
  const blogsQ = useQuery({ queryKey: ["blogs-count"], queryFn: () => apphost.entities.BlogPost.list("id"), select: (d) => d?.length || 0 });

  const statsData = useMemo(() => ({
    perfumes: perfumesQ.data || 0,
    brands: brandsQ.data || 0,
    notes: notesQ.data || 0,
    perfumers: perfumersQ.data || 0,
    userPerfumes: userPerfumesQ.data || 0,
    incomes: incomesQ.data || 0,
    expenses: expensesQ.data || 0,
    obligations: obligationsQ.data || 0,
    assets: assetsQ.data || 0,
    purchases: purchasesQ.data || 0,
    shopProducts: shopProductsQ.data || 0,
    blogs: blogsQ.data || 0,
  }), [perfumesQ.data, brandsQ.data, notesQ.data, perfumersQ.data, userPerfumesQ.data, incomesQ.data, expensesQ.data, obligationsQ.data, assetsQ.data, purchasesQ.data, shopProductsQ.data, blogsQ.data]);

  const handleExport = async (format) => {
    const content = generateExportContent(format);
    
    if (format === "pdf") {
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text(t.name, 10, 10);
      doc.setFontSize(10);
      doc.text(content.split("\n"), 10, 20);
      const pdfBlob = doc.output('blob');
      await downloadBlob(pdfBlob, `${t.name}.pdf`);
    } else if (format === "text") {
      const blob = new Blob([content], { type: "text/plain" });
      await downloadBlob(blob, `${t.name}.txt`);
    } else if (format === "html") {
      const html = generateHTMLContent();
      const blob = new Blob([html], { type: "text/html" });
      await downloadBlob(blob, `${t.name}.html`);
    }
    toast.success((isAr ? "تم التصدير" : "Exported"));
  };

  const generateExportContent = (format) => {
    let content = `${t.name}\n${t.tagline}\n\n${t.description}\n\n`;
    
    content += `📊 STATISTICS:\n`;
    Object.entries(statsData).forEach(([key, count]) => {
      content += `${key}: ${count}\n`;
    });

    content += `\n🔐 SECURITY:\n${t.security.level}\n`;
    t.security.practices.forEach(p => { content += `✓ ${p}\n`; });

    content += `\n📄 PAGES (${t.pages.length}):\n`;
    t.pages.forEach(p => { content += `${p.route} - ${p.name}: ${p.desc}\n`; });

    return content;
  };

  const generateHTMLContent = () => {
    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${t.name}</title>
  <style>
    body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
    h1 { color: #333; border-bottom: 3px solid #10b981; padding-bottom: 10px; }
    h2 { color: #555; margin-top: 30px; }
    .stat { display: inline-block; margin: 10px; padding: 15px; background: #f0f0f0; border-radius: 8px; }
    .feature { margin: 10px 0; padding: 10px; background: #f9f9f9; border-left: 4px solid #10b981; }
    .security { background: #fffacd; padding: 15px; border-radius: 8px; margin: 10px 0; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
    th { background: #10b981; color: white; }
  </style>
</head>
<body>
  <h1>${t.name}</h1>
  <p><strong>${t.tagline}</strong></p>
  <p>${t.description}</p>
  
  <h2>📊 قاعدة البيانات | Database Statistics</h2>
  <div>
    ${Object.entries(statsData).map(([k, v]) => `<div class="stat">${k}: ${v}</div>`).join("")}
  </div>

  <h2>🔐 الأمان | Security</h2>
  <div class="security">
    <strong>${t.security.level}</strong>
    <ul>
      ${t.security.practices.map(p => `<li>${p}</li>`).join("")}
    </ul>
  </div>

  <h2>📄 الصفحات | Pages (${t.pages.length})</h2>
  <table>
    <tr><th>{isAr ? "المسار" : "Route"}</th><th>{isAr ? "الاسم" : "Name"}</th><th>{isAr ? "الوصف" : "Description"}</th></tr>
    ${t.pages.map(p => `<tr><td>${p.route}</td><td>${p.name}</td><td>${p.desc}</td></tr>`).join("")}
  </table>

  <h2>🛠️ المنصات | Technology</h2>
  <h3>{isAr ? "الواجهة" : "Frontend"}</h3>
  <ul>${t.tech.frontend.map(x => `<li>${x}</li>`).join("")}</ul>
  <h3>{isAr ? "الخادم" : "Backend"}</h3>
  <ul>${t.tech.backend.map(x => `<li>${x}</li>`).join("")}</ul>
</body>
</html>
    `;
  };

  return (
    <div className={`px-4 pt-12 pb-20 space-y-6 max-w-4xl mx-auto ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="space-y-2">
        <h1 className="font-heading text-3xl font-bold">{t.name}</h1>
        <p className="text-sm text-muted-foreground">{t.tagline}</p>
        <p className="text-xs leading-relaxed text-foreground/70">{t.description}</p>
      </div>

      {/* Export Buttons */}
      <div className="flex gap-2 flex-wrap">
        <Button size="sm" onClick={() => handleExport("text")} className="gap-2" variant="outline">
          <Download className="w-4 h-4" /> TXT
        </Button>
        <Button size="sm" onClick={() => handleExport("html")} className="gap-2" variant="outline">
          <Download className="w-4 h-4" /> HTML
        </Button>
        <Button size="sm" onClick={() => handleExport("pdf")} className="gap-2" variant="outline">
          <Download className="w-4 h-4" /> PDF
        </Button>
      </div>

      {/* Database Statistics */}
      <div className="bg-blue-50 dark:bg-blue-900/20 rounded-none p-4 space-y-3">
        <h2 className="font-heading text-lg font-semibold">📊 {isAr ? "إحصائيات قاعدة البيانات" : "Database Statistics"}</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {Object.entries(statsData).map(([key, count]) => (
            <div key={key} className="bg-card rounded-none p-3 border border-border/50">
              <p className="text-xs text-muted-foreground capitalize">{key}</p>
              <p className="text-lg font-bold text-primary">{count}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="space-y-3">
        <h2 className="font-heading text-lg font-semibold">✨ {isAr ? "المميزات الرئيسية" : "Key Features"}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {t.features.map((f, i) => (
            <div key={i} className="bg-card rounded-none p-3 border border-border/50">
              <div className="flex gap-2">
                <span className="text-2xl">{f.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{f.name}</p>
                  <p className="text-xs text-muted-foreground">{f.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security */}
      <div className="bg-green-50 dark:bg-green-900/20 rounded-none p-4 space-y-3 border border-green-200 dark:border-green-800">
        <h2 className="font-heading text-lg font-semibold">🔐 {t.security.title}</h2>
        <p className="text-sm font-semibold text-green-700 dark:text-green-400">{t.security.level}</p>
        <ul className="space-y-2">
          {t.security.practices.map((p, i) => (
            <li key={i} className="text-xs flex gap-2">
              <span className="text-green-600 flex-shrink-0">✓</span>
              <span>{p}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Encryption Coverage */}
      <div className="bg-purple-50 dark:bg-purple-900/20 rounded-none p-4 space-y-3 border border-purple-200 dark:border-purple-800">
        <div className="flex items-center justify-between">
          <h2 className="font-heading text-lg font-semibold">🔒 {t.encryption.title}</h2>
          <button onClick={() => setShowDetails(!showDetails)} className="text-xs text-primary">
            {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        {showDetails && (
          <div className="space-y-2">
            {t.encryption.fields.map((e, i) => (
              <div key={i} className="text-xs bg-card rounded-none p-2 border border-border/50">
                <p className="font-semibold text-purple-700 dark:text-purple-300">{e.entity}</p>
                <p className="text-muted-foreground">{e.fields}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Pages */}
      <div className="space-y-3">
        <h2 className="font-heading text-lg font-semibold">📄 {isAr ? "الصفحات" : "Pages"} ({t.pages.length})</h2>
        <div className="space-y-2">
          {t.pages.map((p, i) => (
            <div key={i} className="bg-card rounded-none p-3 border border-border/50">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.desc}</p>
                </div>
                <code className="text-xs bg-secondary px-2 py-1 rounded-none flex-shrink-0">{p.route}</code>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Technology */}
      <div className="space-y-4">
        <h2 className="font-heading text-lg font-semibold">🛠️ {t.tech.title}</h2>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-card rounded-none p-4 border border-border/50 space-y-2">
            <h3 className="font-semibold text-sm">{isAr ? "الواجهة" : "Frontend"}</h3>
            <ul className="text-xs space-y-1 text-muted-foreground">
              {t.tech.frontend.map((f, i) => <li key={i}>• {f}</li>)}
            </ul>
          </div>
          <div className="bg-card rounded-none p-4 border border-border/50 space-y-2">
            <h3 className="font-semibold text-sm">{isAr ? "الخادم" : "Backend"}</h3>
            <ul className="text-xs space-y-1 text-muted-foreground">
              {t.tech.backend.map((b, i) => <li key={i}>• {b}</li>)}
            </ul>
          </div>
          <div className="bg-card rounded-none p-4 border border-border/50 space-y-2">
            <h3 className="font-semibold text-sm">{isAr ? "الأمان" : "Security"}</h3>
            <ul className="text-xs space-y-1 text-muted-foreground">
              {t.tech.security.map((s, i) => <li key={i}>• {s}</li>)}
            </ul>
          </div>
        </div>
      </div>

      {/* Limitations */}
      <div className="bg-orange-50 dark:bg-orange-900/20 rounded-none p-4 space-y-3 border border-orange-200 dark:border-orange-800">
        <h2 className="font-heading text-lg font-semibold">📋 {t.limitations.title}</h2>
        <ul className="space-y-1">
          {t.limitations.rules.map((r, i) => (
            <li key={i} className="text-xs flex gap-2">
              <span className="flex-shrink-0">•</span>
              <span>{r}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { Save, Trash2, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import BackIcon from "@/components/shared/BackIcon";

const emptyItem = () => ({ name: "", website: "", logo_url: "", description: "" });

export default function MaestroBulkAddStores() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [rows, setRows] = useState(() => Array.from({ length: 20 }, emptyItem));
  const [savedRows, setSavedRows] = useState({});
  const [saving, setSaving] = useState({});

  const setField = (idx, field, val) => {
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));
  };

  const handleSaveRow = async (idx) => {
    const row = rows[idx];
    if (!row.name) { toast.error(isAr ? "الاسم مطلوب" : "Name is required"); return; }
    setSaving((p) => ({ ...p, [idx]: true }));
    await apphost.entities.ShopBrand.create({ ...row, type: "perfume_store", person: "family" });
    setSaving((p) => ({ ...p, [idx]: false }));
    setSavedRows((p) => ({ ...p, [idx]: true }));
    qc.invalidateQueries({ queryKey: ["shop-brands"] });
    toast.success(isAr ? `تم حفظ السطر ${idx + 1} بنجاح في قاعدة بيانات التطبيق` : `Row ${idx + 1} saved successfully to app database`);
  };

  const handleSaveAll = async () => {
    const valid = rows.filter((r, i) => r.name && !savedRows[i]);
    if (!valid.length) { toast.error(isAr ? "لا توجد صفوف جديدة للحفظ" : "No new rows to save"); return; }
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].name && !savedRows[i]) await handleSaveRow(i);
    }
    toast.success(isAr ? "تم الحفظ بنجاح" : "All saved successfully");
  };

  const addRow = () => setRows((p) => [...p, emptyItem()]);
  const removeRow = (idx) => setRows((p) => p.filter((_, i) => i !== idx));

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro/perfume-stores" className="p-2 hover:bg-secondary rounded-none">
          <BackIcon className={`w-5 h-5`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🏪 {isAr ? "إضافة متاجر دفعة واحدة" : "Bulk Add Stores"}</h1>
          <p className="text-xs text-muted-foreground">{isAr ? "أضف حتى 20 متجر مرة واحدة" : "Add up to 20 stores at once"}</p>
        </div>
      </div>

      <Button className="w-full mb-4 rounded-none" onClick={handleSaveAll}>
        <Save className="w-4 h-4 mr-2" />
        {isAr ? "حفظ جميع الصفوف الجديدة" : "Save All New Rows"}
      </Button>

      <div className="space-y-4">
        {rows.map((row, idx) => (
          <div key={idx} className={`border rounded-none p-4 space-y-2 transition-colors ${savedRows[idx] ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-300 dark:border-emerald-700" : "bg-card border-border/50"}`}>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-body font-bold text-muted-foreground">#{idx + 1}</span>
                {savedRows[idx] && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                {savedRows[idx] && <span className="text-[10px] text-emerald-600 font-body font-semibold">{isAr ? "تم الحفظ في قاعدة البيانات" : "Saved to database"}</span>}
              </div>
              <button onClick={() => removeRow(idx)} className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
              </button>
            </div>
            <Input placeholder={isAr ? "اسم المتجر*" : "Store Name*"} value={row.name} onChange={(e) => setField(idx, "name", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
            <Input placeholder={isAr ? "الموقع" : "Website"} value={row.website} onChange={(e) => setField(idx, "website", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
            <Input placeholder={isAr ? "رابط الشعار" : "Logo URL"} value={row.logo_url} onChange={(e) => setField(idx, "logo_url", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
            <Textarea placeholder={isAr ? "الوصف" : "Description"} value={row.description} onChange={(e) => setField(idx, "description", e.target.value)} className="rounded-none text-xs resize-none min-h-[48px]" disabled={savedRows[idx]} />
            {!savedRows[idx] && (
              <Button size="sm" className="w-full h-8 rounded-none text-xs" onClick={() => handleSaveRow(idx)} disabled={saving[idx]}>
                <Save className="w-3 h-3 mr-1" />
                {saving[idx] ? (isAr ? "جاري الحفظ.." : "Saving..") : (isAr ? "💾 حفظ هذا السطر" : "💾 Save this row")}
              </Button>
            )}
          </div>
        ))}
      </div>

      <Button variant="outline" className="w-full mt-4 rounded-none" onClick={addRow}>
        {isAr ? "إضافة سطر جديد" : "Add Row"}
      </Button>
    </div>
  );
}
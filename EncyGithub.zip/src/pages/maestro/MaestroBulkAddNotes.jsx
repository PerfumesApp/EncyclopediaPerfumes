import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { Save, Trash2, CheckCircle2, Upload } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import ImageUploadButton from "@/components/ui/ImageUploadButton";
import BackIcon from "@/components/shared/BackIcon";

const PYRAMIDS = ["top", "heart", "base", "conductor", "all", "undefined"];
const NOTE_CATEGORIES = ["main_note", "sub_notes", "low_notes"];

const DEFAULT_FAMILIES = [
  "Fresh منعش", "Floral زهري", "Oriental شرقي", "Woody خشبي",
  "Gourmand حلوي", "Citrus حمضي", "Aromatic عطري", "Fougère فوجير",
  "Chypre شيبر", "Aquatic مائي", "Green أخضر", "Spicy بهاري",
  "Musky مسكي", "Powdery بودري", "Leather جلدي", "Smoky دخاني",
];

const DEFAULT_CATEGORIES = [
  "Floral زهري", "Citrus حمضي", "Woody خشبي", "Spicy بهاري",
  "Resinous راتنجي", "Fruity فاكهي", "Herbal عشبي", "Animalic حيواني",
  "Balsamic بلسمي", "Marine بحري", "Earthy ترابي", "Sweet حلو",
];

const loadList = (key, defaults) => {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaults;
  } catch { return defaults; }
};

// Multi-select chip group
const MultiChipGroup = ({ options, value, onChange, disabled }) => {
  const selected = value ? value.split(",").map((v) => v.trim()).filter(Boolean) : [];
  const toggle = (o) => {
    const next = selected.includes(o) ? selected.filter((s) => s !== o) : [...selected, o];
    onChange(next.join(","));
  };
  return (
    <div className="flex flex-wrap gap-1">
      {options.map((o) => (
        <button
          key={o}
          type="button"
          disabled={disabled}
          onClick={() => toggle(o)}
          className={` rounded-none text-[10px] font-body transition-colors ${
 selected.includes(o)
 ? " text-primary-foreground "
 : " text-muted-foreground "
 }`}
        >
          {o}
        </button>
      ))}
    </div>
  );
};



const emptyNote = () => ({
  name: "",
  category: "",
  odor_family: "",
  pyramid: "",
  note_category: "",
  origin: "",
  description: "",
  image_url: "",
});

export default function MaestroBulkAddNotes() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [rows, setRows] = useState(() => Array.from({ length: 20 }, emptyNote));
  const [savedRows, setSavedRows] = useState({});
  const [saving, setSaving] = useState({});

  const families = loadList("maestro_odor_families", DEFAULT_FAMILIES);
  const categories = loadList("maestro_note_categories", DEFAULT_CATEGORIES);

  const setField = (idx, field, val) => {
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));
  };

  const handleSaveRow = async (idx) => {
    const row = rows[idx];
    if (!row.name) { toast.error(isAr ? "الاسم مطلوب" : "Name is required"); return; }
    setSaving((p) => ({ ...p, [idx]: true }));
    await apphost.entities.PerfumeNote.create({ ...row, is_default: true });
    setSaving((p) => ({ ...p, [idx]: false }));
    setSavedRows((p) => ({ ...p, [idx]: true }));
    qc.invalidateQueries({ queryKey: ["maestro-notes"] });
    toast.success(isAr ? `تم حفظ السطر ${idx + 1}` : `Row ${idx + 1} saved`);
  };

  const handleSaveAll = async () => {
    const valid = rows.filter((r, i) => r.name && !savedRows[i]);
    if (!valid.length) { toast.error(isAr ? "لا توجد صفوف جديدة للحفظ" : "No new rows to save"); return; }
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].name && !savedRows[i]) await handleSaveRow(i);
    }
    toast.success(isAr ? "تم حفظ جميع النوتات" : "All notes saved");
  };

  const handleJsonImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const items = Array.isArray(data) ? data : [data];
      
      let imported = 0;
      for (const item of items) {
        if (item.name) {
          await apphost.entities.PerfumeNote.create({
            ...item,
            is_default: true,
          });
          imported++;
        }
      }
      qc.invalidateQueries({ queryKey: ["maestro-notes"] });
      toast.success(isAr ? `تم استيراد ${imported} نوتة` : `Imported ${imported} notes`);
      e.target.value = "";
    } catch (err) {
      toast.error(isAr ? "خطأ في الملف" : "Invalid JSON file");
    }
  };

  const addRow = () => setRows((p) => [...p, emptyNote()]);
  const removeRow = (idx) => setRows((p) => p.filter((_, i) => i !== idx));

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro/notes" className="p-2 hover:bg-secondary rounded-none">
          <BackIcon className={`w-5 h-5`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🌿 {isAr ? "إضافة نوتات دفعة واحدة" : "Bulk Add Notes"}</h1>
          <p className="text-xs text-muted-foreground">{isAr ? "أضف حتى 20 نوتة مرة واحدة" : "Add up to 20 notes at once"}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <Button className="flex-1 rounded-none" onClick={handleSaveAll}>
          <Save className="w-4 h-4 mr-2" />
          {isAr ? "حفظ الجميع" : "Save All"}
        </Button>
        <label className="flex-1">
          <Button type="button" variant="outline" className="w-full rounded-none" asChild>
            <div className="cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              {isAr ? "استيراد JSON" : "Import JSON"}
            </div>
          </Button>
          <input type="file" accept=".json" onChange={handleJsonImport} className="hidden" />
        </label>
      </div>

      <div className="space-y-4">
        {rows.map((row, idx) => (
          <div key={idx} className={`border rounded-none p-4 space-y-2.5 transition-colors ${savedRows[idx] ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-300 dark:border-emerald-700" : "bg-card border-border/50"}`}>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-body font-bold text-muted-foreground">#{idx + 1}</span>
                {savedRows[idx] && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                {savedRows[idx] && <span className="text-[10px] text-emerald-600 font-body font-semibold">{isAr ? "تم الحفظ" : "Saved"}</span>}
              </div>
              <button onClick={() => removeRow(idx)} className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
              </button>
            </div>

            {/* Name */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الاسم (EN AR)*" : "Name (EN AR)*"}</p>
              <Input
                placeholder={isAr ? "مثال: Rose ورد" : "e.g. Rose ورد"}
                value={row.name}
                onChange={(e) => setField(idx, "name", e.target.value)}
                className="h-9 rounded-none text-xs"
                disabled={savedRows[idx]}
              />
            </div>

            {/* Category — multi */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "التصنيف (متعدد)" : "Category (multi)"}</p>
              <MultiChipGroup options={categories} value={row.category} onChange={(v) => setField(idx, "category", v)} disabled={savedRows[idx]} />
            </div>

            {/* Odor Family — multi */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "العائلة العطرية (متعددة)" : "Odor Family (multi)"}</p>
              <MultiChipGroup options={families} value={row.odor_family} onChange={(v) => setField(idx, "odor_family", v)} disabled={savedRows[idx]} />
            </div>

            {/* Image */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الصورة" : "Image"}</p>
              <div className="flex gap-1.5 items-center">
                <Input
                  placeholder={isAr ? "رابط الصورة" : "Image URL"}
                  value={row.image_url}
                  onChange={(e) => setField(idx, "image_url", e.target.value)}
                  className="h-9 rounded-none text-xs flex-1"
                  disabled={savedRows[idx]}
                />
                {!savedRows[idx] && (
                  <ImageUploadButton onUploaded={(url) => setField(idx, "image_url", url)} options={{ maxWidth: 600, maxHeight: 600, maxKB: 25 }} />
                )}
                {row.image_url && <img src={row.image_url} className="w-8 h-8 rounded-none object-cover border border-border" alt="" />}
              </div>
            </div>

            {/* Pyramid — multi-select */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "موضع الهرم (متعدد)" : "Pyramid (multi)"}</p>
              <MultiChipGroup options={PYRAMIDS} value={row.pyramid || ""} onChange={(v) => setField(idx, "pyramid", v)} disabled={savedRows[idx]} />
            </div>

            {/* Note Level — multi-select */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "مستوى النوتة (متعدد)" : "Note Level (multi)"}</p>
              <MultiChipGroup options={NOTE_CATEGORIES} value={row.note_category || ""} onChange={(v) => setField(idx, "note_category", v)} disabled={savedRows[idx]} />
            </div>

            {/* Origin */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "المنشأ / الأصل" : "Origin"}</p>
              <Input
                placeholder={isAr ? "مثال: India, France.." : "e.g. India, France.."}
                value={row.origin}
                onChange={(e) => setField(idx, "origin", e.target.value)}
                className="h-9 rounded-none text-xs"
                disabled={savedRows[idx]}
              />
            </div>

            {/* Description */}
            <div>
              <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الوصف" : "Description"}</p>
              <Textarea
                placeholder={isAr ? "وصف النوتة.." : "Note description.."}
                value={row.description}
                onChange={(e) => setField(idx, "description", e.target.value)}
                className="rounded-none text-xs resize-none min-h-[48px]"
                disabled={savedRows[idx]}
              />
            </div>

            {!savedRows[idx] && (
              <Button size="sm" className="w-full h-8 rounded-none text-xs" onClick={() => handleSaveRow(idx)} disabled={saving[idx]}>
                <Save className="w-3 h-3 mr-1" />
                {saving[idx] ? (isAr ? "جاري الحفظ.." : "Saving..") : (isAr ? "💾 حفظ هذا السطر" : "💾 Save this row")}
              </Button>
            )}
          </div>
        ))}
      </div>

      <Button variant="outline" className="w-full mt-4 rounded-none" onClick={addRow}>
        {isAr ? "إضافة سطر جديد" : "Add Row"}
      </Button>
    </div>
  );
}
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { Save, Trash2, Search, Layers, Download } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import ImageUploadButton from "@/components/ui/ImageUploadButton";
import { exportAllNotes } from "@/lib/notesExport";
import BackIcon from "@/components/shared/BackIcon";

const PYRAMIDS = ["top", "heart", "base", "conductor", "all", "undefined"];
const NOTE_CATEGORIES = ["main_note", "sub_notes", "low_notes"];

const DEFAULT_FAMILIES = [
  "Fresh منعش", "Floral زهري", "Oriental شرقي", "Woody خشبي",
  "Gourmand حلوي", "Citrus حمضي", "Aromatic عطري", "Fougère فوجير",
  "Chypre شيبر", "Aquatic مائي", "Green أخضر", "Spicy بهاري",
  "Musky مسكي", "Powdery بودري", "Leather جلدي", "Smoky دخاني",
];

const DEFAULT_CATEGORIES = [
  "Floral زهري", "Citrus حمضي", "Woody خشبي", "Spicy بهاري",
  "Resinous راتنجي", "Fruity فاكهي", "Herbal عشبي", "Animalic حيواني",
  "Balsamic بلسمي", "Marine بحري", "Earthy ترابي", "Sweet حلو",
];

const loadList = (key, defaults) => {
  try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : defaults; } catch { return defaults; }
};



// Multi-select chip group
const MultiChipGroup = ({ options, value, onChange, disabled }) => {
  const selected = value ? value.split(",").map((v) => v.trim()).filter(Boolean) : [];
  const toggle = (o) => {
    const next = selected.includes(o) ? selected.filter((s) => s !== o) : [...selected, o];
    onChange(next.join(","));
  };
  return (
    <div className="flex flex-wrap gap-1">
      {options.map((o) => (
        <button
          key={o}
          type="button"
          disabled={disabled}
          onClick={() => toggle(o)}
          className={` rounded-none text-[10px] font-body transition-colors ${
 selected.includes(o)
 ? " text-primary-foreground "
 : " text-muted-foreground "
 }`}
        >
          {o}
        </button>
      ))}
    </div>
  );
};

export default function MaestroNotes() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const families = loadList("maestro_odor_families", DEFAULT_FAMILIES);
  const categories = loadList("maestro_note_categories", DEFAULT_CATEGORIES);
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [localEdits, setLocalEdits] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newNote, setNewNote] = useState({});
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data: notes = [], isLoading } = useQuery({
    queryKey: ["maestro-notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  const filtered = notes.filter(
    (n) => n.name?.toLowerCase().includes(search.toLowerCase()) || n.name?.includes(search)
  );
  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const getEdit = (n) => localEdits[n.id] ?? n;
  const setEdit = (id, field, value) => {
    setLocalEdits((prev) => ({
      ...prev,
      [id]: { ...(prev[id] ?? notes.find((n) => String(n.id) === String(id))), [field]: value },
    }));
  };

  const handleSave = async (id) => {
    const data = localEdits[id];
    if (!data) return;
    setSaving((p) => ({ ...p, [id]: true }));
    await apphost.entities.PerfumeNote.update(id, { ...data, is_default: true });
    setSaving((p) => ({ ...p, [id]: false }));
    qc.invalidateQueries({ queryKey: ["maestro-notes"] });
    toast.success("" + (isAr ? "تم التعديل بنجاح" : "Updated successfully"));
  };

  const handleDelete = async (id) => {
    if (!confirm(isAr ? "حذف هذه النوتة؟" : "Delete this note?")) return;
    await apphost.entities.PerfumeNote.delete(id);
    qc.invalidateQueries({ queryKey: ["maestro-notes"] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAdd = async () => {
    if (!newNote.name) { toast.error((isAr ? "الاسم مطلوب" : "Name required")); return; }
    await apphost.entities.PerfumeNote.create({ ...newNote, is_default: true });
    qc.invalidateQueries({ queryKey: ["maestro-notes"] });
    setNewNote({});
    setShowAddForm(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <BackIcon className={`w-5 h-5`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🌿 {isAr ? "نوتات العطور" : "Fragrance Notes"}</h1>
          <p className="text-xs text-muted-foreground">{notes.length} {isAr ? "نوتة" : "notes"}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input placeholder={isAr ? "بحث.." : "Search.."} value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} className="pl-9 rounded-none h-9" />
        </div>
        <Button size="sm" className="rounded-none" onClick={() => setShowAddForm(!showAddForm)}>
          {isAr ? "إضافة" : "Add"}
        </Button>
        <Link to="/maestro/notes/bulk-add">
          <Button size="sm" variant="outline" className="rounded-none">
            <Layers className="w-4 h-4 mr-1" />{isAr ? "إضافة 20" : "Add 20"}
          </Button>
        </Link>
      </div>

      {/* تصدير كلّ النوتات — نُقل من صفحة النوتات لإبقائها خفيفة (الإخراج الكامل ضخم) */}
      <div className="flex items-center gap-3 flex-wrap mb-4 border border-border rounded-none p-2.5">
        <span className="text-xs font-body font-semibold text-muted-foreground">
          {isAr ? "تصدير كل النوتات" : "Export all notes"}
        </span>
        <button onClick={() => exportAllNotes(notes, "csv")}
          className="flex items-center gap-1 text-xs font-body font-medium text-muted-foreground hover:text-foreground transition-colors">
          <Download className="w-3 h-3" /> CSV
        </button>
        <button onClick={() => exportAllNotes(notes, "txt")}
          className="flex items-center gap-1 text-xs font-body font-medium text-muted-foreground hover:text-foreground transition-colors">
          <Download className="w-3 h-3" /> TXT
        </button>
        <button onClick={() => exportAllNotes(notes, "pdf")}
          className="flex items-center gap-1 text-xs font-body font-medium text-primary hover:opacity-80 transition-colors">
          <Download className="w-3 h-3" /> PDF
        </button>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center gap-2 mb-3 justify-center flex-wrap">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i)} className={`w-7 h-7 rounded-none text-xs ${page === i ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>{i + 1}</button>
          ))}
        </div>
      )}
      <p className="text-[10px] text-muted-foreground text-center mb-3">{filtered.length} {isAr ? "نوتة" : "notes"}</p>

      {/* Add Form */}
      {showAddForm && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <p className="text-sm font-body font-semibold">{isAr ? "إضافة نوتة جديدة" : "Add New Note"}</p>

          {/* Name — single combined field */}
          <Input placeholder={isAr ? "الاسم (EN AR)" : "Name (EN AR)"} value={newNote.name || ""} onChange={(e) => setNewNote({ ...newNote, name: e.target.value })} className="rounded-none h-9 text-xs" />

          {/* Category — multi */}
          <div>
            <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "التصنيف (متعدد)" : "Category (multi)"}</p>
            <MultiChipGroup options={categories} value={newNote.category || ""} onChange={(v) => setNewNote({ ...newNote, category: v })} />
          </div>

          {/* Odor Family — multi */}
          <div>
            <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "العائلة العطرية (متعددة)" : "Odor Family (multi)"}</p>
            <MultiChipGroup options={families} value={newNote.odor_family || ""} onChange={(v) => setNewNote({ ...newNote, odor_family: v })} />
          </div>

          <Input placeholder={isAr ? "المنشأ (Origin)" : "Origin"} value={newNote.origin || ""} onChange={(e) => setNewNote({ ...newNote, origin: e.target.value })} className="rounded-none h-9 text-xs" />

          <div className="flex gap-1.5 items-center">
            <Input placeholder={isAr ? "رابط الصورة" : "Image URL"} value={newNote.image_url || ""} onChange={(e) => setNewNote({ ...newNote, image_url: e.target.value })} className="rounded-none h-9 text-xs flex-1" />
            <ImageUploadButton onUploaded={(url) => setNewNote({ ...newNote, image_url: url })} options={{ maxWidth: 600, maxHeight: 600, maxKB: 25 }} />
          </div>

          {/* Pyramid — multi-select */}
          <div>
            <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "موضع الهرم (متعدد)" : "Pyramid (multi)"}</p>
            <MultiChipGroup options={PYRAMIDS} value={newNote.pyramid || ""} onChange={(v) => setNewNote({ ...newNote, pyramid: v })} />
          </div>

          {/* Note Level — multi-select */}
          <div>
            <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "مستوى النوتة (متعدد)" : "Note Level (multi)"}</p>
            <MultiChipGroup options={NOTE_CATEGORIES} value={newNote.note_category || ""} onChange={(v) => setNewNote({ ...newNote, note_category: v })} />
          </div>

          {/* Description — single field for both languages */}
          <Textarea placeholder={isAr ? "الوصف" : "Description"} value={newNote.description || ""} onChange={(e) => setNewNote({ ...newNote, description: e.target.value })} className="rounded-none text-xs resize-none min-h-[50px]" />

          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAdd}>{isAr ? "إضافة" : "Add Note"}</Button>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          {paginated.map((note) => {
            const edit = getEdit(note);
            const isDirty = JSON.stringify(edit) !== JSON.stringify(note);
            return (
              <div key={note.id} className="bg-card border border-border/50 rounded-none p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {note.image_url && <img src={note.image_url} className="w-7 h-7 rounded-none object-cover" alt="" />}
                    <div>
                      <p className="text-sm font-body font-semibold">{note.name}</p>
                      <p className="text-[10px] text-muted-foreground">{note.category} — {note.pyramid}</p>
                    </div>
                  </div>
                  <button onClick={() => handleDelete(note.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </button>
                </div>

                <div className="space-y-2">
                  {/* Name — single combined field */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الاسم (EN AR)" : "Name (EN AR)"}</p>
                    <Input value={edit.name || ""} onChange={(e) => setEdit(note.id, "name", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>

                  {/* Category — multi */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "التصنيف (متعدد)" : "Category (multi)"}</p>
                    <MultiChipGroup options={categories} value={edit.category || ""} onChange={(v) => setEdit(note.id, "category", v)} />
                  </div>

                  {/* Odor Family — multi */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "العائلة العطرية (متعددة)" : "Odor Family (multi)"}</p>
                    <MultiChipGroup options={families} value={edit.odor_family || ""} onChange={(v) => setEdit(note.id, "odor_family", v)} />
                  </div>

                  {/* Pyramid — multi-select chips */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "موضع الهرم (متعدد)" : "Pyramid (multi)"}</p>
                    <MultiChipGroup options={PYRAMIDS} value={edit.pyramid || ""} onChange={(v) => setEdit(note.id, "pyramid", v)} />
                  </div>

                  {/* Note Level — multi-select chips */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "مستوى النوتة (متعدد)" : "Note Level (multi)"}</p>
                    <MultiChipGroup options={NOTE_CATEGORIES} value={edit.note_category || ""} onChange={(v) => setEdit(note.id, "note_category", v)} />
                  </div>

                  {/* Origin */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "المنشأ" : "Origin"}</p>
                    <Input value={edit.origin || ""} onChange={(e) => setEdit(note.id, "origin", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>

                  {/* Image */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "رابط الصورة" : "Image URL"}</p>
                    <div className="flex gap-1.5 items-center">
                      <Input value={edit.image_url || ""} onChange={(e) => setEdit(note.id, "image_url", e.target.value)} className="h-8 rounded-none text-xs flex-1" />
                      <ImageUploadButton onUploaded={(url) => setEdit(note.id, "image_url", url)} options={{ maxWidth: 600, maxHeight: 600, maxKB: 25 }} />
                    </div>
                  </div>

                  {/* Description — single field */}
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الوصف" : "Description"}</p>
                    <Textarea value={edit.description || ""} onChange={(e) => setEdit(note.id, "description", e.target.value)} className="rounded-none text-xs resize-none min-h-[50px]" />
                  </div>
                </div>

                <Button onClick={() => handleSave(note.id)} disabled={!isDirty || saving[note.id]} className="w-full h-8 rounded-none text-xs" variant={isDirty ? "default" : "outline"}>
                  <Save className="w-3 h-3 mr-1" />
                  {saving[note.id] ? (isAr ? "جاري الحفظ.." : "Saving..") : (isAr ? "💾 حفظ" : "💾 Save")}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
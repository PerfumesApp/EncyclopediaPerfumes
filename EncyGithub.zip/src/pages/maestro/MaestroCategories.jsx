import { useState } from "react";
import { Link } from "react-router-dom";
import { Trash2, ChevronDown, ChevronRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import { DEFAULT_MAIN_CATEGORIES, DEFAULT_SUB_CATEGORIES } from "@/lib/shopCategories";
import BackIcon from "@/components/shared/BackIcon";

// Convert static categories to maestro format
const convertToMaestroFormat = () => {
  return DEFAULT_MAIN_CATEGORIES.map(main => ({
    id: main.id,
    icon: main.icon,
    name_en: main.name_en,
    name_ar: main.name_ar,
    subs: (DEFAULT_SUB_CATEGORIES[main.id] || []).map(sub => ({
      id: sub.id,
      icon: sub.icon || "📌",
      name_en: sub.name_en,
      name_ar: sub.name_ar,
    }))
  }));
};

const DEFAULT_CATEGORIES = convertToMaestroFormat();

const STORAGE_KEY = "maestro_shopping_categories";

function loadCategories() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
  } catch {
    return DEFAULT_CATEGORIES;
  }
}

function saveCategories(cats) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cats));
}

export default function MaestroCategories() {
  const { isAr } = useLang();
  const [categories, setCategories] = useState(loadCategories);
  const [expandedCats, setExpandedCats] = useState({});
  const [editingCat, setEditingCat] = useState(null);
  const [editingSub, setEditingSub] = useState(null);
  const [newSubCat, setNewSubCat] = useState({});
  const [showNewMain, setShowNewMain] = useState(false);
  const [newMain, setNewMain] = useState({ icon: "🏷️", name_en: "", name_ar: "", subs: [] });

  const save = (updated) => {
    setCategories(updated);
    saveCategories(updated);
  };

  const handleUpdateMain = (catId, field, val) => {
    save(categories.map((c) => String(c.id) === String(catId) ? { ...c, [field]: val } : c));
  };

  const handleDeleteMain = (catId) => {
    if (!confirm(isAr ? "حذف القسم الرئيسي و كل فروعه؟" : "Delete main category and all its subcategories?")) return;
    save(categories.filter((c) => c.id !== catId));
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAddMain = () => {
    if (!newMain.name_en) { toast.error((isAr ? "الاسم الإنجليزي مطلوب" : "English name required")); return; }
    const newCat = { ...newMain, id: `cat_${Date.now()}`, subs: [] };
    save([...categories, newCat]);
    setNewMain({ icon: "🏷️", name_en: "", name_ar: "", subs: [] });
    setShowNewMain(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  const handleUpdateSub = (catId, subId, field, val) => {
    save(categories.map((c) => String(c.id) === String(catId)
      ? { ...c, subs: c.subs.map((s) => String(s.id) === String(subId) ? { ...s, [field]: val } : s) }
      : c
    ));
  };

  const handleDeleteSub = (catId, subId) => {
    save(categories.map((c) => String(c.id) === String(catId)
      ? { ...c, subs: c.subs.filter((s) => s.id !== subId) }
      : c
    ));
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAddSub = (catId) => {
    const sub = newSubCat[catId];
    if (!sub?.name_en) { toast.error((isAr ? "الاسم الإنجليزي مطلوب" : "English name required")); return; }
    const newSubItem = { ...sub, id: `sub_${Date.now()}` };
    save(categories.map((c) => String(c.id) === String(catId) ? { ...c, subs: [...c.subs, newSubItem] } : c));
    setNewSubCat((p) => ({ ...p, [catId]: { icon: "📌", name_en: "", name_ar: "" } }));
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  const handleReset = () => {
    if (!confirm(isAr ? "إعادة تعيين إلى الافتراضي؟" : "Reset to defaults?")) return;
    save(DEFAULT_CATEGORIES);
    toast.success(isAr ? "تمت إعادة التعيين" : "Reset done");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
            <BackIcon className={`w-5 h-5`} />
          </Link>
          <div>
            <h1 className="font-heading text-xl font-bold">🗂️ {isAr ? "تصنيفات التسوق" : "Shopping Categories"}</h1>
            <p className="text-xs text-muted-foreground">{categories.length} {isAr ? "قسم رئيسي" : "main categories"}</p>
          </div>
        </div>
        <button onClick={handleReset} className="text-[10px] text-muted-foreground hover:text-destructive underline font-body">
          {isAr ? "إعادة تعيين" : "Reset"}
        </button>
      </div>

      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 rounded-none p-3 mb-4 text-xs font-body text-blue-700 dark:text-blue-300">
        {isAr ? "💡 التعديلات تُحفظ محلياً وتُطبق على التطبيق فوراً" : "💡 Changes are saved locally and applied immediately to the app"}
      </div>

      {/* Add New Main */}
      <button
        onClick={() => setShowNewMain(!showNewMain)}
        className="w-full flex items-center justify-center gap-2 bg-primary/5 border border-primary/20 border-dashed rounded-none px-4 py-3 mb-4 hover:bg-primary/10 transition-colors"
      >
        <span className="text-sm font-body text-primary">{isAr ? "إضافة قسم رئيسي جديد" : "Add New Main Category"}</span>
      </button>

      {showNewMain && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <div className="grid grid-cols-3 gap-2">
            <Input placeholder={isAr ? "رمز الأيقونة" : "Icon emoji"} value={newMain.icon} onChange={(e) => setNewMain({ ...newMain, icon: e.target.value })} className="rounded-none h-9 text-xs text-center" />
            <Input placeholder={isAr ? "الاسم بالإنجليزية" : "Name EN*"} value={newMain.name_en} onChange={(e) => setNewMain({ ...newMain, name_en: e.target.value })} className="rounded-none h-9 text-xs col-span-1" />
            <Input placeholder="الاسم عربي" value={newMain.name_ar} onChange={(e) => setNewMain({ ...newMain, name_ar: e.target.value })} className="rounded-none h-9 text-xs" dir="rtl" />
          </div>
          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAddMain}>{isAr ? "إضافة" : "Add Category"}</Button>
        </div>
      )}

      <div className="space-y-3">
        {categories.map((cat) => (
          <div key={cat.id} className="bg-card border border-border/50 rounded-none overflow-hidden">
            {/* Main Category Header */}
            <div className="flex items-center gap-2 p-3">
              <button onClick={() => setExpandedCats((p) => ({ ...p, [cat.id]: !p[cat.id] }))} className="flex items-center gap-2 flex-1">
                <span className="text-xl">{cat.icon}</span>
                <div className="text-left flex-1">
                  <p className="text-sm font-body font-semibold">{isAr ? cat.name_ar || cat.name_en : cat.name_en}</p>
                  <p className="text-[10px] text-muted-foreground">{cat.subs.length} {isAr ? "فرع" : "subcategories"}</p>
                </div>
                {expandedCats[cat.id] ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
              </button>
              <button onClick={() => handleDeleteMain(cat.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                <Trash2 className="w-3.5 h-3.5 text-red-500" />
              </button>
            </div>

            {expandedCats[cat.id] && (
              <div className="border-t border-border/30 p-3 space-y-3 bg-secondary/10">
                {/* Edit main */}
                <div className="grid grid-cols-3 gap-2">
                  <Input placeholder={isAr ? "الأيقونة" : "Icon"} value={cat.icon} onChange={(e) => handleUpdateMain(cat.id, "icon", e.target.value)} className="rounded-none h-8 text-xs text-center" />
                  <Input value={cat.name_en} onChange={(e) => handleUpdateMain(cat.id, "name_en", e.target.value)} className="rounded-none h-8 text-xs" placeholder={isAr ? "الاسم بالإنجليزية" : "Name EN"} />
                  <Input value={cat.name_ar} onChange={(e) => handleUpdateMain(cat.id, "name_ar", e.target.value)} className="rounded-none h-8 text-xs" dir="rtl" placeholder="الاسم عربي" />
                </div>

                {/* Subcategories */}
                <div className="space-y-2">
                  <p className="text-[9px] text-muted-foreground uppercase font-body">{isAr ? "الأقسام الفرعية" : "Subcategories"}</p>
                  {cat.subs.map((sub) => (
                    <div key={sub.id} className="flex items-center gap-2 bg-background rounded-none p-2">
                      <Input value={sub.icon} onChange={(e) => handleUpdateSub(cat.id, sub.id, "icon", e.target.value)} className="rounded-none h-7 text-xs text-center w-12 flex-shrink-0 p-1" />
                      <Input value={sub.name_en} onChange={(e) => handleUpdateSub(cat.id, sub.id, "name_en", e.target.value)} className="rounded-none h-7 text-xs flex-1" placeholder="EN" />
                      <Input value={sub.name_ar} onChange={(e) => handleUpdateSub(cat.id, sub.id, "name_ar", e.target.value)} className="rounded-none h-7 text-xs flex-1" placeholder="عربي" dir="rtl" />
                      <button onClick={() => handleDeleteSub(cat.id, sub.id)} className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none flex-shrink-0">
                        <Trash2 className="w-3 h-3 text-red-500" />
                      </button>
                    </div>
                  ))}
                  {/* Add sub */}
                  <div className="flex items-center gap-2">
                    <Input
                      value={newSubCat[cat.id]?.icon || "📌"}
                      onChange={(e) => setNewSubCat((p) => ({ ...p, [cat.id]: { ...(p[cat.id] || {}), icon: e.target.value } }))}
                      className="rounded-none h-7 text-xs text-center w-12 flex-shrink-0 p-1"
                    />
                    <Input
                      placeholder={isAr ? "الاسم بالإنجليزية" : "Name EN*"}
                      value={newSubCat[cat.id]?.name_en || ""}
                      onChange={(e) => setNewSubCat((p) => ({ ...p, [cat.id]: { ...(p[cat.id] || {}), name_en: e.target.value } }))}
                      className="rounded-none h-7 text-xs flex-1"
                    />
                    <Input
                      placeholder="عربي"
                      value={newSubCat[cat.id]?.name_ar || ""}
                      onChange={(e) => setNewSubCat((p) => ({ ...p, [cat.id]: { ...(p[cat.id] || {}), name_ar: e.target.value } }))}
                      className="rounded-none h-7 text-xs flex-1"
                      dir="rtl"
                    />
                    <button onClick={() => handleAddSub(cat.id)} className="p-1 bg-primary/10 hover:bg-primary/20 rounded-none flex-shrink-0">
                      Add</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
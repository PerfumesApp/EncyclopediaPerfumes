import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import BackIcon from "@/components/shared/BackIcon";

/**
 * ReadingGuide — "موجهة القراءة / A Reading Guide": عتبة سردية للموسوعة.
 * عامة بلا إحصائيات — تشرح أقسام الموسوعة الخمسة (القصص، المصطلحات،
 * الاقتباسات، معنى علامة، أطوار العطور) و مميزاتها و إمكانياتها كاملة
 * (الإعداد، التقاط و تعبئة، الحقول، الخطوط، المصنفات، خيارات القراءة).
 * مكتوبة كأن الموسوعة فارغة. ثنائية اللغة، بلا تشكيل، تُعرض كما كُتبت.
 * مرتبطة من صفحة خطوط الموسوعة و قائمة المستخدم.
 */

const GOLD = "var(--brand)";

function Q({ children, dir }) {
  return (
    <p dir={dir} style={{ borderInlineStart: `2px solid ${GOLD}66`, paddingInlineStart: 12, margin: "10px 0", color: "#6b7280", fontStyle: "italic", lineHeight: 1.9 }}>
      {children}
    </p>
  );
}
function H({ children, dir }) {
  return <h2 dir={dir} className="font-heading" style={{ color: GOLD, fontSize: 16, fontWeight: 700, margin: "22px 0 8px" }}>{children}</h2>;
}
function P({ children, dir }) {
  return <p dir={dir} className="font-body" style={{ fontSize: 13.5, lineHeight: 2, color: "var(--tw-prose, inherit)", margin: "0 0 10px" }}>{children}</p>;
}

export default function ReadingGuide() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  return (
    <div className="px-5 page-top pb-20 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-5">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
          <BackIcon className="w-5 h-5" />
        </button>
        <h1 className="font-heading text-2xl font-bold" style={{ color: GOLD }}>
          {isAr ? "موجهة القراءة" : "A Reading Guide"}
        </h1>
      </div>

      {/* ───────────── Arabic ───────────── */}
      <section dir="rtl" className="mb-12">
        <P dir="rtl">الموسوعة مكتبتك التي تبنيها بنفسك — خمسة عوالم متجاورة تجمع فيها ما يدهشك و ما يفيدك، بلغتين متقابلتين، تقرؤها على مهلك و ترتبها كما تحب.</P>
        <Q dir="rtl">هذه ليست قاعدة بيانات تملؤها ثم تنساها، بل عتبة تعبرها كل يوم. ابن بابا، ثم ادخل منه.</Q>

        <H dir="rtl">ما الذي تضمه</H>
        <P dir="rtl">خلف الواجهة الهادئة خمسة أقسام، لكل قسم طابعه:</P>
        <P dir="rtl">◆ <b>القصص</b> — حركات قصيرة يفصل بينها خط، تبدأ بسؤال أو مشهد ثم تتسع ثم تنصف الطرفين دائما — فلا فكرة بلا اعتراض. تروى لتدهشك لا لتعظك، كما يروي صديق شيئا أذهله للتو.</P>
        <P dir="rtl">◆ <b>المصطلحات</b> — لفظة بشرح موجز بلغتين، ضوء سريع يعرفك بالشيء. لكل حقل لغته و مفرداته — من بنية العطر إلى أبعد المجالات.</P>
        <P dir="rtl">◆ <b>الاقتباسات</b> — أصوات مسندة إلى قائليها، مرتبة بتصنيفات تختار منها حسب مزاجك. حيث الإسناد مشهور غير موثق تجد كلمة منسوب، مصارحة لك لا تشكيكا في الجمال.</P>
        <P dir="rtl">◆ <b>معنى علامة</b> — رمزية بأسلوب صفحة العطر: وسوم و تفاعل و خاطرة و علامة مرجعية و تنقل بين السابق و التالي.</P>
        <P dir="rtl">◆ <b>قصائد</b> — دواوين الشعر عبر العصور، مرتبة بخطوط زمنية، لكل قصيدة شاعرها و بحرها و قافيتها و شرحها — من الجاهلية إلى الحديث و النبطي.</P>
        <P dir="rtl">◆ <b>أطوار العطور</b> — خط زمني للعطور يسحب من كاتالوجك نفسه، يريك تسلسلها عبر الزمن دون أن تكتب شيئا.</P>

        <H dir="rtl">كيف تبنيها</H>
        <P dir="rtl">◆ <b>الإعداد</b> — أضف ما تشاء من الأقسام و التصنيفات و الخطوط الزمنية. البنية بين يديك، تنمو كلما أضفت.</P>
        <P dir="rtl">◆ <b>التقاط و تعبئة</b> — أكبر ميسر: الصق رد الذكاء كما هو، فينظف التطبيق الترويسة و الماركداون و التسميات، ثم يفصل اللغتين، و يجعل أول سطر عنوانا و الباقي محتوى — فتمتلئ حقول العنوان و النص باللغتين بضغطة واحدة.</P>
        <P dir="rtl">◆ <b>الحقول</b> — لكل مدخل عنوان و نص و صورة بكل لغة، و شرح و سنة و نطق و مصدر و وسوم، و ربط صريح بقسم و تصنيف فرعي و خط زمني — لا عبر الوسوم، بل بمعرف ثابت لا يضيع.</P>

        <H dir="rtl">كيف تتصفحها</H>
        <P dir="rtl">◆ <b>الأقسام</b> أزرار في الأعلى، يليها بحث و صفحات. لكل قسم آخر صفحة بلغت إليها، تعود إليها حين ترجع.</P>
        <P dir="rtl">◆ <b>الخطوط الزمنية</b> — كل خط تقسيمة قائمة بذاتها، يفتح صفحته مرتبة بالسنة، يعلوها خط بلونك أنت.</P>
        <P dir="rtl">◆ <b>المصنفات</b> — تصنيف بالمحاور: النوع و المنطقة و الفئة و الحقل، كل فرعية تفتح صفحتها بعدد مدخلاتها.</P>
        <P dir="rtl">◆ <b>المفضلة</b> — قلب يجمع ما علمته بإعجاب أو قراءة، فترجع إليه متى شئت.</P>

        <H dir="rtl">كيف تقرؤها على ذوقك</H>
        <P dir="rtl">◆ اختر <b>لغة العرض</b> — عربي أو إنجليزي أو الاثنين معا — و <b>حجم الخط</b>، و <b>ترتيب العناوين</b> حتى حسب لغتك، و <b>طريقة الفرز</b>. كلها محفوظة، و في قائمة المستخدم أيضا تحت خيار واحد مطوي.</P>
        <P dir="rtl">◆ في <b>صفحة المدخل</b>: وسوم و تفاعل و علامة مرجعية و خاطرة و تنقل إلى السابق و التالي — فالقراءة لا تنقطع.</P>

        <Q dir="rtl">الموسوعة تكبر معك. كل مدخل باب إلى غيره، و كل قسم خيط يجر خيطا. لا تطلب منك أن تنهيها، بل أن تعود إليها — فابنها على مهلك، و ابدأ من حيث ناداك قلبك.</Q>
      </section>

      <div style={{ height: 1, background: `${GOLD}40`, margin: "8px 0 28px" }} />

      {/* ───────────── English ───────────── */}
      <section dir="ltr" className="mb-10">
        <P dir="ltr">The encyclopedia is your own library, built by your hand — five neighboring worlds gathering what astonishes you and what serves you, in two facing languages, read at your pace and arranged as you like.</P>
        <Q dir="ltr">This is not a database you fill and forget, but a threshold you cross each day. Build a door, then walk through it.</Q>

        <H dir="ltr">What it holds</H>
        <P dir="ltr">Behind the quiet surface are five sections, each with its character:</P>
        <P dir="ltr">◆ <b>Stories</b> — short movements divided by a line, opening on a question or a scene, then widening, always weighing both sides — no idea without its objection. Told to astonish you, not to instruct you, the way a friend tells you something that just amazed them.</P>
        <P dir="ltr">◆ <b>Vocabulary</b> — a word with a brief bilingual gloss, a quick light that introduces a thing. Every field has its own language and terms — from the architecture of perfume to the farthest subjects.</P>
        <P dir="ltr">◆ <b>Quotes</b> — voices tied to their speakers, arranged in categories you pick by mood. Where an attribution is famous but unproven, the word attributed sits beside the name — honesty with you, not doubt about the beauty.</P>
        <P dir="ltr">◆ <b>Poems</b> — diwans of poetry across the ages, arranged by timelines, each poem with its poet, meter, rhyme and commentary — from the pre-Islamic era to the modern and the Nabati.</P>
        <P dir="ltr">◆ <b>Marking Meaning</b> — symbolism in the perfume-page style: tags, reactions, a thought, a bookmark, and prev/next navigation.</P>
        <P dir="ltr">◆ <b>Perfume Era</b> — a timeline of perfumes drawn from your own catalog, showing their sequence through time without your writing a thing.</P>

        <H dir="ltr">How you build it</H>
        <P dir="ltr">◆ <b>Setup</b> — add as many sections, classifications and timelines as you wish. The structure is in your hands, growing as you add.</P>
        <P dir="ltr">◆ <b>Capture & Fill</b> — the great shortcut: paste the AI reply as it is, and the app strips the preamble, the markdown and the labels, separates the two languages, makes the first line a title and the rest the body — so the title and text fields fill in both languages with a single tap.</P>
        <P dir="ltr">◆ <b>Fields</b> — every entry holds a title, text and image per language, plus an explanation, a year, a pronunciation, a source and tags, and an explicit link to a section, a sub-class and a timeline — not through tags, but by a stable id that never gets lost.</P>

        <H dir="ltr">How you browse it</H>
        <P dir="ltr">◆ <b>Sections</b> are buttons at the top, followed by search and pages. Each section remembers the last page you reached.</P>
        <P dir="ltr">◆ <b>Timelines</b> — each timeline is a division of its own, opening to its page ordered by year, crowned by a line in your color.</P>
        <P dir="ltr">◆ <b>Classifications</b> — sorted by axes: kind, region, category and field, each sub-class opening to its page with its entry count.</P>
        <P dir="ltr">◆ <b>Favorites</b> — a heart gathering what you marked with a reaction or a read, to return to whenever you like.</P>

        <H dir="ltr">How you read it your way</H>
        <P dir="ltr">◆ Choose the <b>display language</b> — Arabic, English or both — the <b>font size</b>, the <b>title order</b> even by your language, and the <b>sort</b>. All are saved, and gathered in the user menu too under one folded option.</P>
        <P dir="ltr">◆ On the <b>entry page</b>: tags, reactions, a bookmark, a thought, and movement to previous and next — so the reading never breaks.</P>

        <Q dir="ltr">The encyclopedia grows with you. Every entry is a door to another, every section a thread pulling a thread. It asks you not to finish it, but to return to it — so build it at your pace, and begin where your heart called you.</Q>

        <div className="pt-4">
          <button type="button" onClick={() => navigate("/encyclopedia")}
            className="font-body text-sm font-semibold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
            {isAr ? "إلى الموسوعة" : "To the encyclopedia"}
          </button>
        </div>
      </section>
    </div>
  );
}

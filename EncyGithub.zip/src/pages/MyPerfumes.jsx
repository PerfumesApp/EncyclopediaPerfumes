import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import BackIcon from "@/components/shared/BackIcon";

export default function MyPerfumes() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { formatPrice } = useCurrency();
  const queryClient = useQueryClient();

  const { data: userPerfumes = [], isLoading } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: wishlists = [] } = useQuery({
    queryKey: ["wishlists"],
    queryFn: () => apphost.entities.Wishlist.list("-created_date"),
  });

  const { data: perfumeDetails = [] } = useQuery({
    queryKey: ["perfumes-details", userPerfumes],
    queryFn: async () => {
      if (userPerfumes.length === 0) return [];
      const ids = [...new Set(userPerfumes.map(up => up.perfume_id))];
      const results = await Promise.all(
        ids.map(id => apphost.entities.Perfume.filter({ id }).then(r => r?.[0]))
      );
      return results.filter(Boolean);
    },
    enabled: userPerfumes.length > 0,
  });

  const { data: wishlistPerfumeDetails = [] } = useQuery({
    queryKey: ["wishlist-perfumes-details", wishlists],
    queryFn: async () => {
      if (wishlists.length === 0) return [];
      const ids = [...new Set(wishlists.map(w => w.perfume_id))];
      const results = await Promise.all(
        ids.map(id => apphost.entities.Perfume.filter({ id }).then(r => r?.[0]))
      );
      return results.filter(Boolean);
    },
    enabled: wishlists.length > 0,
  });

  const deleteWishlist = useMutation({
    mutationFn: (id) => apphost.entities.Wishlist.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["wishlists"] });
      toast.success(isAr ? "تم حذف الرغبة" : "Wish removed");
    },
  });

  const totalWishCost = wishlists.reduce((sum, w) => sum + (parseFloat(w.estimated_price) || 0), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const counts = {
    total: new Set(userPerfumes.map(up => up.perfume_id)).size,
    person1: new Set(userPerfumes.filter(up => up.person === "person1").map(up => up.perfume_id)).size,
    person2: new Set(userPerfumes.filter(up => up.person === "person2").map(up => up.perfume_id)).size,
    wishes: wishlists.length,
  };

  return (
    <div className="px-5 page-top pb-20">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <BackIcon className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="font-heading text-2xl font-bold">🌹 {isAr ? "مجموعتي من العطور" : "My Perfume Collection"}</h1>
          <p className="text-xs text-muted-foreground mt-1">
            {counts.total} {isAr ? "عطر" : "perfumes"} {names.person1}: {counts.person1} {names.person2}: {counts.person2}
          </p>
        </div>
      </div>

      {/* My Perfumes Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <h2 className="font-heading text-lg font-semibold">📦 {isAr ? "المملوكة" : "Owned"}</h2>
          <span className="text-xs text-primary rounded-none">{counts.total}</span>
        </div>
        {perfumeDetails.length === 0 ? (
          <div className="text-center py-8 bg-secondary/30 rounded-none">
            <p className="text-sm text-muted-foreground font-body">{isAr ? "لا توجد عطور مملوكة" : "No perfumes owned yet"}</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {perfumeDetails.map((perfume) => (
              <div
                key={perfume.id}
                onClick={() => navigate(`/perfume?id=${perfume.id}`)}
                className="cursor-pointer hover:opacity-80 transition-opacity"
              >
                <PerfumeCard
                  perfume={perfume}
                  userPerfume={userPerfumes.find(up => String(up.perfume_id) === String(perfume.id))}
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Wishlist Section */}
      {counts.wishes > 0 && (
        <div className="space-y-4 mt-8 pt-8 border-t border-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="font-heading text-lg font-semibold">💕 {isAr ? "أرغب بالشراء" : "Wish List"}</h2>
              <span className="text-xs text-pink-600 dark:text-pink-400 rounded-none">{counts.wishes}</span>
            </div>
            {totalWishCost > 0 && (
              <div className="text-right">
                <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الإجمالي" : "Total"}</p>
                <p className="text-lg font-heading font-bold text-pink-600 dark:text-pink-400">{formatPrice(totalWishCost)}</p>
              </div>
            )}
          </div>

          {/* Wishlist Cards */}
          <div className="space-y-2">
            {wishlists.map((wish) => {
              const perfume = wishlistPerfumeDetails.find(p => String(p.id) === String(wish.perfume_id));
              if (!perfume) return null;
              
              const priorityEmojis = { high: "🔴", medium: "🟡", low: "🔵" };
              
              return (
                <div
                  key={wish.id}
                  className="flex items-center gap-3 bg-secondary/40 rounded-none p-3 hover:bg-secondary/60 transition-colors"
                >
                  {/* Thumbnail */}
                  <div
                    className="w-12 h-12 rounded-none bg-white dark:bg-slate-800 flex-shrink-0 overflow-hidden cursor-pointer hover:opacity-75"
                    onClick={() => navigate(`/perfume?id=${perfume.id}`)}
                  >
                    {perfume.image_url ? (
                      <img src={perfume.image_url} alt={perfume.name_en} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">
                        <span className="text-sm">💧</span>
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0 cursor-pointer" onClick={() => navigate(`/perfume?id=${perfume.id}`)}>
                    <p className="text-xs font-body font-bold text-foreground truncate">{perfume.name_en || perfume.name_ar}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{perfume.brand_name}</p>
                  </div>

                  {/* Priority badge */}
                  <div className="text-sm">{priorityEmojis[wish.priority] || "🔵"}</div>

                  {/* Price */}
                  {wish.estimated_price > 0 && (
                    <div className="text-right min-w-fit">
                      <p className="text-[10px] text-muted-foreground font-body">{isAr ? "السعر" : "Price"}</p>
                      <p className="text-xs font-body font-bold">{formatPrice(wish.estimated_price)}</p>
                    </div>
                  )}

                  {/* Delete button */}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10 flex-shrink-0"
                    onClick={() => deleteWishlist.mutate(wish.id)}
                    disabled={deleteWishlist.isPending}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
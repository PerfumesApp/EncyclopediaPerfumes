import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useNavigate } from "react-router-dom";
import { Droplets, Search, Heart, Store, Music, BottleWine, Book, SprayCan, Axe, Wine, Diamond, Turtle, SunSnow, Tally4, Tag, Newspaper, Wallet, Palette, FlaskConical, Layers, Weight, Flower2, TestTubes } from "lucide-react";
import EncyclopediaLogo from "@/components/icons/EncyclopediaLogo";
import PerfumeDesignerIcon from "@/components/icons/PerfumeDesignerIcon";
import AccordPaletteIcon from "@/components/icons/AccordPaletteIcon";
import StoreFrontIcon from "@/components/icons/StoreFrontIcon";
import BrandDiamondsIcon from "@/components/icons/BrandDiamondsIcon";
import { useTranslations } from "@/lib/useTranslations";
import { compareEnglish } from "@/lib/sortName";
import { useLang } from "@/lib/LanguageContext";
import { cn } from "@/lib/utils";
import Pagination from "@/components/Pagination";

function PerfumeBottleIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 3h8v2H8z" />
      <path d="M10 5v3h4V5" />
      <path d="M9 8h6v10c0 1.1-.9 2-2 2h-2c-1.1 0-2-.9-2-2V8z" />
    </svg>
  );
}

// Borderless quick link: icon + label only, no box/frame/background.
// Color shifts on hover/press. `color` is the Tailwind text-color class set.
function GlossaryDots({ className }) {
  const xs = [3.5, 7.3, 11.1, 14.9, 18.7, 22.5];
  const ys = [5, 8.5, 12, 15.5, 19];
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      {ys.flatMap((y) => xs.map((x) => <circle key={`${x}-${y}`} cx={x} cy={y} r="0.9" />))}
    </svg>
  );
}

// قصص = لوتس ملوّن (٧ خطوط خلفية + هالة ذهبية + لوتس وردي بمركز ماسي) — inline، ألوان صريحة
function StoryLotus({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <clipPath id="storyLotusSq"><rect x="0" y="0" width="24" height="24" /></clipPath>
      <g clipPath="url(#storyLotusSq)">
        <rect x="0" y="0" width="3.4286" height="24" fill="#FFFFFF" />
        <rect x="3.4286" y="0" width="3.4286" height="24" fill="#FBBF24" />
        <rect x="6.8571" y="0" width="3.4286" height="24" fill="#2563EB" />
        <rect x="10.2857" y="0" width="3.4286" height="24" fill="#EC4899" />
        <rect x="13.7143" y="0" width="3.4286" height="24" fill="#7DD3FC" />
        <rect x="17.1429" y="0" width="3.4286" height="24" fill="#0891B2" />
        <rect x="20.5714" y="0" width="3.4286" height="24" fill="#9333EA" />
        <circle cx="12" cy="12.5" r="8.6" fill="#E6B422" opacity="0.3" />
        <g transform="translate(0,-0.5)">
          <ellipse cx="12" cy="19" rx="9" ry="2.4" fill="#22C55E" />
          <path d="M12 7 C10.5 12 10.5 15 12 17 C13.5 15 13.5 12 12 7 Z" fill="#F472B6" />
          <path d="M12 17 C8.5 14 5 13.5 4 14.5 C4.5 16.5 7.5 17.5 12 17 Z" fill="#EC4899" />
          <path d="M12 17 C15.5 14 19 13.5 20 14.5 C19.5 16.5 16.5 17.5 12 17 Z" fill="#EC4899" />
          <path d="M12 17 C9.5 15 6.5 16 6 18 C8 19 11 18 12 17 Z" fill="#F9A8D4" />
          <path d="M12 17 C14.5 15 17.5 16 18 18 C16 19 13 18 12 17 Z" fill="#F9A8D4" />
          <path d="M12 13.1 L14.2 15.5 L12 17.9 L9.8 15.5 Z" fill="none" stroke="#D4AF37" strokeWidth="0.45" />
          <path d="M12 13.8 L13.5 15.5 L12 17.2 L10.5 15.5 Z" fill="#FFFFFF" stroke="#EC4899" strokeWidth="0.45" />
        </g>
      </g>
    </svg>
  );
}

// الحكمة = حجر الفلاسفة الذهبي (ماسة ذهبية بأوجه) — inline، ألوان صريحة (لا تُستورد من lucide)
function GoldenStone({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      {/* السطح العلوي (table) */}
      <polygon points="6,8 18,8 15,11 9,11" fill="#FCD884" stroke="#D4AF37" strokeWidth="0.4" />
      {/* أوجه التاج (crown) */}
      <polygon points="6,8 9,11 4,11" fill="#F6B23F" />
      <polygon points="18,8 20,11 15,11" fill="#F6B23F" />
      {/* القاعدة (pavilion) */}
      <polygon points="4,11 20,11 12,21" fill="#E89A24" />
      <polygon points="9,11 15,11 12,21" fill="#F6B23F" />
      <polygon points="4,11 9,11 12,21" fill="#D98B12" />
      <polygon points="15,11 20,11 12,21" fill="#D98B12" />
      {/* لمعة خيط ذهبي */}
      <polygon points="6,8 18,8 12,21" fill="none" stroke="#D4AF37" strokeWidth="0.4" opacity="0.5" />
      <path d="M9 11 L8 8.6" stroke="#FFF3D6" strokeWidth="0.5" opacity="0.6" />
    </svg>
  );
}

function QuickLink({ to, icon: Icon, label, color, iconClassName, labelClassName, labelStyle, reverse, flip, horizontal, decorative }) {
  const cls = cn(
    "flex items-center justify-center gap-2 py-1 select-none transition-transform",
    !decorative && "active:scale-95",
    horizontal ? "flex-row" : "flex-col",
    reverse && (horizontal ? "flex-row-reverse" : "flex-col-reverse"),
    color
  );
  const inner = (
    <>
      <Icon className={cn("w-[22px] h-[22px] shrink-0", iconClassName, flip && "rotate-180")} />
      {!decorative && <span style={labelStyle} className={cn("text-[11px] font-body font-semibold text-center leading-tight", labelClassName, flip && "rotate-180")}>{label}</span>}
    </>
  );
  // decorative: مشهد بصري فقط — أيقونة بلا رابط و بلا نص
  if (decorative) return <div className={cls} aria-hidden="true">{inner}</div>;
  return <Link to={to} className={cls}>{inner}</Link>;
}
import PerfumeCard from "@/components/perfume/PerfumeCard";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import { getSecureStorage } from "@/lib/storageEncryption";
import { searchPerfumeIds, normalizeSearch, searchIndexReady } from "@/lib/searchIndex";
import { rankName } from "@/lib/sortName";


export default function Perfumes() {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [linkSettings, setLinkSettings] = useState(() => {
    const defaults = { brands: true, mixer: true, culture: true, budget: true, stores: true, lists: true, blog: true, perfumers: true, notes: true, quotes: true, wisdom: true, samples: true, glossary: true };
    const stored = getSecureStorage("perfumeLinkSettings", {});
    return Object.fromEntries(Object.keys(defaults).map(k => [k, stored[k] !== false]));
  });
  const interfaceStyle = "traditional"; // الواجهة موحّدة على التقليديّة (أُزيل خيار غير التقليديّة)
  const { names } = usePersonNames();
  const { t } = useTranslations();
  const { isAr } = useLang();
  const navigate = useNavigate();

  // debounce: لا نعيد الترتيب على كل ضغطة حرف — ننتظر توقف الكتابة 250ms
  useEffect(() => {
    const id = setTimeout(() => setDebouncedSearch(search), 250);
    return () => clearTimeout(id);
  }, [search]);

  useEffect(() => {
    const handler = () => {
      const defaults = { brands: true, mixer: true, culture: true, budget: true, stores: true, lists: true, blog: true, perfumers: true, notes: true, quotes: true, wisdom: true, samples: true, glossary: true };
      const stored = getSecureStorage("perfumeLinkSettings", {});
      setLinkSettings(Object.fromEntries(Object.keys(defaults).map(k => [k, stored[k] !== false])));
    };
    window.addEventListener("perfumeLinkSettingsChanged", handler);
    return () => {
      window.removeEventListener("perfumeLinkSettingsChanged", handler);
    };
  }, []);

  // البحث عبر الفهرس: نجلب معرّفات المطابقة من فهرس التوكنات (بلا تحميل 130 ألفاً)
  // ثمّ getMany. إن لم يكتمل الفهرس بعد (تنصيب قائم أثناء الترحيل) نسقط لبحث بادئة
  // الاسم عبر فهرس sort_key — نتائج فوريّة جزئيّة خيرٌ من تجميدٍ أو فراغ.
  const { data: perfumes = [], isLoading } = useQuery({
    queryKey: ["perfume-search", debouncedSearch],
    staleTime: 1000 * 60 * 5,
    enabled: !!debouncedSearch.trim(),
    queryFn: async () => {
      const term = debouncedSearch.trim();
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(term);
        if (ids.length) return await apphost.entities.Perfume.getMany(ids);
        return [];
      }
      // سقوط: بادئة الاسم عبر sort_key (كما في GlobalSearch) حتى يكتمل الفهرس.
      const t = normalizeSearch(term);
      const prefix = String(rankName(t)) + t;
      const { items } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", { lower: prefix, upper: prefix + "\uffff" }, 0, 50, "next", false
      );
      return items || [];
    },
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });



  const filtered = useMemo(() => {
    if (!debouncedSearch.trim()) return [];
    // ترشيح ثانويّ موحّد التطبيع (يصلح للعربيّ واللاتينيّ والهمزات والتشكيل معاً)
    // فوق المرشّحين القلائل العائدين من الفهرس — لا فوق 130 ألفاً.
    const q = normalizeSearch(debouncedSearch);
    const visible = perfumes.filter((p) => !p.hidden);
    const filteredRaw = visible.filter((p) => {
      const hay = normalizeSearch(
        [p.name, p.name_en, p.name_ar, p.brand_name, p.brand_name_ar].filter(Boolean).join(" ")
      );
      return hay.includes(q);
    });
    return [...filteredRaw].sort((a, b) => compareEnglish(a, b, 1));
  }, [perfumes, debouncedSearch]);

  return (
    <div className="px-4 pb-4 space-y-3" style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 6px)" }}>
      {/* Header - App branding only */}
      <div className={cn("flex items-center justify-between", isAr && "flex-row-reverse")}>
        <div className="flex items-center gap-2.5">
          <span style={{ color: "var(--brand)" }}><EncyclopediaLogo className="w-7 h-7" /></span>
        </div>
        <div className="flex items-center gap-2">
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      {/* صفّ الحقل القديم — فارغ (نُقل البحث لأسفل الصفحة) */}

      {/* Perfume + Shopping boxes — non-traditional only (they become grid tiles in traditional) */}
      {interfaceStyle !== "traditional" && (
      <div className="grid grid-cols-2 gap-3">
        {/* Perfumes Box - Creative Design */}
        <Link to="/explore" className="group block relative overflow-hidden rounded-none hover:scale-[1.01] transition-all duration-300 border-2 border-transparent">
          {/* subtle pattern overlay */}
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: "radial-gradient(circle at 20% 50%, #fff 1px, transparent 1px), radial-gradient(circle at 80% 20%, #fff 1px, transparent 1px), radial-gradient(circle at 60% 80%, #fff 1px, transparent 1px)",
            backgroundSize: "60px 60px, 80px 80px, 50px 50px"
          }} />
          <div className="relative flex flex-col items-center justify-center py-9 px-6 gap-3">
            <div className="w-16 h-16 border-2 border-transparent rounded-none flex items-center justify-center">
              <BottleWine className="w-10 h-10 text-amber-400" />
            </div>
          </div>
        </Link>

        {linkSettings.stores && (
        <Link to="/shopping" className="group block relative overflow-hidden rounded-none hover:scale-[1.01] transition-all duration-300 border-2 border-transparent">
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: "radial-gradient(circle at 20% 50%, #fff 1px, transparent 1px), radial-gradient(circle at 80% 20%, #fff 1px, transparent 1px), radial-gradient(circle at 60% 80%, #fff 1px, transparent 1px)",
            backgroundSize: "60px 60px, 80px 80px, 50px 50px"
          }} />
          <div className="relative flex flex-col items-center justify-center py-9 px-6 gap-3">
            <div className="w-16 h-16 border-2 border-transparent rounded-none flex items-center justify-center">
              <Wine className="w-10 h-10" style={{ color: "#B76E79" }} />
            </div>
          </div>
        </Link>
        )}
      </div>
      )}

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "color-mix(in srgb, var(--brand) 30%, transparent)", borderTopColor: "var(--brand)" }} />
        </div>
      )}

      {/* Empty collection */}
      {!isLoading && debouncedSearch.trim() && perfumes.length === 0 && (
        <div className="text-center py-16 space-y-4">
          <div className="w-20 h-20 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <Droplets className="w-10 h-10 text-primary/40" />
          </div>
          <div className="space-y-2">
            <h2 className="font-heading text-xl font-semibold">{t('perfumes.startExploring')}</h2>
            <p className="text-muted-foreground text-sm font-body max-w-xs mx-auto">
              {isAr ? 'استخدم القائمة (أعلى اليمين) لإضافة عطرك الأول' : 'Use the menu (top right) to add your first perfume.'}
            </p>
          </div>
          <Link to="/add" className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-none px-5 py-2.5 text-sm font-body font-medium hover:bg-primary/90 transition-colors">
            {t('perfumes.addPerfume')}
          </Link>
        </div>
      )}

      {/* Search results */}
      {!isLoading && search.trim() && (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground font-body">{filtered.length} {isAr ? 'نتيجة' : 'result' + (filtered.length !== 1 ? "s" : "")}</p>
          {filtered.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-8">{isAr ? 'لا توجد عطور' : 'No perfumes found'}</p>
          ) : (
            <Pagination
              items={filtered}
              itemsPerPage={50}
              renderItem={(items) => (
                <div className="grid grid-cols-2 gap-3">
                  {items.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
                </div>
              )}
              emptyMessage="No perfumes found"
            />
          )}
        </div>
      )}

      {/* Sections (no search active) */}
      {!isLoading && !search.trim() && (
        <>

          {/* Favorites + Samples moved below the Glossary box */}

          {/* Traditional uniform 2-per-row grid (includes Perfumes + Stores; Culture stays as its own link below) */}
          {interfaceStyle === "traditional" && (() => {
            const tradLinks = [
              { to: "/explore", icon: Flower2, label: isAr ? 'عطور' : 'Perfumes', color: "text-amber-600 dark:text-amber-400 hover:text-amber-500" },
              linkSettings.lists && { to: "/brands", icon: Tag, label: isAr ? 'ماركات' : 'Brands', color: "text-emerald-800 dark:text-emerald-400 hover:text-emerald-600" },
              { to: "/reaction", icon: Heart, label: isAr ? 'مفضلة' : 'Favorites', color: "text-rose-600 dark:text-rose-400 hover:text-rose-500" },
              linkSettings.stores && { to: "/shopping", icon: Store, label: isAr ? 'متاجر' : 'Stores', color: "text-rose-600 dark:text-rose-400 hover:text-rose-500" },
              linkSettings.blog && { to: "/blog", icon: Newspaper, label: isAr ? 'مدونة' : t('navigation.blog'), color: "text-emerald-500 dark:text-emerald-400 hover:text-emerald-400" },
              linkSettings.budget && { to: "/budget", icon: Wallet, label: isAr ? 'ميزانية' : 'Budget', color: "text-emerald-700 dark:text-emerald-400 hover:text-emerald-500" },
              linkSettings.perfumers && { to: "/perfumers", icon: Weight, label: isAr ? 'مصممين عطور' : 'Perfume Designers', color: "text-pink-700 dark:text-pink-400 hover:text-pink-500" },
              linkSettings.notes && { to: "/notes", icon: Music, label: isAr ? 'نوتات عطرية' : t('navigation.notes'), color: "text-green-700 dark:text-green-400 hover:text-green-500" },
              linkSettings.glossary && { to: "/encyclopedia", icon: Tally4, label: isAr ? 'موسوعة' : 'Encyclopedia', color: "text-stone-700 dark:text-stone-300 hover:text-stone-500" },
              linkSettings.samples && { to: "/samples", icon: FlaskConical, label: isAr ? 'عينات' : t('navigation.samples'), color: "text-lime-700 dark:text-lime-300 hover:text-lime-500" },
              linkSettings.mixer && { to: "/layering", icon: TestTubes, label: isAr ? "مزج" : "The Mixer", color: "text-emerald-700 dark:text-emerald-400 hover:text-emerald-500" },
            ].filter(Boolean);
            return (
              <div className="grid grid-cols-2 gap-x-8 gap-y-6 pt-1">
                {tradLinks.map((lnk, idx) => (
                  <QuickLink key={idx} to={lnk.to} icon={lnk.icon} label={lnk.label} color={lnk.color} />
                ))}
              </div>
            );
          })()}

          {/* Quick links — borderless icon+label, alternating 2 / 1-centered pattern */}
          {interfaceStyle !== "traditional" && (() => {
            const VL = { writingMode: "vertical-rl" };                                  // يسار: أول حرف بالأعلى
            const VR = { writingMode: "vertical-rl", transform: "rotate(180deg)" };      // يمين: أول حرف بالأعلى (الجهة المعكوسة)
            const links = [
              { to: "/reaction",          icon: Heart,        label: isAr ? 'مفضلة' : 'Favorites',                  color: "text-rose-600 dark:text-rose-400 hover:text-rose-500", reverse: true, flip: true },
              linkSettings.lists     && { to: "/brands",                    icon: BrandDiamondsIcon, label: t('navigation.brands'),                       color: "text-emerald-800 dark:text-emerald-400 hover:text-emerald-600", horizontal: true, reverse: true, labelStyle: VL },
              linkSettings.blog      && { to: "/blog",                      icon: Turtle,        label: isAr ? 'مدونة' : t('navigation.blog'),            color: "text-emerald-500 dark:text-emerald-400 hover:text-emerald-400", horizontal: true, iconClassName: "-rotate-90", labelStyle: VR },
              linkSettings.budget  && { to: "/budget",                  icon: GlossaryDots,label: isAr ? 'ميزانية' : 'Budget',                      color: "text-emerald-700 dark:text-emerald-400 hover:text-emerald-500", horizontal: true },
              linkSettings.perfumers && { to: "/perfumers",                 icon: AccordPaletteIcon,  label: isAr ? 'سحر و سحرة' : 'Magic & Magician',      color: "text-pink-700 dark:text-pink-400 hover:text-pink-500", horizontal: true, reverse: true, labelStyle: VL },
              linkSettings.notes     && { to: "/notes",                     icon: Music,       label: isAr ? 'نوتات عطرية' : t('navigation.notes'),     color: "text-green-700 dark:text-green-400 hover:text-green-500", horizontal: true, iconClassName: "-rotate-90", labelStyle: VR },
              linkSettings.glossary && { to: "/encyclopedia",        icon: Tally4,  label: isAr ? 'موسوعة' : 'Encyclopedia',                          color: "text-stone-700 dark:text-stone-300 hover:text-stone-500", horizontal: true },
              linkSettings.quotes    && { to: "/shopping",                    icon: StoreFrontIcon,    label: isAr ? 'متاجر' : 'Store',                      color: "text-indigo-700 dark:text-indigo-400 hover:text-indigo-500", horizontal: true, reverse: true, iconClassName: "rotate-90", labelStyle: VL },
              linkSettings.wisdom    && { to: "/explore",         icon: GoldenStone, label: isAr ? 'عطور' : 'Perfumes',    color: "text-amber-700 dark:text-amber-400 hover:text-amber-500", horizontal: true, iconClassName: "-rotate-90", labelStyle: VR },
              linkSettings.samples && { to: "/samples",        icon: SprayCan,  label: isAr ? 'عينات' : t('navigation.samples'),         color: "text-lime-700 dark:text-lime-300 hover:text-lime-500", horizontal: true, reverse: true },
              linkSettings.mixer     && { to: "/layering",                  icon: SunSnow,       label: isAr ? 'مزج' : 'The Mixer',                       color: "text-emerald-700 dark:text-emerald-400 hover:text-emerald-500", horizontal: true, iconClassName: "-rotate-90", labelStyle: VR },
            ].filter(Boolean);

            // Build alternating rows: 1 (centered), 2, 1, 2, ... starting centered
            const rows = [];
            let i = 0, two = false;
            while (i < links.length) {
              if (two) { rows.push(links.slice(i, i + 2)); i += 2; }
              else     { rows.push(links.slice(i, i + 1)); i += 1; }
              two = !two;
            }

            return (
              <div dir="ltr" className="flex flex-col gap-6 pt-1">
                {rows.map((row, idx) => (
                  <div
                    key={idx}
                    className={row.length === 2 ? "flex justify-center items-center gap-12" : "flex justify-center"}
                  >
                    {row.map((lnk, j) => (
                      <QuickLink key={`${idx}-${j}`} to={lnk.to} icon={lnk.icon} label={lnk.label} color={lnk.color} iconClassName={lnk.iconClassName} labelStyle={lnk.labelStyle} reverse={lnk.reverse} flip={lnk.flip} horizontal={lnk.horizontal} decorative={lnk.decorative} />
                    ))}
                  </div>
                ))}
              </div>
            );
          })()}

          {/* Lists / The Mixer / Budget moved into the quick-links grid above */}

          {linkSettings.culture && (
          <Link to="/perfume-culture" className="flex items-center justify-between px-4 py-2 hover:opacity-80 transition-opacity bg-transparent">
            <div className="flex items-center gap-3">
              <Axe className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
              <p className="text-sm font-body font-semibold text-blue-600 dark:text-blue-400">{isAr ? 'ثقافة، قواعد & آداب' : 'Culture, Rules & Courtesy'}</p>
            </div>
          </Link>
          )}

           </>
           )}

          {/* صفّان فارغان ثم حقل البحث — أسفل الصفحة، في الواجهتين (بعد رابط الثقافة) */}
          <div className="h-8" aria-hidden="true" />
          <div className="relative flex items-center h-10 bg-[var(--page-bg,#fff)]" dir="ltr">
            <div aria-hidden="true" className="w-px h-5 mx-3 flex-shrink-0" style={{ background: "var(--brand)" }} />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="" dir={isAr ? "rtl" : "ltr"} className="flex-1 h-10 bg-transparent outline-none font-body text-sm px-1" />
            <span className="px-3 flex-shrink-0"><Search className="w-4 h-4" style={{ color: "var(--brand)" }} /></span>
          </div>

          </div>
          );
          }

function PersonSection({ title, person, personName, count, linkTo, children }) {
  const { isAr } = useLang();
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-none ${person === "person2" ? "bg-violet-500" : "bg-primary"}`} />
          <div>
            <h2 className="font-heading text-base font-semibold">{isAr ? `${title} ${personName}` : `${personName}'s ${title}`}</h2>
            <p className="text-xs text-muted-foreground font-body">{count} {isAr ? 'عنصر' : 'items'}</p>
          </div>
        </div>
        <Link to={linkTo} className="text-primary text-sm font-body hover:underline">
          {isAr ? 'عرض الكل' : 'See all'}
        </Link>
      </div>
      {children}
    </div>
  );
}

function Section({ title, linkTo, children }) {
  const { isAr } = useLang();
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-lg font-semibold">{title}</h2>
        <Link to={linkTo} className="text-primary text-sm font-body hover:underline">
          {isAr ? 'عرض الكل' : 'See all'}
        </Link>
      </div>
      {children}
    </div>
  );
}
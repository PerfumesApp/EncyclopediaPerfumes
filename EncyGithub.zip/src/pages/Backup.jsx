import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { Download, Upload, AlertCircle, Lock, Eye, EyeOff, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { downloadBlob } from "@/lib/exportHelper";
import { encryptBackup, decryptBackup, isEncryptedBackup } from "@/lib/backupCrypto";
import { toast } from "sonner";
import BackIcon from "@/components/shared/BackIcon";

export default function Backup() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const queryClient = useQueryClient();
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  // Mandatory password for encrypted backup (export & restore are never plaintext)
  const [exportPassword, setExportPassword] = useState("");
  const [exportPasswordConfirm, setExportPasswordConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const MIN_PW = 6;
  const pwValid = exportPassword.length >= MIN_PW && exportPassword === exportPasswordConfirm;
  // Holds a parsed-but-locked encrypted file awaiting a password to restore
  const [pendingEncrypted, setPendingEncrypted] = useState(null);
  const [importPassword, setImportPassword] = useState("");

  // User data - Only current user's data (auto-filtered via RLS)
  const { data: userPerfumes = [] } = useQuery({ queryKey: ["user-perfumes"], queryFn: () => apphost.entities.UserPerfume.list("-created_date") });
  const { data: wearLogs = [] } = useQuery({ queryKey: ["wear-logs"], queryFn: () => apphost.entities.WearLog.list("-date") });
  const { data: layers = [] } = useQuery({ queryKey: ["layers"], queryFn: () => apphost.entities.PerfumeLayer.list("-created_date") });
  const { data: posts = [] } = useQuery({ queryKey: ["blog-posts"], queryFn: () => apphost.entities.BlogPost.list("-created_date") });
  const { data: wishlist = [] } = useQuery({ queryKey: ["wishlist"], queryFn: () => apphost.entities.Wishlist.list() });
  const { data: userBrands = [] } = useQuery({ queryKey: ["user-brands"], queryFn: () => apphost.entities.UserBrand.list() });
  const { data: goals = [] } = useQuery({ queryKey: ["goals"], queryFn: () => apphost.entities.Goal.list() });
  const { data: budgetExpenses = [] } = useQuery({ queryKey: ["budget-expenses"], queryFn: () => apphost.entities.BudgetExpense.list() });
  const { data: budgetIncomes = [] } = useQuery({ queryKey: ["budget-incomes"], queryFn: () => apphost.entities.BudgetIncome.list() });
  const { data: purchaseRecords = [] } = useQuery({ queryKey: ["purchase-records"], queryFn: () => apphost.entities.PurchaseRecord.list() });
  const { data: shopProducts = [] } = useQuery({ queryKey: ["shop-products"], queryFn: () => apphost.entities.ShopProduct.list() });
  const { data: moodEntries = [] } = useQuery({ queryKey: ["mood-entries"], queryFn: () => apphost.entities.MoodEntry.list() });

  // Built-in database
  const { data: perfumes = [] } = useAllPerfumes("-created_date");
  const { data: brands = [] } = useQuery({ queryKey: ["brands"], queryFn: () => apphost.entities.PerfumeBrand.list() });
  const { data: perfumers = [] } = useQuery({ queryKey: ["perfumers"], queryFn: () => apphost.entities.Perfumer.list() });
  const { data: notes = [] } = useQuery({ queryKey: ["notes"], queryFn: () => apphost.entities.PerfumeNote.list() });
  const { data: collections = [] } = useQuery({ queryKey: ["collections"], queryFn: () => apphost.entities.PerfumeCollection.list() });
  const { data: quotes = [] } = useQuery({ queryKey: ["quotes"], queryFn: () => apphost.entities.Quote.list() });
  const { data: glossary = [] } = useQuery({ queryKey: ["glossary"], queryFn: () => apphost.entities.GlossaryTerm.list() });
  const { data: stores = [] } = useQuery({ queryKey: ["stores"], queryFn: () => apphost.entities.Store.list() });
  const { data: shopBrands = [] } = useQuery({ queryKey: ["shop-brands"], queryFn: () => apphost.entities.ShopBrand.list() });
  const { data: shopCategories = [] } = useQuery({ queryKey: ["shop-categories"], queryFn: () => apphost.entities.ShopCategory.list() });
  const { data: wisdom = [] } = useQuery({ queryKey: ["wisdom"], queryFn: () => apphost.entities.Wisdom.list() });

  const handleExport = async () => {
    if (!pwValid) {
      toast.error(isAr ? `كلمة السرّ مطلوبة (${MIN_PW} أحرف على الأقل) و يجب أن تتطابق` : `Password is required (min ${MIN_PW} chars) and must match`);
      return;
    }
    setExporting(true);
    try {
      // ---- gather EVERY user-input entity (nothing left behind) ----
      const fetchAll = (ent) => apphost.entities[ent].list().then((r) => r || []).catch(() => []);
      const [
        userGlossary, userQuotes, userWisdom, wearSchedules,
        budgetObligations, recurringExpenses, savingsGoals,
        bookmarks, shopQuotes, brandServices, assets,
        customLayers, customLists, customPerfumes, symbolism,
      ] = await Promise.all([
        fetchAll("UserGlossaryTerm"), fetchAll("UserQuote"), fetchAll("UserWisdom"), fetchAll("WearSchedule"),
        fetchAll("BudgetObligation"), fetchAll("RecurringExpense"), fetchAll("SavingsGoal"),
        fetchAll("Bookmark"), fetchAll("ShopQuote"), fetchAll("BrandService"), fetchAll("Asset"),
        fetchAll("CustomLayer"), fetchAll("CustomList"), fetchAll("CustomPerfume"), fetchAll("PerfumeSymbolism"),
      ]);

      const user_data = {
        userPerfumes, userBrands, userGlossary, userQuotes, userWisdom,
        wearLogs, wearSchedules, purchaseRecords, wishlist, layers,
        goals, moodEntries, posts, bookmarks,
        budgetExpenses, budgetIncomes, budgetObligations, recurringExpenses, savingsGoals,
        shopProducts, stores, shopBrands, shopCategories, shopQuotes, brandServices, assets,
        collections, customLayers, customLists, customPerfumes,
      };

      // ---- referenced reference entities (only what the user touched) + user-added (is_user) ----
      const isU = (r) => !!r && (r.is_user === 1 || r.is_user === true || r.is_user === "1");
      const pid = new Set(); const bid = new Set(); const bname = new Set();
      for (const rows of Object.values(user_data)) {
        if (!Array.isArray(rows)) continue;
        for (const r of rows) {
          if (!r) continue;
          if (r.perfume_id != null) pid.add(String(r.perfume_id));
          if (r.linked_perfume_id != null) pid.add(String(r.linked_perfume_id));
          if (r.brand_id != null) bid.add(String(r.brand_id));
          if (r.brand_name) bname.add(String(r.brand_name));
        }
      }
      const refPerfumes = perfumes.filter((pp) => pid.has(String(pp.id)) || isU(pp));
      for (const pp of refPerfumes) { if (pp.brand_id != null) bid.add(String(pp.brand_id)); if (pp.brand_name) bname.add(String(pp.brand_name)); }
      const refBrands = brands.filter((b) => bid.has(String(b.id)) || bname.has(String(b.name)) || bname.has(String(b.name_en)) || isU(b));

      // person identity (the extra distinguishing mechanism) — from localStorage
      let persons = {};
      try {
        persons = {
          names: JSON.parse(localStorage.getItem("perfume_person_names") || "null"),
          profiles: JSON.parse(localStorage.getItem("perfume_person_profiles") || "null"),
        };
      } catch { persons = {}; }

      // unique id per backup — lets the app tell two snapshots apart (also in filename)
      const backupId = (typeof crypto !== "undefined" && crypto.randomUUID)
        ? crypto.randomUUID()
        : (Date.now().toString(36) + Math.random().toString(36).slice(2, 8));

      const backup = {
        process_app_backup: true,
        version: "3.0",
        backup_id: backupId,
        exported_at: new Date().toISOString(),
        persons,
        counts: {
          perfumes: refPerfumes.length, brands: refBrands.length,
          user: Object.values(user_data).reduce((sum, a) => sum + (Array.isArray(a) ? a.length : 0), 0),
        },
        user_data,
        reference: {
          perfumes: refPerfumes,
          brands: refBrands,
          perfumers: perfumers.filter(isU),
          notes: notes.filter(isU),
          glossary: glossary.filter(isU),
          quotes: quotes.filter(isU),
          wisdom: wisdom.filter(isU),
          symbolism: symbolism.filter(isU),
        },
      };

      // Password is mandatory — the backup is always encrypted (never plaintext).
      const fileObject = await encryptBackup(backup, exportPassword);
      const suffix = "-encrypted";

      const blob = new Blob([JSON.stringify(fileObject, null, 2)], { type: "application/json" });
      await downloadBlob(blob, `process-app-backup${suffix}-${new Date().toISOString().split("T")[0]}-${backupId.slice(0, 8)}.json`, { toDownload: true });
      toast.success(isAr ? "تم تنزيل النسخة المشفّرة!" : "Encrypted backup downloaded!");
      setExportPassword(""); setExportPasswordConfirm("");
    } catch (e) {
      toast.error(isAr ? "فشل التصدير" : "Export failed");
    } finally {
      setExporting(false);
    }
  };

  // Insert rows preserving original ids (keeps every relationship intact:
  // perfume_id, brand_id, user_perfume_id…). Skips ids that already exist
  // (e.g. a re-seeded catalog) so restore is safe whether the DB is empty or seeded.
  const restoreEntity = async (entity, rows) => {
    if (!Array.isArray(rows) || rows.length === 0) return 0;
    let existing = new Set();
    try {
      const ids = rows.map((r) => String(r?.id)).filter(Boolean);
      const found = await apphost.entities[entity].getMany(ids);
      existing = new Set((found || []).map((f) => String(f.id)));
    } catch { /* getMany unavailable → treat as empty (clean install) */ }
    const toAdd = [];
    for (const r of rows) {
      if (!r) continue;
      if (existing.has(String(r.id))) continue; // already present — avoid duplicate/collision
      const idNum = Number(r.id);
      if (Number.isFinite(idNum) && String(idNum) === String(r.id)) toAdd.push({ ...r, id: idNum });
      else { const { id, ...rest } = r; toAdd.push(rest); }
    }
    if (!toAdd.length) return 0;
    try { await apphost.entities[entity].bulkCreate(toAdd); return toAdd.length; }
    catch (err) { console.error(`Restore failed for ${entity}`, err); return 0; }
  };

  // Writes a parsed (already-decrypted) backup payload into the local database.
  const restorePayload = async (backup) => {
    // 1) person identity first (names + profiles) — the distinguishing mechanism
    try {
      if (backup.persons?.names) localStorage.setItem("perfume_person_names", JSON.stringify(backup.persons.names));
      if (backup.persons?.profiles) localStorage.setItem("perfume_person_profiles", JSON.stringify(backup.persons.profiles));
    } catch { /* noop */ }

    let restored = 0;

    // 2) reference entities first (so foreign keys resolve), ids preserved
    const ref = backup.reference || {};
    restored += await restoreEntity("Perfume", ref.perfumes);
    restored += await restoreEntity("PerfumeBrand", ref.brands);
    restored += await restoreEntity("Perfumer", ref.perfumers);
    restored += await restoreEntity("PerfumeNote", ref.notes);
    restored += await restoreEntity("GlossaryTerm", ref.glossary);
    restored += await restoreEntity("Quote", ref.quotes);
    restored += await restoreEntity("Wisdom", ref.wisdom);
    restored += await restoreEntity("PerfumeSymbolism", ref.symbolism);

    // 3) all user data (ids preserved to keep intra-references like user_perfume_id)
    const ud = backup.user_data || {};
    const UD = [
      ["UserPerfume", ud.userPerfumes], ["UserBrand", ud.userBrands], ["UserGlossaryTerm", ud.userGlossary],
      ["UserQuote", ud.userQuotes], ["UserWisdom", ud.userWisdom],
      ["WearLog", ud.wearLogs], ["WearSchedule", ud.wearSchedules], ["PurchaseRecord", ud.purchaseRecords],
      ["Wishlist", ud.wishlist], ["PerfumeLayer", ud.layers], ["Goal", ud.goals], ["MoodEntry", ud.moodEntries],
      ["BlogPost", ud.posts], ["Bookmark", ud.bookmarks],
      ["BudgetExpense", ud.budgetExpenses], ["BudgetIncome", ud.budgetIncomes], ["BudgetObligation", ud.budgetObligations],
      ["RecurringExpense", ud.recurringExpenses], ["SavingsGoal", ud.savingsGoals],
      ["ShopProduct", ud.shopProducts], ["Store", ud.stores], ["ShopBrand", ud.shopBrands], ["ShopCategory", ud.shopCategories],
      ["ShopQuote", ud.shopQuotes], ["BrandService", ud.brandServices], ["Asset", ud.assets],
      ["PerfumeCollection", ud.collections], ["CustomLayer", ud.customLayers], ["CustomList", ud.customLists], ["CustomPerfume", ud.customPerfumes],
    ];
    for (const [entity, rows] of UD) restored += await restoreEntity(entity, rows);
    return restored;
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);

      // Encrypted file? Hold it and ask for the password (separate UI step).
      if (isEncryptedBackup(parsed)) {
        setPendingEncrypted(parsed);
        setImportPassword("");
        toast.info(isAr ? "هذه نسخة مشفّرة — أدخل كلمة السرّ لاستعادتها." : "Encrypted backup — enter the password to restore.");
        return;
      }

      // No restore without a password: reject any non-encrypted backup.
      toast.error(isAr ? "لا استرداد بدون كلمة سرّ — هذه النسخة غير مشفّرة. تُقبل النسخ المشفّرة فقط." : "No restore without a password — this backup is not encrypted. Only password-protected backups are accepted.");
    } catch (err) {
      toast.error(isAr ? "ملف النسخة غير صالح" : "Invalid backup file");
    } finally {
      setImporting(false);
      e.target.value = "";
    }
  };

  // Decrypt the held encrypted file with the entered password, then restore.
  const handleDecryptAndRestore = async () => {
    if (!pendingEncrypted || !importPassword) return;
    setImporting(true);
    try {
      const backup = await decryptBackup(pendingEncrypted, importPassword);
      const count = await restorePayload(backup);
      await queryClient.invalidateQueries();
      toast.success(isAr ? `تمت استعادة ${count} سجلّ بنجاح.` : `Restored ${count} records successfully.`);
      setPendingEncrypted(null);
      setImportPassword("");
    } catch (err) {
      if (err.code === "WRONG_PASSWORD") {
        toast.error(isAr ? "كلمة السرّ غير صحيحة. حاول مرّة أخرى." : "Wrong password. Please try again.");
      } else {
        toast.error(isAr ? "تعذّر فكّ تشفير الملف" : "Could not decrypt the file");
      }
    } finally {
      setImporting(false);
    }
  };

  const userDataTotal = userPerfumes.length + wearLogs.length + layers.length + posts.length + wishlist.length + userBrands.length + goals.length + budgetExpenses.length + budgetIncomes.length + purchaseRecords.length + shopProducts.length + moodEntries.length;
  const builtinDataTotal = perfumes.length + brands.length + perfumers.length + notes.length + collections.length + quotes.length + glossary.length + stores.length + shopBrands.length + shopCategories.length + wisdom.length;
  const totalRecords = userDataTotal + builtinDataTotal;

  return (
    <div className={`px-4 page-top pb-8 space-y-6 ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="rounded-none" onClick={() => navigate(-1)}>
          <BackIcon className={`w-5 h-5`} />
        </Button>
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>{isAr ? "النسخ الاحتياطية و الاستعادة" : "Backup & Restore"}</h1>
      </div>

      {/* Summary - User Data */}
      <div className="py-4 space-y-4" style={{ borderBottom: "1px solid rgba(200,160,46,0.4)" }}>
        <div className="flex items-center gap-3">
          <div>
            <p className="font-heading font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "بيانات حسابك الشخصية" : "Your Personal Data"}</p>
            <p className="text-xs text-muted-foreground font-body">{userDataTotal} {isAr ? "سجل إجمالي" : "total records"}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {[
            { label_en: "Collections", label_ar: "الكلكشن الخاصة بك", count: userPerfumes.length },
            { label_en: "Wear Logs", label_ar: "سجل الاستخدام", count: wearLogs.length },
            { label_en: "Layers", label_ar: "المزج و الطبقات", count: layers.length },
            { label_en: "Journal", label_ar: "دفتر اليوميات", count: posts.length },
            { label_en: "Wishlist", label_ar: "قائمة الأمنيات", count: wishlist.length },
            { label_en: "Brand Reviews", label_ar: "تقييمات الماركات", count: userBrands.length },
            { label_en: "Goals", label_ar: "الأهداف", count: goals.length },
            { label_en: "Budget", label_ar: "الميزانية", count: budgetExpenses.length + budgetIncomes.length },
            { label_en: "Purchases", label_ar: "المشتريات", count: purchaseRecords.length + shopProducts.length },
            { label_en: "Mood", label_ar: "المزاج", count: moodEntries.length },
          ].map(({ label_en, label_ar, count }) => (
            <div key={label_en} className="px-1 py-2" style={{ borderBottom: "1px solid #f0ece2" }}>
              <p className="text-lg font-heading font-bold" style={{ color: "var(--brand)" }}>{count}</p>
              <p className="text-[11px] text-muted-foreground font-body">{isAr ? label_ar : label_en}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Summary - Built-in Database */}
      <div className="py-4 space-y-4" style={{ borderBottom: "1px solid rgba(200,160,46,0.4)" }}>
        <div className="flex items-center gap-3">
          <div>
            <p className="font-heading font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "قاعدة البيانات المدمجة" : "Built-in Database"}</p>
            <p className="text-xs text-muted-foreground font-body">{builtinDataTotal} {isAr ? "سجل إجمالي" : "total records"}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {[
            { label_en: "Perfumes", label_ar: "العطور", count: perfumes.length },
            { label_en: "Brands", label_ar: "الماركات", count: brands.length },
            { label_en: "Perfumers", label_ar: "العطارون", count: perfumers.length },
            { label_en: "Notes", label_ar: "النوتات", count: notes.length },
            { label_en: "Collections", label_ar: "المجموعات", count: collections.length },
            { label_en: "Stores", label_ar: "المتاجر", count: stores.length + shopBrands.length },
            { label_en: "Categories", label_ar: "التصنيفات", count: shopCategories.length },
          ].map(({ label_en, label_ar, count }) => (
            <div key={label_en} className="px-1 py-2" style={{ borderBottom: "1px solid #f0ece2" }}>
              <p className="text-lg font-heading font-bold" style={{ color: "var(--brand)" }}>{count}</p>
              <p className="text-[11px] text-muted-foreground font-body">{isAr ? label_ar : label_en}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Export */}
      <div className="py-4 space-y-3" style={{ borderBottom: "1px solid rgba(200,160,46,0.4)" }}>
        <div className="flex items-center gap-3 mb-1">
          <Download className="w-4 h-4 text-primary" />
          <h2 className="font-heading font-semibold">{isAr ? "تصدير النسخة الاحتياطية الكاملة" : "Export Complete Backup"}</h2>
        </div>
        <p className="text-sm font-body text-muted-foreground">
          {isAr
            ? "نسخةٌ مشفّرةٌ قائمةٌ بذاتها: بياناتك الشخصية + فقط العطور و البراندات و العطّارون الذين تفاعلتَ معهم أو أضفتَهم (مع روابطهم) + إضافاتك + ملفّات الأشخاص. لا يُنسَخ الكتالوج المرجعيّ الكامل لأنّه يُعاد بناؤه عند التنصيب. تُستعاد على نسخةٍ نظيفة بلا قاعدة."
            : "A self-contained encrypted snapshot: your personal data + only the perfumes, brands, and perfumers you touched or added (with their relationships) + your additions + person profiles. The full reference catalog is NOT included — it is rebuilt on install. Restores on a clean install with no database."}
        </p>
        <div className="space-y-2 text-xs text-muted-foreground font-body rounded-none ">
          <p><strong>{isAr ? "يتضمن:" : "Includes:"}</strong></p>
          <ul className="list-disc list-inside space-y-0.5">
            <li><strong>{isAr ? "بياناتك:" : "Your Data:"}</strong> {isAr ? "التقييمات، الارتداء والجدولة، المشتريات، الرغبات، الأهداف، الميزانية (لكلّ شخص/العائلة)، المزاج، القوائم، الطبقات، التدوينات، النوتبوك" : "Ratings, wear & schedule, purchases, wishlist, goals, budget (per-person/family), mood, lists, layers, blog, notebook"}</li>
            <li><strong>{isAr ? "العطور المرتبطة:" : "Linked perfumes:"}</strong> {isAr ? "فقط العطور و البراندات و العطّارون الذين قيّمتَهم/اشتريتَهم/أضفتَهم — بمعرّفاتهم و روابطهم" : "Only the perfumes, brands & perfumers you rated/bought/added — with their ids & relationships"}</li>
            <li><strong>{isAr ? "إضافاتك:" : "Your additions:"}</strong> {isAr ? "ما أضفتَه يدويًّا من عطور/براندات/نوتات/قصص/اقتباسات/حِكَم/رمزيّات" : "Anything you manually added: perfumes, brands, notes, stories, quotes, wisdom, symbolism"}</li>
            <li><strong>{isAr ? "التسوّق:" : "Shopping:"}</strong> {isAr ? "المتاجر و براندات المتاجر و الفئات و المنتجات" : "Stores, shop brands, categories, and products"}</li>
            <li><strong>{isAr ? "الأشخاص:" : "Persons:"}</strong> {isAr ? "أسماء و ألوان و صور الملفّات الشخصية (تمييز person1/person2)" : "Profile names, colors & photos (person1/person2 distinction)"}</li>
          </ul>
        </div>

        {/* Mandatory password protection */}
        <div className="space-y-2 pt-1">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-primary" />
            <label className="text-sm font-body font-medium">
              {isAr ? "حماية بكلمة السرّ (مطلوبة)" : "Password protection (required)"}
            </label>
          </div>
          <div className="relative">
            <input name="Backup-1"
              type={showPassword ? "text" : "password"}
              value={exportPassword}
              onChange={(e) => setExportPassword(e.target.value)}
              placeholder={isAr ? `كلمة السرّ (${MIN_PW} أحرف على الأقل)` : `Password (min ${MIN_PW} chars)`}
              className={`w-full h-11 rounded-none border border-border bg-background px-3 ${isAr ? "pl-10 text-right" : "pr-10"} text-sm font-body focus:outline-none focus:ring-2 focus:ring-primary/40`}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className={`absolute top-1/2 -translate-y-1/2 ${isAr ? "left-3" : "right-3"} text-muted-foreground hover:text-foreground`}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <input name="Backup-2"
            type={showPassword ? "text" : "password"}
            value={exportPasswordConfirm}
            onChange={(e) => setExportPasswordConfirm(e.target.value)}
            placeholder={isAr ? "تأكيد كلمة السرّ" : "Confirm password"}
            className={`w-full h-11 rounded-none border bg-background px-3 ${isAr ? "text-right" : ""} text-sm font-body focus:outline-none focus:ring-2 focus:ring-primary/40 ${exportPasswordConfirm && exportPassword !== exportPasswordConfirm ? "border-red-400" : "border-border"}`}
          />
          {exportPasswordConfirm && exportPassword !== exportPasswordConfirm && (
            <p className="text-xs font-body text-red-600">{isAr ? "كلمتا السرّ غير متطابقتين" : "Passwords do not match"}</p>
          )}
          <div className="bg-red-50 border border-red-200 rounded-none px-4 py-3 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs font-body text-red-700">
              {isAr
                ? "احفظ كلمة السرّ في مكان آمن. التطبيق محلّيّ بالكامل بلا خادم، فإذا نسيتها لن تتمكّن أنت ولا أيّ أحد من استعادة هذه النسخة نهائيّاً. يُشتقّ مفتاح التشفير من كلمة السرّ نفسها (لا من الجهاز)، فتستطيع الاستعادة على أيّ جهاز جديد بتنصيب جديد بكلمة السرّ فقط."
                : "Keep this password safe. The app is fully local with no server, so if you forget it, neither you nor anyone can ever recover this backup. The encryption key is derived from the password itself (not the device), so you can restore on any brand-new device with just the password."}
            </p>
          </div>
        </div>

        <Button className="w-full h-11 rounded-none font-body gap-2" onClick={handleExport} disabled={exporting || !pwValid}>
          {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
          {exporting
            ? (isAr ? "جارٍ تجهيز النسخة... قد يستغرق لحظات للبيانات الكبيرة" : "Preparing backup... may take a moment for large data")
            : (isAr ? "تنزيل نسخة مشفّرة" : "Download Encrypted Backup")}
        </Button>
      </div>

      {/* Import */}
      <div className="py-4 space-y-3" style={{ borderBottom: "1px solid rgba(200,160,46,0.4)" }}>
        <div className="flex items-center gap-3 mb-1">
          <Upload className="w-4 h-4 text-primary" />
          <h2 className="font-heading font-semibold">{isAr ? "استعادة من نسخة احتياطية" : "Restore from Backup"}</h2>
        </div>
        <p className="text-sm font-body text-muted-foreground">
          {isAr ? "قم برفع ملف نسخة احتياطية تم تصديره مسبقاً لاستعادة بياناتك." : "Upload a previously exported backup file to restore your data."}
        </p>
        <div className="bg-amber-50 border border-amber-200 rounded-none px-4 py-3 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs font-body text-amber-700">
            {isAr
              ? "سيتم إضافة البيانات فوق السجلات الموجودة. قد تظهر إدخالات مكررة."
              : "Restore will add data on top of existing records. Duplicate entries may appear."}
          </p>
        </div>
        <label className="w-full">
          <input type="file" accept=".json" className="hidden" onChange={handleImport} disabled={importing} />
          <div className="w-full h-11 rounded-none font-body border-2 border-dashed border-border flex items-center justify-center gap-2 text-sm text-muted-foreground hover:border-primary hover:text-primary cursor-pointer transition-colors">
            <Upload className="w-4 h-4" />
            {importing ? (isAr ? "جاري قراءة الملف.." : "Reading file..") : (isAr ? "اختر ملف النسخة الاحتياطية" : "Choose Backup File")}
          </div>
        </label>

        {/* Encrypted file: ask for password before restoring */}
        {pendingEncrypted && (
          <div className="bg-secondary/40 border border-primary/30 rounded-none p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-primary" />
              <p className="text-sm font-body font-medium">
                {isAr ? "نسخة مشفّرة — أدخل كلمة السرّ" : "Encrypted backup — enter password"}
              </p>
            </div>
            <input name="Backup-3"
              type="password"
              value={importPassword}
              onChange={(e) => setImportPassword(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") handleDecryptAndRestore(); }}
              placeholder={isAr ? "كلمة السرّ" : "Password"}
              className={`w-full h-11 rounded-none border border-border bg-background px-3 text-sm font-body ${isAr ? "text-right" : ""} focus:outline-none focus:ring-2 focus:ring-primary/40`}
              autoFocus
            />
            <div className="flex gap-2">
              <Button className="flex-1 h-10 rounded-none font-body gap-2" onClick={handleDecryptAndRestore} disabled={importing || !importPassword}>
                <Lock className="w-4 h-4" />
                {importing ? (isAr ? "جاري الاستعادة.." : "Restoring..") : (isAr ? "فكّ التشفير و الاستعادة" : "Decrypt & Restore")}
              </Button>
              <Button variant="ghost" className="h-10 rounded-none font-body" onClick={() => { setPendingEncrypted(null); setImportPassword(""); }} disabled={importing}>
                {isAr ? "إلغاء" : "Cancel"}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
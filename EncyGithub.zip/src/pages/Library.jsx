import { useRef, useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Upload, BookOpen, Trash2, FolderUp } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { listBookFiles, importBookFiles, deleteBookFile } from "@/lib/libraryFiles";
import BackIcon from "@/components/shared/BackIcon";

// «كتبي» — أرشفة كتب الجهاز (PDF/EPUB) كمدخلات منفردة داخل التطبيق، وفتحها في
// القارئ الداخلي. زرّ واحد يفتح منتقي ملفات الجهاز (اختيار متعدّد) فيؤرشف كل ملف
// مختار ككتاب مستقل يظهر هنا وفي قسم «مكتبة» بالموسوعة.
export default function Library() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const inputRef = useRef(null);
  const folderRef = useRef(null);
  const [books, setBooks] = useState([]);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");

  const refresh = useCallback(async () => {
    try { setBooks(await listBookFiles()); } catch { setBooks([]); }
  }, []);
  useEffect(() => { refresh(); }, [refresh]);

  const onPick = async (e) => {
    const files = e.target.files;
    if (!files || !files.length) return;
    setBusy(true); setNote("");
    try {
      const n = await importBookFiles(files);
      setNote(isAr ? `أُضيف ${n} كتاباً` : `${n} book(s) added`);
      await refresh();
    } catch {
      setNote(isAr ? "تعذّرت الإضافة" : "Import failed");
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  // إضافة مجلّد كامل: نرشّح ملفّات المجلّد إلى PDF/EPUB ثمّ نؤرشفها كلّها مهما كان العدد
  const onPickFolder = async (e) => {
    const all = Array.from(e.target.files || []);
    const books = all.filter((f) => /\.(pdf|epub)$/i.test(f.name || ""));
    if (!books.length) { setNote(isAr ? "لا كتب PDF أو EPUB في المجلّد" : "No PDF/EPUB books in the folder"); if (folderRef.current) folderRef.current.value = ""; return; }
    setBusy(true); setNote("");
    try {
      const n = await importBookFiles(books);
      setNote(isAr ? `أُضيف ${n} كتاباً من المجلّد` : `${n} book(s) added from folder`);
      await refresh();
    } catch {
      setNote(isAr ? "تعذّرت إضافة المجلّد" : "Folder import failed");
    } finally {
      setBusy(false);
      if (folderRef.current) folderRef.current.value = "";
    }
  };

  const onDelete = async (id) => {
    try { await deleteBookFile(id); await refresh(); } catch { /* تجاهل */ }
  };

  return (
    <div className="px-5 page-top pb-24" dir={isAr ? "rtl" : "ltr"}>
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => navigate(-1)} className="w-9 h-9 flex items-center justify-center hover:opacity-70" aria-label={isAr ? "رجوع" : "Back"}>
          <BackIcon className={`w-5 h-5`} style={{ color: "var(--brand)" }} />
        </button>
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>{isAr ? "كتبي" : "My Books"}</h1>
      </div>

      <input ref={inputRef} type="file" accept=".pdf,.epub,application/pdf,application/epub+zip" multiple onChange={onPick} className="hidden" />
      <input ref={folderRef} type="file" webkitdirectory="" directory="" multiple onChange={onPickFolder} className="hidden" />

      <button type="button" onClick={() => inputRef.current?.click()} disabled={busy}
        className="flex items-center gap-2 py-2 mb-1 font-body text-sm font-semibold hover:opacity-70 disabled:opacity-50"
        style={{ color: "var(--brand)" }}>
        <Upload className="w-4 h-4" />
        {busy ? (isAr ? "جارٍ الأرشفة.." : "Archiving..") : (isAr ? "أضف كتباً من الجهاز (PDF / EPUB)" : "Add books from device (PDF / EPUB)")}
      </button>

      <button type="button" onClick={() => folderRef.current?.click()} disabled={busy}
        className="flex items-center gap-2 py-2 mb-1 font-body text-sm font-semibold hover:opacity-70 disabled:opacity-50"
        style={{ color: "var(--brand)" }}>
        <FolderUp className="w-4 h-4" />
        {busy ? (isAr ? "جارٍ الأرشفة.." : "Archiving..") : (isAr ? "أضف مجلّداً كاملاً بكتبه" : "Add a whole folder of books")}
      </button>
      <p className="text-[11px] font-body text-muted-foreground mb-5">
        {isAr ? "اختر عدّة كتب دفعةً واحدة، أو أضف مجلّداً كاملاً فتُؤرشَف كلّ كتبه (PDF و EPUB) مهما كان عددها. كلّ كتاب مدخل مستقل يُفتح في القارئ مع حفظ موضع التوقّف" : "Pick several books at once, or add a whole folder to archive all its PDF/EPUB books regardless of count. Each book is its own entry, opens in the reader, and remembers where you stopped"}
      </p>
      {note && <p className="text-xs font-body mb-3" style={{ color: "var(--brand)" }}>{note}</p>}

      {books.length === 0 ? (
        <p className="text-xs font-body text-muted-foreground py-8 text-center">{isAr ? "لا كتب بعد — أضف أول كتاب" : "No books yet — add your first"}</p>
      ) : (
        <div className="space-y-3">
          {books.map((b) => (
            <div key={b.id} className="flex items-center gap-3" dir={isAr ? "rtl" : "ltr"}>
              <button type="button" onClick={() => navigate(`/reader/${b.id}`)} className="flex items-center gap-3 flex-1 min-w-0 text-start hover:opacity-70">
                <BookOpen className="w-5 h-5 flex-shrink-0" style={{ color: "var(--brand)" }} />
                <span className="flex-1 min-w-0">
                  <span className="block font-body text-sm font-semibold truncate" style={{ color: "var(--brand)" }}>{b.name}</span>
                  <span className="block font-body text-[11px] text-muted-foreground" dir="ltr">
                    {b.kind?.toUpperCase()}{b.progress ? ` - ${b.progress}%` : ""}
                  </span>
                </span>
              </button>
              <button type="button" onClick={() => onDelete(b.id)} className="w-8 h-8 flex items-center justify-center hover:opacity-70" aria-label={isAr ? "حذف" : "Delete"}>
                <Trash2 className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

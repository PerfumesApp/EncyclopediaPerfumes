import { useState, useMemo, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Pencil, User, Users, Clock, CalendarDays, CalendarRange, BarChart2, Lightbulb, Download, Wallet } from "lucide-react";
import { Link } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import WearReminders from "@/components/shared/WearReminders";
import GoalsProgressChart from "@/components/goals/GoalsProgressChart";
import { CATEGORIES, RETURN_TYPES, OUTCOMES, FREQ_COLORS } from "@/lib/goalConstants";
import SectionDivider from "@/components/shared/SectionDivider";

const FREQ_ICONS = {
  hourly: Clock,
  daily: CalendarDays,
  weekly: CalendarRange,
  monthly: BarChart2
};

const SUGGESTIONS = [
{ title: "Wear a new perfume today", title_ar: "جرّب عطراً جديداً اليوم", person: "person1", frequency: "daily", category: "wear" },
{ title: "Try a perfume neither of us has worn", title_ar: "جرّبا عطراً لم يجرّبه أحدكما", person: "both", frequency: "weekly", category: "explore" },
{ title: "Rate all unrated perfumes", title_ar: "قيّم كل العطور غير المقيّمة", person: "person1", frequency: "weekly", category: "review" },
{ title: "Morning routine — no skipping", title_ar: "روتين الصباح بلا تفويت", person: "person1", frequency: "daily", category: "daily_lifestyle" },
{ title: "Pay a pending bill", title_ar: "ادفع فاتورة معلّقة", person: "both", frequency: "monthly", category: "life_responsibility" },
{ title: "Explore a new brand this month", title_ar: "اكتشف برانداً جديداً هذا الشهر", person: "both", frequency: "monthly", category: "explore" },
{ title: "Log what you're wearing today", title_ar: "سجّل ما ترتديه اليوم", person: "person2", frequency: "daily", category: "wear" },
{ title: "Organise your space", title_ar: "رتّب مساحتك", person: "both", frequency: "weekly", category: "life_responsibility" },
{ title: "Write a review for your last purchase", title_ar: "اكتب مراجعة لآخر شراء", person: "person1", frequency: "weekly", category: "review" },
{ title: "Declutter one drawer", title_ar: "فرّغ درجاً من الفوضى", person: "person1", frequency: "weekly", category: "life_responsibility" },
{ title: "Drink enough water today", title_ar: "اشرب ماءً كافياً اليوم", person: "both", frequency: "daily", category: "daily_lifestyle" },
{ title: "Add one perfume to your wishlist", title_ar: "أضف عطراً لقائمة رغباتك", person: "person2", frequency: "weekly", category: "wishlist" },
{ title: "Sample a niche fragrance", title_ar: "جرّب عطراً نيتش", person: "person1", frequency: "monthly", category: "explore" },
{ title: "Re-test a perfume you disliked", title_ar: "أعد اختبار عطر لم يعجبك", person: "person1", frequency: "monthly", category: "review" },
{ title: "Take a 20-minute walk", title_ar: "امشِ عشرين دقيقة", person: "both", frequency: "daily", category: "daily_lifestyle" },
{ title: "Back up your phone", title_ar: "انسخ هاتفك احتياطياً", person: "person1", frequency: "monthly", category: "life_responsibility" },
{ title: "Wear a scent that matches the weather", title_ar: "ارتدِ عطراً يناسب الطقس", person: "person2", frequency: "daily", category: "wear" },
{ title: "Compare two similar fragrances", title_ar: "قارن بين عطرين متشابهين", person: "person1", frequency: "weekly", category: "review" },
{ title: "Read about perfume notes", title_ar: "اقرأ عن نوتات العطور", person: "both", frequency: "weekly", category: "explore" },
{ title: "Plan next month's budget", title_ar: "خطّط ميزانية الشهر القادم", person: "both", frequency: "monthly", category: "life_responsibility" },
{ title: "Wear a perfume you've ignored", title_ar: "ارتدِ عطراً أهملته", person: "person1", frequency: "weekly", category: "wear" },
{ title: "Discover a perfumer's story", title_ar: "اكتشف قصة عطّار", person: "person2", frequency: "monthly", category: "explore" },
{ title: "Update your collection notes", title_ar: "حدّث ملاحظات مجموعتك", person: "person1", frequency: "weekly", category: "review" },
{ title: "Sleep before midnight", title_ar: "نم قبل منتصف الليل", person: "both", frequency: "daily", category: "daily_lifestyle" },
{ title: "Reply to a pending message", title_ar: "ردّ على رسالة معلّقة", person: "person1", frequency: "daily", category: "life_responsibility" },
{ title: "Layer two fragrances", title_ar: "امزج عطرين معاً", person: "person1", frequency: "weekly", category: "wear" },
{ title: "Find a dupe for an expensive scent", title_ar: "ابحث عن بديل لعطر غالٍ", person: "both", frequency: "monthly", category: "explore" },
{ title: "Rate today's wear", title_ar: "قيّم عطر اليوم", person: "person2", frequency: "daily", category: "review" },
{ title: "Tidy your wardrobe", title_ar: "رتّب خزانتك", person: "both", frequency: "weekly", category: "life_responsibility" },
{ title: "Try an oud-based perfume", title_ar: "جرّب عطراً بالعود", person: "person1", frequency: "monthly", category: "explore" },
{ title: "Stretch for five minutes", title_ar: "تمدّد خمس دقائق", person: "both", frequency: "daily", category: "daily_lifestyle" },
{ title: "Set a savings target", title_ar: "حدّد هدف ادخار", person: "both", frequency: "monthly", category: "life_responsibility" },
{ title: "Wear a vintage fragrance", title_ar: "ارتدِ عطراً كلاسيكياً", person: "person1", frequency: "weekly", category: "wear" },
{ title: "Note a new favorite note", title_ar: "دوّن نوتة مفضّلة جديدة", person: "person2", frequency: "weekly", category: "review" },
{ title: "Explore a fragrance family you avoid", title_ar: "اكتشف عائلة عطرية تتجنّبها", person: "person1", frequency: "monthly", category: "explore" },
{ title: "Make your bed every morning", title_ar: "رتّب سريرك كل صباح", person: "both", frequency: "daily", category: "daily_lifestyle" },
{ title: "Review your monthly spending", title_ar: "راجع مصروف الشهر", person: "both", frequency: "monthly", category: "life_responsibility" },
{ title: "Add a seasonal scent to wishlist", title_ar: "أضف عطراً موسمياً للرغبات", person: "person1", frequency: "weekly", category: "wishlist" },
{ title: "Wear something bold today", title_ar: "ارتدِ عطراً جريئاً اليوم", person: "person2", frequency: "daily", category: "wear" },
{ title: "Test a fragrance on skin, not paper", title_ar: "جرّب العطر على البشرة لا الورق", person: "person1", frequency: "weekly", category: "explore" },
{ title: "Clean your perfume shelf", title_ar: "نظّف رفّ عطورك", person: "both", frequency: "monthly", category: "life_responsibility" },
{ title: "Journal one line about today", title_ar: "دوّن سطراً عن يومك", person: "both", frequency: "daily", category: "daily_lifestyle" },
{ title: "Rate the longevity of today's scent", title_ar: "قيّم ثبات عطر اليوم", person: "person1", frequency: "daily", category: "review" },
{ title: "Discover a quote you love", title_ar: "اكتشف اقتباساً يعجبك", person: "person2", frequency: "weekly", category: "explore" },
{ title: "Wear a gift perfume", title_ar: "ارتدِ عطراً مُهدى", person: "person1", frequency: "weekly", category: "wear" },
{ title: "Skip one impulse purchase", title_ar: "امتنع عن شراء اندفاعي", person: "both", frequency: "monthly", category: "life_responsibility" },
{ title: "Try a unisex fragrance", title_ar: "جرّب عطراً للجنسين", person: "person2", frequency: "monthly", category: "explore" },
{ title: "Tidy your phone gallery", title_ar: "رتّب معرض صور هاتفك", person: "person1", frequency: "weekly", category: "life_responsibility" },
{ title: "Wear a fresh citrus scent", title_ar: "ارتدِ عطر حمضيات منعشاً", person: "both", frequency: "daily", category: "wear" },
{ title: "Pick a fragrance for an occasion", title_ar: "اختر عطراً لمناسبة قادمة", person: "both", frequency: "monthly", category: "wishlist" }];


const FREQ_TABS = ["all", "daily", "weekly", "monthly", "hourly"];

const FREQ_LABELS_AR = { all: "الكل", hourly: "كل ساعة", daily: "يومي", weekly: "أسبوعي", monthly: "شهري" };

const catInfo = (val, customLabel) => {
  const found = CATEGORIES.find((c) => c.value === val);
  if (!found) return { label: val, emoji: "🎯", cls: "bg-secondary text-foreground" };
  if (found.value === "custom" && customLabel) return { ...found, label: customLabel };
  return found;
};

const returnInfo = (val) => RETURN_TYPES.find((r) => r.value === val);

const EMPTY_FORM = {
  title: "", description: "", person: "person1", frequency: "daily",
  category: "daily_lifestyle", custom_category: "",
  return_type: "once", start_time: "", end_time: "", due_date: ""
};

export default function Goals() {
  const qc = useQueryClient();
  const { names } = usePersonNames();
  const { isAr } = useLang();
  const [freqFilter, setFreqFilter] = useState("all");
  const [personFilter, setPersonFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [suggestOpen, setSuggestOpen] = useState(false);
  const navigate = useNavigate();
  const [form, setForm] = useState(EMPTY_FORM);
  const [editId, setEditId] = useState(null);
  const handleEditGoal = (goal) => {
    setForm({ ...EMPTY_FORM, ...goal });
    setEditId(goal.id);
    setDialogOpen(true);
  };
  const [showStats, setShowStats] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState("month");

  useEffect(() => {
    const handlePeriodChange = (e) => setSelectedPeriod(e.detail.period);
    window.addEventListener("goalsPeriodChange", handlePeriodChange);
    return () => window.removeEventListener("goalsPeriodChange", handlePeriodChange);
  }, []);

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => apphost.entities.Goal.list("-created_date")
  });

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.Goal.create(data),
    onSuccess: () => {qc.invalidateQueries({ queryKey: ["goals"] });toast.success((isAr ? "أُضيف الهدف" : "Goal added"));setDialogOpen(false);setForm(EMPTY_FORM);}
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => apphost.entities.Goal.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["goals"] })
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.Goal.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["goals"] })
  });

  const filtered = useMemo(() => goals.filter((g) => {
    const matchFreq = freqFilter === "all" || g.frequency === freqFilter;
    const matchPerson = personFilter === "all" || g.person === personFilter || g.person === "both";
    return matchFreq && matchPerson;
  }), [goals, freqFilter, personFilter]);

  const active = filtered.filter((g) => g.status !== "done");
  const pending = active.filter((g) => g.status !== "skipped");
  const skipped = filtered.filter((g) => g.status === "skipped");
  const done = filtered.filter((g) => g.status === "done");

  const personLabel = (p) => p === "both" ? (isAr ? "كلاهما" : "Both") : p === "person2" ? names.person2 : names.person1;

  const [suggestSample, setSuggestSample] = useState([]);
  const shuffleSuggestions = () => {
    setSuggestSample([...SUGGESTIONS].sort(() => Math.random() - 0.5).slice(0, 5));
  };

  const handleSuggestion = (s) => {
    createMutation.mutate({
      title: isAr ? (s.title_ar || s.title) : s.title,
      person: "person1", frequency: s.frequency, category: s.category,
      status: "pending", return_type: "once",
    });
    setSuggestOpen(false);
  };

  const f = (k, v) => setForm((prev) => ({ ...prev, [k]: v }));

  return (
    <div className="px-4 page-top pb-4 space-y-5 overflow-x-hidden">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="space-y-0.5 min-w-0">
          <h1 className="font-heading text-2xl font-bold" style={{ color: 'var(--brand)' }}>{isAr ? 'تحسن' : 'Goals'}</h1>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      {/* تذكير ارتداء العطر — فوق الأهداف */}
      <WearReminders />

      {/* Person filter - Before frequency tabs */}
      <div className="flex gap-2">
        {[
        { val: "all", label: isAr ? "الكل" : "All", icon: <Users className="w-3 h-3" /> },
        { val: "person1", label: names.person1, icon: <User className="w-3 h-3" /> },
        { val: "person2", label: names.person2, icon: <User className="w-3 h-3" /> }].
        map(({ val, label, icon }) =>
        <button key={val} onClick={() => setPersonFilter(val)}
        className={`flex items-center gap-1 px-1 py-1 text-xs font-body font-medium transition-colors ${personFilter === val ? val === "person2" ? "text-violet-500 font-semibold" : "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"}`}>
            {icon}{label}
          </button>
        )}
      </div>

      {/* Frequency tabs + Stats toggle */}
      <div className="grid grid-cols-3 gap-1 pb-1">
        {FREQ_TABS.map((f) =>
        <button key={f} onClick={() => setFreqFilter(f)}
        className={`text-[10px] font-body py-2 px-1 capitalize transition-colors line-clamp-2 leading-tight ${freqFilter === f ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"}`}>
            {isAr ? (FREQ_LABELS_AR[f] || f) : f}
          </button>
        )}
        <button
          onClick={() => setShowStats(!showStats)}
          className={`text-[10px] font-body py-2 px-1 font-medium transition-colors line-clamp-2 leading-tight ${showStats ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"}`}>
          📊 {isAr ? "إحصاءات" : "Stats"}
        </button>
      </div>

      {/* Progress Charts */}
      {showStats && goals.length > 0 &&
      <div className="pt-1">
          <GoalsProgressChart goals={goals} personFilter={personFilter} selectedPeriod={selectedPeriod} />
        </div>
      }

      <SectionDivider />

      {/* العدّاد — أعلى الأهداف */}
      <p className="text-xs text-muted-foreground font-body px-1">
        {isAr
          ? `${pending.length} قيد التنفيذ — ${skipped.length} متجاوَز — ${done.length} منجز`
          : `${pending.length} pending — ${skipped.length} skipped — ${done.length} done`}
      </p>

      {/* Empty */}
      {goals.length === 0 &&
      <div className="text-center py-14 space-y-3">
          <p className="font-heading text-lg font-semibold">{isAr ? "لا أهداف بعد" : "No goals yet"}</p>
          <p className="text-xs text-muted-foreground font-body">{isAr ? "اضغط اقتراح لأفكار ذكية، أو إضافة الهدف لإنشاء هدفك." : "Tap Suggest for smart ideas or Add Goal to create your own."}</p>
        </div>
      }

      {/* Pending goals */}
      {pending.length > 0 &&
      <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body px-1">{isAr ? "قيد التنفيذ" : "Pending"}</p>
          {pending.map((g) => <GoalCard key={g.id} goal={g} onUpdate={updateMutation.mutate} onDelete={deleteMutation.mutate} onEdit={handleEditGoal} personLabel={personLabel} />)}
        </div>
      }

      {/* Skipped goals — تبقى ظاهرة وحالتها مسجّلة */}
      {skipped.length > 0 &&
      <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body px-1">{isAr ? "متجاوَز" : "Skipped"}</p>
          {skipped.map((g) => <GoalCard key={g.id} goal={g} onUpdate={updateMutation.mutate} onDelete={deleteMutation.mutate} onEdit={handleEditGoal} personLabel={personLabel} />)}
        </div>
      }

      {/* Done goals */}
      {done.length > 0 &&
      <div className="space-y-2">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body px-1">{isAr ? "مكتمل" : "Completed"}</p>
          {done.map((g) => <GoalCard key={g.id} goal={g} onUpdate={updateMutation.mutate} onDelete={deleteMutation.mutate} onEdit={handleEditGoal} personLabel={personLabel} />)}
        </div>
      }

      {/* إضافة + تصدير + اقتراح — أسفل الصفحة، أيقونات بلا نصّ */}
      <div className="flex items-center justify-center gap-6 pt-4">
        <button type="button" title={isAr ? "إضافة" : "Add"} onClick={() => { setForm(EMPTY_FORM); setEditId(null); setDialogOpen(true); }}
          className="flex items-center justify-center hover:opacity-70 transition-opacity">
          <span className="font-body text-sm font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "إضافة هدف" : "Add Goal"}</span>
        </button>
        <button type="button" title={isAr ? "تصدير" : "Export"} onClick={() => navigate("/export?type=goals")}
          className="flex items-center justify-center hover:opacity-70 transition-opacity">
          <Download className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
        <button type="button" title={isAr ? "اقتراح" : "Suggest"} onClick={() => { shuffleSuggestions(); setSuggestOpen(true); }}
          className="flex items-center justify-center hover:opacity-70 transition-opacity">
          <Lightbulb className="w-5 h-5" style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {/* صندوق تصميم ميزانية — أسفل الصفحة بعد الاقتباس */}
      <Link to="/budget" className="block hover:opacity-80 transition-opacity">
        <div className="flex items-center justify-center gap-2 py-4 px-3">
          <Wallet className="w-5 h-5" style={{ color: "var(--brand)" }} />
          <span className="font-body text-base font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "تصميم ميزانية" : "Design a Budget"}</span>
        </div>
      </Link>

      {/* Add dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading text-[13px] sm:text-sm font-semibold text-center leading-snug">{editId ? (isAr ? "تعديل الهدف" : "Edit Goal") : (isAr ? "إضافة هدف.. مهمة.. و ما إلى ذلك" : "Add Goal.. Task.. & So Forth")}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input value={form.title} onChange={(e) => f("title", e.target.value)} placeholder={isAr ? "ما الهدف" : "What's the goal?"} className="rounded-none font-body text-sm h-10" />
            <Textarea value={form.description} onChange={(e) => f("description", e.target.value)} placeholder={isAr ? "تفاصيل اختياري" : "Details (optional)"} className="rounded-none font-body text-xs min-h-[50px] resize-none" />

            {/* For / Frequency */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "لِمن" : "For"}</p>
                <Select value={form.person} onValueChange={(v) => f("person", v)}>
                  <SelectTrigger className="rounded-none h-9 font-body text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="person1">{names.person1}</SelectItem>
                    <SelectItem value="person2">{names.person2}</SelectItem>
                    <SelectItem value="both">{isAr ? "كلاهما" : "Both"}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "التكرار" : "Frequency"}</p>
                <Select value={form.frequency} onValueChange={(v) => f("frequency", v)}>
                  <SelectTrigger className="rounded-none h-9 font-body text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">{isAr ? "كل ساعة" : "Hourly"}</SelectItem>
                    <SelectItem value="daily">{isAr ? "يومي" : "Daily"}</SelectItem>
                    <SelectItem value="weekly">{isAr ? "أسبوعي" : "Weekly"}</SelectItem>
                    <SelectItem value="monthly">{isAr ? "شهري" : "Monthly"}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Category */}
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الفئة" : "Category"}</p>
              <div className="grid grid-cols-2 gap-1.5">
                {CATEGORIES.map(({ value, label, label_ar, emoji, cls }) =>
                <button key={value} onClick={() => f("category", value)}
                className={`flex items-center gap-2 px-2.5 py-2 rounded-none border text-xs font-body font-medium transition-all ${form.category === value ? `${cls} border-current shadow-sm` : "bg-secondary/60 text-muted-foreground border-transparent hover:bg-secondary"}`}>
                    <span>{emoji}</span> {isAr ? (label_ar || label) : label}
                  </button>
                )}
              </div>
              {form.category === "custom" &&
              <Input value={form.custom_category} onChange={(e) => f("custom_category", e.target.value)} placeholder={isAr ? "أدخل اسم فئة مخصّصة" : "Enter custom category name…"} className="rounded-none h-8 font-body text-xs mt-1" />
              }
            </div>

            {/* Return / Motivation type */}
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "نوع التحفيز" : "Motivation Type"}</p>
              <div className="space-y-1">
                {RETURN_TYPES.map(({ value, label, label_ar, emoji, desc, desc_ar }) =>
                <button key={value} onClick={() => f("return_type", value)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-none border text-left transition-all ${form.return_type === value ? "bg-primary/10 border-primary/40 text-primary" : "bg-secondary/60 border-transparent text-muted-foreground hover:bg-secondary"}`}>
                    <span className="text-base">{emoji}</span>
                    <div>
                      <p className="text-xs font-body font-semibold leading-none">{isAr ? (label_ar || label) : label}</p>
                      <p className="text-[10px] font-body opacity-70 mt-0.5">{isAr ? (desc_ar || desc) : desc}</p>
                    </div>
                  </button>
                )}
              </div>
            </div>

            {/* Time range + Due date */}
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "وقت البدء" : "Start Time"}</p>
                <Input type="time" value={form.start_time} onChange={(e) => f("start_time", e.target.value)} className="rounded-none h-9 font-body text-xs" />
              </div>
              <div className="space-y-1">
                <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "وقت الانتهاء" : "End Time"}</p>
                <Input type="time" value={form.end_time} onChange={(e) => f("end_time", e.target.value)} className="rounded-none h-9 font-body text-xs" />
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "تاريخ الاستحقاق" : "Due Date"}</p>
              <Input type="date" value={form.due_date} onChange={(e) => f("due_date", e.target.value)} className="rounded-none h-9 font-body text-xs" />
            </div>

            <Button className="w-full h-10 rounded-none font-body text-sm"
              onClick={() => {
                if (editId) {
                  updateMutation.mutate({ id: editId, data: { ...form } });
                  toast.success(isAr ? "حُدّث الهدف" : "Goal updated");
                  setDialogOpen(false); setForm(EMPTY_FORM); setEditId(null);
                } else {
                  createMutation.mutate({ ...form, status: "pending" });
                }
              }}
              disabled={!form.title || createMutation.isPending}>
              {editId ? (isAr ? "احفظ التعديل" : "Save Changes") : createMutation.isPending ? (isAr ? "جارٍ.." : "Saving..") : (isAr ? "إضافة هدف / مهمة" : "Add Goal / Task")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Suggestions dialog */}
      <Dialog open={suggestOpen} onOpenChange={setSuggestOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base flex items-center gap-2">
              {isAr ? "أهداف مقترحة" : "Suggested Goals"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {suggestSample.map((s, i) => {
              const cat = catInfo(s.category);
              return (
                <button key={i} onClick={() => handleSuggestion(s)}
                className="w-full text-left rounded-none px-1 py-2.5 space-y-1 border-b border-border/30 hover:opacity-70 transition-opacity">
                  <p className="text-xs font-body font-medium" dir="ltr" style={{ unicodeBidi: "isolate" }}>{s.title}</p>
                  <p className="text-xs font-body font-medium text-muted-foreground" dir="rtl" style={{ unicodeBidi: "isolate" }}>{s.title_ar}</p>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] px-2 py-0.5 rounded-none font-body ${FREQ_COLORS[s.frequency]}`}>{isAr ? (FREQ_LABELS_AR[s.frequency] || s.frequency) : s.frequency}</span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-none font-body ${cat.cls}`}>{cat.emoji} {isAr ? (cat.label_ar || cat.label) : cat.label}</span>
                  </div>
                </button>);

            })}
          </div>
          <button
            onClick={shuffleSuggestions}
            className="w-full mt-1 flex items-center justify-center gap-1.5 text-xs font-body font-medium text-primary hover:bg-primary/10 rounded-none py-2 transition-colors"
          >
            🎲 {isAr ? "اقتراحات أخرى" : "Shuffle ideas"}
          </button>
        </DialogContent>
      </Dialog>
    </div>);

}

function GoalCard({ goal, onUpdate, onDelete, onEdit, personLabel }) {
  const { isAr } = useLang();
  const [showMenu, setShowMenu] = useState(false);
  const isDone = goal.status === "done";
  const isSkipped = goal.status === "skipped";
  const cat = catInfo(goal.category, goal.custom_category);
  const ret = returnInfo(goal.return_type);
  const OUTCOME_COLOR = { succeeded: "text-emerald-600", failed: "text-red-600", try_again: "text-amber-600", what: "text-slate-500" };

  const handleOutcome = (value) => {
    if (isDone && goal.outcome === value) {
      onUpdate({ id: goal.id, data: { status: "pending", outcome: null, completed_at: null } });
    } else {
      onUpdate({ id: goal.id, data: { status: "done", outcome: value, completed_at: new Date().toISOString() } });
    }
  };

  return (
    <div className={`px-1 py-2 space-y-2 transition-all ${isSkipped ? "opacity-60" : ""}`}>
      <div className="flex items-start gap-3">
        <div className="flex-1 min-w-0 space-y-1">
          <p className={`text-xs font-body font-medium ${isDone ? "line-through text-muted-foreground" : ""}`}>{goal.title}</p>
          {goal.description && <p className="text-[10px] text-muted-foreground font-body">{goal.description}</p>}

          {/* Time range */}
          {(goal.start_time || goal.end_time) &&
          <p className="text-[10px] text-muted-foreground font-body flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {goal.start_time && goal.end_time ? `${goal.start_time} – ${goal.end_time}` : goal.start_time || goal.end_time}
            </p>
          }

          <div className="flex items-center gap-1.5 flex-wrap">
            <span className={`text-[10px] rounded-none font-body ${FREQ_COLORS[goal.frequency] || " text-muted-foreground"}`}>
              {isAr ? (FREQ_LABELS_AR[goal.frequency] || goal.frequency) : goal.frequency}
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-none font-body ${cat.cls}`}>
              {cat.emoji} {isAr ? (cat.label_ar || cat.label) : cat.label}
            </span>
            {ret &&
            <span className="text-[10px] rounded-none font-body text-foreground">
                {ret.emoji} {isAr ? (ret.label_ar || ret.label) : ret.label}
              </span>
            }
            <span className={`text-[10px] rounded-none font-body ${goal.person === "person2" ? " text-violet-600" : goal.person === "both" ? " text-foreground" : " text-primary"}`}>
              {personLabel(goal.person)}
            </span>
            {goal.due_date && <span className="text-[10px] text-muted-foreground font-body">{goal.due_date}</span>}
          </div>
        </div>

        <div className="relative flex-shrink-0">
          <button onClick={() => setShowMenu((v) => !v)} title={isAr ? "تعديل" : "Edit"} className="text-muted-foreground hover:text-foreground transition-colors">
            <Pencil className="w-3.5 h-3.5" />
          </button>
          {showMenu && (
            <div className="absolute end-0 mt-1 z-20 bg-card border border-border shadow-md rounded-none py-1 min-w-[110px]">
              <button onClick={() => { setShowMenu(false); onEdit && onEdit(goal); }}
                className="w-full text-start px-3 py-1.5 text-xs font-body hover:bg-secondary/60 transition-colors">{isAr ? "تعديل" : "Edit"}</button>
              {!isDone && (
                <button onClick={() => { setShowMenu(false); onUpdate({ id: goal.id, data: { status: isSkipped ? "pending" : "skipped" } }); }}
                  className="w-full text-start px-3 py-1.5 text-xs font-body hover:bg-secondary/60 transition-colors">{isSkipped ? (isAr ? "إلغاء التجاوز" : "Un-skip") : (isAr ? "تخطّي" : "Skip")}</button>
              )}
              <button onClick={() => { setShowMenu(false); onDelete(goal.id); }}
                className="w-full text-start px-3 py-1.5 text-xs font-body text-destructive hover:bg-secondary/60 transition-colors">{isAr ? "حذف" : "Delete"}</button>
            </div>
          )}
        </div>
      </div>

      {/* أزرار النتيجة — أسفل كل هدف للتحفيز، نصّ بألوان مختلفة بلا أيقونات/إطار/خلفية */}
      <div className="flex items-center gap-4 flex-wrap pt-0.5">
        {OUTCOMES.map(({ value, label, label_ar }) => {
          const active = isDone && goal.outcome === value;
          return (
            <button key={value} onClick={() => handleOutcome(value)}
              className={`text-[11px] font-body transition-opacity ${OUTCOME_COLOR[value] || "text-muted-foreground"} ${active ? "opacity-100 font-semibold underline underline-offset-4" : "opacity-45 hover:opacity-80"}`}>
              {isAr ? (label_ar || label) : label}
            </button>
          );
        })}
      </div>
    </div>);

}
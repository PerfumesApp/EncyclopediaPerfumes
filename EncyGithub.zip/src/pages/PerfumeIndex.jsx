import { useState, useEffect, useMemo, useCallback, useRef, memo } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Search, Loader2, TestTubeDiagonal } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import { rankName } from "@/lib/sortName";
import BackIcon from "@/components/shared/BackIcon";

// أيقونة «عدد العطور» (Total) — منقولة من شريط البراندات
function ScatterSquares({ className, style }) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="square" strokeLinejoin="miter" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M4 3v17h17" />
      <rect x="7" y="13.4" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="10.6" y="8.6" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="14.2" y="11.4" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="16.6" y="5.6" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="8.4" y="6.4" width="2.4" height="2.4" fill="currentColor" stroke="none" />
    </svg>
  );
}

/**
 * PerfumeIndex — فهرس العطور A–Z فوق ~130k عطر، أوفلاين وبلا تجميد.
 * يعتمد فهرس 'sort_key' (rank + الاسم بحروف صغيرة) مع مؤشّر نطاق
 * (pageByIndexRange): يُقرأ حرفٌ/بادئة واحدة فقط صفحةً صفحة — لا تحميل للقاعدة كاملة.
 */

const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").concat("#");
const PAGE = 50;

// قَصّ صفّي محدود بعدد المحارف؛ يستبدل التجاوز بنقطتين فقط (..) لا بثلاث.
function trimText(s, max) {
  const str = String(s || "");
  if (str.length <= max) return str;
  return str.slice(0, max).replace(/\s+$/, "") + "..";
}

// يبني حدود مفتاح الفرز للبادئة/الحرف المختار.
function boundsFor(query, letter) {
  const t = (query || "").trim().toLowerCase();
  if (t) {
    const prefix = String(rankName(t)) + t;       // نفس صياغة sort_key للبادئة
    return { lower: prefix, upper: prefix + "\uffff" };
  }
  if (!letter) return undefined;                   // لا اختيار بعد — لا تحميل (الحروف فقط) if (letter === "all") return null;               // كل العطور بترتيب الفرز (sort_key) — بلا تصفية
  if (letter === "#") return { lower: "1" };       // كل ما ليس حرفاً إنجليزياً (أرقام/رموز/لغات أخرى)
  const prefix = "0" + letter.toLowerCase();        // حرف إنجليزي (rank 0)
  return { lower: prefix, upper: prefix + "\uffff" };
}

// صفّ مُذكَّر (memo): عند «عرض المزيد» تُرسم الصفوف الجديدة فقط بدل إعادة رسم
// كلّ ما حُمِّل سابقاً — يبقي التصفّح المستمرّ خفيفاً مهما طالت القائمة.
const IndexRow = memo(function IndexRow({ p }) {
  return (
    <Link
      to={`/perfume?id=${p.id}`}
      dir="ltr"
      className="flex items-center justify-between gap-3 py-2.5 px-2 -mx-2 rounded-none hover:bg-secondary/60 transition-colors group"
    >
      <div className="min-w-0 flex-1 overflow-hidden">
        <p className="text-sm font-body font-medium text-foreground group-hover:text-[var(--brand)] transition-colors whitespace-nowrap overflow-hidden">
          {trimText(p.name_en || p.name || p.name_ar, 28)}
        </p>
      </div>
      {p.brand_name && (
        <span className="text-[10px] text-muted-foreground font-body shrink-0 max-w-[28%] whitespace-nowrap overflow-hidden text-right">{trimText(p.brand_name, 14)}</span>
      )}
    </Link>
  );
});

export default function PerfumeIndex() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  const [letter, setLetter] = useState("");   // يبدأ بلا اختيار — الحروف فقط حتى تختار
  const [query, setQuery] = useState("");
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lettersOpen, setLettersOpen] = useState(true); // شريط الحروف ظاهر دائماً

  const offsetRef = useRef(0);
  const reqIdRef = useRef(0);
  const emptyRetriesRef = useRef(0);

  const bounds = useMemo(() => boundsFor(query, letter), [query, letter]);

  const loadPage = useCallback(async (reset) => {
    // لا اختيار (bounds undefined): لا نحمّل شيئاً — نعرض الحروف فقط.
    if (bounds === undefined) { setItems([]); setTotal(0); setHasMore(false); setLoading(false); setLoadingMore(false); return; }
    const myReq = ++reqIdRef.current;
    if (reset) { setLoading(true); offsetRef.current = 0; }
    else setLoadingMore(true);
    try {
      // «الكل» (bounds فارغ): لا نعدّ كلّ الـ130 ألف قبل أوّل صفحة — نتركه ونشتقّ
      // «المزيد» من امتلاء الصفحة، والإجمالي يأتي لاحقاً بعدّ رخيص غير حاجب.
      const withTotal = reset && bounds != null;
      const { items: rows, total: tot } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", bounds, offsetRef.current, PAGE, "next", withTotal
      );
      if (myReq !== reqIdRef.current) return; // سباق: تجاهل نتيجة قديمة
      offsetRef.current += rows.length;
      setItems((prev) => (reset ? rows : [...prev, ...rows]));
      setHasMore(rows.length === PAGE);
      if (reset && tot != null) setTotal(tot);
    } catch (e) {
      console.error("perfume index load failed", e);
      if (myReq === reqIdRef.current && reset) { setItems([]); setTotal(0); setHasMore(false); }
    } finally {
      if (myReq === reqIdRef.current) { setLoading(false); setLoadingMore(false); }
    }
  }, [bounds]);

  useEffect(() => { loadPage(true); }, [loadPage]);

  // شبكة أمان: إن عُرض التطبيق قبل اكتمال البذر (مهلة السبلاش على الأجهزة البطيئة)
  // يحمّل عرض «الكل» فارغاً. نعيد الجلب بضع مرّات حتى تظهر البيانات — دون تدخّل المستخدم.
  useEffect(() => {
    if (loading || loadingMore) return;
    if (bounds === null && !query.trim() && items.length === 0 && emptyRetriesRef.current < 6) {
      emptyRetriesRef.current += 1;
      const t = setTimeout(() => loadPage(true), 700);
      return () => clearTimeout(t);
    }
    if (items.length > 0) emptyRetriesRef.current = 0;
  }, [loading, loadingMore, items.length, bounds, query, loadPage]);

  // في «الكل» (نطاق فارغ) نجلب الإجمالي بعدّ أصليّ رخيص — متوازٍ ولا يحجب أوّل صفحة.
  useEffect(() => {
    if (bounds !== null) return;
    let alive = true;
    apphost.entities.Perfume.count().then((c) => { if (alive) setTotal(c); }).catch(() => {});
    return () => { alive = false; };
  }, [bounds]);

  // ضغط «All» يفتح الشريط ويختار «الكل». ضغط حرف يختاره ويطوي الشريط.
  // ضغط الحرف النشط بينما الشريط مطوي يعيد فتحه دون تغيير الفلتر.
  const onPickLetter = (l) => {
    setQuery("");
    setLetter(l);
  };
  return (
    <div className="px-5 page-top pb-16">
      {/* رأس */}
      <div className={`flex items-center gap-3 mb-4 ${isAr ? "flex-row-reverse" : ""}`}>
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors shrink-0" title={isAr ? "رجوع" : "Back"}>
          <BackIcon className={`w-5 h-5`} />
        </button>
        <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">{isAr ? "فهرس العطور" : "Perfume Index"}</h1>
      </div>

      {/* بحث بالبادئة */}
      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input name="PerfumeIndex-1"
          dir="ltr"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={isAr ? "بحث عن عطر" : "Search Perfume"}
          className="w-full pl-10 pr-9 h-11 rounded-none font-body bg-secondary/50 border-0 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand)]/40"
        />
        
      </div>

      {/* أحرف A–Z + #: مطوية افتراضياً، تنفتح بضغط «All»؛ وعند اختيار حرف يبقى هو وحده ظاهراً */}
      <div className="flex flex-wrap items-center gap-1 mb-4" dir="ltr">
        {/* Total/Top — منقولتان من شريط البراندات؛ تفتحان العرض في /brands عند الضغط فقط (lazy) */}
        <button type="button" onClick={() => navigate("/brands?sort=perfumeCount")} title={isAr ? "عدد العطور" : "Total Perfume"}
          className="flex items-center justify-center w-7 h-7 hover:opacity-70 transition-opacity">
          <ScatterSquares className="w-5 h-5" style={{ color: "#9a7b1f" }} />
        </button>
        <button type="button" onClick={() => navigate("/brands?view=analytics")} title={isAr ? "الأعلى" : "Top"}
          className="flex items-center justify-center w-7 h-7 hover:opacity-70 transition-opacity">
          <TestTubeDiagonal className="w-5 h-5" style={{ color: "#9a7b1f" }} />
        </button>
        <button
          onClick={() => onPickLetter("all")}
          className={`px-2 h-7 rounded-none text-xs font-body font-bold transition-colors ${
            !query.trim() && letter === "all" ? "bg-[var(--brand)] text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/70"
          }`}
        >
          {isAr ? "الكل" : "All"}
        </button>
        {lettersOpen ? (
          LETTERS.map((l) => {
            const active = !query.trim() && l === letter;
            return (
              <button
                key={l}
                onClick={() => onPickLetter(l)}
                className={`w-7 h-7 rounded-none text-xs font-body font-bold transition-colors ${
                  active ? "bg-[var(--brand)] text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/70"
                }`}
              >
                {l}
              </button>
            );
          })
        ) : (
          !query.trim() && letter !== "all" && (
            <button
              key={letter}
              onClick={() => onPickLetter(letter)}
              className="w-7 h-7 rounded-none text-xs font-body font-bold transition-colors bg-[var(--brand)] text-white shadow"
            >
              {letter}
            </button>
          )
        )}
      </div>

      {/* النتائج */}
      {(!letter && !query.trim()) ? (
        <div className="text-center py-16 space-y-2">
          <Search className="w-9 h-9 text-[var(--brand)]/25 mx-auto" />
          <p className="text-sm text-muted-foreground font-body">{isAr ? "اختر حرفاً أو الكل" : "Pick a letter or All"}</p>
        </div>
      ) : loading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="w-6 h-6 text-[var(--brand)] animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-16 space-y-2">
          <Search className="w-9 h-9 text-[var(--brand)]/25 mx-auto" />
          <p className="text-sm text-muted-foreground font-body">{isAr ? "لا عطور هنا" : "No perfumes here"}</p>
        </div>
      ) : (
        <>
          <div className="divide-y divide-border/40">
            {items.map((p) => (
              <IndexRow key={p.id} p={p} />
            ))}
          </div>

          {hasMore && (
            <div className="flex justify-center pt-4">
              <button
                onClick={() => loadPage(false)}
                disabled={loadingMore}
                className="inline-flex items-center gap-2 rounded-none text-xs font-body font-medium text-foreground disabled:opacity-60 transition-colors"
              >
                {loadingMore ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                {isAr ? `عرض المزيد (${items.length}/${total})` : `Load more (${items.length}/${total})`}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

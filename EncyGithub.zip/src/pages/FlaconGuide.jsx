
import { useNavigate, Link } from "react-router-dom";
import AccordFlaconCard from "@/components/perfume/AccordFlaconCard";
import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { useLang } from "@/lib/LanguageContext";
import BackIcon from "@/components/shared/BackIcon";

/**
 * FlaconGuide — صفحة شرح «قنينة العطر»: ماذا يمثّل كل عنصر في الرسم.
 * نص على خلفية بيضاء، بلا إطارات/صناديق، عناوين ذهبية، عربي ثم إنجليزي.
 */

// عيّنات: id:weight للأكوردات (موجودة في accords_builtin)
const SAMPLE = { id: "guide-main", accords: "a68:100;a8:55;a7:35", gender: "Men", type: "Eau de Parfum", release_year: 2100, brand_name: "Brand" };
const SAMPLES = [
  { id: "g-men",   accords: "a8:100;a68:50", gender: "Men",    type: "Eau de Parfum",   release_year: 2100, brand_name: "Men", labelAr: "رجالي", labelEn: "Men", col: "#22c55e" },
  { id: "g-women", accords: "a7:100",       gender: "Women",  type: "Eau de Toilette", release_year: 2100, brand_name: "Women", labelAr: "نسائي", labelEn: "Women", col: "#f472b6" },
  { id: "g-uni",   accords: "a68:80;a7:60;a8:40", gender: "Unisex", type: "Parfum",     release_year: 2100, brand_name: "Unisex", labelAr: "للجنسين", labelEn: "Unisex", col: "#fcd34d" },
];

export default function FlaconGuide() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  const legend = [
    { ar: "الغطاء و العنق", en: "Cap & neck", da: "علوي القنينة ذهبيّ دائماً.", de: "Always a unified gold top." },
    { ar: "جسم القنينة", en: "Bottle body", da: "أبيض، يحمل السائل و التسميات.", de: "White, holds the liquid and labels." },
    { ar: "الموجة الكبرى = الأكورد المسيطر", en: "Large band = dominant accord", da: "أكبر طبقة لون، و لونها هو لون أقوى أكورد في العطر.", de: "The largest color layer; its color is the strongest accord." },
    { ar: "طبقات القاع = بقية الأكوردات", en: "Base layers = other accords", da: "طبقات رفيعة أسفل القنينة، عرض كلٍّ منها بحسب وزنه.", de: "Thin layers at the base, each sized by its weight." },
    { ar: "الشريط الرفيع = الفئة", en: "Thin strip = gender", da: "فوق الموجة الكبرى مباشرة (انظر الألوان أدناه).", de: "Right above the large band (see colors below)." },
    { ar: "أعلى اليسار = النوع", en: "Top-left = type", da: "EDP EDT Parfum … بلون الفئة.", de: "EDP / EDT / Parfum … in the gender color." },
    { ar: "أعلى اليمين = سنة الإصدار", en: "Top-right = release year", da: "بلون الفئة أيضاً.", de: "Also in the gender color." },
    { ar: "الوسط = اسم الأكورد المسيطر", en: "Center = dominant accord name", da: "الإنجليزي يساراً و العربي يميناً.", de: "English on the left, Arabic on the right." },
    { ar: "الأسفل = البراند", en: "Bottom = brand", da: "اسم العلامة في وسط الأسفل.", de: "The brand name, bottom-center." },
  ];

  // شرح صفحة العطر — أقسامها بالترتيب
  const perfumePage = [
    { ar: "الاسم", en: "Name", da: "الاسم الإنجليزي بلون ذهبيّ و العربي بلون ورديّ، و اسم البراند فوقهما صغيراً ذهبيّاً.", de: "English name in gold, Arabic in rose, with the small gold brand above." },
    { ar: "الخصائص في «عن العطر»", en: "Traits inside About", da: "التصنيف العطري و التركيز و سنة الإصدار، تظهر بعد وصف العطر بإطارات ذهبية.", de: "Scent class, concentration and year appear after the description as gold chips." },
    { ar: "بطاقة عطر", en: "Perfume Card", da: "رأي الجمهور: الثبات و الفوحان و القيمة، و شريط الفئة، و الفصول بجانب اليوم، و مناسبات العطر.", de: "Crowd view: longevity, sillage, value, a gender bar, seasons beside time, and occasions." },
    { ar: "العائلة العطرية", en: "Odor Family", da: "أشرطة الأكوردات، طول كلٍّ بحسب قوّته في العطر.", de: "Accord bars, each sized by its strength." },
    { ar: "هرم النوتات", en: "Notes Pyramid", da: "صور النوتات بإطار ذهبي و اسمها بلغتين، و مثلّث في الزاوية يبدّل العرض إلى نص.", de: "Note images with gold frames and bilingual names; a corner triangle switches to text." },
    { ar: "العطّارون و العطور المشابهة", en: "Perfumers & Similar", da: "صانعو العطر، و عطور تشبهه، مجموعة في المقدمة.", de: "The perfume's makers and look-alikes, grouped in the intro." },
    { ar: "تخصيص المستخدم", en: "User Customization", da: "لكل شخص خلفية لون خاصة: الانطباع و التفاعل و التقييم العام و التفصيلي و المناسبات و المراجعة.", de: "Each person has a tinted area: impression, reaction, overall and detailed ratings, occasions, review." },
    { ar: "العمليات", en: "Operations", da: "شراء عينة أو علبة (مل و تكلفة و متجر)، و تسجيل ملاحظة، و تسجيل ارتداء.", de: "Buy a sample or bottle (ml, cost, store), add a note, log a wear." },
    { ar: "التصدير", en: "Export", da: "صندوق ذهبي واحد: تصدير مراجعة و مطوّر و بطاقة و كاست أواي، مع نوتبوك و حفظ و نسخ.", de: "One gold box: Review, Advanced, Card and Cast Away exports, plus Notebook, Bookmark and Copy." },
    { ar: "تعديل العطر", en: "Edit Perfume", da: "في أسفل الصفحة، منفصلاً في الفوتر.", de: "At the very bottom, separated in the footer." },
  ];

  // بطاقة العطر أينما ظهرت (صفحة العطور — صفحة البراند — أعلى صفحة العطر)
  const cards = [
    { ar: "قنينة صفحة العطر", en: "Perfume page — the flacon",
      da: "في صفحة العطر و الاستكشاف و أعلى صفحة العطر: قنينة ملوّنة مفصّلة تختصر العطر برسمها — طبقات الأكوردات بألوانها، الفئة و النوع و السنة. رسم غنيّ يحمل بياناته في ذاته.",
      de: "On the perfume page, Explore and atop the perfume page: a detailed colored flacon summing up the perfume — accord layers in their colors, the class, type and year. A rich drawing that carries its data within itself." },
    { ar: "قنينة صفحة البراند", en: "Brand page — the flacon",
      da: "تختلف عن قنينة صفحة العطر تصميماً و بيانات. ترسم أبسط: حدّ الجسم و الرقبة بلون الأكورد المسيطر، و الغطاء بلون الأكورد الثاني، و السائل بلون المسيطر وحده بلا تكديس. لا نصّ داخل الرسم — البيانات في زوايا البطاقة الأربع: المجموعة أعلى البداية، و السنة أعلى النهاية — أو تاج أفضل العقد، و الأكورد المسيطر أسفل البداية، و النوع أسفل النهاية. إطارها بلون الجنس و زواياها حادّة — و يصير الإطار ذهبياً لأفضل العقد. تحلّ صورة العطر الحقيقية محلّ الرسم متى توفّرت، و يظهر الاسم الإنجليزي تحتها سطرين.",
      de: "It differs from the perfume-page flacon in design and data. It is drawn leaner: body and neck borders take the dominant accord color, the cap the second accord, the liquid the dominant alone with no stacking. No text inside the drawing — the data sits in the four card corners: collection at the start-top, year at the end-top — or a Best-of-Decade crown, the dominant accord at the start-bottom, and the type at the end-bottom. Its frame is gender-colored with sharp corners — turning gold for Best of Decade. A real product photo replaces the drawing when one exists, with the English name on two lines beneath." },
    { ar: "النوتة المسيطرة و الشارات", en: "Dominant note & badges",
      da: "تحت البطاقة الإضافية سطرٌ بمؤشّر مربّع للأكورد المسيطر، و شارات مربّعة: منقطع (بنّي)، ضمن مجموعة (ذهبي)، نوتة مقيّدة (أحمر).",
      de: "Under the extra card: a square marker for the dominant accord, plus square badges — discontinued (brown), in a collection (gold), restricted note (red)." },
  ];

  // المميزات المتعلقة بالعطور
  const features = [
    { ar: "التثبيت", en: "Pinning",
      da: "ثبّت عطراً أو برانداً ليظهر مختصراً في أعلى صفحة الاستكشاف للوصول السريع.",
      de: "Pin a perfume or brand so it shows, shrunk, at the top of the Explore page for quick access." },
    { ar: "المجموعات", en: "Collections",
      da: "اجمع عطورك في مجموعات؛ العطر ضمن مجموعة يحمل شارة ذهبية على بطاقته.",
      de: "Group your perfumes into collections; a perfume in a collection carries a gold badge on its card." },
    { ar: "النوتبوك", en: "Notebook",
      da: "دوّن ملاحظة حرّة مرتبطة بالعطر من زرّ النوتبوك في صندوق التصدير.",
      de: "Jot a free note tied to the perfume via the Notebook button in the export box." },
    { ar: "الكاست أواي", en: "Cast Away",
      da: "صدّر بطاقة «كاست أواي» للعطر لمشاركتها خارج التطبيق.",
      de: "Export a Cast-Away card of the perfume to share it outside the app." },
    { ar: "الحفظ و النسخ", en: "Bookmark & Copy",
      da: "احفظ العطر في مرجعياتك، أو انسخ بياناته نصّاً من صندوق التصدير.",
      de: "Bookmark the perfume, or copy its data as text from the export box." },
  ];

  // شارات و مؤشّرات على القنينة و حولها
  const indicators = [
    { ar: "أفضل العقد", en: "Best of Decade",
      da: "مفتاح أخضر في نموذج العطر؛ خمس معيّنات خضراء صغيرة على غطاء القنينة أينما ظهرت، و العقد يظهر نصّاً تحت القنينة في صفحة العطر مشتقّاً من سنة الإصدار.",
      de: "A green toggle in the perfume form; five tiny green diamonds on the cap wherever the bottle appears, and the decade shows as text under the flacon, derived from the release year." },
    { ar: "مؤشّر القوّة", en: "Strength Indicator",
      da: "شريط هادئ بجانب نوع التركيز يمتلئ بنسبة الدرجة و بلونها — أخضر للخفيف فكهرماني فأحمر فبنّي غامق للثقيل المزعج جداً؛ يظهر في صفحة العطر و نموذج الإضافة و بطاقة التصدير، و سلّمه الكامل في دليل التناغمات.",
      de: "A quiet bar beside the concentration type, filling to the grade percent in its color — green for light, then amber, red, and dark brown for very heavy harsh; shown on the perfume page, the add form and the export card, with the full scale in the accords guide." },
  ];

  // المعرفة — معجم و قصص و رمزية و تدوين
  const knowledge = [
    { ar: "المعجم و القصص", en: "Glossary & Stories",
      da: "مفردات عطرية بشرح ثنائيّ اللغة مع موجِّهة القراءة و كلّ المَنشنات و تصدير PDF، و قصص من عالم العطور.",
      de: "Bilingual perfume vocabulary with a Reading Guide, All-mentions view and PDF export, plus stories from the perfume world." },
    { ar: "معنى علامة", en: "Marking Meaning",
      da: "رمزية العلامات بأسلوب صفحة العطر: وسوم و تفاعل و خاطرة و علامة مرجعية و تنقّل سابق و تالي.",
      de: "Symbolism pages in the perfume-page style: tags, reactions, a thought, a bookmark, and prev/next navigation." },
    { ar: "كلّ @ في التطبيق", en: "Every @ Across The App",
      da: "فهرس واحد لكلّ الإشارات: بحث و تصفية بالفئات و تحميل المزيد.",
      de: "One index for every mention: search, category filters and load-more." },
    { ar: "المدونة", en: "Blog",
      da: "اكتب & اقرأ — دوّن مدخلاتك بأنواعها و اقرأها في مكان واحد.",
      de: "Write & Read — jot entries of every type and read them in one place." },
    { ar: "الحكمة", en: "Wisdom",
      da: "دوّن حكمتك بلغتين مع مفضّلة و إعجاب و نسخ و تصدير.",
      de: "Write your wisdom in both languages, with favorites, reactions, copy and export." },
    { ar: "اقتباسات", en: "Quotes",
      da: "اجمع اقتباسات العطور مع إعجاب و حفظ و تصدير PDF.",
      de: "Collect perfume quotes with reactions, saving and PDF export." },
  ];

  // الاستخدام اليومي
  const daily = [
    { ar: "تقدم", en: "Progress",
      da: "سجلّ الارتداء و إحصاءاته البيانية مع تصدير التقرير، و رابطه في أعلى قائمة المستخدم.",
      de: "Your wear log and its charts with report export, linked at the top of the user menu." },
    { ar: "ترشيحات العطور", en: "Recommendations",
      da: "تشابه محلّي بلا إنترنت — اقتراحات من الكاتلوج نفسه.",
      de: "Local similarity, fully offline — suggestions from the catalog itself." },
    { ar: "الخلاط", en: "Layering",
      da: "احفظ تركيبات الطبقات بين عطورك و عُد إليها متى شئت.",
      de: "Save layering combinations of your perfumes and return to them any time." },
    { ar: "المازج", en: "The Mixer",
      da: "صمّم مزجات و احصل على توصيات ذكية.",
      de: "Design blends and get smart recommendations." },
    { ar: "الأعلى تقييماً", en: "Top Rated",
      da: "عطورك الأعلى تقييماً في قائمة واحدة.",
      de: "Your highest-rated perfumes in one list." },
  ];

  // الميزانية و المشتريات
  const money = [
    { ar: "ميزانية", en: "Budget",
      da: "مدخلات الصرف و التحليل الشهري، و رابطها في أعلى قائمة المستخدم.",
      de: "Spending entries and monthly analysis, linked at the top of the user menu." },
    { ar: "تحسن", en: "Goals",
      da: "أهداف تُضاف و تُقترح و تُتجاوز و تُصدّر.",
      de: "Goals you add, get suggested, skip and export." },
    { ar: "مشتريات", en: "Purchase",
      da: "سجل الشراء و سجل المنتجات و المتاجر و الأقسام في لوحة واحدة.",
      de: "Purchase log, product log, stores and categories in one dashboard." },
    { ar: "قائمة العينات", en: "Sample List",
      da: "تتبّع عيناتك في قائمة خاصة بها.",
      de: "Track your samples in their own list." },
    { ar: "أرغب بالشراء", en: "I Want To Buy",
      da: "قائمة ما تتمنّى اقتناءه لاحقاً.",
      de: "The list of what you wish to own next." },
  ];

  // الحساسية و الأمان
  const safety = [
    { ar: "صداع", en: "Headache",
      da: "قيّم حساسية الصداع من صفحة العطر، و راجع الدليل و السجلّ في صفحتها.",
      de: "Rate headache sensitivity from the perfume page, and review the guide and log on its page." },
    { ar: "حساسية جيوب أنفية", en: "Sinus Sensitivity",
      da: "بنفس الأسلوب — تقييم من صفحة العطر و دليل و سجلّ خاصّان.",
      de: "Same pattern — rated from the perfume page, with its own guide and log." },
    { ar: "مهملات", en: "Cast Away",
      da: "المخفيّ من القصص و المفردات و غيرها — استعادة بضغطة واحدة.",
      de: "Hidden stories, vocabulary and more — restored with a single tap." },
    { ar: "النسخ الاحتياطية و الاستعادة", en: "Backup & Restore",
      da: "احفظ بياناتك كاملة و استعِدها متى شئت.",
      de: "Save all your data and bring it back whenever you wish." },
  ];

  // مفتاح كل التناغمات بألوانها (منسوخ من دليل التناغمات، مرتّب أبجدياً بالإنجليزي)
  const allAccords = Object.values(ACCORDS)
    .filter((a) => a && (a.en || a.ar))
    .sort((a, b) => (a.en || "").localeCompare(b.en || ""));

  return (
    <div className="px-5 page-top pb-10 space-y-7">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
          <BackIcon className="w-5 h-5" />
        </button>
        <div>
          <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">شرح المميزات</h1>
          <p className="text-xs text-muted-foreground font-body mt-0.5" dir="ltr">Features Definition</p>
        </div>
      </div>

      {/* عيّنة كبيرة */}
      <div className="flex justify-center">
        <div className="w-44 h-44">
          <AccordFlaconCard perfume={SAMPLE} className="w-full h-full" />
        </div>
      </div>
      <p className="text-center text-xs text-muted-foreground font-body leading-relaxed" dir="rtl">
        كل قنينة في الكاتلوج تَحمل معلومات العطر برسمها
      </p>
      <p className="text-center text-xs text-muted-foreground font-body leading-relaxed" dir="ltr">
        Every bottle in the catalog carries the perfume's data in its drawing
      </p>

      {/* المفتاح */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">المفتاح</span>
          <span dir="ltr" className="block">The Key</span>
        </h2>
        <div className="space-y-3">
          {legend.map((it, i) => (
            <div key={i} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ألوان الفئة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">ألوان الفئة</span>
          <span dir="ltr" className="block">Gender Colors</span>
        </h2>
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          {[
            { c: "#22c55e", ar: "رجالي", en: "Men" },
            { c: "#f472b6", ar: "نسائي", en: "Women" },
            { c: "#fcd34d", ar: "للجنسين", en: "Unisex" },
          ].map((g, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="inline-block w-4 h-4 rounded-none" style={{ background: g.c }} />
              <span className="text-sm font-body" dir="auto">{isAr ? g.ar : g.en}</span>
            </div>
          ))}
        </div>
      </section>

      {/* أمثلة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">أمثلة</span>
          <span dir="ltr" className="block">Examples</span>
        </h2>
        <div className="grid grid-cols-3 gap-3">
          {SAMPLES.map((s) => (
            <div key={s.id} className="flex flex-col items-center">
              <div className="w-full aspect-square">
                <AccordFlaconCard perfume={s} className="w-full h-full" />
              </div>
              <span className="text-[11px] font-body mt-1" style={{ color: s.col }} dir="auto">{isAr ? s.labelAr : s.labelEn}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground font-body leading-relaxed" dir="rtl">
          عطر بأتناغم منفرد تملأ موجته القنينة، و عطر بعدّة تناغمات عطرية تتوزّع طبقاته بحسب أوزانها
        </p>
        <p className="text-xs text-muted-foreground font-body leading-relaxed" dir="ltr">
          A single-accord perfume fills the bottle; a multi-accord one splits into weighted layers
        </p>
      </section>

      {/* شرح صفحة العطر */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">شرح صفحة العطر</span>
          <span dir="ltr" className="block">The Perfume Page</span>
        </h2>
        <div className="space-y-3">
          {perfumePage.map((it, i) => (
            <div key={i} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
        </div>
      </section>

      {/* بطاقات العطر و مميزاتها */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">بطاقات العطر و مميزاتها</span>
          <span dir="ltr" className="block">Perfume Cards & Features</span>
        </h2>
        <div className="space-y-3">
          {cards.map((it, i) => (
            <div key={i} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
          {features.map((it, i) => (
            <div key={`f${i}`} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
        </div>
      </section>

      {/* بقية مميزات التطبيق — خمسة أقسام بنفس الأسلوب */}
      {[
        { ar: "شارات و مؤشّرات", en: "Badges & Indicators", items: indicators },
        { ar: "المعرفة", en: "Knowledge", items: knowledge },
        { ar: "الاستخدام اليومي", en: "Daily Use", items: daily },
        { ar: "الميزانية و المشتريات", en: "Budget & Purchases", items: money },
        { ar: "الحساسية و الأمان", en: "Sensitivity & Safety", items: safety },
      ].map((sec, si) => (
        <section key={`sec${si}`} className="space-y-3">
          <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
            <span dir="rtl" className="block">{sec.ar}</span>
            <span dir="ltr" className="block">{sec.en}</span>
          </h2>
          <div className="space-y-3">
            {sec.items.map((it, i) => (
              <div key={i} className="leading-relaxed">
                <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
                <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
                <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
                <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
              </div>
            ))}
          </div>
        </section>
      ))}

      {/* مفتاح كل التناغمات بألوانها — منسوخ من دليل التناغمات، ثنائي اللغة بلا نقطة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">مفتاح كل التناغمات بألوانها</span>
          <span dir="ltr" className="block">All Accord Colors</span>
        </h2>
        <p className="text-xs text-muted-foreground font-body" dir="rtl">الألوان نفسها المستخدمة على كل قنينة في الكاتلوج، لكل تناغمٍ لونه المميّز</p>
        <p className="text-xs text-muted-foreground font-body" dir="ltr">The exact colors used on every flacon in the catalog</p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
          {allAccords.map((a, i) => (
            <div key={i} className="flex items-center gap-2 min-w-0">
              <span className="w-3.5 h-3.5 rounded-none shrink-0 ring-1 ring-black/10" style={{ background: a.bar }} />
              <span className="text-xs font-body text-foreground/85 truncate" dir="auto">{a.en} {a.ar}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ترابط: صفحة التناغمات */}
      <Link
        to="/accords-guide"
        className="flex items-center justify-between py-3 px-1 border-t border-border/40 hover:bg-secondary/30 transition-colors"
        dir={isAr ? "rtl" : "ltr"}
      >
        <span className="text-sm font-body font-semibold text-[var(--brand)]">
          {isAr ? "ما هو التناغم العطري" : "What Is An Accord"}
        </span>
        <span className="text-xs text-muted-foreground font-body">{isAr ? "دليل تناغم" : "Accords Guide"}</span>
      </Link>
    </div>
  );
}

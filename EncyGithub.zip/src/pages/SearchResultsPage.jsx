import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { Search } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import { useLang } from "@/lib/LanguageContext";
import { rankName } from "@/lib/sortName";
import { searchIndexReady, searchPerfumeIds } from "@/lib/searchIndex";
import { brandCategoryKey, brandCategoryLabel } from "@/lib/brandCategories";
import BackIcon from "@/components/shared/BackIcon";

// resolver نص الاقتباس
function quoteTexts(x) {
  if (x?.text_en || x?.text_ar) return { en: x.text_en || "", ar: x.text_ar || "" };
  const raw = x?.text_enar || x?.text || ""; if (!raw) return { en: "", ar: "" };
  const m = raw.match(/^([^\u0600-\u06FF]*)([\u0600-\u06FF][\s\S]*)$/);
  if (m && m[1].trim()) return { en: m[1].trim(), ar: m[2].trim() };
  if (/[\u0600-\u06FF]/.test(raw)) return { en: "", ar: raw };
  return { en: raw, ar: "" };
}

/**
 * SearchResultsPage — صفحة نتائج بحث **موحّدة**: حقل بحث واحد لكلّ التطبيق يجلب نتائج
 * من كلّ الأنواع (عطور، براندات، عطّارون، نوتات، موسوعة، مصطلحات، اقتباسات) و يعرضها
 * مجموعةً حسب نوعها. العطور عبر فهرس البحث ثمّ getMany (بلا تحميل 130 ألف). بقيّة
 * المتاجر قوائم تُرشّح بالذاكرة (محدودة، مخزّنة بـstaleTime).
 */
// قسم بترقيم كسول: يعرض ٢٠ ثمّ «نتائج أكثر» — بلا أعداد أو رموز
function PagedSection({ label, items, renderRow, wrapClass = "px-4", isAr, step = 20 }) {
  const [shown, setShown] = useState(step);
  if (!items || !items.length) return null;
  return (
    <div className="mb-4">
      <h2 className="px-5 py-2 text-xs font-heading font-bold text-[var(--brand)] tracking-wide">{label}</h2>
      <div className={wrapClass}>{items.slice(0, shown).map(renderRow)}</div>
      {items.length > shown && (
        <button type="button" onClick={() => setShown((s) => s + step)}
          className="px-5 pt-2 text-xs font-body font-semibold text-[var(--brand)] hover:opacity-70 transition-opacity">
          {isAr ? "نتائج أكثر" : "More Results"}
        </button>
      )}
    </div>
  );
}

export default function SearchResultsPage() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const q = (params.get("q") || "").trim();
  const cat = (params.get("cat") || "").trim();   // فئة براند — تصفية بالحقل لا بحث
  const ql = q.toLowerCase();
  const has = (...vals) => vals.some((v) => v && (String(v).toLowerCase().includes(ql) || String(v).includes(q)));

  const submit = (term) => {
    const s = (term != null ? term : q).trim();
    if (s) setParams({ q: s });
  };

  // ── عطور: عبر الفهرس (آمن) ثمّ احتياط بادئة الاسم ──
  const { data: perfumes = [], isLoading: pLoading } = useQuery({
    queryKey: ["search-perfumes", q],
    enabled: !!q,
    queryFn: async () => {
      const t = ql;
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(t);
        if (ids && ids.length) return apphost.entities.Perfume.getMany(ids);
      }
      const prefix = String(rankName(t)) + t;
      const { items } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", { lower: prefix, upper: prefix + "\uffff" }, 0, 100, "next", false
      );
      return items || [];
    },
    staleTime: 5 * 60 * 1000,
  });

  const { data: allBrands = [] } = useQuery({ queryKey: ["search-brands"], enabled: !!q || !!cat, queryFn: () => apphost.entities.PerfumeBrand.list("name"), staleTime: 5 * 60 * 1000 });
  const brands = useMemo(() => {
    if (cat) return allBrands.filter((b) => b && !b.hidden && brandCategoryKey(b) === cat);
    return !q ? [] : allBrands.filter((b) => b && !b.hidden && has(b.name, b.name_en, b.name_ar, b.country, b.country_ar));
  }, [allBrands, q, cat]); // eslint-disable-line react-hooks/exhaustive-deps

  const { data: allPerfumers = [] } = useQuery({ queryKey: ["search-perfumers"], enabled: !!q, queryFn: () => apphost.entities.Perfumer.list("name"), staleTime: 5 * 60 * 1000 });
  const perfumers = useMemo(() => !q ? [] : allPerfumers.filter((x) => x && has(x.name, x.name_en, x.name_ar, x.nationality)), [allPerfumers, q]);

  const { data: allNotes = [] } = useQuery({ queryKey: ["search-notes"], enabled: !!q, queryFn: () => apphost.entities.PerfumeNote.list("name"), staleTime: 5 * 60 * 1000 });
  const notes = useMemo(() => !q ? [] : allNotes.filter((n) => n && has(n.name, n.name_en, n.name_ar, n.odor_family)), [allNotes, q]);

  const { data: allEnc = [] } = useQuery({ queryKey: ["search-enc"], enabled: !!q, queryFn: () => apphost.entities.EncEntry.list("-updated_date", 20000), staleTime: 5 * 60 * 1000 });
  const encEntries = useMemo(() => !q ? [] : allEnc.filter((e) => e && has(e.titles?.ar, e.titles?.en, e.texts?.ar, e.texts?.en)).slice(0, 80), [allEnc, q]);

  const { data: allGlossary = [] } = useQuery({ queryKey: ["search-glossary"], enabled: !!q, queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"), staleTime: 5 * 60 * 1000 });
  const glossary = useMemo(() => !q ? [] : allGlossary.filter((t) => t && has(t.term_en, t.term_ar, t.meaning, t.meaning_ar, t.tags)), [allGlossary, q]);

  const { data: allQuotes = [] } = useQuery({ queryKey: ["search-quotes"], enabled: !!q, queryFn: () => apphost.entities.Quote.list("-created_date"), staleTime: 5 * 60 * 1000 });
  const quotes = useMemo(() => !q ? [] : allQuotes.filter((x) => { const t = quoteTexts(x); return has(t.en, t.ar, x.quoteauthor, x.author); }), [allQuotes, q]);

  const total = perfumes.length + brands.length + perfumers.length + notes.length + encEntries.length + glossary.length + quotes.length;
  const L = (en, ar) => isAr ? ar : en;

  return (
    <div className="page-top pb-24">
      <div className="px-5 pt-2 pb-3 space-y-3">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="rounded-none hover:bg-secondary/20" onClick={() => navigate(-1)}>
            <BackIcon className="w-5 h-5" />
          </Button>
          <h1 className="font-heading text-lg font-bold text-[var(--brand)]">{L("Results", "النتائج")}</h1>
        </div>
        <div className="relative">
          <Search className={`absolute ${isAr ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none`} />
          <Input
            defaultValue={q}
            onKeyDown={(e) => { if (e.key === "Enter") submit(e.currentTarget.value); }}
            placeholder=""
            dir={isAr ? "rtl" : "ltr"}
            className={`${isAr ? "pr-10" : "pl-10"} h-11 rounded-none font-body bg-[var(--page-bg,#fff)] border border-transparent`}
          />
        </div>
        {q && <p className="text-xs text-muted-foreground font-body">{L("Results for", "نتائج")} «{q}»</p>}
        {cat && <p className="text-xs text-muted-foreground font-body">{brandCategoryLabel({ brand_category: cat }, isAr)}</p>}
      </div>

      {pLoading && total === 0 ? (
        <div className="flex justify-center py-16"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>
      ) : (!q && !cat) ? null : total === 0 ? (
        <p className="text-center text-sm text-muted-foreground font-body py-16">{L("No matching results", "لا نتائج مطابِقة")}</p>
      ) : (
        <>
          <PagedSection label={L("Perfumes", "العطور")} items={perfumes} isAr={isAr} wrapClass="px-4 grid grid-cols-2 gap-2"
            renderRow={(p) => <PerfumeCard key={p.id} perfume={p} compact={60} />} />

          <PagedSection label={L("Brands", "البراندات")} items={brands} isAr={isAr}
            renderRow={(b) => (
              <Link key={b.id} to={`/brand?id=${b.id}`} className="block bg-card p-4 border-t border-b border-border">
                {b.name_ar && <p className="text-xs font-body text-[#9D174D]" dir="rtl">{b.name_ar}</p>}
                <p className="font-body font-semibold text-sm">{b.name_en || b.name}</p>
                {(b.country || b.country_ar) && <p className="text-xs text-muted-foreground font-body">{isAr ? (b.country_ar || b.country) : (b.country || b.country_ar)}</p>}
              </Link>
            )} />

          <PagedSection label={L("Perfumers", "العطّارون")} items={perfumers} isAr={isAr}
            renderRow={(x) => (
              <Link key={x.id} to={`/perfumer?id=${x.id}`} className="block bg-card p-4 border-t border-b border-border">
                {x.name_ar && <p className="text-xs font-body text-[#9D174D]" dir="rtl">{x.name_ar}</p>}
                <p className="font-body font-semibold text-sm">{x.name_en || x.name}</p>
                {x.nationality && <p className="text-xs text-muted-foreground font-body">{x.nationality}</p>}
              </Link>
            )} />

          <PagedSection label={L("Notes", "النوتات")} items={notes} isAr={isAr}
            renderRow={(n) => (
              <Link key={n.id} to={`/note?id=${n.id}`} className="flex items-center gap-3 bg-card p-3 border-t border-b border-border">
                {n.image_url && <img src={n.image_url} alt="" className="w-8 h-8 object-cover" />}
                <span className="min-w-0">
                  {n.name_ar && <span className="block text-xs font-body text-[#9D174D]" dir="rtl">{n.name_ar}</span>}
                  <span className="font-body text-sm">{n.name_en || n.name}</span>
                </span>
              </Link>
            )} />

          <PagedSection label={L("Encyclopedia", "الموسوعة")} items={encEntries} isAr={isAr}
            renderRow={(e) => (
              <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)} className="block w-full text-start bg-card p-4 border-t border-b border-border">
                {e.titles?.ar && <p className="text-xs font-body text-[#9D174D]" dir="rtl">{e.titles.ar}</p>}
                {e.titles?.en && <p className="font-body text-sm">{e.titles.en}</p>}
              </button>
            )} />

          <PagedSection label={L("Glossary", "المصطلحات")} items={glossary} isAr={isAr}
            renderRow={(t) => (
              <Link key={t.id} to={`/glossary-term?id=${t.id}`} className="block bg-card p-4 border-t border-b border-border">
                {t.term_ar && <p className="text-xs font-body text-[#9D174D]" dir="rtl">{t.term_ar}</p>}
                <p className="font-body text-sm">{t.term_en || t.term_ar}</p>
              </Link>
            )} />

          <PagedSection label={L("Quotes", "الاقتباسات")} items={quotes} isAr={isAr} wrapClass="px-4 space-y-2"
            renderRow={(x) => {
              const t = quoteTexts(x); const au = (x.quoteauthor || x.author || "").trim();
              return (
                <div key={x.id} className="bg-card p-4 border-t border-b border-border">
                  {t.ar && <p className="font-body text-sm" dir="rtl">{t.ar}</p>}
                  {t.en && <p className="font-body text-sm text-muted-foreground">{t.en}</p>}
                  {au && <p className="text-xs text-[var(--brand)] font-body mt-1">— {au}</p>}
                </div>
              );
            }} />
        </>
      )}
    </div>
  );
}

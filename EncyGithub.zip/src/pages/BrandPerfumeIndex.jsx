import { useState, useEffect, useMemo, useCallback, useRef, memo } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Search, Loader2, TestTubeDiagonal, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import { rankName } from "@/lib/sortName";
import { downloadBlob } from "@/lib/exportHelper";
import BackIcon from "@/components/shared/BackIcon";

/**
 * BrandPerfumeIndex — فهرس موحّد منفصل تماماً عن /brand?id= و /brands و صفحات العطور.
 * يشير إليه الجميع و يغذّيهم. وضعان: «براند» (افتراضي، فيه Total/Top محسوبان من
 * perfume_ids بلا تحميل 130 ألف) و «عطر» (بلا Total/Top). كل النتائج داخل الصفحة.
 * «All» زرّ طيّ/فتح الحروف فقط — لا يعرض نتائج. اختيار حرف → تحميل كسول.
 */

// أيقونة «العدد» (Total)
function ScatterSquares({ className, style }) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="square" strokeLinejoin="miter" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M4 3v17h17" />
      <rect x="7" y="13.4" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="10.6" y="8.6" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="14.2" y="11.4" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="16.6" y="5.6" width="2.4" height="2.4" fill="currentColor" stroke="none" />
      <rect x="8.4" y="6.4" width="2.4" height="2.4" fill="currentColor" stroke="none" />
    </svg>
  );
}

const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").concat("#");
const PAGE = 50;

function trimText(s, max) {
  const str = String(s || "");
  if (str.length <= max) return str;
  return str.slice(0, max).replace(/\s+$/, "") + "..";
}

// حدود فهرس العطر (بادئة/حرف) — يُقرأ صفحةً صفحة بلا تحميل القاعدة كاملة.
function boundsFor(query, letter) {
  const t = (query || "").trim().toLowerCase();
  if (t) {
    const prefix = String(rankName(t)) + t;
    return { lower: prefix, upper: prefix + "\uffff" };
  }
  if (!letter) return undefined;
  if (letter === "#") return { lower: "1" };
  const prefix = "0" + letter.toLowerCase();
  return { lower: prefix, upper: prefix + "\uffff" };
}

// عدد عطور البراند من perfume_ids — رخيص، بلا تحميل العطور.
function brandPerfumeCount(b) {
  if (!b || !b.perfume_ids) return 0;
  return String(b.perfume_ids).split(",").map((s) => s.trim()).filter(Boolean).length;
}
function brandFirstLetter(b) {
  const n = (b.name || b.name_en || "").trim().toUpperCase();
  const c = n[0] || "";
  return /[A-Z]/.test(c) ? c : "#";
}

const PerfumeRow = memo(function PerfumeRow({ p }) {
  return (
    <Link to={`/perfume?id=${p.id}`} dir="ltr"
      className="flex items-center justify-between gap-3 py-2.5 px-2 -mx-2 rounded-none hover:bg-secondary/40 transition-colors group">
      <div className="min-w-0 flex-1 overflow-hidden">
        <p className="text-sm font-body font-medium text-foreground group-hover:text-[var(--brand)] transition-colors whitespace-nowrap overflow-hidden">
          {trimText(p.name_en || p.name || p.name_ar, 28)}
        </p>
      </div>
      {p.brand_name && (
        <span className="text-[10px] text-muted-foreground font-body shrink-0 max-w-[28%] whitespace-nowrap overflow-hidden text-right">{trimText(p.brand_name, 14)}</span>
      )}
    </Link>
  );
});

const BrandRow = memo(function BrandRow({ b, isAr }) {
  const ar = b.name_ar && b.name_ar.trim();
  return (
    <Link to={`/brand?id=${b.id}`} dir={isAr ? "rtl" : "ltr"}
      className="flex items-center gap-2 py-2.5 px-2 -mx-2 rounded-none hover:opacity-70 transition-opacity">
      <span className="font-body text-sm min-w-0 truncate">
        {ar && <span className="font-semibold">{b.name_ar}</span>}
        {ar && b.name ? <span className="opacity-50"> .. </span> : null}
        {b.name && <span style={{ letterSpacing: "0.02em" }}>{b.name}</span>}
      </span>
    </Link>
  );
});

export default function BrandPerfumeIndex() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  const [mode, setMode] = useState("brand"); // البراند هو الافتراضي

  // ===== فهرس العطر (تحميل كسول حرفاً حرفاً) =====
  const [letter, setLetter] = useState("");
  const [query, setQuery] = useState("");
  const [items, setItems] = useState([]);
  const [pTotal, setPTotal] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [pLoading, setPLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [pLettersOpen, setPLettersOpen] = useState(false);

  const offsetRef = useRef(0);
  const reqIdRef = useRef(0);

  const bounds = useMemo(() => boundsFor(query, letter), [query, letter]);

  const loadPage = useCallback(async (reset) => {
    if (bounds === undefined) { setItems([]); setPTotal(0); setHasMore(false); setPLoading(false); setLoadingMore(false); return; }
    const myReq = ++reqIdRef.current;
    if (reset) { setPLoading(true); offsetRef.current = 0; } else setLoadingMore(true);
    try {
      const { items: rows } = await apphost.entities.Perfume.pageByIndexRange("sort_key", bounds, offsetRef.current, PAGE, "next", false);
      if (myReq !== reqIdRef.current) return;
      offsetRef.current += rows.length;
      setItems((prev) => (reset ? rows : [...prev, ...rows]));
      setHasMore(rows.length === PAGE);
    } catch (e) {
      console.error("perfume index load failed", e);
      if (myReq === reqIdRef.current && reset) { setItems([]); setPTotal(0); setHasMore(false); }
    } finally {
      if (myReq === reqIdRef.current) { setPLoading(false); setLoadingMore(false); }
    }
  }, [bounds]);

  useEffect(() => { if (mode === "perfume") loadPage(true); }, [loadPage, mode]);

  const onPickLetter = (l) => { setQuery(""); setLetter(l); };

  // ===== فهرس البراند (رخيص — perfume_ids، بلا 130 ألف) =====
  const [bView, setBView] = useState(""); // "" | "total" | "top" | "letters"
  const [bLetter, setBLetter] = useState("");
  const [bLettersOpen, setBLettersOpen] = useState(false);
  const [bShown, setBShown] = useState(20); // تحميل تدريجي 20/دفعة

  const { data: allBrands = [], isLoading: bLoading } = useQuery({
    queryKey: ["bpi-brands"],
    enabled: mode === "brand",
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    staleTime: Infinity,
  });

  const brandRows = useMemo(() => {
    if (mode !== "brand" || !bView) return [];
    const live = (allBrands || []).filter((b) => b && !b.hidden);
    if (bView === "total") return [...live].sort((a, b) => brandPerfumeCount(b) - brandPerfumeCount(a));
    if (bView === "top") return [...live].sort((a, b) => brandPerfumeCount(b) - brandPerfumeCount(a));
    if (bView === "letters" && bLetter) return live.filter((b) => brandFirstLetter(b) === bLetter).sort((a, b) => (a.name || "").localeCompare(b.name || ""));
    return [];
  }, [mode, allBrands, bView, bLetter]);

  // إعادة ضبط التحميل التدريجي عند كل تغيير في العرض أو الحرف
  useEffect(() => { setBShown(20); }, [bView, bLetter]);

  const onPickBrandLetter = (l) => { setBView("letters"); setBLetter(l); };

  // تصدير العرض الحاليّ فقط نصّاً — لا تصدير لكامل الصفحة.
  const exportCurrent = async () => {
    const lines = [];
    let title = "";
    if (mode === "brand") {
      title = isAr ? "فهرس البراندات" : "Brand Index";
      for (const b of brandRows) {
        const ar = b.name_ar && b.name_ar.trim();
        lines.push([ar, b.name].filter(Boolean).join(" .. "));
      }
    } else {
      title = isAr ? "فهرس العطور" : "Perfume Index";
      for (const p of items) {
        const en = p.name_en || p.name || "";
        const ar = isAr ? (p.name_ar && p.name_ar.trim()) : "";
        const nm = [ar, en].filter(Boolean).join(" .. ");
        lines.push(p.brand_name ? `${nm} — ${p.brand_name}` : nm);
      }
    }
    if (!lines.length) return;
    const text = `${title}\n\n${lines.join("\n")}`;
    try {
      const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
      await downloadBlob(blob, `${title}.txt`);
    } catch (e) { console.error("index export failed", e); }
  };
  const canExport = mode === "brand" ? brandRows.length > 0 : items.length > 0;

  return (
    <div className="px-5 page-top pb-16">
      {/* رأس */}
      <div className={`flex items-center gap-3 mb-4 ${isAr ? "flex-row-reverse" : ""}`}>
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors shrink-0" title={isAr ? "رجوع" : "Back"}>
          <BackIcon className="w-5 h-5" />
        </button>
        <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">{isAr ? "الفهرس" : "Index"}</h1>
        {canExport && (
          <button type="button" onClick={exportCurrent} className="ms-auto w-8 h-8 flex items-center justify-center hover:opacity-70 transition-opacity"
            aria-label={isAr ? "تصدير العرض الحالي نصّاً" : "Export current view as text"} title={isAr ? "تصدير نصّ" : "Export text"}>
            <Download className="w-5 h-5" style={{ color: "var(--brand)" }} />
          </button>
        )}
      </div>

      {/* مفتاح الوضع: براند | عطر */}
      <div className="flex items-center gap-5 mb-4" dir={isAr ? "rtl" : "ltr"}>
        <button type="button" onClick={() => setMode("brand")} className="text-sm font-body font-bold hover:opacity-80 transition-opacity"
          style={{ color: mode === "brand" ? "var(--brand)" : "#9a7b1f", opacity: mode === "brand" ? 1 : 0.55 }}>
          {isAr ? "براند" : "Brand"}
        </button>
        <button type="button" onClick={() => setMode("perfume")} className="text-sm font-body font-bold hover:opacity-80 transition-opacity"
          style={{ color: mode === "perfume" ? "var(--brand)" : "#9a7b1f", opacity: mode === "perfume" ? 1 : 0.55 }}>
          {isAr ? "عطر" : "Perfume"}
        </button>
      </div>

      {mode === "brand" ? (
        <>
          {/* صفّ البراند: Total · Top · All Brands · حروف (بلا إطارات) */}
          <div className="flex flex-wrap items-center gap-2 mb-4" dir="ltr">
            <button type="button" onClick={() => setBView("total")} title={isAr ? "العدد" : "Total"}
              className="flex items-center justify-center w-7 h-7 hover:opacity-70 transition-opacity">
              <ScatterSquares className="w-5 h-5" style={{ color: bView === "total" ? "var(--brand)" : "#9a7b1f" }} />
            </button>
            <button type="button" onClick={() => setBView("top")} title={isAr ? "الأعلى" : "Top"}
              className="flex items-center justify-center w-7 h-7 hover:opacity-70 transition-opacity">
              <TestTubeDiagonal className="w-5 h-5" style={{ color: bView === "top" ? "var(--brand)" : "#9a7b1f" }} />
            </button>
            <button type="button" onClick={() => setBLettersOpen((v) => !v)}
              className="px-1 h-7 text-xs font-body font-bold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
              {isAr ? "كل البراندات" : "All Brands"}
            </button>
            {bLettersOpen && LETTERS.map((l) => (
              <button key={l} type="button" onClick={() => onPickBrandLetter(l)}
                className="w-6 h-7 text-xs font-body font-bold hover:opacity-70 transition-opacity"
                style={{ color: (bView === "letters" && bLetter === l) ? "var(--brand)" : "#9a7b1f" }}>
                {l}
              </button>
            ))}
          </div>

          {bLoading ? (
            <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 text-[var(--brand)] animate-spin" /></div>
          ) : !bView ? (
            <div className="text-center py-16 space-y-2">
              <Search className="w-9 h-9 text-[var(--brand)]/25 mx-auto" />
              <p className="text-sm text-muted-foreground font-body">{isAr ? "اختر حرفاً أو كل البراندات" : "Pick a letter or All Brands"}</p>
            </div>
          ) : brandRows.length === 0 ? (
            <div className="text-center py-16"><p className="text-sm text-muted-foreground font-body">{isAr ? "لا براندات" : "No brands"}</p></div>
          ) : (
            <div className="divide-y divide-border/30">
              {brandRows.slice(0, bShown).map((b) => <BrandRow key={b.id} b={b} isAr={isAr} />)}
              {brandRows.length > bShown && (
                <div className="flex justify-center pt-3">
                  <button type="button" onClick={() => setBShown((n) => n + 20)}
                    className="text-sm font-body font-bold hover:opacity-80 transition-opacity" style={{ color: "var(--brand)" }}>
                    {isAr ? "عرض المزيد" : "Show more"}
                  </button>
                </div>
              )}
            </div>
          )}
        </>
      ) : (
        <>
          {/* بحث عطر */}
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input name="bpi-perfume-search" dir="ltr" value={query} onChange={(e) => setQuery(e.target.value)}
              placeholder={isAr ? "بحث عن عطر" : "Search Perfume"}
              className="w-full pl-10 pr-9 h-11 rounded-none font-body bg-transparent border-0 text-sm focus-visible:outline-none focus-visible:ring-0" />
          </div>

          {/* صفّ العطر: All Perfumes · حروف (بلا Total/Top، بلا إطارات) */}
          <div className="flex flex-wrap items-center gap-2 mb-4" dir="ltr">
            <button type="button" onClick={() => setPLettersOpen((v) => !v)}
              className="px-1 h-7 text-xs font-body font-bold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
              {isAr ? "كل العطور" : "All Perfumes"}
            </button>
            {pLettersOpen && LETTERS.map((l) => (
              <button key={l} type="button" onClick={() => onPickLetter(l)}
                className="w-6 h-7 text-xs font-body font-bold hover:opacity-70 transition-opacity"
                style={{ color: (!query.trim() && letter === l) ? "var(--brand)" : "#9a7b1f" }}>
                {l}
              </button>
            ))}
          </div>

          {(!letter && !query.trim()) ? (
            <div className="text-center py-16 space-y-2">
              <Search className="w-9 h-9 text-[var(--brand)]/25 mx-auto" />
              <p className="text-sm text-muted-foreground font-body">{isAr ? "اختر حرفاً أو كل العطور" : "Pick a letter or All Perfumes"}</p>
            </div>
          ) : pLoading ? (
            <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 text-[var(--brand)] animate-spin" /></div>
          ) : items.length === 0 ? (
            <div className="text-center py-16"><p className="text-sm text-muted-foreground font-body">{isAr ? "لا عطور هنا" : "No perfumes here"}</p></div>
          ) : (
            <>
              <div className="divide-y divide-border/30">
                {items.map((p) => <PerfumeRow key={p.id} p={p} />)}
              </div>
              {hasMore && (
                <div className="flex justify-center pt-4">
                  <button onClick={() => loadPage(false)} disabled={loadingMore}
                    className="inline-flex items-center gap-2 rounded-none text-xs font-body font-medium text-foreground disabled:opacity-60 transition-colors">
                    {loadingMore ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                    {isAr ? "عرض المزيد" : "Load more"}
                  </button>
                </div>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}

import { useState, useEffect, useRef, useCallback } from "react";
import { createPortal } from "react-dom";
import { Link, useLocation } from "react-router-dom";
import { Home, Tally4, Search, ShoppingBag, Ratio, Sunset, Music } from "lucide-react";
import { cn } from "@/lib/utils";
import { useLang } from "@/lib/LanguageContext";
import { getSecureStorage } from "@/lib/storageEncryption";

function PerfumeBottle({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 3h8v2H8z" />
      <path d="M10 5v3h4V5" />
      <path d="M9 8h6v10c0 1.1-.9 2-2 2h-2c-1.1 0-2-.9-2-2V8z" />
    </svg>
  );
}

// أيقونات مؤقتة inline (Turtle/CreditCard غير مؤكّدتين في lucide 1.16) — نصمّم بدائل مبتكرة لاحقاً.
function SaturnIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <g transform="rotate(9 21 31)">
        <path d="M11 25 H31 V33 A6 6 0 0 1 25 39 H17 A6 6 0 0 1 11 33 Z" />
        <path d="M31 27 H35 A3.3 3.3 0 0 1 35 33 H31" />
      </g>
      <path d="M13 22 C 11.5 19.5, 14.5 18, 13 15" />
      <path d="M17 22 C 18.5 19.5, 15.5 18, 17 15" />
      <path d="M21 22 C 19.5 19.5, 22.5 18, 21 15" />
      <path d="M25 22 C 26.5 19.5, 23.5 18, 25 15" />
      <path d="M29 22 C 27.5 19.5, 30.5 18, 29 15" />
    </svg>
  );
}
function NetworkIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <line x1="24" y1="24" x2="24" y2="10" />
      <line x1="24" y1="24" x2="38" y2="16" />
      <line x1="24" y1="24" x2="38" y2="34" />
      <line x1="24" y1="24" x2="10" y2="32" />
      <circle cx="24" cy="24" r="3.4" fill="currentColor" stroke="none" />
      <circle cx="24" cy="8" r="3" />
      <circle cx="40" cy="15" r="3" />
      <circle cx="40" cy="35" r="3" />
      <circle cx="9" cy="33" r="3" />
    </svg>
  );
}
function TrailIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 41 C 7 35, 15 32, 11 25" />
      <path d="M21 43 C 17 35, 25 31, 21 21" />
      <path d="M31 41 C 27 35, 35 32, 31 24" />
      <path d="M41 42 C 37 36, 45 33, 41 27" />
    </svg>
  );
}

// أيقونة «اكتشف»: عيّنة عطر صغيرة (قارورة نحيلة) بمضخّة، يخرج منها رشّ — تتبع لون البلاطة عبر currentColor.
function SampleSprayIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 23 v13 a4 4 0 0 0 4 4 h2 a4 4 0 0 0 4 -4 v-13 z" />
      <line x1="19" y1="31.5" x2="29" y2="31.5" />
      <path d="M21.5 23 v-3 h5 v3" />
      <rect x="20.5" y="14" width="7" height="6" rx="1.2" />
      <path d="M27 16.4 l3 -2" />
      <g stroke="none">
        <rect x="31.4" y="11.1" width="2.4" height="2.4" fill="#E36A91" transform="rotate(12 32.6 12.3)" />
        <rect x="34.6" y="9" width="2" height="2" fill="#E0972A" transform="rotate(12 35.6 10)" />
        <rect x="37.15" y="11.25" width="1.7" height="1.7" fill="#3FA7D6" transform="rotate(12 38 12.1)" />
        <rect x="35.68" y="6.88" width="1.5" height="1.5" fill="#9B7BBF" transform="rotate(12 36.4 7.6)" />
      </g>
    </svg>
  );
}

// أيقونة «Purchase»: رشّات متناثرة تملأ المساحة بخلفية شفافة — لا علاقة لها بالعطور. تتبع لون البلاطة.
function SpritzScatterIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" stroke="none" aria-hidden="true">
      <rect x="6.7" y="8.7" width="4.6" height="4.6" fill="#E36A91" transform="rotate(12 9 11)" />
      <rect x="15.7" y="5.7" width="2.6" height="2.6" fill="#9B7BBF" transform="rotate(12 17 7)" />
      <rect x="22.1" y="11.1" width="3.8" height="3.8" fill="#E0972A" transform="rotate(12 24 13)" />
      <rect x="30.5" y="6.5" width="3" height="3" fill="#6FBF73" transform="rotate(12 32 8)" />
      <rect x="37.8" y="9.8" width="4.4" height="4.4" fill="#3FA7D6" transform="rotate(12 40 12)" />
      <rect x="11.4" y="20.4" width="3.2" height="3.2" fill="#F2C12E" transform="rotate(12 13 22)" />
      <rect x="19.6" y="23.6" width="4.8" height="4.8" fill="#E14B4B" transform="rotate(12 22 26)" />
      <rect x="29.6" y="20.6" width="2.8" height="2.8" fill="#8E8DD0" transform="rotate(12 31 22)" />
      <rect x="38.2" y="23.2" width="3.6" height="3.6" fill="#2E7D52" transform="rotate(12 40 25)" />
      <rect x="8.1" y="32.1" width="3.8" height="3.8" fill="#EE9CB6" transform="rotate(12 10 34)" />
      <rect x="16.7" y="36.7" width="4.6" height="4.6" fill="#B5532A" transform="rotate(12 19 39)" />
      <rect x="26.5" y="31.5" width="3" height="3" fill="#3FA7D6" transform="rotate(12 28 33)" />
      <rect x="35" y="36" width="4" height="4" fill="#9B7BBF" transform="rotate(12 37 38)" />
      <rect x="42.9" y="38.9" width="2.2" height="2.2" fill="#E0972A" transform="rotate(12 44 40)" />
    </svg>
  );
}

// أيقونة «Progress»: ميدان من ٢٦ معيناً و مربعاً مختلفة الأحجام، متناثرة، بميلانٍ متفاوت، بألوان الأكورد — بلا أسهم.
function ProgressGemsIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" stroke="none" aria-hidden="true">
      <rect x="6.15" y="33.75" width="3.3" height="3.3" fill="#C0392B" transform="rotate(41 7.8 35.4)" />
      <rect x="11.43" y="12.23" width="3.9" height="3.9" fill="#C0392B" transform="rotate(48 13.38 14.18)" />
      <rect x="14.66" y="6.93" width="2.6" height="2.6" fill="#EE9CB6" transform="rotate(18 15.96 8.23)" />
      <rect x="32.01" y="36.78" width="3.5" height="3.5" fill="#F2C12E" transform="rotate(47 33.76 38.53)" />
      <rect x="5.54" y="40.3" width="2.6" height="2.6" fill="#3FA7D6" transform="rotate(13 6.84 41.6)" />
      <rect x="32.99" y="18.04" width="2.7" height="2.7" fill="#6D28D9" transform="rotate(40 34.34 19.39)" />
      <rect x="31.86" y="12.2" width="3" height="3" fill="#2E7D52" transform="rotate(14 33.36 13.7)" />
      <rect x="4.12" y="7.05" width="2.7" height="2.7" fill="#B5532A" transform="rotate(42 5.47 8.4)" />
      <rect x="21.99" y="6.76" width="2.7" height="2.7" fill="#B5532A" transform="rotate(43 23.34 8.11)" />
      <rect x="31.38" y="32.67" width="3.8" height="3.8" fill="#EE9CB6" transform="rotate(10 33.28 34.57)" />
      <rect x="14.12" y="25.67" width="2.8" height="2.8" fill="#2E7D52" transform="rotate(9 15.52 27.07)" />
      <rect x="21.41" y="25.34" width="3.7" height="3.7" fill="#9B7BBF" transform="rotate(11 23.26 27.19)" />
      <rect x="13.5" y="17.41" width="2.1" height="2.1" fill="#E36A91" transform="rotate(19 14.55 18.46)" />
      <rect x="38.08" y="19.17" width="2.6" height="2.6" fill="#8E8DD0" transform="rotate(16 39.38 20.47)" />
      <rect x="41.13" y="24.68" width="2.1" height="2.1" fill="#E14B4B" transform="rotate(41 42.18 25.73)" />
      <rect x="38.52" y="33.5" width="3.6" height="3.6" fill="#B5532A" transform="rotate(45 40.32 35.3)" />
      <rect x="38.07" y="11.03" width="3.2" height="3.2" fill="#B5532A" transform="rotate(9 39.67 12.63)" />
      <rect x="40.26" y="39.62" width="3.3" height="3.3" fill="#6D28D9" transform="rotate(10 41.91 41.27)" />
      <rect x="14.33" y="32.64" width="3.7" height="3.7" fill="#E0972A" transform="rotate(46 16.18 34.49)" />
      <rect x="24.55" y="40.46" width="2" height="2" fill="#3FA7D6" transform="rotate(47 25.55 41.46)" />
      <rect x="40.62" y="5.68" width="3.4" height="3.4" fill="#E36A91" transform="rotate(41 42.32 7.38)" />
      <rect x="32.48" y="26.14" width="2.3" height="2.3" fill="#6D28D9" transform="rotate(45 33.63 27.29)" />
      <rect x="29.69" y="5.55" width="4.2" height="4.2" fill="#E36A91" transform="rotate(46 31.79 7.65)" />
      <rect x="21.93" y="30.28" width="2.9" height="2.9" fill="#9B7BBF" transform="rotate(13 23.38 31.73)" />
      <rect x="6.27" y="26.69" width="2.3" height="2.3" fill="#6D28D9" transform="rotate(12 7.42 27.84)" />
      <rect x="4.44" y="18.93" width="2.1" height="2.1" fill="#3FA7D6" transform="rotate(50 5.49 19.98)" />
    </svg>
  );
}

// أيقونة «الواجهة/Front»: كوب قهوة بميلانٍ خفيف مع بخار — تتبع لون البلاطة.
// أُرجِعت للوضع الأصليّ (العروة و الميل يسار
function CoffeeCupIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
      {/* بخار — خمس خصلات رفيعة، بلون الخط */}
      <path d="M12 16 q-1.8 -2.4 0 -4.8 q1.8 -2.4 0 -4.8" strokeWidth="1.9" />
      <path d="M16.5 16 q-1.8 -2.4 0 -4.8 q1.8 -2.4 0 -4.8" strokeWidth="1.9" />
      <path d="M21 16 q-1.8 -2.4 0 -4.8 q1.8 -2.4 0 -4.8" strokeWidth="1.9" />
      <path d="M25.5 16 q-1.8 -2.4 0 -4.8 q1.8 -2.4 0 -4.8" strokeWidth="1.9" />
      <path d="M30 16 q-1.8 -2.4 0 -4.8 q1.8 -2.4 0 -4.8" strokeWidth="1.9" />
      {/* الكوب مائل قليلاً، العروة يسار */}
      <g transform="rotate(-8 21 24)">
        <path d="M8 22 Q9 32 21 34 Q33 32 34 22" />
        <ellipse cx="21" cy="22" rx="11" ry="2.5" fill="#1A1A1A" stroke="none" />
        <ellipse cx="21" cy="22" rx="13" ry="3.2" />
        <path d="M8 24 H3 A4.5 4.5 0 0 0 3 31 H9" />
      </g>
    </svg>
  );
}

// Petal-burst overlay: 12 petals (6 rose-wine, 6 deep blue) rise from the
// bottle CAP upward, then fall and fade. One-shot per trigger. Drawn on an
// absolutely-positioned SVG layer above the lucide icon — never touches the
// icon itself (no color/size change). Exposed via ref: ref.current.burst().
const PetalBurst = (function () {
  const ROSE = ["#be123c", "#e11d48", "#fb7185"];
  const NAVY = ["#1e3a8a", "#1d4ed8", "#3b82f6"];
  return function PetalBurstLayer({ fireRef }) {
    const svgRef = useRef(null);

    const burst = useCallback(() => {
      const svg = svgRef.current;
      if (!svg) return;
      const NS = "http://www.w3.org/2000/svg";
      // viewBox 0 0 90 90; the icon sits centered, cap near top.
      const capX = 45, capY = 30;
      for (let i = 0; i < 12; i++) {
        const pal = i % 2 === 0 ? ROSE : NAVY;
        const color = pal[(Math.random() * pal.length) | 0];
        const p = document.createElementNS(NS, "ellipse");
        p.setAttribute("rx", "3.2");
        p.setAttribute("ry", "1.9");
        p.setAttribute("cx", capX);
        p.setAttribute("cy", capY);
        p.setAttribute("fill", color);
        svg.appendChild(p);

        const ang = -Math.PI / 2 + (i - 5.5) * 0.16 + (Math.random() - 0.5) * 0.16;
        const dist = 24 + Math.random() * 20;
        const dx = Math.cos(ang) * dist;
        const dy = Math.sin(ang) * dist;
        const rot = (Math.random() - 0.5) * 220;
        const t0 = performance.now();
        const dur = 850;
        const frame = (t) => {
          const k = Math.min(1, (t - t0) / dur);
          const ease = 1 - Math.pow(1 - k, 2);
          const x = dx * ease;
          const y = dy * ease + (k > 0.5 ? (k - 0.5) * 20 : 0);
          p.setAttribute("transform", `translate(${x},${y}) rotate(${rot * k} ${capX} ${capY})`);
          p.setAttribute("opacity", String(k < 0.12 ? k / 0.12 : 1 - (k - 0.12) / 0.88));
          if (k < 1) requestAnimationFrame(frame);
          else if (p.parentNode) svg.removeChild(p);
        };
        requestAnimationFrame(frame);
      }
    }, []);

    useEffect(() => {
      if (fireRef) fireRef.current = burst;
    }, [fireRef, burst]);

    return (
      <svg
        ref={svgRef}
        width="90"
        height="90"
        viewBox="0 0 90 90"
        aria-hidden="true"
        style={{
          position: "absolute",
          left: "50%",
          top: "50%",
          transform: "translate(-50%,-50%)",
          pointerEvents: "none",
          overflow: "visible",
        }}
      />
    );
  };
})();

export default function MobileNav() {
  const location = useLocation();
  const { isAr } = useLang();
  const explodeRef = useRef(null);
  const [showLabels, setShowLabels] = useState(() => getSecureStorage("showTabLabels", false));
  const [showMaestro, setShowMaestro] = useState(() => getSecureStorage("showMaestroNav", false));
  const [navTabs, setNavTabs] = useState(() => {
    const defaults = { home: true, perfumes: true, explore: true, shopping: true, progress: true, goals: true, maestro: true };
    const stored = getSecureStorage("navTabSettings", {});
    return Object.fromEntries(Object.keys(defaults).map(k => [k, stored[k] !== false]));
  });

  useEffect(() => {
    const handler = () => {
      setShowLabels(getSecureStorage("showTabLabels", false));
      setShowMaestro(getSecureStorage("showMaestroNav", false));
      const defaults = { home: true, perfumes: true, explore: true, shopping: true, progress: true, goals: true, maestro: true };
      const stored = getSecureStorage("navTabSettings", {});
      setNavTabs(Object.fromEntries(Object.keys(defaults).map(k => [k, stored[k] !== false])));
    };
    
    window.addEventListener("tabLabelsChanged", handler);
    window.addEventListener("maestroNavChanged", handler);
    window.addEventListener("navTabSettingsChanged", handler);
    
    return () => {
      window.removeEventListener("tabLabelsChanged", handler);
      window.removeEventListener("maestroNavChanged", handler);
      window.removeEventListener("navTabSettingsChanged", handler);
    };
  }, []);

  const navItems = [
    { key: "home", path: "/home", icon: Home, label: isAr ? "دار" : "House", visible: navTabs.home !== false },
    { key: "perfumes", path: "/", icon: Tally4, label: isAr ? "واجهة" : "Front", visible: navTabs.perfumes !== false },
    { key: "explore", path: "/explore", icon: Search, label: isAr ? "اكتشف" : "Explore", visible: navTabs.explore !== false },
    { key: "shopping", path: "/shopping", icon: ShoppingBag, label: isAr ? "مشتريات" : "Purchase", visible: navTabs.shopping !== false },
    { key: "progress", path: "/progress", icon: Ratio, label: isAr ? "تقدم" : "Progress", visible: navTabs.progress !== false },
    { key: "goals", path: "/goals", icon: Sunset, label: isAr ? "أهداف" : "Goals", visible: navTabs.goals !== false },
    { key: "maestro", path: "/maestro", icon: Music, label: "Maestro", visible: showMaestro && navTabs.maestro !== false },
  ].filter(item => item.visible && item.icon != null);

  // إخفاء الشريط بالكامل إن لم يبقَ أيّ تبويب ظاهر (المستخدم أطفأها كلّها) — لا شريط فارغ.
  if (navItems.length === 0) return null;

  const navEl = (
    <nav id="app-bottom-nav" className="fixed bottom-0 left-0 right-0 z-50 backdrop-blur-xl" style={{ background: "var(--page-bg, #ffffff)", paddingBottom: "env(safe-area-inset-bottom)", pointerEvents: "auto" }}>
      <div dir="ltr" className="flex items-center justify-around w-full max-w-xl mx-auto py-2 min-h-[56px]">
        {navItems.map(({ key, path, icon: NavIcon, label }) => {
          if (!NavIcon) return null;
          const isActive = location.pathname === path || (path === "/maestro" && location.pathname.startsWith("/maestro"));
          const isExplore = key === "explore";
          return (
            <Link
              key={path}
              to={path}
              title={label}
              onClick={isExplore ? () => { if (explodeRef.current) explodeRef.current(); } : undefined}
              className="flex flex-col items-center gap-0.5 flex-1 min-w-0 py-1.5 rounded-none transition-all duration-200"
              style={{ color: isActive ? "#B76E79" : "var(--brand)" }}
            >
              {isExplore ? (
                <span className="relative inline-flex items-center justify-center w-5 h-5 shrink-0">
                  <PetalBurst fireRef={explodeRef} />
                  <NavIcon className={cn("w-5 h-5 shrink-0", isActive && "stroke-[2.5]")} />
                </span>
              ) : (
                <NavIcon className={cn("w-5 h-5 shrink-0", isActive && "stroke-[2.5]")} />
              )}
              {showLabels && (
                <span
                  className="font-body font-medium w-full text-center leading-tight block truncate"
                  style={{ fontSize: navItems.length > 5 ? "8px" : "10px" }}
                >
                  {label}
                </span>
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
  return typeof document !== "undefined" ? createPortal(navEl, document.body) : navEl;
}
import { useEffect, useState, useRef } from 'react';
import { useLang } from "@/lib/LanguageContext";
import { apphost } from '@/api/apphostClient';
import { prepSet, prepDone } from '@/lib/prepProgress';
import { seedAllLocal, getExpectedSeedCounts, getSeedFingerprint, seedDefaultPinsLocal, rebuildPerfumeLinks } from '@/lib/localSeeder';

import { queryClientInstance } from '@/lib/query-client';
import { seedEncyclopedia } from '@/lib/encyclopedia';
import { prependDefaultPins } from '@/lib/usePins';
import { buildSearchIndex, searchIndexStale } from '@/lib/searchIndex';
import { requestWakeLock, releaseWakeLock } from '@/lib/wakeLock';
import { getAppName } from '@/lib/useAppName';
import { DB_NAME } from '@/lib/dbName';

// Friendly labels for each entity (EN / AR)
const ENTITY_LABELS = {
  PerfumeBrand: { en: 'Brands',    ar: 'البراندات' },
  PerfumeNote:  { en: 'Notes',     ar: 'النوتات' },
  Perfumer:     { en: 'Perfumers', ar: 'العطّارون' },
  Perfume:      { en: 'Perfumes',  ar: 'العطور' },
  EncEntry:     { en: 'Encyclopedia', ar: 'الموسوعة' },
};

// Real entities to count for the empty-DB check.
const ENTITY_ORDER = ['PerfumeBrand', 'PerfumeNote', 'Perfumer', 'Perfume'];
// Display order for the progress rows — العطور ثمّ الموسوعة فقط (المعجم وُقف).
const DISPLAY_ORDER = ['PerfumeBrand', 'PerfumeNote', 'Perfumer', 'Perfume', 'EncEntry'];

/**
 * Detects whether the local database is empty and, if so, runs the
 * built-in seeder while showing an elegant progress UI.
 *
 * Children render only AFTER seeding completes (or if data already exists).
 */
export default function AutoSeedSplash({ children }) {
  const { isAr } = useLang();
  const [phase, setPhase] = useState('checking'); // 'checking' | 'seeding' | 'done' | 'error'
  const [progress, setProgress] = useState({});
  const [overallPercent, setOverallPercent] = useState(0);
  const [error, setError] = useState(null);

  // إبقاء الشاشة مُضاءة طوال التنصيب/الزرع فلا يتوقّف بإطفائها.
  useEffect(() => { requestWakeLock(); return () => releaseWakeLock(); }, []);
  const ranOnce = useRef(false);

  // إطلاق بناء فهرس البحث في الخلفية (لا await، لا يعطّل الدخول للتطبيق):
  // يجلب عدد العطور (count رخيص بلا قراءة سجلات)، فإن كان الفهرس قديماً/ناقصاً
  // بدأ البناء المستأنف المجزّأ. آمنٌ للنداء المتكرّر — يتجاهل إن كان بانياً أصلاً.
  const kickSearchIndex = () => {
    // تأجيل البناء حتى يستقرّ التطبيق ويصبح تفاعلياً (لا فور انتهاء البذر، فذلك
    // يُشبع الخيط لحظة بدء التصفّح فيبدو متجمّداً). البحث يعمل أثناء ذلك عبر سقوط
    // sort_key. تأخير سخيّ + بدءٌ عند خمول المتصفّح إن توفّر.
    const start = () => {
      try {
        Promise.resolve(apphost.entities.Perfume.count())
          .then((n) => { if (searchIndexStale(n)) buildSearchIndex(n); })
          .catch(() => { /* غير حرِج */ });
      } catch { /* غير حرِج */ }
    };
    setTimeout(() => {
      if (typeof requestIdleCallback === "function") requestIdleCallback(start, { timeout: 5000 });
      else start();
    }, 8000);
  };

  // فهرس الوسوم صار كسولا بالكامل: الوسوم ليست ميزة رئيسية،
  // فلا يبنى عند الإقلاع إطلاقا — يبنى فقط حين تفتح صفحة الوسم بعد الضغط على
  // وسم (At.jsx يتكفل بذلك)، و لصفحة /at مسار بديل حتى يجهز.
  const kickTagIndex = () => { /* أُلغي البناء عند الإقلاع عمدا — انظر At.jsx */ };

  useEffect(() => {
    if (ranOnce.current) return;
    ranOnce.current = true;

    // Safety net: if anything stalls during the initial check, never trap the
    // user on the splash — force the app to render after this many ms. Seeding
    // (which legitimately takes longer) sets phase to 'seeding' first and is
    // unaffected, because we only fire this while still 'checking'.
    const safetyTimer = setTimeout(() => {
      setPhase((p) => (p === 'checking' ? 'done' : p));
    }, 4000);

    (async () => {
      const startedAt = Date.now();
      // ─── تنصيب جديد: عند أول رؤية لاسم قاعدة جديد تُمسح بوابات الزرع
      // في localStorage حتى تعمل كل الزارعات من الصفر — لا اعتماد على أعلام قديمة.
      try {
        if (localStorage.getItem('db_install_tag') !== DB_NAME) {
          for (const k of Object.keys(localStorage)) {
            if (/^(proc_seed_fp|proc_last_prep_ts|proc_notes_main|proc_example_refresh|enc_seed_rev|enc_pin_cheers|proc_seed|searchIndex)/.test(k)) {
              localStorage.removeItem(k);
            }
          }
          localStorage.setItem('db_install_tag', DB_NAME);
        }
      } catch { /* تجاهل */ }

      // Keep the splash visible for at least this long so the message is
      // actually readable and never flashes by on a fast device.
      const MIN_VISIBLE_MS = 400;
      const settle = (fn) => {
        const elapsed = Date.now() - startedAt;
        const wait = Math.max(0, MIN_VISIBLE_MS - elapsed);
        setTimeout(fn, wait);
      };

      try {
        // ─── «جلسة التجهيز» (طلب A): ضمن النافذة الزمنية المختارة (يوم/أسبوع/شهر)
        // و البصمة مطابقة لآخر تجهيز ناجح → دخول فوري بلا أي عمل خلفي و لا حتى
        // عدّ الجداول. أندرويد يقتل العملية بعد الخمول فكل عودة إقلاع بارد —
        // هذه النافذة تجعل العودة صفرية الكلفة. تغيّر البصمة (نسخة جديدة) أو
        // غياب آخر طابع يفتح المسار الكامل كالمعتاد. 'always' = السلوك القديم.
        try {
          const win = localStorage.getItem('proc_session_window') || 'week';
          const WIN_MS = { day: 864e5, week: 6048e5, month: 26298e5 }[win];
          if (WIN_MS) {
            const last = parseInt(localStorage.getItem('proc_last_prep_ts') || '0', 10);
            const fpNow = getSeedFingerprint();
            const fpStored = localStorage.getItem('proc_seed_fp');
            if (last && Date.now() - last < WIN_MS && fpStored === fpNow) {
              clearTimeout(safetyTimer);
              setPhase('done');
              return;
            }
          }
        } catch { /* غير حرِج — نسقط للمسار الكامل */ }

        const stats = await getDbStats();
        const isEmpty = Object.values(stats).every((n) => n === 0);
        clearTimeout(safetyTimer); // got an answer — no longer need the net

        if (!isEmpty) {
          // إطلاق عادي: القاعدة فيها بيانات. قبل الدخول نُجري «استكمال القصص»:
          // إضافة القصص الجديدة التي جاءت مع نسخة التطبيق ولم تكن موجودة بعد
          // (لأنّ البذر الكامل لا يُعاد على قاعدة غير فارغة). الفحص سريع جداً
          // ويتخطّى فوراً إن لا جديد. لا يحذف ولا يعدّل أيّ قصّة قائمة.
          // إضافة-المفقود ثقيلة (تحمّل كل جدول)، فلا نشغّلها إلا إذا تغيّرت بذرة
          // التطبيق منذ آخر فتح — بصمة محفوظة في التخزين المحلّي. الفتح المعتاد
          // (لا جديد) يتخطّاها فوراً، فلا «إعادة تحميل كل شيء» في كل مرة.
          // الدخول فوراً — لا شاشة «تحديث» في العودات الباردة بعد اليوم (v662).
          // أندرويد يقتل العملية بعد الخمول، فكل عودة = إقلاع بارد؛ كان المسار
          // يحجز المستخدم على البصمة + الترحيلات. الآن: قاعدة غير فارغة = ادخل،
          // وكل التحديث يجري في الخلفية ثم يُحدَّث كاش الاستعلامات عند الاكتمال.
          settle(() => setPhase('done'));
          (async () => {
            let changed = false;
            let seedFp = null, storedFp = null;
            try { seedFp = getSeedFingerprint(); storedFp = localStorage.getItem("proc_seed_fp"); } catch { /* تجاهل */ }
            if (storedFp !== seedFp) {
              // تتابعية لا متوازية: التوازي كان يفتح سبعة مسوح كاملة
              // للقاعدة معاً فتتجمد الصفحات حتى يكتمل كل شيء — التتابع يخفض الضغط،
              // و شريط «جاري تجهيز التطبيق ٪» يعرض التقدم بدل التجمد الصامت.
              // كل خطوة محمية وحدها (فشل واحد لا يمنع حفظ البصمة — idempotent).
              prepSet(2);
              const steps = [
                // وُقفت زراعة المعجم (قصص/مصطلحات/رمزيات/اقتباسات/حكم) — كلّها الآن في الموسوعة.
                // تبقى الملاحظات العطرية و الخط الزمنيّ (مرتبطة بالعطور لا بالمعجم).
                // [نُظّف] أُزيلت كتل الإنزال top-up — البذر المباشر يكفي
              ];
              let failed = 0;
              let base = 2;
              for (const [fn, upto] of steps) {
                try {
                  const from = base, span = upto - from;
                  const r = await fn((done, total) => { if (total > 0) prepSet(from + (span * done) / total); });
                  // added يشمل إشارة المزامنة في القصص/المعجم/الرمزيات؛ النوتات و الحكم
                  // تعيد synced منفصلاً — أي تغيير فعليّ في القاعدة يرفع العلم
                  // فيستدعى invalidateQueries و يظهر المزامَن فوراً في الصفحات المفتوحة.
                  if (r && (r.added > 0 || r.synced > 0 || r.retagged > 0 || r.extraSynced > 0)) changed = true;
                } catch { failed++; }
                base = upto;
                prepSet(upto);
              }
              try { localStorage.setItem("proc_seed_fp", seedFp); } catch { /* تجاهل */ }
              if (failed) console.warn(`top-up: ${failed} part(s) failed (fp saved; idempotent retry on next fp change)`);
              prepSet(98);
            }
            try {
              kickTagIndex();
              kickSearchIndex();
            } catch { /* غير حرِج */ }
            // استرداد: إن أُغلق التطبيق قبل اكتمال الربط الخلفيّ بعد التنصيب
            // (proc_links_done غائب)، أعِد تعبئة perfume_ids في الخلفية. يحرس نفسه
            // بالعلم فيتخطّى فوراً في الفتح المعتاد. .
            try {
              if (localStorage.getItem('proc_links_done') !== '1') rebuildPerfumeLinks();
            } catch { /* غير حرِج */ }
            try { await seedDefaultPinsLocal(); } catch { /* غير حرِج */ }
            // جذر «بعد التقييم ظهرت معلومات لم تكن موجودة»: الإنعاش كان يرقّع سجل
            // الجهاز في الخلفية (أكوردات، عطّارون، صور…) لكن نتيجته كانت تُهمل —
            // و staleTime: Infinity يعني أن الصفحات تبقى على النسخة القديمة حتى
            // أول mutation/فتح جديد (لهذا «أصلحها» التقييم). الآن patched يرفع العلم.
            // [نُظّف] أُزيل إنعاش المثال refreshExampleRecordsLocal — البذر المباشر يكفي
            try { localStorage.setItem('proc_last_prep_ts', String(Date.now())); } catch { /* تجاهل */ }
            prepDone();
            // ما أُضيف في الخلفية يظهر فوراً: علّم الاستعلامات النشطة قديمة.
            if (changed) {
              // إبطال موجه لا شامل (جذر «التجميد» الذي زادته إصلاحات 1.806/1.807):
              // invalidateQueries() الشامل كان يعيد جلب كل الاستعلامات النشطة و على
              // رأسها ["perfumes"] = تحميل و فرز 130 ألف سجل على الخيط الرئيسي —
              // تجمد ثوان بعد كل دورة تجهيز. الاستثناء الوحيد هو هذا المفتاح الضخم؛
              // كل ما تلمسه دورات التجهيز فعلا (قصص/معجم/رمزيات/حكم/اقتباسات/نوتات/
              // خط زمني/سجل مرحبا المفرد/البراند) يبقى مبطلا فيتحدث فورا و رخيصا.
              try {
                queryClientInstance.invalidateQueries({ predicate: (q) => q.queryKey?.[0] !== 'perfumes' });
              } catch { /* تجاهل */ }
            }
          })();
          return;
        }

        // First run (empty DB): show the waiting-with-value screen (message +
        // percentages) first, hold it for 6 seconds, then begin seeding.
        const expected = getExpectedSeedCounts();
        const initial = {};
        for (const ent of DISPLAY_ORDER) {
          initial[ent] = { current: 0, total: expected[ent] || 0, percent: 0 };
        }
        // الموسوعة ظاهرة من البداية (طلب A): عدّ تقريبيّ معروف حتى قبل بدء زرعها.
        initial.EncEntry = { current: 0, total: expected.EncEntry || 12299, percent: 0 };
        setProgress(initial);
        setOverallPercent(0);
        setPhase('welcome');
        await new Promise((r) => setTimeout(r, 400));

        setPhase('seeding');

        await seedAllLocal((info) => {
          setProgress((prev) => ({
            ...prev,
            [info.entity]: {
              current: info.current,
              total: info.total,
              percent: info.percent,
            },
          }));
          if (typeof info.overallPercent === 'number') {
            setOverallPercent(Math.min(99, info.overallPercent));
          }
        });

        // زرع الموسوعة ضمن شاشة التنصيب (تظهر «الموسوعة» مع العطور) — تقدّم حيّ.
        try {
          await seedEncyclopedia((current, total, percent) => {
            setProgress((prev) => ({ ...prev, EncEntry: { current, total, percent } }));
          });
        } catch { /* غير حرِج */ }

        // تثبيت افتراضيّ: تشيرز (قصة + مسلسل) و ساينفيلد (قصة الكوميديا عن لا شيء + مسلسل) — أربعة
        try {
          if (localStorage.getItem('enc_pin_v4') !== '1') {
            const all = (await apphost.entities.EncEntry.list('-updated_date', 20000)) || [];
            const want = all.filter((e) => {
              const en = String(e.titles?.en || ''); const ar = String(e.titles?.ar || '');
              if (en.startsWith('Cheers') || ar.includes('تشيرز')) return true;
              if (en === 'Seinfeld — The Comedy About Nothing' || ar.includes('الكوميديا عن لا شيء')) return true;
              if (en === 'Seinfeld' && e.library?.media_type === 'series') return true;
              return false;
            });
            const ids = want.map((e) => String(e.id));
            if (ids.length) {
              prependDefaultPins('encentry', ids);
              localStorage.setItem('enc_pin_v4', '1');
            }
          }
        } catch { /* غير حرِج */ }

        // Force every row to 100% so the completion table reads cleanly full.
        setProgress((prev) => {
          const full = {};
          for (const ent of DISPLAY_ORDER) {
            const p = prev[ent] || { current: 0, total: 0 };
            full[ent] = { current: p.total, total: p.total, percent: 100 };
          }
          return full;
        });
        // Show the "installation complete" state, then auto-advance.
        setPhase('complete');
        // حفظ بصمة البذرة فور اكتمال الزرع الأول: كانت لا تُحفظ هنا،
        // فأول إقلاع بعد التنصيب يجد البصمة مفقودة و يفتح دورة top-up كاملة
        // (سبعة مسوح لكل الجداول ~150 ألف قراءة) — هذا كان «تجمد ما بعد التنصيب».
        // كل شيء بُذر للتو من البذرة نفسها فلا حاجة لأي استكمال.
        try { localStorage.setItem("proc_seed_fp", getSeedFingerprint()); } catch { /* تجاهل */ }
        try { localStorage.setItem('proc_last_prep_ts', String(Date.now())); } catch { /* تجاهل */ }
        // ابنِ فهرس وسوم العطور + فهرس البحث في الخلفية بعد البذر الأول (لا await).
        kickTagIndex();
        kickSearchIndex();
        setTimeout(() => setPhase('done'), 700);
        // التثبيت الافتراضي (براند/عطّار/نوتة) مؤجَّل بعد الدخول كي لا يحجب التصيير.
        // عطر المثال (Marhaba) مُثبَّت أصلاً وقت البذر، فلا مسح ثقيل هنا.
        setTimeout(() => { seedDefaultPinsLocal().catch(() => {}); }, 2000);
      } catch (e) {
        // Fail OPEN: if we can't determine DB state, never trap the user on a
        // blank/splash screen — just show the app and let it load on its own.
        console.error('Auto-seed check failed (showing app anyway):', e);
        settle(() => setPhase('done'));
      }
    })();

    return () => clearTimeout(safetyTimer);
  }, []);

  if (phase === 'done') return children;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 999998,
        background: 'linear-gradient(135deg, #ffffff 0%, #F3EEE2 100%)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '32px 24px',
        paddingTop: 'calc(32px + env(safe-area-inset-top, 0px))',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',
        color: '#1c1917',
      }}
    >
      {/* Logo + title */}
      <div style={{ marginBottom: 32, textAlign: 'center' }}>
        <h1
          style={{
            fontSize: 26,
            fontWeight: 700,
            letterSpacing: '-0.02em',
            margin: 0,
            background: 'linear-gradient(135deg, var(--brand), #9a7b1f)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}
        >
          {isAr ? getAppName().name_ar : getAppName().name_en}
        </h1>
        <p style={{ fontSize: 11, color: '#78716c', marginTop: 10, fontWeight: 500, maxWidth: 300, lineHeight: 1.6, paddingLeft: 8, paddingRight: 8 }}>
          {(() => {
            const m =
              phase === 'checking' ? { ar: 'جارٍ التحقق', en: 'Checking' }
              : phase === 'refresh' ? { ar: 'في طور التحديث', en: 'Refreshing' }
              : phase === 'welcome' ? { ar: 'نجهز تطبيقك: للإنتظار قيمة', en: 'Preparing Your App: Waiting Has Value' }
              : phase === 'complete' ? { ar: 'اكتمل تنصيب قاعدة البيانات', en: 'Database installation complete' }
              : { ar: 'في طور الاعداد', en: 'Setting Up' };
            return (
              <>
                <span dir="rtl" style={{ display: 'block' }}>{m.ar}</span>
                <span dir="ltr" style={{ display: 'block' }}>{m.en}</span>
              </>
            );
          })()}
        </p>
      </div>

      {/* Spinner while checking/refreshing (before seeding card appears) */}
      {(phase === 'checking' || phase === 'refresh') && (
        <div style={{ marginTop: 8 }}>
          <div
            style={{
              width: 28,
              height: 28,
              border: '3px solid #e7e5e4',
              borderTopColor: 'var(--brand)',
              borderRadius: '50%',
              animation: 'processSpin 0.8s linear infinite',
            }}
          />
          <style>{`@keyframes processSpin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {/* Progress card */}
      {(phase === 'welcome' || phase === 'seeding' || phase === 'complete') && (
        <div
          style={{
            width: '100%',
            maxWidth: 380,
            background: '#ffffff',
            borderRadius: 0,
            padding: 20,
            boxShadow: '0 10px 30px -10px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.05)',
            border: '1px solid var(--brand)',
          }}
        >
          {/* Per-entity rows */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {DISPLAY_ORDER.map((ent) => {
              const label = ENTITY_LABELS[ent];
              const p = progress[ent] || { current: 0, total: 0, percent: 0 };
              if (!p.total) return null;
              return (
                <EntityRow
                  key={ent}
                  label={isAr ? label.ar : label.en}
                  percent={p.percent}
                  current={p.current}
                  total={p.total}
                  isAr={isAr}
                />
              );
            })}
          </div>

          {/* Overall bar */}
          <div style={{ marginTop: 18, paddingTop: 16, borderTop: '1px solid #f5f5f4' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 11, fontWeight: 600, color: '#57534e', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                {isAr ? 'الإجمالي' : 'Overall'}
              </span>
              <span style={{ fontSize: 11, fontWeight: 700, color: '#9a7b1f' }}>{overallPercent}%</span>
            </div>
            <div style={{ height: 4, background: '#f5f5f4', borderRadius: 0, overflow: 'hidden' }}>
              <div
                style={{
                  height: '100%',
                  width: `${overallPercent}%`,
                  background: 'linear-gradient(90deg, #d9b84a, var(--brand))',
                  transition: 'width 200ms ease-out',
                  borderRadius: 0,
                }}
              />
            </div>
          </div>

          {/* Completion line — only on the complete phase */}
          {phase === 'complete' && (
            <p style={{ marginTop: 14, textAlign: 'center', fontSize: 12, fontWeight: 700, color: '#9a7b1f', lineHeight: 1.6 }}>
              <span dir="rtl" style={{ display: 'block' }}>تم</span>
              <span dir="ltr" style={{ display: 'block' }}>{isAr ? "تم" : "Done"}</span>
            </p>
          )}
        </div>
      )}

      {/* Footnote — both languages, small */}
      <p
        style={{
          fontSize: 9,
          color: '#a8a29e',
          marginTop: 32,
          textAlign: 'center',
          maxWidth: 320,
          lineHeight: 1.6,
          letterSpacing: '0.02em',
        }}
      >
        Waiting Has Value للإنتظار قيمة
      </p>

      {/* Error state */}
      {phase === 'error' && (
        <div style={{ marginTop: 16, padding: 12, background: '#fef2f2', borderRadius: 8, color: '#991b1b', fontSize: 12, maxWidth: 380, textAlign: 'center' }}>
          {error}
          <br />
          <button
            type="button"
            onClick={() => window.location.reload()}
            style={{ marginTop: 8, padding: '6px 12px', background: '#991b1b', color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer' }}
          >
            {isAr ? 'إعادة المحاولة' : 'Try again'}
          </button>
          <button
            type="button"
            onClick={() => { window.location.href = (import.meta.env.BASE_URL || '/'); }}
            style={{ marginTop: 8, marginInlineStart: 8, padding: '6px 12px', background: 'var(--brand, var(--brand))', color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer' }}
          >
            {isAr ? 'رئيسية التطبيق' : 'App home'}
          </button>
        </div>
      )}
    </div>
  );
}

/** Single entity progress row — text only, no icons */
function EntityRow({ label, percent, current, total, isAr }) {
  const done = percent >= 100;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5, gap: 8 }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: '#292524', minWidth: 0, flex: '1 1 auto', overflowWrap: 'anywhere', wordBreak: 'break-word', lineHeight: 1.35 }}>
          {label}
        </span>
        <span style={{ fontSize: 11, fontWeight: 500, color: done ? '#9a7b1f' : '#a8a29e', fontVariantNumeric: 'tabular-nums', flexShrink: 0 }}>
          {done ? (isAr ? 'تم' : 'Done') : `${Math.round(percent)}%`}
        </span>
      </div>
      <div style={{ height: 3, background: '#f5f5f4', borderRadius: 0, overflow: 'hidden' }}>
        <div
          style={{
            height: '100%',
            width: `${percent}%`,
            background: done ? 'var(--brand)' : 'linear-gradient(90deg, #d9b84a, var(--brand))',
            transition: 'width 200ms ease-out',
            borderRadius: 0,
          }}
        />
      </div>
    </div>
  );
}

/** Quick count of records in each entity to detect a fresh install */
async function getDbStats() {
  const stats = {};
  for (const ent of ENTITY_ORDER) {
    try {
      if (!apphost?.entities?.[ent]) {
        stats[ent] = 0;
        continue;
      }
      // عدّ سريع عبر IndexedDB count (فوري، بلا جلب أو فكّ تشفير السجلات).
      // نسقط للطريقة القديمة فقط لو count غير متاحة.
      if (typeof apphost.entities[ent].count === "function") {
        stats[ent] = await apphost.entities[ent].count();
      } else {
        const sample = await apphost.entities[ent].list('-created_date', 1);
        stats[ent] = Array.isArray(sample) ? sample.length : 0;
      }
    } catch {
      stats[ent] = 0;
    }
  }
  return stats;
}

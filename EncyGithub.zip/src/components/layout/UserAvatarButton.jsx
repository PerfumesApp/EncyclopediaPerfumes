/**
 * UserAvatarButton — a small circular button that shows:
 *   - The user's uploaded profile photo if available
 *   - Otherwise their initials
 *   - Otherwise a generic User icon
 *
 * Use as the trigger child of <SettingsSheet> across pages so the avatar
 * actually updates when the user uploads a new photo from Settings.
 *
 * Subscribes to "userProfileChanged" so all instances refresh immediately
 * after a photo upload — without a page reload.
 */

import { useEffect, useState, forwardRef } from "react";
import { apphost } from "@/api/apphostClient";

const UserAvatarButton = forwardRef(function UserAvatarButton(
  { size = 28, className = "", bg = "var(--page-bg, #ffffff)", borderColor = "var(--brand)", ...props },
  ref
) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const u = await apphost.auth.me();
        if (!cancelled) setUser(u || null);
      } catch {
        if (!cancelled) setUser(null);
      }
    };
    load();
    const handler = () => load();
    window.addEventListener("userProfileChanged", handler);
    return () => {
      cancelled = true;
      window.removeEventListener("userProfileChanged", handler);
    };
  }, []);

  const photo = user?.profile_photo;

  return (
    <button
      ref={ref}
      {...props}
      className={`overflow-hidden flex items-center justify-center hover:opacity-80 transition-opacity ${className}`}
      style={{ width: size, height: size, background: bg, border: "1.5px solid var(--brand)", borderRadius: 0 }}
      aria-label="Open settings"
    >
      {photo && <img src={photo} alt="" className="w-full h-full object-cover" />}
      {/* No photo: clean white square with sharp gold border — no icon, no letters */}
    </button>
  );
});

export default UserAvatarButton;

import { useState, useRef, useEffect, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { X, Loader2 } from "lucide-react";

export default function SearchableEntityPicker({ 
  label, 
  getLabel, 
  getValue,
  searchFn,
  selectedId, 
  selectedLabel,
  onSelect, 
  onClear,
  placeholder,
  isMulti = false,
  currentValue = "",
  onRemove
}) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleSearch = useCallback(async (q) => {
    setQuery(q);
    if (q.trim().length === 0) {
      setResults([]);
      setOpen(false);
      return;
    }
    
    setLoading(true);
    setOpen(true);
    try {
      const filtered = await searchFn(q);
      setResults(filtered);
    } catch (err) {
      console.error("Search error:", err);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, [searchFn]);

  const multiValues = currentValue ? currentValue.split(",").map(v => v.trim()).filter(Boolean) : [];

  return (
    <div className="space-y-1" ref={ref}>
      <p className="text-[10px] text-muted-foreground font-body uppercase">{label}</p>
      
      {isMulti ? (
        <>
          {multiValues.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-2">
              {multiValues.map((val) => (
                <div key={val} className="flex items-center gap-1 px-2.5 py-1 bg-primary/10 rounded-none">
                  <span className="text-xs font-body text-primary">{val}</span>
                  <button onClick={() => onRemove(val)} className="text-primary/60 hover:text-primary transition-colors">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="relative">
            <div className="flex items-center relative">
              <Input
                value={query}
                onChange={(e) => handleSearch(e.target.value)}
                onFocus={() => query.trim() && setOpen(true)}
                placeholder={placeholder || `Search ${label}..`}
                className="rounded-none h-9 font-body text-xs pr-8"
              />
              {loading && <Loader2 className="absolute right-2.5 w-4 h-4 animate-spin text-muted-foreground" />}
            </div>
            {open && results.length > 0 && (
              <div className="absolute z-50 top-full mt-1 w-full bg-card border border-border rounded-none shadow-lg max-h-44 overflow-y-auto">
                {results.map((item) => {
                  const itemValue = getValue(item);
                  const isAdded = multiValues.includes(itemValue);
                  return (
                    <button
                      key={itemValue}
                      className={`w-full text-left px-3 py-2 text-xs font-body ${isAdded ? "bg-primary/10 text-primary" : "hover:bg-accent"} transition-colors`}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        onSelect(itemValue);
                        setQuery("");
                        setResults([]);
                      }}
                    >
                      {getLabel(item)} {isAdded && "✓"}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </>
      ) : (
        <>
           {selectedId ? (
             <div className="flex items-center gap-2 px-3 py-2 bg-primary/10 rounded-none">
               <span className="text-xs font-body flex-1 text-primary truncate">{selectedLabel || selectedId}</span>
               <button onClick={onClear} className="text-primary/60 hover:text-primary transition-colors flex-shrink-0">
                 <X className="w-3.5 h-3.5" />
               </button>
             </div>
           ) : (
            <div className="relative">
              <div className="flex items-center relative">
                <Input
                  value={query}
                  onChange={(e) => handleSearch(e.target.value)}
                  onFocus={() => query.trim() && setOpen(true)}
                  placeholder={placeholder || `Search ${label}..`}
                  className="rounded-none h-9 font-body text-xs pr-8"
                />
                {loading && <Loader2 className="absolute right-2.5 w-4 h-4 animate-spin text-muted-foreground" />}
              </div>
              {open && results.length > 0 && (
                <div className="absolute z-50 top-full mt-1 w-full bg-card border border-border rounded-none shadow-lg max-h-44 overflow-y-auto">
                  {results.map((item) => (
                    <button
                      key={getValue(item)}
                      className="w-full text-left px-3 py-2 text-xs font-body hover:bg-accent transition-colors"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        onSelect(getValue(item), getLabel(item));
                        setQuery("");
                        setResults([]);
                        setOpen(false);
                      }}
                    >
                      {getLabel(item)}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
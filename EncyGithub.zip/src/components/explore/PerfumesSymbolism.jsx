import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Pencil, AArrowUp, AArrowDown } from "lucide-react";
import EraserIcon from "@/components/icons/EraserIcon";
import { Link, useNavigate} from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import { useReadingPrefs } from "@/lib/useReadingPrefs";
import InteractionBar from "@/components/shared/InteractionBar";
import StoryFooter from "@/components/shared/StoryFooter";
import ExportOptionsDialog from "@/components/export/ExportOptionsDialog";
import GlosseryExplain from "@/components/shared/GlosseryExplain";
import { exportSingleTerm, exportSingleTermImage } from "@/lib/glossaryExport";
import { compareGlossary } from "@/lib/sortName";
import { getSecureStorage, setSecureStorage } from "@/lib/storageEncryption";
import BackIcon from "@/components/shared/BackIcon";

// تحويل مدخل الرمزية إلى شكل «مصطلح» لمحرّك التصدير المشترك (renderTermHtml/StoryFooter):
// العربيّ = المعنى + الملاحظات، والإنجليزيّ = الحرفيّ + الأصل + رابط الرائحة، مع الوسوم.
function symbolismToTerm(e) {
  return {
    term_en: e.name_en || "",
    term_ar: e.name_ar || "",
    meaning_ar: [e.meaning_ar, e.notes_ar].filter(Boolean).join("\n\n"),
    meaning: [e.literal_meaning_en, e.etymology_en, e.scent_link_en].filter(Boolean).join("\n\n"),
    tags: Array.isArray(e.tags) ? e.tags.join(",") : (e.tags || ""),
    entry_type: "symbolism",
  };
}

/**
 * PerfumesSymbolism — قسم «رمزية العطور» داخل المعجم.
 * يجلب public/seed/perfumes_symbolism.json (محتوى يُعَدّ خارجياً) ويعرضه بنفس
 * تنسيق صفحات المعجم: بطاقات بيضاء بحدّ ذهبي مربّع، عنوان EN ذهبي + AR وردي،
 * مبدّل لغة (AR/EN/الاثنان)، خيارات تفاعل (إعجاب/فكرة/دفتر)، وسوم @، وتنقّل سابق/تالٍ.
 * الربط والتصميم هنا فقط؛ تغذية المحتوى مسؤولية منفصلة.
 * التفاعلات تُخزَّن في UserGlossaryTerm بمعرّف منمسَق: term_id = `sym:{story_idx}`.
 */

const GOLD = "var(--brand)";
// مختصر بلا نقاط في نهايته — قصّ عند حدّ كلمة (كان الاستخدام موجوداً بلا تعريف فانهارت الصفحة)
const excerpt = (txt, n = 90) => { const s2 = String(txt || "").replace(/\s+/g, " ").trim(); if (s2.length <= n) return s2; const cut = s2.slice(0, n); const i = cut.lastIndexOf(" "); return i > 40 ? cut.slice(0, i) : cut; };
const goldDivider = { height: 1, background: "linear-gradient(90deg, transparent, var(--brand), transparent)" };

// وصف القسم ثابت (نصّ تطبيق ثابت) فلا نجلب ملفّاً ضخماً (حتى عشرة آلاف مدخل) لأجله.
const SYMBOLISM_DESC = {
  ar: "معجم رمزية اسماء العطور: ما يرمز اليه كل اسم، و لغته و مصدره و كيف تطور المصطلح، و علاقته بالرائحة و اشاراته الثقافية و الاجتماعية. لكل مدخل المصطلح بالانجليزية و العربية، نطقه، شرحه، و ترجمة عربية مع شرح اضافي عند الحاجة",
  en: "A lexicon of the symbolism of perfume names: what each name evokes, its language, source and how the term evolved, and its tie to the scent and its cultural and social references.",
};

const firstWordSplit = (text) => {
  const t = (text || "").trim();
  if (!t) return ["", ""];
  const sp = t.indexOf(" ");
  return sp > 0 ? [t.slice(0, sp), t.slice(sp)] : [t, ""];
};

// تطبيع مدخل المعجم الجديد (headword_*/meaning_en) إلى الحقول التي يقرأها العرض
// (name_*/literal_meaning_en)، مع إبقاء التوافق مع المخطط القديم. ولأن الالفاظ بلا
// story_idx (و معظم الاسماء story_idx=null)، نشتقّ مفتاحاً مستقرّاً للمفاتيح/التنقّل/الرابط.
function normalizeSymbolism(r) {
  const name_en = r.headword_en ?? r.name_en ?? "";
  const sidRaw = r.story_idx;
  const hasSid = sidRaw !== null && sidRaw !== undefined && String(sidRaw).trim() !== "";
  return {
    ...r,
    name_en,
    name_ar: r.headword_ar ?? r.name_ar ?? "",
    pronunciation_en: r.pronunciation_en ?? r.pronunciation ?? "",
    literal_meaning_en: r.meaning_en ?? r.literal_meaning_en ?? "",
    meaning_ar: r.meaning_ar ?? "",
    story_idx: hasSid ? sidRaw : `hw:${name_en}`,
  };
}

function SymbolismDetail({ entry, entries, onSelect, onBack, isAr }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { lang, fontScale } = useReadingPrefs();
  const termKey = `sym:${entry.story_idx}`;
  const [thoughtOpen, setThoughtOpen] = useState(false);
  const [thoughtDraft, setThoughtDraft] = useState("");
  const [confirmDel, setConfirmDel] = useState(false);

  // تعديل المدخل نفسه (في مخزن PerfumeSymbolism) — يحفظ الحقول العربية والإنجليزية والوسوم.

  // الحذف/الكاست أواي: المضاف من المستخدم يُحذف؛ المبنيّ يُخفى (hidden) فيمكن استرجاعه بالبذر.
  const deleteMutation = useMutation({
    mutationFn: async () => {
      if (entry.is_user) return apphost.entities.PerfumeSymbolism.delete(entry.id);
      return apphost.entities.PerfumeSymbolism.update(entry.id, { hidden: true });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["perfumes-symbolism"] }); onBack(); },
  });

    const openEdit = () => navigate(`/content-edit?type=symbolism&id=${entry.id}`);

  const { data: userReactions = [] } = useQuery({
    queryKey: ["user-glossary-terms"],
    queryFn: () => apphost.entities.UserGlossaryTerm.list("-created_date"),
  });
  const mine = userReactions.find((r) => r.term_id === termKey);
  const currentReaction = mine?.reaction && mine.reaction !== "none" ? mine.reaction : "none";

  const reactMutation = useMutation({
    mutationFn: async ({ reaction }) => {
      if (mine) {
        if (mine.reaction === reaction) return apphost.entities.UserGlossaryTerm.update(mine.id, { reaction: "none" });
        return apphost.entities.UserGlossaryTerm.update(mine.id, { reaction });
      }
      return apphost.entities.UserGlossaryTerm.create({ term_id: termKey, term_en: entry.name_en || "", term_ar: entry.name_ar || "", reaction });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-glossary-terms"] }),
  });

  const thoughtMutation = useMutation({
    mutationFn: async ({ newThought }) => {
      if (mine) return apphost.entities.UserGlossaryTerm.update(mine.id, { thought: newThought });
      return apphost.entities.UserGlossaryTerm.create({ term_id: termKey, term_en: entry.name_en || "", term_ar: entry.name_ar || "", thought: newThought });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["user-glossary-terms"] }); setThoughtOpen(false); },
  });

  const openThought = () => { setThoughtDraft(mine?.thought || ""); setThoughtOpen(true); };

  const idx = entries.findIndex((e) => String(e.story_idx) === String(entry.story_idx));
  const prev = idx > 0 ? entries[idx - 1] : null;
  const next = idx >= 0 && idx < entries.length - 1 ? entries[idx + 1] : null;

  const showAr = lang !== "en";
  const showEn = lang !== "ar";
  const [fw, rest] = firstWordSplit(entry.meaning_ar);
  const tags = Array.isArray(entry.tags) ? entry.tags.filter(Boolean) : [];
  const fs = (px) => `${(px * (fontScale || 1)).toFixed(1)}px`;

  const PrevArrow = isAr ? ChevronRight : ChevronLeft;
  const NextArrow = isAr ? ChevronLeft : ChevronRight;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-sm font-body text-muted-foreground hover:text-foreground transition-colors"
        >
          <BackIcon className={`w-4 h-4`} /> {isAr ? "معنى علامة" : "Marking Meaning"}
        </button>
      </div>

      {/* جدول العنوان — الاسم باللغتين + النطق واللغة */}
      <div className="px-1 py-2" dir="ltr" style={{ textAlign: "left" }}>
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.3rem", fontWeight: 700, color: "#9a7b1f", lineHeight: 1.2 }}>{entry.name_en}</div>
        {entry.name_ar && (
          <div dir="rtl" style={{ fontFamily: "'Amiri', serif", fontSize: "1.25rem", fontWeight: 700, color: "#9D174D", lineHeight: 1.4, marginTop: 2 }}>{entry.name_ar}</div>
        )}
        {entry.origin === "claude_invention" && (
          <span dir="rtl" className="inline-block mt-2 font-body" style={{ fontSize: 10, fontWeight: 600, color: "#9a7b1f", border: "1px solid #e7dfc9", padding: "1px 7px" }}>ابتكار Invention</span>
        )}
        {(entry.pronunciation_en || entry.language) && (
          <div className="text-[11px] text-muted-foreground font-body mt-2">{[entry.pronunciation_en, entry.language].filter(Boolean).join("  —  ")}</div>
        )}
      </div>

      {/* الكتلة العربية */}
      {showAr && (entry.meaning_ar || entry.notes_ar) && (
        <div className="px-1 py-4 space-y-3" style={{ borderTop: `1px solid ${GOLD}` }}>
          {entry.meaning_ar && (
            <p dir="rtl" className="font-body" style={{ fontSize: fs(15), lineHeight: 1.95, color: "#374151", textAlign: "right" }}>
              <span style={{ color: "#9D174D", fontWeight: 700 }}>{fw}</span>{rest}
            </p>
          )}
          {entry.notes_ar && (
            <>
              <div style={goldDivider} />
              <p dir="rtl" className="font-body text-muted-foreground" style={{ fontSize: fs(13), lineHeight: 1.8, textAlign: "right" }}>{entry.notes_ar}</p>
            </>
          )}
        </div>
      )}

      {/* الكتلة الإنجليزية */}
      {showEn && (entry.literal_meaning_en || entry.etymology_en || entry.scent_link_en || entry.roots) && (
        <div className="px-1 py-4 space-y-3" dir="ltr" style={{ borderTop: `1px solid ${GOLD}`, textAlign: "left" }}>
          {entry.literal_meaning_en && <p className="font-body" style={{ fontSize: fs(13), color: "#9a7b1f", fontWeight: 600 }}>{entry.literal_meaning_en}</p>}
          {entry.etymology_en && <p className="font-body text-foreground/80" style={{ fontSize: fs(13.5), lineHeight: 1.7 }}>{entry.etymology_en}</p>}
          {entry.scent_link_en && (
            <>
              <div style={goldDivider} />
              <p className="font-body text-foreground/80" style={{ fontSize: fs(13.5), lineHeight: 1.7 }}>{entry.scent_link_en}</p>
            </>
          )}
          {entry.roots && <p className="text-[11px] text-muted-foreground font-body" style={{ marginTop: 4 }}>{entry.roots}</p>}
        </div>
      )}

      {/* صور المدخل (حتى خمس) */}
      {Array.isArray(entry.images) && entry.images.length > 0 && (
        <div className="flex flex-wrap gap-2 justify-center">
          {entry.images.map((url, i) => (
            <img key={i} src={url} alt="" className="h-20 w-20 object-cover rounded-lg" />
          ))}
        </div>
      )}

      {/* الوسوم @ — تظهر متى أضافها المحتوى؛ تربط بصفحة المنشنات */}
      {tags.length > 0 && (
        <div className="flex flex-wrap gap-x-4 gap-y-1.5 justify-center">
          {tags.map((t) => (
            <Link key={t} to={`/search-results?q=${encodeURIComponent(t)}`} className="text-xs font-body text-primary hover:underline" dir="auto">@{t}</Link>
          ))}
        </div>
      )}

      {/* شريط التفاعل: إعجاب + فكرة + دفتر */}
      <InteractionBar
        reaction={currentReaction}
        hasThought={!!mine?.thought}
        showWtf={true}
        center={true}
        onReact={(kind) => reactMutation.mutate({ reaction: kind })}
        onThought={openThought}
        bookmark={{
          item_type: "symbolism",
          item_id: entry.story_idx,
          title_en: entry.name_en || "",
          title_ar: entry.name_ar || "",
          subtitle: isAr ? "معنى علامة" : "Marking Meaning",
          path: `/glossary?tab=symbolism&sym=${entry.story_idx}`,
        }}
      />

      {/* شرح و إشارات — قائمة واحدة مطويّة تضم كل الحقول المرفقة (شرح/ترادف/أضداد/نطق) */}
      <GlosseryExplain entry={entry} showAr={showAr} showEn={showEn} />

      {/* قائمة واحدة مطويّة: التصدير والإعداد — لغة + خطّ + خيارات + لون + أزرار التصدير */}
      <div className="flex justify-center pt-1">
        <ExportOptionsDialog userMarkAvailable={true} showReading accent="amber">
          <div className="space-y-4 pt-2 border-t border-border/30">
            <StoryFooter
              term={symbolismToTerm(entry)}
              showNav={false}
              topBorder={false}
              accentColor="amber"
              onExportPdf={(l) => exportSingleTerm(symbolismToTerm(entry), mine, { lang: l || "both" })}
              onExportImg={(l) => exportSingleTermImage(symbolismToTerm(entry), { lang: l || "both" })}
            />
          </div>
        </ExportOptionsDialog>
      </div>

      {/* محرّر الفكرة (سطري) */}
      {thoughtOpen && (
        <div className="space-y-2">
          <textarea name="PerfumesSymbolism-tex1"
            value={thoughtDraft}
            onChange={(e) => setThoughtDraft(e.target.value)}
            dir="auto"
            rows={3}
            placeholder={isAr ? "اكتب فكرتك.." : "Write your thought.."}
            className="w-full text-sm font-body p-3 rounded-none border border-input bg-white dark:bg-transparent focus:outline-none focus:border-foreground/40"
          />
          <div className="flex gap-2 justify-center">
            <button onClick={() => thoughtMutation.mutate({ newThought: thoughtDraft })} className="text-xs font-body rounded-none text-white transition-colors">{isAr ? "حفظ" : "Save"}</button>
            <button onClick={() => setThoughtOpen(false)} className="text-xs font-body rounded-none text-muted-foreground transition-colors">{isAr ? "إلغاء" : "Cancel"}</button>
          </div>
        </div>
      )}

      {/* عرض الفكرة المحفوظة */}
      {mine?.thought && !thoughtOpen && (
        <div className="p-3 space-y-1.5">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "فكرتي" : "My thought"}</p>
          <p className="text-sm font-body" dir="auto">{mine.thought}</p>
          <button onClick={openThought} className="text-[10px] text-muted-foreground hover:underline font-body">{isAr ? "تعديل" : "Edit"}</button>
        </div>
      )}

      {/* تعديل / كاست أواي للمدخل نفسه — كصفحة المعجم: ✏️ تعديل + إخفاء/حذف، مع تأكيد */}
      <div className="flex items-center justify-center gap-5 pt-1">
        <button onClick={openEdit} title={isAr ? "تعديل" : "Edit"} aria-label={isAr ? "تعديل" : "Edit"}
          className="text-muted-foreground hover:text-amber-700 transition-colors">
          <Pencil className="w-4 h-4" />
        </button>
        <button onClick={() => setConfirmDel(true)} title={isAr ? (entry.is_user ? "حذف" : "إهمال") : (entry.is_user ? "Delete" : "Cast Out")}
          aria-label={isAr ? (entry.is_user ? "حذف" : "إهمال") : (entry.is_user ? "Delete" : "Cast Out")}
          className="text-muted-foreground hover:text-[var(--brand)] transition-colors">
          <EraserIcon className="w-4 h-4" />
        </button>
      </div>

      {confirmDel && (
        <div className="flex items-center justify-center gap-2 pt-1">
          <span className="text-xs font-body text-muted-foreground">{isAr ? "متأكّد؟" : "Sure?"}</span>
          <button onClick={() => deleteMutation.mutate()} disabled={deleteMutation.isPending}
            className="text-xs font-body text-rose-600 hover:underline">{isAr ? "نعم" : "Yes"}</button>
          <button onClick={() => setConfirmDel(false)} className="text-xs font-body text-muted-foreground hover:underline">{isAr ? "إلغاء" : "Cancel"}</button>
        </div>
      )}

      

      {/* تنقّل سابق/تالٍ بين المداخل */}
      {(prev || next) && (
        <div className="flex items-center justify-between pt-2 border-t border-border/40">
          {prev ? (
            <button onClick={() => onSelect(prev.story_idx)} className="flex items-center gap-1 text-xs font-body text-primary hover:underline max-w-[45%]">
              <PrevArrow className="w-3.5 h-3.5 shrink-0" /> <span className="truncate" dir="auto">{isAr ? (prev.name_ar || prev.name_en) : prev.name_en}</span>
            </button>
          ) : <span />}
          {next ? (
            <button onClick={() => onSelect(next.story_idx)} className="flex items-center gap-1 text-xs font-body text-primary hover:underline max-w-[45%]">
              <span className="truncate" dir="auto">{isAr ? (next.name_ar || next.name_en) : next.name_en}</span> <NextArrow className="w-3.5 h-3.5 shrink-0" />
            </button>
          ) : <span />}
        </div>
      )}
    </div>
  );
}

export default function PerfumesSymbolism() {
  const { isAr } = useLang();
  const [sel, setSel] = useState(() => {
    const s = new URLSearchParams(window.location.search).get("sym");
    return s != null && s !== "" ? s : null;
  });
  const [sortOrder, setSortOrder] = useState(() => {
    const saved = getSecureStorage("symbolismSettings", null);
    return saved ? saved.sortOrder || "newest" : "newest";
  });
  const SYM_PAGE = 25;
  const [symPage, setSymPage] = useState(1);

  // الرمزية تُقرأ من مخزن DB المخصّص (PerfumeSymbolism) — قابل للتعديل ويتّسع لعشرة آلاف،
  // بدل جلب ملفّ JSON كاملاً في الذاكرة.
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["perfumes-symbolism"],
    queryFn: () => apphost.entities.PerfumeSymbolism.list("-created_date", 1000000),
    staleTime: Infinity,
  });

  // فرز موحّد مع المعجم: نفس مبدّل المصطلحات (أبجدي/معكوس/الأحدث/الأقدم). الأبجدي عبر
  // compareGlossary بالاسم الإنجليزي لكلتا اللغتين، فيتّسق ترتيب كامل المعجم. التطبيع يوفّر name_en.
  const normalized = [...rows].filter((r) => !r.hidden).map(normalizeSymbolism);
  const entries = normalized.sort((a, b) => {
    if (sortOrder === "alpha_asc") return compareGlossary(a, b, 1);
    if (sortOrder === "alpha_desc") return compareGlossary(a, b, -1);
    if (sortOrder === "newest") return new Date(b.created_date) - new Date(a.created_date);
    if (sortOrder === "oldest") return new Date(a.created_date) - new Date(b.created_date);
    return compareGlossary(a, b, 1);
  });
  const selected = sel != null ? entries.find((e) => String(e.story_idx) === String(sel)) : null;
  const totalSymPages = Math.max(1, Math.ceil(entries.length / SYM_PAGE));
  const pagedEntries = entries.slice((symPage - 1) * SYM_PAGE, symPage * SYM_PAGE);
  useEffect(() => { setSymPage(1); }, [sortOrder]);
  useEffect(() => { if (symPage > totalSymPages) setSymPage(1); }, [symPage, totalSymPages]);

  // إن جاء ?sym لمدخل غير موجود، ارجع للقائمة
  useEffect(() => {
    if (sel != null && entries.length > 0 && !selected) setSel(null);
  }, [sel, entries.length, selected]);

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="w-6 h-6 border-2 border-amber-300 border-t-amber-600 rounded-full animate-spin" />
      </div>
    );
  }

  if (selected) {
    return <SymbolismDetail entry={selected} entries={entries} onSelect={(i) => setSel(String(i))} onBack={() => setSel(null)} isAr={isAr} />;
  }

  return (
    <div className="space-y-3">
      {SYMBOLISM_DESC.ar && (
        <p className="text-[11px] text-amber-700/80 dark:text-amber-400/70 font-body leading-relaxed" dir={isAr ? "rtl" : "ltr"}>
          {isAr ? SYMBOLISM_DESC.ar : SYMBOLISM_DESC.en}
        </p>
      )}

      {/* مبدّل الفرز — نفس تنسيق صفحة المصطلحات */}
      <div className="flex items-center gap-1" dir="ltr">
        {[
          { value: "alpha_asc", en: "Alphabetical", ar: "أبجدي", Icon: AArrowUp },
          { value: "alpha_desc", en: "Descend", ar: "معكوس", Icon: AArrowDown },
          { value: "newest", en: "Newest", ar: "الأحدث" },
          { value: "oldest", en: "Oldest", ar: "الأقدم" },
        ].map(({ value, en, ar, Icon }) => (
          <button
            key={value}
            onClick={() => {
              setSortOrder(value);
              const cur = getSecureStorage("symbolismSettings", {}) || {};
              setSecureStorage("symbolismSettings", { ...cur, sortOrder: value });
            }}
            className={
              Icon
                ? `flex items-center gap-1 px-2 py-1 text-[9.5px] font-body font-medium bg-transparent transition-colors ${
                    sortOrder === value ? "text-[#059669]" : "text-muted-foreground hover:text-foreground"
                  }`
                : `rounded-none px-2 py-1 text-[9.5px] font-body font-medium transition-colors ${
                    sortOrder === value ? "text-[#059669]" : "text-muted-foreground hover:text-foreground"
                  }`
            }
            title={isAr ? ar : en}
          >
            {Icon ? <Icon className="w-4 h-4" /> : (isAr ? ar : en)}
          </button>
        ))}
      </div>

      {entries.length === 0 ? (
        <p className="text-center text-muted-foreground font-body text-sm py-10">{isAr ? "لا مدخلات بعد" : "No entries yet"}</p>
      ) : (
        <div>
          {pagedEntries.map((e) => (
            <button
              key={e.story_idx}
              onClick={() => setSel(String(e.story_idx))}
              className="w-full text-left px-1 py-3.5 transition-opacity hover:opacity-80"
              style={{ borderRadius: 0, borderBottom: `1px solid ${GOLD}` }}
            >
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-0.5">
                <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "1rem", fontWeight: 700, color: "#9a7b1f" }}>{e.name_en}</span>
                {e.name_ar && <span dir="rtl" style={{ fontFamily: "'Amiri', serif", fontWeight: 700, fontSize: "1rem", color: "#9D174D" }}>{e.name_ar}</span>}
              </div>
              {e.literal_meaning_en && <div className="text-xs text-muted-foreground font-body mt-1" dir="ltr">{excerpt(e.literal_meaning_en)}</div>}
            </button>
          ))}
          {totalSymPages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-4">
              <button disabled={symPage === 1} onClick={() => setSymPage((p) => Math.max(1, p - 1))} className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "السابق" : "Prev"}</button>
              <span className="text-xs text-muted-foreground tabular-nums">{symPage} / {totalSymPages}</span>
              <button disabled={symPage >= totalSymPages} onClick={() => setSymPage((p) => Math.min(totalSymPages, p + 1))} className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "التالي" : "Next"}</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

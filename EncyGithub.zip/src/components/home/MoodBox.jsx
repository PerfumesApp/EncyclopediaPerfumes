import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { usePersonNames } from "@/lib/usePersonNames";
import { useNumberEncryption } from "@/lib/useNumberEncryption";


// Full emoji sequence regex: captures ZWJ sequences, variation selectors, skin tones, flags
const EMOJI_REGEX = /(?:\p{Extended_Pictographic}(?:\uFE0F)?(?:\u20D0-\u20FF)?(?:\u200D\p{Extended_Pictographic}(?:\uFE0F)?)*|\p{Emoji_Presentation}\uFE0F?(?:\u200D\p{Extended_Pictographic}\uFE0F?)*|[\uD83C][\uDDE0-\uDDFF][\uD83C][\uDDE0-\uDDFF])/gu;

function extractEmoji(str) {
  const matches = str.match(EMOJI_REGEX) || [];
  return matches;
}

function stripEmojis(str) {
  return str.replace(EMOJI_REGEX, "").trim();
}

export default function MoodBox({ defaultPerson = "person1" }) {
  const { names, profiles } = usePersonNames();
  const queryClient = useQueryClient();
  const { encryptFields, decryptFields } = useNumberEncryption();

  const [expanded, setExpanded] = useState(false);
  const [text, setText] = useState("");
  const [person, setPerson] = useState(defaultPerson);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [postedMood, setPostedMood] = useState(null);
  const textareaRef = useRef();

  const personColor = person === "person2"
    ? (profiles?.person2?.color || "#8b5cf6")
    : (profiles?.person1?.color || "#10b981");

  const mutation = useMutation({
    mutationFn: async (data) => {
      const encrypted = await encryptFields({ text: data.text }, ['text']);
      return apphost.entities.MoodEntry.create({ ...data, ...encrypted });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["mood-entries"] });
      setPostedMood({ emoji: variables.emoji, text: variables.text });
      setText("");
      setError("");
      setSaved(true);
      setExpanded(false);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  const handleSubmit = () => {
    const emojis = extractEmoji(text);
    const cleanText = text.trim();

    if (!cleanText) {
      setError("Please write something.");
      return;
    }
    if (emojis.length === 0) {
      setError("Add at least one emoji to your mood.");
      return;
    }
    if (text.length > 100) {
      setError("Max 100 characters.");
      return;
    }

    setError("");
    // Save full raw text (text + all emojis), first emoji as the mood emoji
    mutation.mutate({ text: cleanText, emoji: emojis[0], person });
  };

  const handleChange = (e) => {
    const val = e.target.value;
    const emojis = extractEmoji(val);
    setError("");
    if (val.length <= 100) setText(val);
  };

  const charsLeft = 100 - text.length;

  return (
    <div className="overflow-hidden">
      {/* Header — always visible, click to expand/collapse */}
      <button
        onClick={() => { setExpanded((v) => !v); setPostedMood(null); }}
        className="w-full flex items-center justify-center py-1 transition-colors"
      >
        <span className="text-base">🌱</span>
      </button>

      {/* Posted mood display (collapsed after save) */}
      {!expanded && postedMood && (
        <div className="flex items-center justify-center gap-1.5 pb-1">
          <span className="text-sm">{postedMood.emoji}</span>
          <span className="text-xs text-muted-foreground font-body">{postedMood.text}</span>
        </div>
      )}

      {/* Expandable content */}
      {expanded && (
        <div className="pb-2 space-y-2">
          {/* Person toggle */}
          <div className="flex gap-1.5 justify-center">
            {["person1", "person2"].map((p) => (
              <button
                key={p}
                onClick={() => setPerson(p)}
                className="text-[10px] font-body px-2 py-0.5 rounded-none transition-all"
                style={{
                  background: person === p ? personColor + "22" : "transparent",
                  color: person === p ? personColor : undefined,
                  border: `1px solid ${person === p ? personColor : "hsl(var(--border))"}`,
                }}
              >
                {p === "person1" ? (names.person1 || "Alpha") : (names.person2 || "Bravo")}
              </button>
            ))}
          </div>

          {/* Text input */}
          <div className="relative">
            <textarea name="MoodBox-tex1"
              ref={textareaRef}
              value={text}
              onChange={handleChange}
              placeholder="with an emoji and few words what mood you at 💚"
              rows={2}
              className="w-full rounded-none border border-input bg-background/60 px-3 py-2 text-sm font-body placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring resize-none"
              style={{ borderColor: text.length > 0 ? personColor + "66" : undefined }}
            />
            <span className={`absolute bottom-2 right-3 text-[10px] font-body ${charsLeft <= 10 ? "text-destructive" : "text-muted-foreground"}`}>
              {charsLeft}
            </span>
          </div>

          {/* Error */}
          {error && <p className="text-xs text-destructive font-body">{error}</p>}

          {/* Save button */}
          <button
            onClick={handleSubmit}
            disabled={mutation.isPending || !text.trim()}
            className="w-full py-1.5 rounded-none text-xs font-body font-semibold transition-all disabled:opacity-40"
            style={{ background: personColor, color: "#fff" }}
          >
            {saved ? "Saved ✓" : mutation.isPending ? "Saving…" : "MooD"}
          </button>
        </div>
      )}
    </div>
  );
}
import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Search, X } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { getSearchHistory, addSearchHistory, removeSearchHistory } from "@/lib/searchHistory";

/**
 * GlobalSearch — صندوق بحث «إرسال فقط»: لا نتائج حيّة، و لا تحميل أيّ بيانات أثناء
 * الكتابة. عند Enter أو ضغط أيقونة البحث → ينتقل لصفحة النتائج المستقلّة
 * (/search-results) التي تجلب النوع المطلوب وحده عبر فهرس البحث (بلا تحميل 130 ألف).
 * رقائق السجلّ تظهر فقط عند التركيز و الصندوق فارغ (ليست نتائج بحث).
 */
export default function GlobalSearch() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [focused, setFocused] = useState(false);
  const [history, setHistory] = useState(() => getSearchHistory());
  const boxRef = useRef(null);

  useEffect(() => {
    const h = () => setHistory(getSearchHistory());
    window.addEventListener("searchHistoryChanged", h);
    return () => window.removeEventListener("searchHistoryChanged", h);
  }, []);

  useEffect(() => {
    const onClick = (e) => { if (boxRef.current && !boxRef.current.contains(e.target)) setFocused(false); };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const runSearch = (term) => {
    const s = (term != null ? term : q).trim();
    if (!s) return;
    addSearchHistory(s);
    setHistory(getSearchHistory());
    setFocused(false);
    navigate(`/search-results?q=${encodeURIComponent(s)}`);
  };

  return (
    <div ref={boxRef} className="relative">
      <div className="flex items-center gap-2 px-3 h-11 bg-[var(--page-bg,#fff)]" style={{ borderRadius: 0 }} dir="ltr">
        <div aria-hidden="true" className="w-px h-5 flex-shrink-0" style={{ background: "var(--brand)" }} />
        <input name="GlobalSearch-1"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onFocus={() => setFocused(true)}
          onKeyDown={(e) => { if (e.key === "Enter") runSearch(); }}
          placeholder=""
          dir={isAr ? "rtl" : "ltr"}
          className="flex-1 bg-transparent outline-none text-sm font-body placeholder:text-muted-foreground"
        />
        {q && (
          <span className="text-[10px] font-body text-muted-foreground/80 flex-shrink-0 whitespace-nowrap" aria-hidden="true">
            {isAr ? "اضغط انتر" : "Press Enter"}
          </span>
        )}
        <button onClick={() => runSearch()} aria-label={isAr ? "بحث" : "search"} className="flex-shrink-0 hover:opacity-70 transition-opacity">
          <Search className="w-4 h-4" style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {focused && !q && history.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-card rounded-none shadow-xl z-40" style={{ borderTop: "2px solid var(--brand)" }}>
          <div className="flex flex-wrap gap-1.5 p-2">
            {history.map((h) => (
              <span key={h} className="inline-flex items-center gap-1 px-2 py-1 bg-secondary/60 text-xs font-body text-foreground/80">
                <button onClick={() => { setQ(h); runSearch(h); }} className="hover:text-[var(--brand)]">{h}</button>
                <button onClick={() => removeSearchHistory(h)} className="text-muted-foreground hover:text-red-500" aria-label="remove">
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

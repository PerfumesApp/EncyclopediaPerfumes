import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { Link } from "react-router-dom";
import { Heart, ThumbsUp, ThumbsDown, RotateCw, Download } from "lucide-react";
import { toast } from "sonner";
import BookmarkButton from "@/components/shared/BookmarkButton";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { resolveUserMark, DEFAULT_USER_MARK } from "@/lib/exportSettings";
import { perfumeQuotePool } from "@/lib/perfumeQuotes";

/**
 * RandomQuote — اقتباس عشوائي على Goals/Home.
 * يعرض اللغتين دائماً، بلا تصنيف، بخلفية مختلفة وبلا إطارات، وبخمسة أزرار
 * تفاعل بلا إطارات: مفضّل — إعجاب — عدم إعجاب — مذهول 😱 — إبعاد (cast away).
 * الإبعاد يُخفي الاقتباس من الدوران ويسجّله reaction="castaway".
 */
export default function RandomQuote({ linkTo }) {
  const { isAr } = useLang();
  const [currentQuote, setCurrentQuote] = useState(null);
  const qc = useQueryClient();

  // حوض اقتباسات العطور المدمج (بعد إزالة قسمي Quotes / Marking من الموسوعة).
  const { data: quotes = [] } = useQuery({
    queryKey: ["perfume-quotes-random-pool"],
    queryFn: async () => {
      const all = perfumeQuotePool();
      const POOL = Math.min(14, all.length);
      const idxs = new Set();
      while (idxs.size < POOL) idxs.add(Math.floor(Math.random() * all.length));
      return [...idxs].map((i) => all[i]);
    },
    staleTime: 1000 * 60 * 5,
  });

  // التفاعلات تغذّي الموسوعة مباشرةً: تُحفظ في EncEntry.reactions حسب المستخدم النشط.
  const activePerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";

  const pickNewQuote = (excludeId = null) => {
    const ex = excludeId != null ? String(excludeId) : null;
    const withText = quotes.filter(
      (q) => (q.text_enar || q.text_en || q.text_ar || q.text) &&
        (q.reactions?.[activePerson] !== "castaway") &&
        String(q.id) !== ex
    );
    const pool = withText.length > 0 ? withText : quotes.filter((q) => String(q.id) !== ex);
    if (pool.length > 0) setCurrentQuote(pool[Math.floor(Math.random() * pool.length)]);
  };

  useEffect(() => {
    pickNewQuote();
     
  }, [quotes.length]);

  useEffect(() => {
    const handle = () => pickNewQuote();
    window.addEventListener("refreshQuote", handle);
    return () => window.removeEventListener("refreshQuote", handle);
     
  }, [quotes.length]);

  if (!currentQuote) return null;

  const userReaction = currentQuote.reactions?.[activePerson] || "none";
  const react = (reaction) => {
    const newReaction = userReaction === reaction ? "none" : reaction;
    const reactions = { ...(currentQuote.reactions || {}) };
    if (newReaction === "none") delete reactions[activePerson]; else reactions[activePerson] = newReaction;
    setCurrentQuote({ ...currentQuote, reactions }); // عرض فوريّ
    const id = currentQuote.id;
    apphost.entities.EncEntry.update(id, { reactions }).then(() => {
      qc.invalidateQueries({ queryKey: ["enc-fav-entries"] });
    }).catch(() => {});
    if (newReaction === "castaway") setTimeout(() => pickNewQuote(id), 0);
  };

  // تصدير الاقتباس صورةً — على غرار و نفس تنسيق «المعاني غير المكتملة» (بطاقة ذهبية ثنائية).
  const exportQuote = async (q) => {
    let mark = DEFAULT_USER_MARK;
    try { mark = (await resolveUserMark()) || DEFAULT_USER_MARK; } catch { /* default */ }
    const GOLD_T = "#9a7b1f"; // ذهبي قاتم مقروء على الأبيض
    const card = document.createElement("div");
    // خلفية بيضاء، بلا إطار، عرض حتى 680 (لا يتجاوز)
    card.style.cssText = "position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none; width:600px; max-width:680px; box-sizing:border-box; background:#ffffff; padding:40px 36px; display:flex; flex-direction:column; gap:14px; font-family:'Playfair Display','Amiri','Georgia',serif;";
    const add = (text, css) => { if (!text) return; const el = document.createElement("div"); el.textContent = text; el.style.cssText = css; card.appendChild(el); };
    const enT = q.text_enar || q.text_en || q.text || "";
    const arT = q.text_ar || "";
    // الإنجليزي من اليسار لليمين، العربي من اليمين لليسار (ليس وسط)
    add(enT, `direction:ltr;text-align:left;color:${GOLD_T};font-size:16px;font-style:italic;line-height:1.55;`);
    add(arT, `direction:rtl;text-align:right;color:${GOLD_T};font-size:17px;line-height:1.85;font-family:'Amiri',serif;`);
    if (q.author) add("— " + q.author, `direction:ltr;text-align:left;color:${GOLD_T};font-size:13px;`);
    add(mark, `color:${GOLD_T};font-size:12px;letter-spacing:3px;text-align:left;margin-top:4px;font-family:sans-serif;`);
    document.body.appendChild(card);
    try {
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const w = Math.min(card.scrollWidth || 600, 680), h = Math.min(card.scrollHeight, 680);
      const canvas = await captureElement(card, { scale: 2, useCORS: true, allowTaint: true, logging: false, backgroundColor: "#ffffff", width: w, height: h, windowWidth: w, windowHeight: h });
      const d = new Date(); const pad = (n) => String(n).padStart(2, "0");
      const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
      await saveCanvasAsImage(canvas, `Quote-${stamp}.png`);
      toast(isAr ? "تم التصدير" : "Exported", { position: "bottom-right" });
    } catch {
      toast.error(isAr ? "فشل التصدير" : "Export failed", { position: "bottom-right" });
    } finally { document.body.removeChild(card); }
  };

  // اللغتان دائماً: نفضّل المدمج، وإلا نعرض الإنجليزي والعربي معاً.
  const enar = currentQuote.text_enar || "";
  const en = currentQuote.text_en || currentQuote.text || "";
  const ar = currentQuote.text_ar || "";

  const RBtn = ({ active, activeColor, title, onClick, children }) => (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-label={title}
      className={`flex items-center justify-center w-8 h-8 bg-transparent transition-all ${
        active ? "text-[#B76E79]" : "text-[var(--brand)] hover:opacity-70"
      }`}
    >
      {children}
    </button>
  );

  return (
    <div className="px-1 py-2 space-y-3">
      {/* عنوان الصندوق — اقتباسات العطور */}
      <p className="text-[11px] font-body text-muted-foreground/70" dir="auto" style={{ unicodeBidi: "plaintext" }}>
        {isAr ? "اقتباسات" : "Quotes"}
      </p>
      {/* Bilingual quote — always both languages — نصّ ذهبيّ */}
      {enar ? (
        <p className="text-sm font-body font-medium leading-relaxed text-[#9a7b1f]" dir="auto" style={{ unicodeBidi: "plaintext" }}>{enar}</p>
      ) : (
        <div className="space-y-1">
          {en && <p className="text-sm font-body font-medium leading-relaxed text-[#9a7b1f]" dir="ltr">{en}</p>}
          {ar && <p className="text-sm font-body font-medium leading-relaxed text-[#9a7b1f]" dir="rtl">{ar}</p>}
        </div>
      )}

      {currentQuote.author && (
        <p className="text-xs font-body text-[#9a7b1f]/80" dir="auto" style={{ unicodeBidi: "plaintext" }}>— {currentQuote.author}</p>
      )}

      {currentQuote.category && (
        <span className="inline-block text-[10px] font-body text-[#9a7b1f]/80" dir="auto" style={{ unicodeBidi: "plaintext" }}>
          {currentQuote.category}
        </span>
      )}

      <div className="flex items-center gap-2 justify-between pt-1 flex-wrap-reverse">
        <button type="button" onClick={() => pickNewQuote()}
          className="p-1.5 text-[#9a7b1f]/50 hover:text-[#9a7b1f] transition-colors"
          title={isAr ? "اقتباس آخر" : "Next quote"}>
          <RotateCw className="w-4 h-4" />
        </button>
        {/* تفاعلات ذهبية موحّدة: مفضّل — إعجاب — عدم إعجاب — ماذا — نوت بوك — تصدير */}
        <div className="flex gap-1 items-center">
          <RBtn active={userReaction === "favorite"} activeColor="text-[var(--brand)]" title={isAr ? "مفضّل" : "Favourite"} onClick={() => react("favorite")}>
            <Heart className={`w-4 h-4 ${userReaction === "favorite" ? "fill-current" : ""}`} />
          </RBtn>
          <RBtn active={userReaction === "like"} activeColor="text-[var(--brand)]" title={isAr ? "إعجاب" : "Like"} onClick={() => react("like")}>
            <ThumbsUp className="w-4 h-4" />
          </RBtn>
          <RBtn active={userReaction === "dislike"} activeColor="text-[var(--brand)]" title={isAr ? "عدم إعجاب" : "Dislike"} onClick={() => react("dislike")}>
            <ThumbsDown className="w-4 h-4" />
          </RBtn>
          <RBtn active={userReaction === "wtf"} activeColor="text-[var(--brand)]" title={isAr ? "ماذا" : "What"} onClick={() => react("wtf")}>
            <span className={`text-base leading-none ${userReaction === "wtf" ? "opacity-100" : "opacity-60"}`}>😱</span>
          </RBtn>
          <BookmarkButton size={32} descriptor={{
            item_type: "quote", item_id: String(currentQuote.id),
            title_en: currentQuote.text_en || currentQuote.text || currentQuote.text_enar || "",
            title_ar: currentQuote.text_ar || "",
            subtitle: currentQuote.category || "", path: `/encyclopedia/view/${currentQuote.id}`,
          }} />
          <RBtn active={false} activeColor="" title={isAr ? "تصدير" : "Export"} onClick={() => exportQuote(currentQuote)}>
            <Download className="w-4 h-4" />
          </RBtn>
        </div>
      </div>

      {/* رابط الموسوعة — ثنائي بلا أسهم */}
      <Link to="/encyclopedia" className="block text-[#9a7b1f] text-[11px] font-body hover:underline pt-1">
        {isAr ? "موسوعة" : "Encyclopedia"}
      </Link>
    </div>
  );
}

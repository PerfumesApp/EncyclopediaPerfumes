import { useMemo } from "react";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useLang } from "@/lib/LanguageContext";

export default function GoalsProgressChart({ goals, personFilter, selectedPeriod = "month" }) {
  const { isAr } = useLang();
  const filteredGoals = useMemo(() => {
    return goals.filter((g) => {
      const matchPerson = personFilter === "all" || g.person === personFilter || g.person === "both";
      const isDone = g.status === "done";
      return matchPerson && isDone;
    });
  }, [goals, personFilter]);

  // Calculate completed goals by week/month
  const completionData = useMemo(() => {
    const now = new Date();
    const data = [];

    if (selectedPeriod === "week") {
      // Last 4 weeks
      for (let i = 3; i >= 0; i--) {
        const weekStart = new Date(now);
        weekStart.setDate(weekStart.getDate() - weekStart.getDay() - i * 7);
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekEnd.getDate() + 6);

        const count = filteredGoals.filter((g) => {
          const completedDate = g.completed_at ? new Date(g.completed_at) : null;
          return completedDate >= weekStart && completedDate <= weekEnd;
        }).length;

        data.push({
          name: `Week ${4 - i}`,
          completed: count,
        });
      }
    } else {
      // Last 6 months
      for (let i = 5; i >= 0; i--) {
        const monthStart = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const monthEnd = new Date(monthStart.getFullYear(), monthStart.getMonth() + 1, 0);

        const count = filteredGoals.filter((g) => {
          const completedDate = g.completed_at ? new Date(g.completed_at) : null;
          return completedDate >= monthStart && completedDate <= monthEnd;
        }).length;

        const monthName = monthStart.toLocaleDateString("en-US", { month: "short" });
        data.push({
          name: monthName,
          completed: count,
        });
      }
    }
    return data;
  }, [filteredGoals, selectedPeriod]);

  // Calculate completed goals by category
  const categoryData = useMemo(() => {
    const categoryMap = {};

    filteredGoals.forEach((g) => {
      const category = g.category === "custom" ? g.custom_category : g.category;
      categoryMap[category] = (categoryMap[category] || 0) + 1;
    });

    return Object.entries(categoryMap).map(([name, value]) => ({
      name: name.replace(/_/g, " "),
      value,
    }));
  }, [filteredGoals]);

  const COLORS = [
    "#10b981", "#8b5cf6", "#f59e0b", "#ef4444", "#3b82f6",
    "#ec4899", "#14b8a6", "#f97316", "#6366f1", "#84cc16",
  ];

  const totalCompleted = filteredGoals.length;
  const avgPerPeriod = selectedPeriod === "week"
    ? (totalCompleted / 4).toFixed(1)
    : (totalCompleted / 6).toFixed(1);

  return (
    <div className="space-y-4">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 dark:from-emerald-900/20 dark:to-emerald-800/10 rounded-none p-3 border border-emerald-200/50 dark:border-emerald-800/30">
          <p className="text-[10px] text-emerald-700 dark:text-emerald-300 font-body uppercase tracking-wide">{isAr ? "إجمالي المكتمل" : "Total Completed"}</p>
          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">{totalCompleted}</p>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 dark:from-blue-900/20 dark:to-blue-800/10 rounded-none p-3 border border-blue-200/50 dark:border-blue-800/30">
          <p className="text-[10px] text-blue-700 dark:text-blue-300 font-body uppercase tracking-wide">{isAr ? "المتوسط" : "Average"}</p>
          <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 mt-1">{avgPerPeriod}</p>
          <p className="text-[9px] text-blue-600 dark:text-blue-400 font-body mt-0.5">{isAr ? (selectedPeriod === "week" ? "أسبوعياً" : "شهرياً") : `per ${selectedPeriod}`}</p>
        </div>
      </div>

      {/* Period Toggle */}
      <div className="flex gap-2 bg-secondary/40 rounded-none p-1">
        {["week", "month"].map((period) => (
          <button
            key={period}
            onClick={() => window.dispatchEvent(new CustomEvent("goalsPeriodChange", { detail: { period } }))}
            className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all capitalize ${
              selectedPeriod === period
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {isAr ? (period === "week" ? "أسبوعي" : "شهري") : `${period}ly`}
          </button>
        ))}
      </div>

      {/* Completion Over Time */}
      {completionData.length > 0 && (
        <div className="bg-card border border-border/50 rounded-none p-3">
          <p className="text-xs font-body font-semibold mb-3">{isAr ? "الأهداف المكتملة عبر الوقت" : "Completed Goals Over Time"}</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={completionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="var(--color-muted-foreground)" />
              <YAxis tick={{ fontSize: 11 }} stroke="var(--color-muted-foreground)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  borderRadius: "0.5rem",
                }}
                labelStyle={{ color: "var(--color-foreground)", fontSize: 12 }}
              />
              <Bar dataKey="completed" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Category Breakdown */}
      {categoryData.length > 0 && (
        <div className="bg-card border border-border/50 rounded-none p-3">
          <p className="text-xs font-body font-semibold mb-3">{isAr ? "المكتمل حسب الفئة" : "Completed by Category"}</p>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={60}
                fill="#8884d8"
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--color-card)",
                  border: "1px solid var(--color-border)",
                  borderRadius: "0.5rem",
                }}
                labelStyle={{ color: "var(--color-foreground)", fontSize: 12 }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Empty State */}
      {totalCompleted === 0 && (
        <div className="text-center py-6 text-muted-foreground">
          <p className="text-sm font-body">{isAr ? "لا أهداف مكتملة بعد، أكمل هدفاً لترى التقدّم" : "No completed goals yet. Complete a goal to see progress!"}</p>
        </div>
      )}
    </div>
  );
}
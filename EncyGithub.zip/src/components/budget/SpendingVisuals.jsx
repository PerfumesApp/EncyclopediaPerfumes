import { useMemo } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  PieChart, Pie, Legend
} from "recharts";
import { useLang } from "@/lib/LanguageContext";

// أسماء الفئات بالعربية (للرسوم والأساطير)
const CAT_AR = {
  Income: "الدخل", Expenses: "المصاريف", Obligations: "الالتزامات", Recurring: "متكرّر",
  food: "طعام", transportation: "تنقّل", utilities: "خدمات", shopping: "تسوّق",
  entertainment: "ترفيه", health: "صحّة", education: "تعليم", perfume: "عطور",
  insurance: "تأمين", subscription: "اشتراك", other: "أخرى", perfume_purchase: "شراء عطر",
};

const CATEGORY_COLORS = {
  food: "#f59e0b",
  transportation: "#3b82f6",
  utilities: "#8b5cf6",
  shopping: "#ec4899",
  entertainment: "#14b8a6",
  health: "#10b981",
  education: "#6366f1",
  perfume: "#f97316",
  insurance: "#64748b",
  subscription: "#a855f7",
  other: "#94a3b8",
  perfume_purchase: "#e11d48",
};

const INCOME_COLOR = "#10b981";
const EXPENSE_COLOR = "#ef4444";

export default function SpendingVisuals({ monthExpenses, monthPurchases, monthIncomes, totalIncome, totalExpense, totalPurchases, totalObligations, totalRecurring, currency }) {
  const { isAr } = useLang();
  // اسم الفئة معروضاً: عربي عند العربية، وإلا تجميل الإنجليزي
  const catLabel = (name) => isAr ? (CAT_AR[name] || name) : String(name).replace("_", " ");
  // Bar chart: income vs spending breakdown
  const barData = useMemo(() => [
    { name: "Income", value: totalIncome, color: INCOME_COLOR },
    { name: "Expenses", value: totalExpense + totalPurchases, color: EXPENSE_COLOR },
    { name: "Obligations", value: totalObligations, color: "#f97316" },
    { name: "Recurring", value: totalRecurring, color: "#8b5cf6" },
  ].filter(d => d.value > 0), [totalIncome, totalExpense, totalPurchases, totalObligations, totalRecurring]);

  // Pie chart: expense categories breakdown
  const pieData = useMemo(() => {
    const cats = {};
    monthExpenses.forEach((e) => {
      const cat = e.category || "other";
      cats[cat] = (cats[cat] || 0) + (e.amount || 0);
    });
    // Perfume purchases as their own slice
    const purchaseTotal = monthPurchases.reduce((s, p) => s + (p.cost || 0), 0);
    if (purchaseTotal > 0) cats["perfume_purchase"] = purchaseTotal;

    return Object.entries(cats)
      .map(([name, value]) => ({ name, value: Math.round(value) }))
      .sort((a, b) => b.value - a.value);
  }, [monthExpenses, monthPurchases]);

  const totalSpend = pieData.reduce((s, d) => s + d.value, 0);

  if (barData.length === 0 && pieData.length === 0) {
    return (
      <div className="text-center text-xs text-muted-foreground py-6">
        {isAr ? "لا بيانات ماليّة هذا الشهر للعرض." : "No financial data this month to visualize."}
      </div>
    );
  }

  const customTooltip = ({ active, payload }) => {
    if (active && payload?.length) {
      return (
        <div className=" rounded-none text-xs ">
          <p className="font-semibold">{catLabel(payload[0]?.payload?.name ?? payload[0].name)}</p>
          <p className="text-primary font-bold">{payload[0].value.toFixed(0)} {currency}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-5">
      {/* Bar chart: Income vs Spending */}
      {barData.length > 0 && (
        <div className="py-2 space-y-3">
          <h3 className="text-sm font-heading font-semibold">📊 {isAr ? "الدخل مقابل الصرف Income vs Spending" : "Income vs Spending"}</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={barData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <XAxis dataKey="name" tick={{ fontSize: 10 }} tickFormatter={catLabel} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip content={customTooltip} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                {barData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Pie chart: Expense categories */}
      {pieData.length > 0 && (
        <div className="py-2 space-y-3">
          <h3 className="text-sm font-heading font-semibold">🥧 {isAr ? "أين يذهب مالك Where Your Money Goes" : "Where Your Money Goes"}</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={80}
                innerRadius={40}
                paddingAngle={2}
              >
                {pieData.map((entry, i) => (
                  <Cell key={i} fill={CATEGORY_COLORS[entry.name] || "#94a3b8"} />
                ))}
              </Pie>
              <Tooltip content={customTooltip} />
              <Legend
                formatter={(value) => <span style={{ fontSize: 10 }}>{catLabel(value)}</span>}
                iconSize={10}
              />
            </PieChart>
          </ResponsiveContainer>

          {/* Category legend with amounts */}
          <div className="space-y-1.5 pt-1 border-t border-border/40">
            {pieData.map((entry) => {
              const pct = totalSpend > 0 ? ((entry.value / totalSpend) * 100).toFixed(0) : 0;
              return (
                <div key={entry.name} className="flex items-center gap-2">
                  <div
                    className="w-2.5 h-2.5 rounded-none flex-shrink-0"
                    style={{ background: CATEGORY_COLORS[entry.name] || "#94a3b8" }}
                  />
                  <span className="text-xs font-body flex-1 capitalize">{catLabel(entry.name)}</span>
                  <span className="text-xs text-muted-foreground">{pct}%</span>
                  <span className="text-xs font-semibold">{entry.value} {currency}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
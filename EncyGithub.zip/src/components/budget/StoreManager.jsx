import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Trash2, ExternalLink, Edit2 } from "lucide-react";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { openExternalUrl } from "@/lib/exportHelper";

export default function StoreManager() {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({ name: "", website: "", logo_url: "", description: "" });
  const qc = useQueryClient();

  // التوحيد: مدير المتاجر يستخدم ShopBrand (نفس متاجر التسوّق والمشتريات).
  const { data: stores = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
  });

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.ShopBrand.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["shop-brands"] }); closeDialog(); toast.success("أُضيف المتجر"); },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => apphost.entities.ShopBrand.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["shop-brands"] }); closeDialog(); toast.success("حُدّث المتجر"); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.ShopBrand.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["shop-brands"] }); toast.success("حُذف المتجر"); },
  });

  const openAdd = () => {
    setEditingId(null);
    setFormData({ name: "", website: "", logo_url: "", description: "" });
    setOpen(true);
  };

  const openEdit = (store) => {
    setEditingId(store.id);
    setFormData({ name: store.name || "", website: store.website || "", logo_url: store.logo_url || "", description: store.description || "" });
    setOpen(true);
  };

  const closeDialog = () => { setOpen(false); setEditingId(null); setFormData({ name: "", website: "", logo_url: "", description: "" }); };

  const handleSave = () => {
    if (!formData.name.trim()) { toast.error("اسم المتجر مطلوب"); return; }

    const payload = { name: formData.name, website: formData.website || null, logo_url: formData.logo_url || null, description: formData.description || null };
    if (editingId) {
      updateMutation.mutate({ id: editingId, data: payload });
    } else {
      createMutation.mutate({ ...payload, type: "perfume_store", person: "family" });
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-heading font-semibold">🏪 Stores</h2>
        <Button size="sm" variant="outline" className="h-8 rounded-none text-xs" onClick={openAdd}>
          Add Store
        </Button>
      </div>

      {stores.length === 0 ? (
        <p className="text-xs text-muted-foreground font-body py-4">لا متاجر بعد No stores yet.</p>
      ) : (
        <div className="space-y-2">
          {stores.map((store) => (
            <div key={store.id} className="flex items-center justify-between bg-secondary/40 rounded-none p-3">
              <div className="flex items-center gap-2 flex-1 min-w-0">
                {store.logo_url && <img src={store.logo_url} alt={store.name} className="w-5 h-5 rounded object-cover" />}
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-body font-medium truncate">{store.name}</p>
                  {store.website && (
                    <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(store.website); }}className="text-[10px] text-primary hover:underline truncate block">
                      {store.website}
                    </button>
                  )}
                  {store.description && <p className="text-[10px] text-muted-foreground truncate">{store.description}</p>}
                </div>
              </div>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <Link to={`/store?id=${store.id}`} className="p-1 rounded hover:bg-accent transition-colors text-muted-foreground hover:text-foreground">
                  <ExternalLink className="w-3.5 h-3.5" />
                </Link>
                <button onClick={() => openEdit(store)} className="p-1 rounded hover:bg-accent transition-colors text-muted-foreground hover:text-foreground">
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => { if (confirm("Delete this store")) deleteMutation.mutate(store.id); }}
                  className="p-1 rounded hover:bg-destructive/10 transition-colors text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={closeDialog}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading">{editingId ? "Edit" : "Add"} Store</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input placeholder="اسم المتجر Store name *" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="rounded-none h-10" />
            <Input placeholder="الموقع (اختياري) Website" value={formData.website} onChange={(e) => setFormData({ ...formData, website: e.target.value })} className="rounded-none h-10" />
            <Input placeholder="رابط الشعار (اختياري) Logo URL" value={formData.logo_url} onChange={(e) => setFormData({ ...formData, logo_url: e.target.value })} className="rounded-none h-10 text-xs" />
            <Input placeholder="الوصف (اختياري) Description" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="rounded-none h-10" />
            <Button className="w-full rounded-none h-10" onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
              {createMutation.isPending || updateMutation.isPending ? "Saving.." : editingId ? "Update Store" : "Add Store"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Bell, X, AlertCircle, Clock, TrendingDown, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export default function AlertsPanel({
  obligations = [],
  recurring = [],
  balance,
  selectedPerson,
  isAr,
  currency,
}) {
  const [dismissedAlerts, setDismissedAlerts] = useState(() => {
    try {
      const saved = localStorage.getItem("dismissedBudgetAlerts");
      const a = saved ? JSON.parse(saved) : [];
      return Array.isArray(a) ? a : [];
    } catch { return []; } // مفتاح فاسد لا يُسقط لوحة التنبيهات
  });
  const [alertsEnabled, setAlertsEnabled] = useState(() => {
    const saved = localStorage.getItem("budgetAlertsEnabled");
    return saved === null ? true : saved === "true";
  });
  const [obligationsOpen, setObligationsOpen] = useState(false);

  const qc = useQueryClient();

  const handleDismiss = (alertId) => {
    const updated = [...dismissedAlerts, alertId];
    setDismissedAlerts(updated);
    localStorage.setItem("dismissedBudgetAlerts", JSON.stringify(updated));
  };

  const toggleAlerts = () => {
    const newState = !alertsEnabled;
    setAlertsEnabled(newState);
    localStorage.setItem("budgetAlertsEnabled", newState ? "true" : "false");
  };

  const disableAllObligations = async () => {
    await Promise.all(obligations.map(o => apphost.entities.BudgetObligation.update(o.id, { status: "paused" })));
    qc.invalidateQueries({ queryKey: ["budget-obligations"] });
  };

  const enableAllObligations = async () => {
    await Promise.all(obligations.filter(o => o.status === "paused").map(o => apphost.entities.BudgetObligation.update(o.id, { status: "active" })));
    qc.invalidateQueries({ queryKey: ["budget-obligations"] });
  };

  const generateAlerts = () => {
    if (!alertsEnabled) return [];

    const alerts = [];
    const today = new Date().toISOString().slice(0, 10);
    const next7Days = new Date();
    next7Days.setDate(next7Days.getDate() + 7);
    const next7DaysStr = next7Days.toISOString().slice(0, 10);

    // Check obligations due soon
    obligations.forEach((obl) => {
      if (obl.end_date >= today && obl.end_date <= next7DaysStr) {
        const daysLeft = Math.ceil(
          (new Date(obl.end_date) - new Date(today)) / (1000 * 60 * 60 * 24)
        );
        alerts.push({
          id: `obl-${obl.id}`,
          type: "obligation_due",
          priority: daysLeft <= 2 ? "critical" : "high",
          title: isAr ? "التزام قريب الأجل" : "Upcoming Obligation",
          message: isAr
            ? `${obl.title} - متبقي ${daysLeft} أيام`
            : `${obl.title} - ${daysLeft} days left`,
          icon: AlertCircle,
          color: "text-red-500",
          bgColor: "bg-red-50 dark:bg-red-900/20",
        });
      }
    });

    // Check recurring expenses
    recurring.forEach((rec) => {
      const recDate = new Date(rec.start_date);
      const dayOfMonth = recDate.getDate();
      const today = new Date();
      const currentDay = today.getDate();
      const daysUntil =
        dayOfMonth >= currentDay
          ? dayOfMonth - currentDay
          : 30 - currentDay + dayOfMonth;

      if (daysUntil <= 5 && daysUntil >= 0) {
        alerts.push({
          id: `rec-${rec.id}`,
          type: "recurring_expense",
          priority: daysUntil <= 2 ? "high" : "medium",
          title: isAr ? "مصروف دوري قريب" : "Upcoming Recurring",
          message: isAr
            ? `${rec.title} - بعد ${daysUntil} أيام`
            : `${rec.title} - in ${daysUntil} days`,
          icon: Clock,
          color: "text-orange-500",
          bgColor: "bg-orange-50 dark:bg-orange-900/20",
        });
      }
    });

    // Low balance warning
    if (balance < 0) {
      alerts.push({
        id: "low-balance",
        type: "low_balance",
        priority: "critical",
        title: isAr ? "رصيد سلبي" : "Negative Balance",
        message: isAr
          ? `الرصيد المتبقي: ${balance.toFixed(0)} (سلبي)`
          : `Remaining balance: ${balance.toFixed(0)} (negative)`,
        icon: TrendingDown,
        color: "text-red-600",
        bgColor: "bg-red-50 dark:bg-red-900/20",
      });
    } else if (balance < 100) {
      alerts.push({
        id: "very-low-balance",
        type: "low_balance",
        priority: "high",
        title: isAr ? "رصيد منخفض جداً" : "Very Low Balance",
        message: isAr
          ? `الرصيد المتبقي: ${balance.toFixed(0)}`
          : `Remaining balance: ${balance.toFixed(0)}`,
        icon: TrendingDown,
        color: "text-orange-500",
        bgColor: "bg-orange-50 dark:bg-orange-900/20",
      });
    }

    return alerts.filter((alert) => !dismissedAlerts.includes(alert.id));
  };

  const alerts = generateAlerts();

  if (!alertsEnabled) {
    return (
      <button
        onClick={toggleAlerts}
        className="w-full flex items-center justify-center gap-2 hover:bg-secondary/40 rounded-none p-3 text-xs font-body transition-colors"
      >
        <Bell className="w-4 h-4 text-muted-foreground" />
        {isAr ? "تفعيل التنبيهات" : "Enable Alerts"}
      </button>
    );
  }

  if (alerts.length === 0) {
    return (
      <div className="py-2 flex items-center gap-2">
        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
        <p className="text-xs font-body text-emerald-700 dark:text-emerald-300">
          {isAr ? "كل شيء على ما يرام" : "Everything looks good"}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-primary" />
          <p className="text-xs font-body font-semibold">
            {isAr ? "التنبيهات" : "Alerts"} ({alerts.length})
          </p>
        </div>
        <button
          onClick={toggleAlerts}
          className="text-[10px] font-body text-muted-foreground hover:text-foreground transition-colors"
        >
          {isAr ? "تعطيل الكل" : "Disable All"}
        </button>
      </div>

      {alerts.map((alert) => {
        const Icon = alert.icon;
        return (
          <div
            key={alert.id}
            className={cn(
              "rounded-none p-3 flex items-start gap-3 border-b border-border/30",
              alert.priority === "critical" && "border-l-2 border-l-red-400",
              alert.priority === "high" && "border-l-2 border-l-orange-400"
            )}
          >
            <Icon className={cn("w-4 h-4 flex-shrink-0 mt-0.5", alert.color)} />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-body font-semibold text-foreground">
                {alert.title}
              </p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                {alert.message}
              </p>
            </div>
            <button
              onClick={() => handleDismiss(alert.id)}
              className="text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}

      {/* Active Obligations */}
      {obligations.length > 0 && (
        <div className="overflow-hidden">
          <button
            onClick={() => setObligationsOpen(!obligationsOpen)}
            className="w-full flex items-center justify-between px-1 py-3 hover:bg-secondary/40 transition-colors border-b border-border/30"
          >
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-orange-600" />
              <p className="text-xs font-body font-semibold text-orange-700 dark:text-orange-300">
                {isAr ? "الالتزامات النشطة" : "Active Obligations"}
              </p>
              <span className="text-[10px] text-orange-700 dark:text-orange-300 rounded-none font-bold">{obligations.length}</span>
            </div>
            <span className="text-orange-500 text-xs">{obligationsOpen ? "▲" : "▼"}</span>
          </button>
          {obligationsOpen && (
            <div className="px-4 pb-3 space-y-2">
              <div className="flex gap-2">
                <button
                  onClick={disableAllObligations}
                  className="flex-1 py-2 rounded-none text-xs font-body font-semibold bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-800 hover:bg-red-200 transition-colors"
                >
                  ⚠️ {isAr ? "تعطيل الكل" : "Disable All"}
                </button>
                <button
                  onClick={enableAllObligations}
                  className="flex-1 py-2 rounded-none text-xs font-body font-semibold bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-200 transition-colors"
                >
                  {isAr ? "تفعيل الكل" : "Enable All"}
                </button>
              </div>
              {obligations.map((o) => {
                const remaining = o.total_amount - (o.paid_amount || 0);
                const progress = Math.min(100, ((o.paid_amount || 0) / o.total_amount) * 100);
                return (
                  <div key={o.id} className="py-2 border-b border-border/30 last:border-b-0 space-y-1.5">
                    <div className="flex justify-between items-start">
                      <p className="text-xs font-body font-semibold">{o.title}</p>
                      <p className="text-xs font-bold text-orange-600">{o.monthly_payment.toFixed(0)} {currency}/mo</p>
                    </div>
                    <div className="w-full h-1.5 bg-orange-100 dark:bg-orange-900/50 rounded-none overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-orange-400 to-red-500" style={{ width: `${progress}%` }} />
                    </div>
                    <div className="flex justify-between text-[10px] text-muted-foreground">
                      <span>Remaining: <b className="text-red-600">{remaining.toFixed(0)} {currency}</b></span>
                      <span>Until: {o.end_date}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

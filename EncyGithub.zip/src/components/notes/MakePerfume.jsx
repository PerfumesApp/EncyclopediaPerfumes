import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { usePersonNames } from "@/lib/usePersonNames";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Trash2, BookOpen, Beaker } from "lucide-react";

const NOTE_CATEGORIES = {
  main_note: { label: "Main Notes", emoji: "🌟", color: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/50" },
  sub_notes: { label: "Sub Notes", emoji: "✨", color: "bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/50" },
  other_notes: { label: "Other Notes", emoji: "🌸", color: "bg-sky-50 dark:bg-sky-950/30 border-sky-200 dark:border-sky-900/50" },
};

export default function MakePerfume() {
  const { names } = usePersonNames();
  const queryClient = useQueryClient();
  const [instructions, setInstructions] = useState("");
  const [draggedNote, setDraggedNote] = useState(null);
  const [showNewDialog, setShowNewDialog] = useState(false);

  // Form state
  const [form, setForm] = useState({
    name: "",
    person: "person1",
    version: "Beta 1",
    type: "Eau de Parfum",
    gender: "Unisex",
    season: "All Seasons",
    description: "",
    main_note_ids: [],
    sub_note_ids: [],
    other_note_ids: [],
  });

  const [layers, setLayers] = useState({ main_note: [], sub_notes: [], other_notes: [] });

  const { data: notes = [] } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  const { data: customPerfumes = [] } = useQuery({
    queryKey: ["custom-perfumes"],
    queryFn: () => apphost.entities.CustomPerfume.list("-created_date"),
  });

  // (Removed the on-mount InvokeLLM "how-to" fetch: it is a no-op in offline
  //  mode and added needless work to every page open.)

  // Group notes
  const notesByCategory = useMemo(() => {
    const grouped = { main_note: [], sub_notes: [], other_notes: [] };
    notes.forEach((note) => {
      const cat = note.note_category || "main_note";
      if (grouped[cat]) grouped[cat].push(note);
    });
    return grouped;
  }, [notes]);

  // Create perfume
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!form.name.trim()) {
        toast.error("أدخل اسم العطر");
        return;
      }
      const perfumeData = {
        name: form.name,
        person: form.person,
        version: form.version,
        type: form.type,
        gender: form.gender,
        season: form.season,
        description: form.description,
        main_note_ids: layers.main_note.map(n => n.id).join(","),
        main_note_names: layers.main_note.map(n => n.name).join(", "),
        sub_note_ids: layers.sub_notes.map(n => n.id).join(","),
        sub_note_names: layers.sub_notes.map(n => n.name).join(", "),
        other_note_ids: layers.other_notes.map(n => n.id).join(","),
        other_note_names: layers.other_notes.map(n => n.name).join(", "),
        samples_created: 0,
        status: "draft",
      };
      await apphost.entities.CustomPerfume.create(perfumeData);
    },
    onSuccess: () => {
      toast.success("أُنشئ العطر");
      setForm({ name: "", person: "person1", version: "Beta 1", type: "Eau de Parfum", gender: "Unisex", season: "All Seasons", description: "" });
      setLayers({ main_note: [], sub_notes: [], other_notes: [] });
      setShowNewDialog(false);
      queryClient.invalidateQueries({ queryKey: ["custom-perfumes"] });
    },
  });

  const handleDragStart = (note, category) => {
    setDraggedNote({ note, fromCategory: category });
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (toCategory) => {
    if (!draggedNote) return;
    const { note, fromCategory } = draggedNote;

    if (fromCategory === toCategory) {
      setDraggedNote(null);
      return;
    }

    if (fromCategory) {
      setLayers({
        ...layers,
        [fromCategory]: layers[fromCategory].filter(n => n.id !== note.id),
      });
    }

    setLayers({
      ...layers,
      [toCategory]: [...layers[toCategory], note],
    });

    setDraggedNote(null);
  };

  const handleRemoveNote = (category, noteId) => {
    setLayers({
      ...layers,
      [category]: layers[category].filter(n => n.id !== noteId),
    });
  };

  const totalNotes = layers.main_note.length + layers.sub_notes.length + layers.other_notes.length;
  const userPerfumes = customPerfumes.filter(p => p.person === form.person);

  return (
    <div className="space-y-4">
      {/* How-to Section */}
      {instructions && (
        <div className="bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950/30 dark:to-blue-950/30 border border-purple-200 dark:border-purple-900/50 rounded-none p-4 space-y-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            <p className="font-body font-semibold text-sm">كيف تصنع عطراً How to Make Perfume</p>
          </div>
          <p className="text-sm font-body text-foreground/80 leading-relaxed whitespace-pre-wrap">{instructions}</p>
        </div>
      )}

      {/* Your Perfumes */}
      {userPerfumes.length > 0 && (
        <div className="bg-card rounded-none p-4 space-y-3 border border-border/50">
          <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider">عطورك Your Perfumes</p>
          <div className="space-y-2 max-h-[200px] overflow-y-auto">
            {userPerfumes.map((perf) => (
              <div key={perf.id} className="flex items-center justify-between bg-secondary/40 rounded-none p-3">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-body font-semibold truncate">{perf.name}</p>
                  <p className="text-[10px] text-muted-foreground font-body">{perf.version} — {perf.status} — {perf.samples_created} samples</p>
                </div>
                <span className="text-xs font-body font-medium rounded-none text-primary">{perf.type}</span>
              </div>
            ))}
          </div>
          <Dialog open={showNewDialog} onOpenChange={setShowNewDialog}>
            <DialogTrigger asChild>
              <Button size="sm" className="w-full rounded-none font-body gap-1.5">
                New Perfume
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-sm rounded-none max-h-[85vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="font-heading">إنشاء عطر جديد Create New Perfume</DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-body font-semibold">اسم العطر Perfume Name</label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Rose Garden" className="rounded-none font-body" />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1.5">
                    <label className="text-xs font-body font-semibold">المنشئ Creator</label>
                    <select name="MakePerfume-sel1" value={form.person} onChange={(e) => setForm({ ...form, person: e.target.value })} className="w-full h-9 px-2 rounded-none border border-input bg-transparent text-xs font-body">
                      <option value="person1">{names.person1}</option>
                      <option value="person2">{names.person2}</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-body font-semibold">الإصدار Version</label>
                    <Input value={form.version} onChange={(e) => setForm({ ...form, version: e.target.value })} placeholder="Beta 1" className="rounded-none font-body text-xs" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1.5">
                    <label className="text-xs font-body font-semibold">النوع Type</label>
                    <select name="MakePerfume-sel2" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="w-full h-9 px-2 rounded-none border border-input bg-transparent text-xs font-body">
                      {["Eau de Parfum", "Eau de Toilette", "Eau de Cologne", "Parfum", "Body Mist", "Other"].map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-body font-semibold">الفئة Gender</label>
                    <select name="MakePerfume-sel3" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })} className="w-full h-9 px-2 rounded-none border border-input bg-transparent text-xs font-body">
                      {["Men", "Women", "Unisex"].map(g => <option key={g} value={g}>{g}</option>)}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1.5">
                    <label className="text-xs font-body font-semibold">الموسم Season</label>
                    <select name="MakePerfume-sel4" value={form.season} onChange={(e) => setForm({ ...form, season: e.target.value })} className="w-full h-9 px-2 rounded-none border border-input bg-transparent text-xs font-body">
                      {["Spring", "Summer", "Fall", "Winter", "All Seasons"].map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-body font-semibold">Inspiration / Notes</label>
                  <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="صف عطرك... Describe your perfume.." className="rounded-none font-body min-h-[60px] text-xs resize-none" />
                </div>

                <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending || !form.name.trim()} className="w-full rounded-none font-body">
                  Create Perfume
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      )}

      {/* Available Notes Palette */}
      <div className="bg-card rounded-none p-4 space-y-3 border border-border/50">
        <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider">النوتات المتاحة Available Notes</p>
        <div className="space-y-3">
          {Object.entries(notesByCategory).map(([category, categoryNotes]) => (
            <div key={category} className="space-y-2">
              <p className="text-xs font-body font-medium text-foreground/70">{NOTE_CATEGORIES[category].label}</p>
              <div className="flex flex-wrap gap-2">
                {categoryNotes.slice(0, 12).map((note) => (
                  <button
                    key={note.id}
                    draggable
                    onDragStart={() => handleDragStart(note, null)}
                    className=" rounded-none text-xs font-body font-medium cursor-grab active:cursor-grabbing transition-colors"
                  >
                    {note.name}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Drop Zones */}
      <div className="space-y-3">
        {Object.entries(NOTE_CATEGORIES).map(([category, { label, emoji, color }]) => (
          <div
            key={category}
            onDragOver={handleDragOver}
            onDrop={() => handleDrop(category)}
            className={`border-2 border-dashed rounded-none p-4 min-h-[100px] transition-colors ${color} flex flex-col`}
          >
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{emoji}</span>
              <p className="text-sm font-body font-semibold">{label}</p>
              <span className="text-xs text-muted-foreground font-body">({layers[category].length})</span>
            </div>
            <div className="flex flex-wrap gap-2 flex-1">
              {layers[category].length === 0 ? (
                <p className="text-xs text-muted-foreground font-body flex items-center h-full">اسحب النوتات هنا Drag notes here...</p>
              ) : (
                layers[category].map((note) => (
                  <div
                    key={note.id}
                    draggable
                    onDragStart={() => handleDragStart(note, category)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-none bg-white/60 dark:bg-black/20 border border-current/30 group cursor-grab active:cursor-grabbing hover:shadow-md transition-all"
                  >
                    <span className="text-xs font-body font-medium text-foreground">{note.name}</span>
                    <button onClick={() => handleRemoveNote(category, note.id)} className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <Trash2 className="w-3 h-3 text-destructive hover:text-destructive/80" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Save button */}
      {totalNotes > 0 && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 space-y-3 sticky bottom-0">
          <p className="text-sm font-body font-semibold flex items-center gap-1.5">
            <Beaker className="w-4 h-4" /> Create Sample
          </p>
          <Button onClick={() => toast.success("سُجّلت العيّنة في عملك")} className="w-full rounded-none font-body gap-2">
            <Beaker className="w-4 h-4" /> Save as Sample ({totalNotes} notes)
          </Button>
        </div>
      )}
    </div>
  );
}
import { useState } from "react";

/**
 * BrandLogo — عرض البراند بلا إطار/مربّع/خلفية.
 *  - الاسم يظهر دائماً كوردمارك: العربي صغير وردي (Amiri) فوق، الإنجليزي ذهبي كابتل (Cinzel) تحت.
 *  - إن وُجد شعار → يطفو فوق الاسم، شفّاف، مُقيَّد الحجم (logoMaxH).
 *  - صفّ الاسم العربي = التاج (يسار، عند best_of_decade) | الاسم العربي (وسط) | عدد العطور (يمين).
 *  - الاسم الإنجليزي الطويل يُقلَّم (ellipsis) ليلائم العرض.
 */
export function Crown({ size = 15 }) {
  return (
    <svg viewBox="0 0 40 16" width={size} height={size * 0.42} aria-hidden="true" style={{ transform: "rotate(-22deg)" }}>
      <path d="M8 13 l2-7 4 4 6-7 6 7 4-4 2 7z" fill="var(--brand)" stroke="#9a7b1f" strokeWidth="0.4" />
    </svg>
  );
}

export default function BrandLogo({
  brand = {},
  crossOrigin,
  bestOfDecade = false,
  count = 0,
  enSize = 13,
  arSize = 11,
  logoMaxH = 34,
  crownSize = 15,
}) {
  const src = brand.logo_url || brand.processappdatabase_logo || "";
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const en = brand.name || "";
  const ar = brand.name_ar || "";
  const showLogo = src && !failed;
  if (!en && !ar && !showLogo) return null;

  return (
    <div className="w-full text-center" dir="ltr" style={{ lineHeight: 1, minWidth: 0 }}>
      {showLogo && (
        <img
          src={src}
          alt={en || "brand"}
          loading="lazy"
          referrerPolicy="no-referrer"
          crossOrigin={crossOrigin}
          onLoad={() => setLoaded(true)}
          onError={() => setFailed(true)}
          className="object-contain mx-auto"
          // لا تُعرض إلّا بعد نجاح التحميل — يمنع وميض الصورة المكسورة (أوفلاين/مفقودة) style={{ maxHeight: logoMaxH, maxWidth: "100%", marginBottom: loaded ? 4 : 0, height: loaded ? undefined : 0, opacity: loaded ? 1 : 0 }}
        />
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "center", columnGap: 4 }} dir="ltr">
        <span style={{ justifySelf: "start", display: "inline-flex", alignItems: "center" }}>{bestOfDecade ? <Crown size={crownSize} /> : null}</span>
        {ar ? (
          <span style={{ fontFamily: "'Amiri', serif", fontSize: arSize, color: "#9D174D", lineHeight: 1, whiteSpace: "nowrap" }}>{ar}</span>
        ) : (
          <span />
        )}
        <span style={{ justifySelf: "end", fontSize: 9, fontWeight: 700, color: "#9a7b1f" }}>{count > 0 ? count : ""}</span>
      </div>
      {en ? (
        <div
          style={{
            fontFamily: "'Cinzel', serif",
            fontWeight: 600,
            letterSpacing: "1px",
            color: "var(--brand)",
            textTransform: "uppercase",
            fontSize: enSize,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            maxWidth: "100%",
            marginTop: 2,
          }}
        >
          {en}
        </div>
      ) : null}
    </div>
  );
}

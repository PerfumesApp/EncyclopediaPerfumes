import { hilalBorder } from "@/lib/hilalArt";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";

import { fetchByEnglishNames, fetchByIds } from "@/lib/indexedLookup";

export default function BrandPerfumersSection({ brand }) {
  const navigate = useNavigate();

  const linkedIds = useMemo(
    () => (Array.isArray(brand.perfumer_ids) ? brand.perfumer_ids.join(",") : String(brand.perfumer_ids || "")).split(",").map(s => s.trim()).filter(Boolean),
    [brand.perfumer_ids]
  );
  const linkedNames = useMemo(
    () => (Array.isArray(brand.perfumer_names) ? brand.perfumer_names.join(",") : String(brand.perfumer_names || "")).split(",").map(s => s.trim()).filter(Boolean),
    [brand.perfumer_names]
  );

  // جلب مفهرس: المعرّفات عبر getMany و الأسماء عبر فهرس name (الاسم الإنجليزي
  // المعتمد) — بدل تحميل كل العطّارين. الاسم بلا سجل يبقى رقاقة اسم فقط كما كان.
  const { data: fetched = { byId: [], byName: [] } } = useQuery({
    queryKey: ["brand-perfumers-linked", linkedIds.join("|"), linkedNames.join("|")],
    queryFn: async () => {
      const [byId, byName] = await Promise.all([
        fetchByIds("Perfumer", linkedIds),
        fetchByEnglishNames("Perfumer", linkedNames),
      ]);
      return { byId, byName };
    },
    enabled: linkedIds.length > 0 || linkedNames.length > 0,
    staleTime: 1000 * 60 * 5,
  });

  // Unified list: manually-linked IDs + auto-linked names (from brand.perfumer_names).
  const unifiedPerfumers = useMemo(() => {
    const seen = new Set();
    const out = [];
    // 1) manually linked by id
    const byIdMap = {};
    fetched.byId.forEach((p) => { byIdMap[String(p.id)] = p; });
    linkedIds.forEach((pid) => {
      const p = byIdMap[String(pid)];
      if (p && !seen.has(p.id)) { seen.add(p.id); out.push(p); }
    });
    // 2) auto-linked by name (imported perfumer_names) — match to DB record if found,
    //    otherwise show as a name-only chip
    const byNameMap = {};
    fetched.byName.forEach((p) => { if (p.name) byNameMap[String(p.name).trim().toLowerCase()] = p; });
    linkedNames.forEach((name) => {
      const rec = byNameMap[name.toLowerCase()];
      if (rec) {
        if (!seen.has(rec.id)) { seen.add(rec.id); out.push(rec); }
      } else {
        const key = "name:" + name.toLowerCase();
        if (!seen.has(key)) { seen.add(key); out.push({ id: key, name, name_ar: "", _nameOnly: true }); }
      }
    });
    return out;
  }, [linkedIds, linkedNames, fetched]);

  return (
    <div className="rounded-none p-5 shadow-sm space-y-4" style={{ background: "var(--page-bg, hsl(var(--background)))" }}>
      <div>
        <h2 className="font-heading font-semibold text-sm">عطّارون مرتبطون بهذه الدار</h2>
      </div>

      {unifiedPerfumers.length > 0 && (
        <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
          {unifiedPerfumers.map(p => {
            const isFemale = p.gender === "Female";
            return (
              <button
                key={p.id}
                onClick={() => !p._nameOnly && navigate(`/perfumer?id=${p.id}`)}
                className="flex flex-col items-center gap-1.5 hover:opacity-80 transition-opacity"
              >
                {/* smaller photo — square with gold frame */}
                <div className="w-12 h-12 rounded-none overflow-hidden flex items-center justify-center shadow-sm flex-shrink-0" style={{ background: "var(--page-bg, #fff)", border: hilalBorder(p.name, p.name_ar, "1.5px solid #d4af37") }}>
                  {p.photo_url ? (
                    <img src={p.photo_url} alt={p.name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                  ) : (
                    <div className="w-full h-full" style={{ background: "var(--page-bg, #fff)" }} />
                  )}
                </div>
                {/* bigger name */}
                <div className="text-center space-y-0.5">
                  <p className={`text-[12px] font-body font-bold leading-tight line-clamp-2 ${isFemale ? "text-pink-500" : "text-blue-700 dark:text-blue-400"}`}>{p.name}</p>
                  {p.name_ar && <p className={`text-[10px] font-body leading-tight ${isFemale ? "text-pink-400" : "text-blue-600 dark:text-blue-500"}`} dir="rtl">{p.name_ar}</p>}
                </div>
              </button>
            );
          })}
        </div>
      )}

    </div>
  );
}

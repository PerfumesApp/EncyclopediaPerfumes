import { Component } from "react";

/**
 * حدّ خطأ يعزل انهيار أي صفحة. بدونه، أي خطأ تشغيلي في صفحة يتصاعد إلى جذر
 * React فيُفكّك كامل التطبيق (بما فيه الشريط السفلي) — وهذا سبب "ظهور الشريط
 * ثم اختفائه". بوضع هذا الحدّ حول محتوى الصفحة فقط، يبقى الهيكل والتنقّل حيّاً
 * ويُعرض بديل لطيف مكان الصفحة المتعطّلة.
 */
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error("Page error caught by ErrorBoundary:", error, info);
  }

  // عند تغيّر المسار نُعيد المحاولة تلقائياً (المفتاح يأتي من الأب).
  componentDidUpdate(prevProps) {
    if (prevProps.resetKey !== this.props.resetKey && this.state.hasError) {
      this.setState({ hasError: false, error: null });
    }
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    const isAr = this.props.isAr;
    return (
      <div className="px-6 pt-16 pb-24 text-center">
        <div className="text-4xl mb-3">🌫️</div>
        <h2 className="font-heading text-lg font-bold mb-2">
          {isAr ? "تعذّر عرض هذه الصفحة" : "This page couldn't load"}
        </h2>
        <p className="text-sm text-muted-foreground font-body mb-5">
          {isAr
            ? "حدث خطأ غير متوقّع. بقيّة التطبيق تعمل — جرّب صفحة أخرى من الشريط، أو أعد المحاولة."
            : "Something went wrong. The rest of the app still works — try another tab below, or retry."}
        </p>
        <div className="flex flex-col items-center gap-3">
          <button
            onClick={() => { window.location.href = (import.meta.env.BASE_URL || "/"); }}
            className="bg-primary text-primary-foreground rounded-none px-6 py-2.5 text-sm font-body font-semibold min-w-[200px]"
          >
            {isAr ? "الذهاب لرئيسية التطبيق" : "Go to app home"}
          </button>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => this.setState({ hasError: false, error: null })}
              className="bg-secondary text-foreground rounded-none px-5 py-2.5 text-sm font-body font-medium"
            >
              {isAr ? "إعادة المحاولة" : "Retry"}
            </button>
            <button
              onClick={() => window.location.reload()}
              className="bg-secondary text-foreground rounded-none px-5 py-2.5 text-sm font-body font-medium"
            >
              {isAr ? "إعادة التحميل" : "Reload"}
            </button>
          </div>
        </div>
        {this.state.error?.message && (
          <p className="mt-5 text-[10px] text-muted-foreground/70 font-mono break-all">
            {String(this.state.error.message).slice(0, 200)}
          </p>
        )}
      </div>
    );
  }
}

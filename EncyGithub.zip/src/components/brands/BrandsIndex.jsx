import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { compareEnglish } from "@/lib/sortName";
import { downloadBlob } from "@/lib/exportHelper";
import { FileText, FileDown, Loader2 } from "lucide-react";

const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").concat("#");

// قَصّ بنقطتين فقط (..) لا بثلاث — يطابق سياسة فهرس العطور.
function trimText(s, max) {
  const str = String(s || "");
  if (str.length <= max) return str;
  return str.slice(0, max).replace(/\s+$/, "") + "..";
}

export default function BrandsIndex({ brands = [], isAr = false }) {
  const [busy, setBusy] = useState(null);          // "pdf" | "txt" | null
  const [letter, setLetter] = useState("all");
  const [lettersOpen, setLettersOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);     // الفهرس لا يُحمَّل حتى يضغط «All»

  // فرز موحّد عبر compareEnglish (لاتيني → أرقام → لغات أخرى → عربي → رموز).
  const sortedBrands = useMemo(
    () => [...brands].filter((b) => !b.hidden).sort((a, b) => compareEnglish(a, b, 1)),
    [brands]
  );

  // تجميع بالحرف الأول للتصفية.
  const { grouped, letters } = useMemo(() => {
    const map = {};
    for (const brand of sortedBrands) {
      const first = (brand.name || "")[0]?.toUpperCase() || "#";
      const key = /^[A-Z]$/.test(first) ? first : "#";
      (map[key] ||= []).push(brand);
    }
    const ls = Object.keys(map).sort((a, b) => {
      if (a === "#") return 1;
      if (b === "#") return -1;
      return a.localeCompare(b);
    });
    return { grouped: map, letters: ls };
  }, [sortedBrands]);

  // البراندات المعروضة بحسب اختيار الحرف.
  const displayed = useMemo(() => {
    if (letter === "all") return sortedBrands;
    return grouped[letter] || [];
  }, [letter, sortedBrands, grouped]);

  // ضغط «All» يفتح الشريط ويختار الكل. ضغط حرف يختاره ويطوي الشريط.
  // ضغط الحرف النشط بينما الشريط مطوي يعيد فتحه دون تغيير الفلتر.
  const onPickLetter = (l) => {
    if (l === "all") {
      setLoaded(true);            // أوّل ضغط على All يحمّل الفهرس
      setLetter("all");
      setLettersOpen(true);
      return;
    }
    if (!lettersOpen && l === letter) {
      setLettersOpen(true);
      return;
    }
    setLetter(l);
    setLettersOpen(false);
  };

  // ── تصدير TXT ──
  const exportTxt = async () => {
    if (busy) return;
    setBusy("txt");
    try {
      const lines = [isAr ? "فهرس البراندات" : "Brands Index", `${sortedBrands.length} ${isAr ? "براند" : "brands"}`, ""];
      for (const l of letters) {
        lines.push(`── ${l} ──`);
        for (const b of grouped[l]) if (b.name) lines.push(b.name);
        lines.push("");
      }
      const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/plain;charset=utf-8" });
      await downloadBlob(blob, "brands-index.txt");
    } catch (e) {
      console.error("brands txt export failed", e);
    } finally {
      setBusy(null);
    }
  };

  // ── تصدير PDF (نص متعدد الصفحات، عمودان) ──
  const exportPdf = async () => {
    if (busy) return;
    setBusy("pdf");
    try {
      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const margin = 14, colGap = 8, lineH = 5;
      const colW = (pageW - margin * 2 - colGap) / 2;
      const colX = [margin, margin + colW + colGap];
      const top = margin + 9, bottom = pageH - margin;
      const maxChars = 46;
      let col = 0, y = top;

      pdf.setFont("helvetica", "bold"); pdf.setFontSize(15);
      pdf.text("Brands Index", margin, margin + 2);
      pdf.setFont("helvetica", "normal"); pdf.setFontSize(9); pdf.setTextColor(120);
      pdf.text(`${sortedBrands.length} brands`, margin, margin + 6);
      pdf.setTextColor(20);

      const nextColOrPage = () => {
        if (col === 0) { col = 1; y = top; }
        else { pdf.addPage(); col = 0; y = top; }
      };
      const ensure = (need) => { if (y + need > bottom) nextColOrPage(); };

      for (const l of letters) {
        ensure(lineH * 2);
        pdf.setFont("helvetica", "bold"); pdf.setFontSize(11); pdf.setTextColor(176, 137, 0);
        pdf.text(l, colX[col], y); pdf.setTextColor(20);
        y += lineH + 1;
        pdf.setFont("helvetica", "normal"); pdf.setFontSize(9);
        for (const b of grouped[l]) {
          if (!b.name) continue;
          ensure(lineH);
          let name = b.name;
          if (name.length > maxChars) name = name.slice(0, maxChars - 1) + "..";
          pdf.text(name, colX[col], y);
          y += lineH;
        }
        y += 2;
      }

      const blob = pdf.output("blob");
      await downloadBlob(blob, "brands-index.pdf");
    } catch (e) {
      console.error("brands pdf export failed", e);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div dir="ltr">
      {/* شريط التصدير */}
      <div className="flex items-center gap-2 mb-3">
        <button
          onClick={exportPdf}
          disabled={busy !== null}
          className="inline-flex items-center gap-1.5 rounded-none text-xs font-body font-medium text-foreground disabled:opacity-60 transition-colors"
        >
          {busy === "pdf" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileDown className="w-3.5 h-3.5" />} PDF
        </button>
        <button
          onClick={exportTxt}
          disabled={busy !== null}
          className="inline-flex items-center gap-1.5 rounded-none text-xs font-body font-medium text-foreground disabled:opacity-60 transition-colors"
        >
          {busy === "txt" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileText className="w-3.5 h-3.5" />} TXT
        </button>
      </div>

      {/* شريط الحروف: «All» وحده ظاهر حتى يُضغط فيحمّل الفهرس و يُظهر الحروف.
          بلا إطارات و لا خلفيات؛ خطّ مذهب يحترم لون المستخدم. */}
      <div className="flex flex-wrap gap-x-3 gap-y-1.5 mb-4">
        <button
          onClick={() => onPickLetter("all")}
          className="h-7 px-1 rounded-none text-xs font-body font-bold transition-opacity hover:opacity-70"
          style={{ color: (loaded && letter === "all") ? "var(--brand)" : "#9a7b1f" }}
        >
          {isAr ? "الكل" : "All"}
        </button>
        {loaded && lettersOpen ? (
          LETTERS.map((l) => {
            const active = l === letter;
            const exists = grouped[l] && grouped[l].length > 0;
            return (
              <button
                key={l}
                onClick={() => exists && onPickLetter(l)}
                disabled={!exists}
                className="h-7 px-0.5 rounded-none text-xs font-body font-bold transition-opacity hover:opacity-70 disabled:opacity-30"
                style={{ color: active ? "var(--brand)" : "#9a7b1f" }}
              >
                {l}
              </button>
            );
          })
        ) : (
          loaded && letter !== "all" && (
            <button
              key={letter}
              onClick={() => onPickLetter(letter)}
              className="h-7 px-0.5 rounded-none text-xs font-body font-bold transition-opacity hover:opacity-70"
              style={{ color: "var(--brand)" }}
            >
              {letter}
            </button>
          )
        )}
      </div>

      {/* قائمة البراندات — لا تظهر حتى يُحمَّل الفهرس بضغط All */}
      {loaded && (
      <div className="divide-y divide-border/40 pb-4">
        {displayed.map((brand) => (
          <Link
            key={brand.id}
            to={`/brand?id=${brand.id}`}
            className="flex items-center justify-start text-left px-2 py-2.5 -mx-2 rounded-none hover:bg-secondary/60 transition-colors group"
          >
            <span className="text-sm font-body font-medium text-foreground group-hover:text-[var(--brand)] transition-colors whitespace-nowrap overflow-hidden">
              {trimText(brand.name, 28)}
            </span>
          </Link>
        ))}
      </div>
      )}
    </div>
  );
}

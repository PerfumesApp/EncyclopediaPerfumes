// جسم القصيدة — تُعرض الأبيات مباشرة بلا تبويبات و لا رؤوس لغة و لا خط فاصل.
// الأبيات تأتي من نصّ المدخل (texts) — كل بيت على سطر «صدر .. عجز». البروفيل و الشرح
// انتقلا الى قائمة «Info» المطوية أسفل المدخل (في صفحة المدخل).

function splitVerses(text) {
  return String(text || "")
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function Verses({ list, dir }) {
  if (!list.length) return null;
  return (
    <div className="space-y-1.5" dir={dir}>
      {list.map((v, i) => (
        <p key={i} className="font-body text-center" style={{ fontSize: 16, lineHeight: 2 }}>{v}</p>
      ))}
    </div>
  );
}

// mode: "ar" | "en" | "both" — لغة عرض الموسوعة المختارة
export function PoemBody({ arText, enText, mode = "both" }) {
  const showAr = mode !== "en";
  const showEn = mode !== "ar";
  const ar = splitVerses(arText);
  const en = splitVerses(enText);
  return (
    <div className="space-y-6">
      {showAr && ar.length > 0 && <Verses list={ar} dir="rtl" />}
      {showEn && en.length > 0 && <Verses list={en} dir="ltr" />}
    </div>
  );
}

export default PoemBody;

import { useState } from "react";
import { AArrowUp, AArrowDown, FileCog } from "lucide-react";
import { ENC_ACCENTS } from "@/lib/encAccents";
import AccentHearts from "@/components/encyclopedia/AccentHearts";

// شريط خيارات أسفل الموسوعة — قائمة مطوية بأيقونة (بلا خلفية/إطار): ترتيب العناوين
// (AR EN / EN AR / حسب اللغة) + عناوين الفرعيّات + الفرز. الحالة محفوظة في الأب (localStorage).
export default function EncOptionsBar({ isAr, titleOrder, setTitleOrder, subTitleOrder, setSubTitleOrder, sortMode, setSortMode, showSort = true, showSubTitle = false, showTitleOrder = true, showLang = true, alwaysOpen = false, isLibrary = false, libType = null, setLibType }) {
  const [open, setOpen] = useState(false);
  const [lang, setLangRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_read_lang")) || "both");
  const setLang = (v) => {
    setLangRaw(v);
    try { localStorage.setItem("enc_read_lang", v); } catch { /* تجاهل */ }
    try { window.dispatchEvent(new Event("enc-lang-change")); } catch { /* تجاهل */ }
  };
  const [accent, setAccentRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_accent_color")) || "");
  const setAccent = (c) => {
    setAccentRaw(c);
    try { localStorage.setItem("enc_accent_color", c); } catch { /* تجاهل */ }
    try { window.dispatchEvent(new Event("enc-accent-change")); } catch { /* تجاهل */ }
  };
  const ACCENTS = ENC_ACCENTS;
  const [fs, setFsRaw] = useState(() => parseInt((typeof localStorage !== "undefined" && localStorage.getItem("enc_font_scale")) || "0", 10) || 0);
  const setFs = (i) => {
    setFsRaw(i);
    try { localStorage.setItem("enc_font_scale", String(i)); } catch { /* تجاهل */ }
    try { window.dispatchEvent(new Event("enc-fs-change")); } catch { /* تجاهل */ }
  };
  const FS_PX = [11, 13, 15, 17, 19]; // أحجام عرض الأيقونة A — الأصغر أولاً
  const brand = { color: "var(--brand)" };
  const pill = (active) => ({ color: "var(--brand)", fontWeight: active ? 700 : 400, opacity: active ? 1 : 0.5 });
  return (
    <div className="pt-3 mt-2 border-t border-border/40">
      {!alwaysOpen && (
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-label={isAr ? "خيارات العرض" : "Display Options"}
        aria-expanded={open}
        className="hover:opacity-70 transition-opacity"
        style={{ color: "var(--brand)", opacity: open ? 1 : 0.6 }}
      >
        <FileCog className="w-4 h-4" />
      </button>
      )}
      {(alwaysOpen || open) && (
        <div className="space-y-2 pt-2">
          {showLang && (
            <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
              <span className="text-[10px] font-body" style={{ ...brand, opacity: 0.7 }}>{isAr ? "لغة الموسوعة" : "Encyclopedia language"}</span>
              <button type="button" onClick={() => setLang("en")} className="font-body text-xs hover:opacity-70" style={pill(lang === "en")}>English</button>
              <button type="button" onClick={() => setLang("ar")} className="font-body text-xs hover:opacity-70" style={pill(lang === "ar")}>عربية</button>
              <button type="button" onClick={() => setLang("both")} className="font-body text-xs hover:opacity-70" style={pill(lang === "both")}>{isAr ? "مدمج" : "Both"}</button>
            </div>
          )}
          {showTitleOrder && (
          <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
            <span className="text-[10px] font-body" style={{ ...brand, opacity: 0.7 }}>{isAr ? "ترتيب العناوين" : "Title Order"}</span>
            <button type="button" onClick={() => setTitleOrder("ar_en")} className="font-body text-xs hover:opacity-70" style={pill(titleOrder === "ar_en")}>AR EN</button>
            <button type="button" onClick={() => setTitleOrder("en_ar")} className="font-body text-xs hover:opacity-70" style={pill(titleOrder === "en_ar")}>EN AR</button>
            <button type="button" onClick={() => setTitleOrder("lang")} className="font-body text-xs hover:opacity-70" style={pill(titleOrder === "lang")}>{isAr ? "حسب اللغة" : "By Language"}</button>
          </div>
          )}
          {/* لون الأقسام و العناوين — خمسة، الأول الحالي افتراضيّ */}
          <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
            <span className="text-[10px] font-body" style={{ ...brand, opacity: 0.7 }}>{isAr ? "لون الأقسام و العناوين" : "Sections & Titles Color"}</span>
            <AccentHearts value={accent} onPick={setAccent} colors={ACCENTS} size={17} />
          </div>
          {/* حجم خط المدخلات — A A A A A، الأصغر أولاً */}
          <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
            <span className="text-[10px] font-body" style={{ ...brand, opacity: 0.7 }}>{isAr ? "حجم الخط" : "Font size"}</span>
            {FS_PX.map((px, i) => (
              <button key={i} type="button" onClick={() => setFs(i)} aria-label={`A${i + 1}`}
                className="font-body leading-none hover:opacity-80 transition-opacity"
                style={{ color: "var(--brand)", fontSize: px, fontWeight: fs === i ? 700 : 400, opacity: fs === i ? 1 : 0.5 }}>A</button>
            ))}
          </div>
          {showSubTitle && setSubTitleOrder && (
            <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
              <span className="text-[10px] font-body" style={{ ...brand, opacity: 0.7 }}>{isAr ? "عناوين الفرعيّات" : "Sub-class titles"}</span>
              <button type="button" onClick={() => setSubTitleOrder("ar_en")} className="font-body text-xs hover:opacity-70" style={pill(subTitleOrder === "ar_en")}>AR EN</button>
              <button type="button" onClick={() => setSubTitleOrder("en_ar")} className="font-body text-xs hover:opacity-70" style={pill(subTitleOrder === "en_ar")}>EN AR</button>
              <button type="button" onClick={() => setSubTitleOrder("lang")} className="font-body text-xs hover:opacity-70" style={pill(subTitleOrder === "lang")}>{isAr ? "حسب اللغة" : "By Language"}</button>
            </div>
          )}
          {showSort && (
            <div className="flex items-center gap-3 flex-wrap" dir="ltr">
              <span className="text-[10px] font-body" style={{ ...brand, opacity: 0.7 }}>{isAr ? "الفرز" : "Sort"}</span>
              <button type="button" onClick={() => setSortMode("alpha_asc")} aria-label="A-Z" className="hover:opacity-70" style={{ color: "var(--brand)", opacity: sortMode === "alpha_asc" ? 1 : 0.45 }}><AArrowUp className="w-4 h-4" /></button>
              <button type="button" onClick={() => setSortMode("alpha_desc")} aria-label="Z-A" className="hover:opacity-70" style={{ color: "var(--brand)", opacity: sortMode === "alpha_desc" ? 1 : 0.45 }}><AArrowDown className="w-4 h-4" /></button>
              <button type="button" onClick={() => setSortMode("newest")} className="font-body text-xs hover:opacity-70" style={pill(sortMode === "newest")}>{isAr ? "الأحدث" : "Newest"}</button>
              <button type="button" onClick={() => setSortMode("oldest")} className="font-body text-xs hover:opacity-70" style={pill(sortMode === "oldest")}>{isAr ? "الأقدم" : "Oldest"}</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

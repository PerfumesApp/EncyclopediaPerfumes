import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

/**
 * Pagination — مبدّل صفحات أدنوي موحّد لكل التطبيق.
 * أسهم للخارج بلا إطار/خلفية، اتجاه موحّد في اللغتين (dir=ltr)،
 * المدى فقط (مثل 51-100) بـ9px — بلا رقم صفحة وبلا إجمالي.
 *
 * Props: page (1-based) — pageCount — onChange(newPage) — totalItems — pageSize
 */
export default function Pagination({ page, pageCount, onChange, totalItems = 0, pageSize = 50 }) {
  const { isAr } = useLang();
  if (pageCount <= 1) return null;

  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, totalItems || page * pageSize);
  const go = (p) => onChange(Math.min(Math.max(1, p), pageCount));

  return (
    <div className="flex items-center justify-center gap-5 py-3" dir="ltr">
      <button
        type="button"
        onClick={() => go(page - 1)}
        disabled={page <= 1}
        className="text-muted-foreground disabled:opacity-25 p-2 -m-1"
        aria-label={isAr ? "السابق" : "Previous"}
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      <span className="text-[9px] text-muted-foreground font-body tabular-nums">{from}-{to}</span>

      <button
        type="button"
        onClick={() => go(page + 1)}
        disabled={page >= pageCount}
        className="text-muted-foreground disabled:opacity-25 p-2 -m-1"
        aria-label={isAr ? "التالي" : "Next"}
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}

import { ArrowLeft, ArrowRight } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

/**
 * BackIcon — سهم رجوع/صعود يحترم *موضع* الزرّ لا اللغة:
 * زرّ الرجوع يقع دائماً في بداية الصفّ (inline-start)، فبصرياً هو يسار في LTR
 * و يمين في RTL. لذا نعرض ArrowLeft في LTR و ArrowRight في RTL — فيشير السهم
 * دائماً نحو جهة «الرجوع» الصحيحة بأيّ لغة. يمرّر كلّ الخصائص (className/size/style)
 * للأيقونة المختارة، فيحلّ محلّ <ArrowLeft .../> مباشرةً بلا تغيير في الاستدعاء.
 */
export default function BackIcon(props) {
  const { isAr } = useLang();
  const Icon = isAr ? ArrowRight : ArrowLeft;
  return <Icon {...props} />;
}

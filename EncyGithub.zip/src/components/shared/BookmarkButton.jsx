import { Notebook } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { useBookmarks } from "@/hooks/useBookmarks";

/**
 * BookmarkButton — a single frameless notebook icon for detail-page headers.
 *
 * Visual states (per user):
 *   - Not saved : blue icon, transparent (blends with the page)
 *   - Saved     : green icon, transparent
 *
 * No border or background — just the icon, thin stroke, so it sits naturally
 * in the page. Used across brand / perfume / perfumer / note / blog detail
 * pages so the markup stays identical everywhere.
 */
export default function BookmarkButton({ descriptor, size = 32 }) {
  const { isAr } = useLang();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  if (!descriptor?.item_id) return null;
  const marked = isBookmarked(descriptor.item_type, descriptor.item_id);

  return (
    <button
      type="button"
      onClick={() => toggleBookmark(descriptor)}
      title={marked ? (isAr ? "في المفكرة" : "In notebook") : (isAr ? "أضف للمفكرة" : "Add to notebook")}
      aria-label={marked ? "In notebook" : "Add to notebook"}
      className="flex items-center justify-center bg-transparent transition-opacity hover:opacity-70 flex-shrink-0"
      style={{
        width: size,
        height: size,
      }}
    >
      <Notebook
        className="w-4 h-4"
        strokeWidth={1.25}
        style={{ color: marked ? "#B76E79" : "var(--brand)" }}
      />
    </button>
  );
}

import { useReadingPrefs, FONT_MIN, FONT_MAX } from "@/lib/useReadingPrefs";

/**
 * ReadingLangToggle — مبدّل لغة عرض المعجم والقصص: العربية / English / Ar&En.
 * من اليمين لليسار، بكلتا اللغتين. يكتب التفضيل العامّ (يُزامَن في كلّ مكان).
 * accent: "amber" للقصص، "emerald" للمصطلحات.
 */
export function ReadingLangToggle({ accent = "amber", className = "", compact = false }) {
  const { lang, setLang } = useReadingPrefs();
  const on = accent === "emerald"
    ? "text-emerald-700 dark:text-emerald-400 font-bold"
    : "text-amber-700 dark:text-amber-400 font-bold";
  const off = accent === "emerald"
    ? "text-muted-foreground hover:text-emerald-700 dark:hover:text-emerald-400"
    : "text-muted-foreground hover:text-amber-700 dark:hover:text-amber-400";
  const btn = (active) => `px-2 py-0.5 text-xs transition-colors bg-transparent ${active ? on : off}`;
  return (
    <div dir="rtl" className={`flex items-center justify-end gap-1 flex-wrap ${className}`}>
      <button type="button" onClick={() => setLang("ar")} className={btn(lang === "ar")} style={compact ? undefined : { fontFamily: "'Amiri', serif" }}>{compact ? "AR" : "العربية"}</button>
      <button type="button" onClick={() => setLang("en")} className={btn(lang === "en")}>{compact ? "EN" : "English"}</button>
      <button type="button" onClick={() => setLang("both")} className={btn(lang === "both")}>AR EN</button>
      <button type="button" onClick={() => setLang("extra")} className={btn(lang === "extra")} style={compact ? undefined : { fontFamily: "'Amiri', serif" }}>{compact ? "AR Extra" : "عربي إضافي"}</button>
      <button type="button" onClick={() => setLang("ar-extra")} className={btn(lang === "ar-extra")}>AR AR</button>
      <button type="button" onClick={() => setLang("ar-extra-en")} className={btn(lang === "ar-extra-en")}>AR AR EN</button>
    </div>
  );
}

/**
 * FontSizeControl — اختيار حجم خطّ القراءة عبر خمسة أحرف A من الأكبر إلى الأصغر
 * (بلا + و -، بلا نسبة). يكتب fontScale العامّ (٠٫٨–١٫٨). محايد للّغة.
 */
export function FontSizeControl({ accent = "amber", className = "" }) {
  const { fontScale, setFontScale } = useReadingPrefs();
  const color = accent === "emerald" ? "#047857" : "#a16207";
  const STEP = (FONT_MAX - FONT_MIN) / 4;
  // من الأكبر إلى الأصغر
  const levels = [4, 3, 2, 1, 0].map((i) => Math.round((FONT_MIN + i * STEP) * 100) / 100);
  const sizes = [23, 19.5, 16, 13, 10.5];
  const activeIdx = levels.reduce(
    (best, v, i) => (Math.abs(v - fontScale) < Math.abs(levels[best] - fontScale) ? i : best),
    0
  );
  return (
    <div className={`flex items-baseline justify-center gap-3 ${className}`}>
      {levels.map((v, i) => {
        const active = i === activeIdx;
        return (
          <button
            key={i}
            type="button"
            onClick={() => setFontScale(v)}
            aria-label={`${Math.round(v * 100)}%`}
            className={`bg-transparent leading-none font-heading transition-colors ${active ? "font-bold" : "text-muted-foreground hover:text-foreground"}`}
            style={{ fontSize: `${sizes[i]}px`, color: active ? color : undefined }}
          >
            A
          </button>
        );
      })}
    </div>
  );
}

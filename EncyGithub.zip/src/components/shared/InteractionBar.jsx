import { useState } from "react";
import {
  Heart, ThumbsUp, ThumbsDown, MessageCircle, Notebook,
  Pencil, Trash2, Eraser,
} from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { useBookmarks } from "@/hooks/useBookmarks";
import PinButton from "@/components/shared/PinButton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

/**
 * InteractionBar — one calm, uncluttered row of actions used across the app:
 *
 *   ♥ Favourite   👍 Like   👎 Dislike   😱 Whoa   💬 Thought   🔖 Bookmark   ✎ Edit   🗑 Delete
 *
 * Design goals (per user):
 *   - Everything on a SINGLE line, icon-only, low visual noise
 *   - The "Whoa" / WTF reaction uses the 😱 emoji in the shared button box (shown when showWtf is set)
 *   - Edit & Delete ask for confirmation
 *   - Quiet, integrated look — no loud colors until a button is active
 *
 * It is presentational + bookmark-aware. Reactions/thought/edit/delete are
 * delegated to the parent via callbacks, so each page keeps its own data
 * mutations and nothing about the existing system changes.
 *
 * Props:
 *   reaction        : "favorite" | "like" | "dislike" | "none"
 *   hasThought      : bool
 *   onReact(kind)   : toggle a reaction
 *   onThought()     : open the thought editor
 *   bookmark        : { item_type, item_id, title_en, title_ar, subtitle, path }
 *   onEdit()        : optional — opens parent's edit UI
 *   onDelete()      : optional — performs delete/hide
 *   isUser          : bool — affects delete vs hide wording
 *   showReactions   : default true
 */
export default function InteractionBar({
  reaction = "none",
  hasThought = false,
  onReact,
  onThought,
  bookmark,
  onEdit,
  onDelete,
  isUser = false,
  showReactions = true,
  showWtf = false,
  pin = null,
  center = false,
  readStatus = "none",
  onReadStatus,
  showReadStatus = false,
  showCastaway = false,
  accentColor = null,
  readStatusAsText = false,
  readKind = "read",
}) {
  const { isAr } = useLang();
  const _rk = readKind === "watch"
    ? { to: isAr ? "سأشاهده" : "To Watch", done: isAr ? "شاهدته" : "Watched" }
    : { to: isAr ? "سأقرأه" : "To Read", done: isAr ? "قرأته" : "Read" };
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const [confirmDel, setConfirmDel] = useState(false);
  const [busy, setBusy] = useState(false);

  const marked = bookmark ? isBookmarked(bookmark.item_type, bookmark.item_id) : false;

  const handleDelete = async () => {
    setBusy(true);
    try {
      await onDelete?.();
      setConfirmDel(false);
    } finally {
      setBusy(false);
    }
  };

  const Btn = ({ active, activeClass, title, onClick, children }) => {
    // التفاعلات (تمرّر activeClass) لها سلوك اللون الموحّد: الافتراضي = لون المستخدم
    // var(--brand)، و عند الضغط (نشط) = روز جولد #B76E79 — إلا إن مُرّر accentColor
    // صراحةً (مثل لون المستخدم النشط في الموسوعة) فيُحترم للحالة النشطة. أزرار
    // التعديل/الحذف (بلا activeClass) تبقى صامتة كما هي.
    const isReaction = activeClass !== undefined;
    const color = active ? (accentColor || "#B76E79") : (isReaction ? "var(--brand)" : undefined);
    return (
      <button
        type="button"
        onClick={onClick}
        title={title}
        aria-label={title}
        style={color ? { color } : undefined}
        className={`flex items-center justify-center w-8 h-8 rounded-none transition-colors ${
          active
            ? ""
            : (isReaction ? "hover:opacity-70" : "text-muted-foreground/70 hover:text-foreground hover:bg-secondary/60")
        }`}
      >
        {children}
      </button>
    );
  };

  return (
    <>
      <div className={`flex items-center gap-1 flex-wrap pt-1 ${center ? "justify-center" : ""}`}>
        {showReactions && (
          <>
            <Btn
              active={reaction === "favorite"}
              activeClass="text-rose-500 bg-rose-50 dark:bg-rose-950/30"
              title={isAr ? "مفضّل" : "Favourite"}
              onClick={() => onReact?.("favorite")}
            >
              <Heart className={`w-4 h-4 ${reaction === "favorite" ? "fill-current" : ""}`} />
            </Btn>
            <Btn
              active={reaction === "like"}
              activeClass="text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30"
              title={isAr ? "إعجاب" : "Like"}
              onClick={() => onReact?.("like")}
            >
              <ThumbsUp className="w-4 h-4" />
            </Btn>
            <Btn
              active={reaction === "dislike"}
              activeClass="text-slate-500 bg-slate-100 dark:bg-slate-800/40"
              title={isAr ? "عدم إعجاب" : "Dislike"}
              onClick={() => onReact?.("dislike")}
            >
              <ThumbsDown className="w-4 h-4" />
            </Btn>
            {showWtf && (
              <Btn
                active={reaction === "wtf"}
                activeClass="bg-violet-50 dark:bg-violet-950/30"
                title="WTF"
                onClick={() => onReact?.("wtf")}
              >
                <span className={`text-base leading-none ${reaction === "wtf" ? "opacity-100" : "opacity-70"}`}>😱</span>
              </Btn>
            )}
            {showCastaway && (
              <Btn
                active={reaction === "castaway"}
                activeClass="text-amber-600 bg-amber-50 dark:bg-amber-950/30"
                title={isAr ? "إبعاد" : "Cast away"}
                onClick={() => onReact?.("castaway")}
              >
                <Eraser className="w-4 h-4" />
              </Btn>
            )}
            {showReadStatus && !readStatusAsText && (
              <>
                <Btn active={readStatus === "to_read"} activeClass="text-amber-600 bg-amber-50 dark:bg-amber-950/30" title={_rk.to} onClick={() => onReadStatus?.("to_read")}>📖</Btn>
                <Btn active={readStatus === "done"} activeClass="text-teal-600 bg-teal-50 dark:bg-teal-950/30" title={_rk.done} onClick={() => onReadStatus?.("done")}>✓</Btn>
              </>
            )}
            <Btn
              active={hasThought}
              activeClass="text-blue-600 bg-blue-50 dark:bg-blue-950/30"
              title={hasThought ? (isAr ? "فكرتي" : "Thought") : (isAr ? "أضف فكرة" : "Add thought")}
              onClick={() => onThought?.()}
            >
              <MessageCircle className="w-4 h-4" />
            </Btn>
          </>
        )}

        {bookmark && (
          <button
            type="button"
            onClick={() => toggleBookmark(bookmark)}
            title={marked ? (isAr ? "في المفكرة" : "In notebook") : (isAr ? "أضف للمفكرة" : "Add to notebook")}
            aria-label={marked ? "In notebook" : "Add to notebook"}
            className="flex items-center justify-center w-8 h-8 bg-transparent transition-opacity hover:opacity-70"
          >
            <Notebook className="w-4 h-4" strokeWidth={1.25} style={{ color: marked ? "#B76E79" : "var(--brand)" }} />
          </button>
        )}

        {/* تثبيت — نفس نسق و لون تثبيت العطر (PinButton المشترك) */}
        {pin && pin.id && (
          <PinButton kind={pin.kind} id={pin.id} size={32} />
        )}

        {/* subtle divider before destructive/edit actions */}
        {(onEdit || onDelete) && <span className="w-px h-4 bg-border/60 mx-0.5" />}

        {onEdit && (
          <Btn
            title={isAr ? "تعديل" : "Edit"}
            onClick={() => onEdit()}
          >
            <Pencil className="w-3.5 h-3.5" />
          </Btn>
        )}
        {onDelete && (
          <Btn
            title={isUser ? (isAr ? "حذف" : "Delete") : (isAr ? "إخفاء" : "Hide")}
            onClick={() => setConfirmDel(true)}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Btn>
        )}

        {showReadStatus && readStatusAsText && (
          <div className="flex items-center gap-5 w-full pt-1">
            <button type="button" onClick={() => onReadStatus?.("to_read")}
              className="font-body text-sm transition-opacity hover:opacity-70"
              style={readStatus === "to_read" ? { color: accentColor || "var(--brand)", fontWeight: 700 } : { color: "var(--muted-foreground, #6b7280)", opacity: 0.7 }}>
              {_rk.to}
            </button>
            <button type="button" onClick={() => onReadStatus?.("done")}
              className="font-body text-sm transition-opacity hover:opacity-70"
              style={readStatus === "done" ? { color: accentColor || "var(--brand)", fontWeight: 700 } : { color: "var(--muted-foreground, #6b7280)", opacity: 0.7 }}>
              {_rk.done}
            </button>
          </div>
        )}

      </div>

      {/* Confirmation for edit is unnecessary (non-destructive); only delete/hide confirms */}
      <Dialog open={confirmDel} onOpenChange={setConfirmDel}>
        <DialogContent className="max-w-xs rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isUser
                ? isAr ? "حذف المدخل؟" : "Delete entry?"
                : isAr ? "إخفاء المدخل؟" : "Hide entry?"}
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs font-body text-muted-foreground" dir="auto">
            {isUser
              ? isAr ? "سيُحذف هذا المدخل نهائياً." : "This entry will be permanently deleted."
              : isAr ? "سيُخفى هذا المدخل من قائمتك." : "This entry will be hidden from your list."}
          </p>
          <div className="flex gap-2 pt-2">
            <Button
              variant="destructive"
              className="flex-1 h-10 rounded-none"
              onClick={handleDelete}
              disabled={busy}
            >
              {busy ? ".." : isUser ? (isAr ? "حذف" : "Delete") : (isAr ? "إخفاء" : "Hide")}
            </Button>
            <Button
              variant="outline"
              className="h-10 rounded-none"
              onClick={() => setConfirmDel(false)}
            >
              {isAr ? "إلغاء" : "Cancel"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

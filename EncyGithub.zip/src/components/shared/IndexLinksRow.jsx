import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";

// صفّ روابط موحّد بألوان مبهجة — أسفل صفحات البراند و العطر و العطور.
// شبكة عطور و ماركات · فهرس صحي · فهرس (/brandperfume-index) · ماركات (/brands).
export default function IndexLinksRow() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const link = (to, color, ar, en) => (
    <button type="button" onClick={() => navigate(to)}
      className="text-[11px] font-body font-semibold hover:opacity-70 transition-opacity" style={{ color }}>
      {isAr ? ar : en}
    </button>
  );
  return (
    <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 pt-3" dir={isAr ? "rtl" : "ltr"}>
      {link("/net", "#2563EB", "شبكة عطور و ماركات", "Perfume and Brand Net")}
      {link("/healthy-index", "#EA580C", "فهرس صحي", "Healthy Index")}
      {link("/brandperfume-index", "#9D174D", "فهرس", "Index")}
      {link("/brands", "#7C3AED", "ماركات", "Brands")}
    </div>
  );
}

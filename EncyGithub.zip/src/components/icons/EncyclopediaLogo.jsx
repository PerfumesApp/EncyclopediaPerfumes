// لوقو الموسوعة — كتاب مفتوح بصفحتين متماثلتين + سطور، يتبع لون الثيم عبر currentColor.
export default function EncyclopediaLogo({ className = "w-6 h-6" }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {/* الصفحتان */}
      <path d="M12 6.5 C10.2 5.4, 7.4 5.3, 5.7 5.8 L5.7 17.6 C7.4 17.1, 10.2 17.2, 12 18.3 Z" />
      <path d="M12 6.5 C13.8 5.4, 16.6 5.3, 18.3 5.8 L18.3 17.6 C16.6 17.1, 13.8 17.2, 12 18.3 Z" />
      <path d="M12 6.5 L12 18.3" />
      {/* سطور متماثلة */}
      <g strokeWidth="1.1" opacity="0.75">
        <path d="M7.4 8.6 L10.4 8.9" />
        <path d="M7.3 10.7 L10.4 10.9" />
        <path d="M7.4 12.8 L10 13" />
        <path d="M16.6 8.6 L13.6 8.9" />
        <path d="M16.7 10.7 L13.6 10.9" />
        <path d="M16.6 12.8 L14 13" />
      </g>
    </svg>
  );
}

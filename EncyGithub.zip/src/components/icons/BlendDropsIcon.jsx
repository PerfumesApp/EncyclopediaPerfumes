// أيقونة مزج (قطرتان متداخلتان تمتزجان) — تتبع لون البلاطة عبر currentColor.
export default function BlendDropsIcon({ className }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      {/* القطرة الخلفية */}
      <path d="M8.6 3.4c2 2.7 3.2 4.8 3.2 6.7a3.2 3.2 0 1 1-6.4 0c0-1.9 1.2-4 3.2-6.7z" fill="currentColor" fillOpacity="0.12" />
      {/* القطرة الأمامية المتداخلة */}
      <path d="M15.2 7.9c2 2.7 3.2 4.8 3.2 6.7a3.2 3.2 0 1 1-6.4 0c0-1.9 1.2-4 3.2-6.7z" fill="currentColor" fillOpacity="0.3" />
    </svg>
  );
}

// أيقونة البراند — 66 معيناً عشوائياً متناثراً (متباعدة قليلاً) بألوان الأكوردات، خلفية شفافة.
// نسخة بحجم أيقونة الشريط (24×24). تناثر ثابت عبر بذرة (mulberry32) فلا يتغيّر.

// لوحة ألوان الأكوردات (من accords_builtin) — مضمّنة هنا بعد إلغاء مكوّن المشاركة.
const ACCORD_PALETTE = [
  "#F8EA8C", "#D8E9F6", "#F1E3C5", "#BC4D10", "#8E4B13", "#E7CEEC", "#63CCE2",
  "#37A089", "#414046", "#C87D7F", "#AD8359", "#94260B", "#F0B642", "#C1C316",
  "#7C6549", "#9A3A0D", "#5D6E27", "#448A33", "#DDA356", "#CE1D33", "#603000",
  "#D2691E", "#F9FF52", "#A59281", "#7A2F14", "#503B1D", "#1B422F",
];

function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SIZE = 24;
const COUNT = 66;
const MIN_DIST = 2.25;   // تباعد خفيف بين المراكز فلا تتراصّ
const rnd = mulberry32(66);
function buildDiamonds() {
  const placed = [];
  let guard = 0;
  while (placed.length < COUNT && guard < 9000) {
    guard++;
    const x = -1 + rnd() * (SIZE + 2);
    const y = -1 + rnd() * (SIZE + 2);
    let ok = true;
    for (let j = 0; j < placed.length; j++) {
      const dx = placed[j].cx - x, dy = placed[j].cy - y;
      if (dx * dx + dy * dy < MIN_DIST * MIN_DIST) { ok = false; break; }
    }
    if (!ok) continue;
    const s = 0.8 + rnd() * 1.5;
    const rot = -18 + rnd() * 36;
    const fill = ACCORD_PALETTE[Math.floor(rnd() * ACCORD_PALETTE.length)];
    const pts = `${x.toFixed(2)},${(y - s).toFixed(2)} ${(x + s).toFixed(2)},${y.toFixed(2)} ${x.toFixed(2)},${(y + s).toFixed(2)} ${(x - s).toFixed(2)},${y.toFixed(2)}`;
    placed.push({ pts, fill, rot, cx: x, cy: y, key: placed.length });
  }
  return placed;
}
const DIAMONDS = buildDiamonds();

export default function BrandDiamondsIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true" style={{ background: "transparent", overflow: "hidden" }}>
      <defs><clipPath id="bdi"><rect x="0" y="0" width="24" height="24" /></clipPath></defs>
      <g clipPath="url(#bdi)">
        {DIAMONDS.map((d) => (
          <polygon key={d.key} points={d.pts} fill={d.fill}
            transform={`rotate(${d.rot.toFixed(0)} ${d.cx.toFixed(2)} ${d.cy.toFixed(2)})`} />
        ))}
      </g>
    </svg>
  );
}

// أيقونة متجر (واجهة محلّ بمظلّة مموّجة) — تتبع لون البلاطة عبر currentColor.
export default function StoreFrontIcon({ className }) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinecap="round"
      strokeLinejoin="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      {/* سقف المظلّة */}
      <path d="M4 9.3 5.4 5h13.2L20 9.3" />
      {/* حافة المظلّة المموّجة */}
      <path d="M4 9.3a2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0" fill="currentColor" fillOpacity="0.12" />
      {/* جسم المحلّ */}
      <path d="M5.4 11v8h13.2v-8" />
      {/* الباب */}
      <path d="M10 19v-4.6h4V19" fill="currentColor" fillOpacity="0.14" />
    </svg>
  );
}

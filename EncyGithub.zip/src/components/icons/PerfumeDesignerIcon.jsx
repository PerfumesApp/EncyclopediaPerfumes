// أيقونة «مصمّم العطور» — نفس أيقونة تبويب العطور في الواجهتين التقليدية و غير
// التقليدية (تُستعمل أيضا لرابط مصمّمي العطور بدل الفرشاة).
export default function PerfumeDesignerIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <g transform="rotate(9 21 31)">
        <path d="M11 25 H31 V33 A6 6 0 0 1 25 39 H17 A6 6 0 0 1 11 33 Z" />
        <path d="M31 27 H35 A3.3 3.3 0 0 1 35 33 H31" />
      </g>
      <path d="M13 22 C 11.5 19.5, 14.5 18, 13 15" />
      <path d="M17 22 C 18.5 19.5, 15.5 18, 17 15" />
      <path d="M21 22 C 19.5 19.5, 22.5 18, 21 15" />
      <path d="M25 22 C 26.5 19.5, 23.5 18, 25 15" />
      <path d="M29 22 C 27.5 19.5, 30.5 18, 29 15" />
    </svg>
  );
}

// AccordPaletteIcon — أيقونة «سحر و سحرة»: شبكة 90 لون أكورد حقيقي (لوحة ألوان
// العطّار، A 1.0). مربعات بزوايا حادة، موسّطة داخل viewBox مربّع فتجلس متوازنة
// في خانة الأيقونة بلا ميلان. تقبل className و size كأي أيقونة lucide.
export default function AccordPaletteIcon({ className = "", size = 24, ...props }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 113.5 113.5"
      className={className}
      preserveAspectRatio="xMidYMid meet"
      {...props}
    >
      <rect x="0.00" y="5.75" width="10" height="10" fill="#2E7D52" />
      <rect x="11.50" y="5.75" width="10" height="10" fill="#3FA7D6" />
      <rect x="23.00" y="5.75" width="10" height="10" fill="#5B3A29" />
      <rect x="34.50" y="5.75" width="10" height="10" fill="#5E6B3B" />
      <rect x="46.00" y="5.75" width="10" height="10" fill="#5E8C61" />
      <rect x="57.50" y="5.75" width="10" height="10" fill="#5FC9D6" />
      <rect x="69.00" y="5.75" width="10" height="10" fill="#6B4226" />
      <rect x="80.50" y="5.75" width="10" height="10" fill="#6D28D9" />
      <rect x="92.00" y="5.75" width="10" height="10" fill="#6E6E6E" />
      <rect x="103.50" y="5.75" width="10" height="10" fill="#6E7B3D" />
      <rect x="0.00" y="17.25" width="10" height="10" fill="#6EC1E4" />
      <rect x="11.50" y="17.25" width="10" height="10" fill="#6F4E37" />
      <rect x="23.00" y="17.25" width="10" height="10" fill="#6FAE6F" />
      <rect x="34.50" y="17.25" width="10" height="10" fill="#6FBF73" />
      <rect x="46.00" y="17.25" width="10" height="10" fill="#7A5C45" />
      <rect x="57.50" y="17.25" width="10" height="10" fill="#7A6A52" />
      <rect x="69.00" y="17.25" width="10" height="10" fill="#7FB069" />
      <rect x="80.50" y="17.25" width="10" height="10" fill="#7FC8E8" />
      <rect x="92.00" y="17.25" width="10" height="10" fill="#8A5A2B" />
      <rect x="103.50" y="17.25" width="10" height="10" fill="#8B5A2B" />
      <rect x="0.00" y="28.75" width="10" height="10" fill="#8C7B6B" />
      <rect x="11.50" y="28.75" width="10" height="10" fill="#8E8DD0" />
      <rect x="23.00" y="28.75" width="10" height="10" fill="#9AA7B0" />
      <rect x="34.50" y="28.75" width="10" height="10" fill="#9B7BBF" />
      <rect x="46.00" y="28.75" width="10" height="10" fill="#9CA3AF" />
      <rect x="57.50" y="28.75" width="10" height="10" fill="#A9743B" />
      <rect x="69.00" y="28.75" width="10" height="10" fill="#A9C7D6" />
      <rect x="80.50" y="28.75" width="10" height="10" fill="#B5532A" />
      <rect x="92.00" y="28.75" width="10" height="10" fill="#B5742E" />
      <rect x="103.50" y="28.75" width="10" height="10" fill="#B5743B" />
      <rect x="0.00" y="40.25" width="10" height="10" fill="#B79A78" />
      <rect x="11.50" y="40.25" width="10" height="10" fill="#B7AEA3" />
      <rect x="23.00" y="40.25" width="10" height="10" fill="#B7C68B" />
      <rect x="34.50" y="40.25" width="10" height="10" fill="#C0392B" />
      <rect x="46.00" y="40.25" width="10" height="10" fill="#C08A2E" />
      <rect x="57.50" y="40.25" width="10" height="10" fill="#C2A06A" />
      <rect x="69.00" y="40.25" width="10" height="10" fill="#C9C2DA" />
      <rect x="80.50" y="40.25" width="10" height="10" fill="#D7C7E0" />
      <rect x="92.00" y="40.25" width="10" height="10" fill="#D98E5A" />
      <rect x="103.50" y="40.25" width="10" height="10" fill="#D9E2E8" />
      <rect x="0.00" y="51.75" width="10" height="10" fill="#DDE3E8" />
      <rect x="11.50" y="51.75" width="10" height="10" fill="#E07B39" />
      <rect x="23.00" y="51.75" width="10" height="10" fill="#E0972A" />
      <rect x="34.50" y="51.75" width="10" height="10" fill="#E0A92E" />
      <rect x="46.00" y="51.75" width="10" height="10" fill="#E14B4B" />
      <rect x="57.50" y="51.75" width="10" height="10" fill="#E36A91" />
      <rect x="69.00" y="51.75" width="10" height="10" fill="#E6CBA8" />
      <rect x="80.50" y="51.75" width="10" height="10" fill="#E6D9B2" />
      <rect x="92.00" y="51.75" width="10" height="10" fill="#E8D9C5" />
      <rect x="103.50" y="51.75" width="10" height="10" fill="#E9D8A6" />
      <rect x="0.00" y="63.25" width="10" height="10" fill="#EAD9B8" />
      <rect x="11.50" y="63.25" width="10" height="10" fill="#EE9CB6" />
      <rect x="23.00" y="63.25" width="10" height="10" fill="#EFC94C" />
      <rect x="34.50" y="63.25" width="10" height="10" fill="#EFE6D0" />
      <rect x="46.00" y="63.25" width="10" height="10" fill="#F0A6C2" />
      <rect x="57.50" y="63.25" width="10" height="10" fill="#F0D9C0" />
      <rect x="69.00" y="63.25" width="10" height="10" fill="#F2A33C" />
      <rect x="80.50" y="63.25" width="10" height="10" fill="#F2C12E" />
      <rect x="92.00" y="63.25" width="10" height="10" fill="#F3E2C0" />
      <rect x="103.50" y="63.25" width="10" height="10" fill="#3CA26A" />
      <rect x="0.00" y="74.75" width="10" height="10" fill="#69BADF" />
      <rect x="11.50" y="74.75" width="10" height="10" fill="#7E5039" />
      <rect x="23.00" y="74.75" width="10" height="10" fill="#7B8C4D" />
      <rect x="34.50" y="74.75" width="10" height="10" fill="#78A57B" />
      <rect x="46.00" y="74.75" width="10" height="10" fill="#88D7E0" />
      <rect x="57.50" y="74.75" width="10" height="10" fill="#915933" />
      <rect x="69.00" y="74.75" width="10" height="10" fill="#8A53E1" />
      <rect x="80.50" y="74.75" width="10" height="10" fill="#888888" />
      <rect x="92.00" y="74.75" width="10" height="10" fill="#8C9D4E" />
      <rect x="103.50" y="74.75" width="10" height="10" fill="#99D3EC" />
      <rect x="0.00" y="86.25" width="10" height="10" fill="#916648" />
      <rect x="11.50" y="86.25" width="10" height="10" fill="#90C090" />
      <rect x="23.00" y="86.25" width="10" height="10" fill="#92CF95" />
      <rect x="34.50" y="86.25" width="10" height="10" fill="#9B7557" />
      <rect x="46.00" y="86.25" width="10" height="10" fill="#988466" />
      <rect x="57.50" y="86.25" width="10" height="10" fill="#9CC28A" />
      <rect x="69.00" y="86.25" width="10" height="10" fill="#AADBF0" />
      <rect x="80.50" y="86.25" width="10" height="10" fill="#B17337" />
      <rect x="92.00" y="86.25" width="10" height="10" fill="#B27337" />
      <rect x="103.50" y="86.25" width="10" height="10" fill="#A39587" />
      <rect x="0.00" y="97.75" width="10" height="10" fill="#B2B1DF" />
      <rect x="11.50" y="97.75" width="10" height="10" fill="#B7C0C6" />
      <rect x="23.00" y="97.75" width="10" height="10" fill="#B59DD0" />
      <rect x="34.50" y="97.75" width="10" height="10" fill="#B8BDC6" />
      <rect x="46.00" y="97.75" width="10" height="10" fill="#C38E54" />
      <rect x="57.50" y="97.75" width="10" height="10" fill="#CCDDE6" />
      <rect x="69.00" y="97.75" width="10" height="10" fill="#D36B3F" />
      <rect x="80.50" y="97.75" width="10" height="10" fill="#D08E46" />
      <rect x="92.00" y="97.75" width="10" height="10" fill="#C98E5A" />
      <rect x="103.50" y="97.75" width="10" height="10" fill="#C9B399" />
    </svg>
  );
}

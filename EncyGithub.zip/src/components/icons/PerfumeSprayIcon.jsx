// أيقونة عطر مرسومة برشّات ملوّنة وخلفية شفافة — لأزرار تصدير بطاقة العطر والبراند.
export default function PerfumeSprayIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle cx="16.6" cy="6" r="1.2" fill="#E0729B" />
      <circle cx="19.5" cy="3.9" r="1" fill="#8A63D2" />
      <circle cx="20.7" cy="7.1" r="0.85" fill="#28B7A6" />
      <circle cx="18.1" cy="8.7" r="0.7" fill="var(--brand)" />
      <circle cx="22" cy="5.1" r="0.6" fill="#E0729B" />
      <rect x="8.3" y="3.5" width="3.7" height="2.3" rx="0.6" fill="#9A7B1F" />
      <rect x="9.8" y="5.6" width="3.1" height="3.4" fill="var(--brand)" />
      <rect x="6.7" y="8.6" width="9.4" height="11.4" rx="2.2" fill="var(--brand)" fillOpacity="0.16" stroke="var(--brand)" strokeWidth="1.4" />
      <path d="M6.7 14.4h9.4v3.4a2.2 2.2 0 0 1-2.2 2.2H8.9a2.2 2.2 0 0 1-2.2-2.2z" fill="var(--brand)" fillOpacity="0.34" />
    </svg>
  );
}

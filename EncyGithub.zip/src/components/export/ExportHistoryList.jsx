import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { exportHistory } from "@/lib/exportHistoryStore";
import { Pencil, Trash2 } from "lucide-react";

// سجلّ حفظ التصدير — يُعرَض أسفل صفحات العطر/البراند/التسويق/المقارنة.
// يتيح: الرجوع للبطاقة وتعديلها وإعادة تصديرها، أو حذفها.
const ROUTE = {
  perfume: (r) => `/export-card?id=${encodeURIComponent(r.refId)}`,
  brand: (r) => `/export-card?brand=${encodeURIComponent(r.refId)}`,
  marketing: (r) => `/marketing-card?rec=${r.id}`,
  comparison: (r) => `/compare-card?rec=${r.id}`,
};

export default function ExportHistoryList({ type, refId, title }) {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [rows, setRows] = useState([]);
  const [confirmId, setConfirmId] = useState(null);
  const [expanded, setExpanded] = useState(false);

  const load = useCallback(() => {
    exportHistory.list({ type, refId }).then(setRows).catch(() => setRows([]));
  }, [type, refId]);

  useEffect(() => {
    load();
    const h = () => load();
    window.addEventListener("exportHistoryChanged", h);
    return () => window.removeEventListener("exportHistoryChanged", h);
  }, [load]);

  const open = (r) => {
    const fn = ROUTE[r.type] || ROUTE[type];
    if (fn) navigate(fn(r));
  };
  const remove = async (id) => {
    await exportHistory.delete(id);
    setConfirmId(null);
    load();
  };

  if (!rows.length) return null;

  return (
    <div className="mt-4">
      <button type="button" onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center justify-between gap-2 mb-2 text-sm font-body font-semibold text-muted-foreground hover:opacity-70 transition-opacity">
        <span>{title || (isAr ? "سجلّ التصدير المحفوظ" : "Saved Exports")}</span>
      </button>
      {expanded && (
      <div className="space-y-1.5">
        {rows.map((r) => (
          <div key={r.id} className="flex items-center gap-2 border rounded-none px-3 py-2">
            <div className="flex-1 min-w-0">
              <div className="text-sm truncate">{r.name || (isAr ? "بطاقة" : "Card")}</div>
            </div>
            {confirmId === r.id ? (
              <div className="flex items-center gap-1.5">
                <button onClick={() => remove(r.id)} className="text-[11px] px-2 py-1 rounded-none bg-red-600 text-white">{isAr ? "حذف" : "Delete"}</button>
                <button onClick={() => setConfirmId(null)} className="text-[11px] px-2 py-1 rounded-none border text-muted-foreground">{isAr ? "إلغاء" : "Cancel"}</button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button onClick={() => open(r)} aria-label="open" title={isAr ? "فتح وتعديل وإعادة التصدير" : "Open / edit / re-export"} className="text-[#C8A02E] hover:opacity-70">
                  <Pencil className="w-4 h-4" />
                </button>
                <button onClick={() => setConfirmId(r.id)} aria-label="delete" title={isAr ? "حذف" : "Delete"} className="text-[#B76E79] hover:opacity-70">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
      )}
    </div>
  );
}

// مساعد للنداء من البطاقات بعد الحفظ بنجاح.
export async function recordExport({ type, refId = "", name = "", payload = {}, recId = null }) {
  let id = recId;
  if (recId) await exportHistory.update(recId, { type, refId, name, payload });
  else id = await exportHistory.add({ type, refId, name, payload });
  try { window.dispatchEvent(new Event("exportHistoryChanged")); } catch { /* noop */ }
  return id;
}

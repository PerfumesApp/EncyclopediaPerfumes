import { BookOpen, Film, Tv, MonitorPlay } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

// بطاقة مكتبة غنية — تقرأ entry.library (النوع، الأمزجة، هوك «لماذا»، الغلاف، السنة).
const MEDIA = {
  book:   { Icon: BookOpen,    ar: "كتاب",  en: "Book",   color: "var(--brand)" },
  film:   { Icon: Film,        ar: "فيلم",  en: "Film",   color: "#7C2D12" },
  tv:     { Icon: MonitorPlay, ar: "برنامج", en: "Show",   color: "#1E3A5F" },
  series: { Icon: Tv,          ar: "مسلسل", en: "Series", color: "#4C1D95" },
};
const MOODS = {
  cozy_night: "ليلة دافئة", good_cry: "بكاء جميل", adrenaline: "إثارة", laugh: "ضحك",
  mind_bender: "حيرة", epic: "ملحمي", wonder: "دهشة", think_deep: "تأمل",
  feel_good: "شعور طيب", dark_tense: "توتر", nostalgia: "حنين", romance: "رومانسي",
};
const MOODS_EN = {
  cozy_night: "Cozy", good_cry: "Good cry", adrenaline: "Adrenaline", laugh: "Laugh",
  mind_bender: "Mind-bender", epic: "Epic", wonder: "Wonder", think_deep: "Think",
  feel_good: "Feel-good", dark_tense: "Tense", nostalgia: "Nostalgia", romance: "Romance",
};

function dash(parts) { return parts.filter(Boolean).join(" - "); }

export default function LibraryCard({ entry, onClick, hideType = false }) {
  const { isAr } = useLang();
  const lib = entry.library || {};
  const m = MEDIA[lib.media_type] || MEDIA.book;
  const ar = entry.titles?.ar || "";
  const en = entry.titles?.en || "";
  const why = isAr ? (lib.why_ar || "") : (lib.why_en || lib.why_ar || "");
  const metaLine = dash([
    isAr ? (lib.creator_ar || lib.creator_en) : (lib.creator_en || lib.creator_ar),
    isAr ? (lib.genre_ar || "") : (lib.genre_en || ""),
    lib.year || "",
  ]);
  const moods = Array.isArray(lib.moods) ? lib.moods.slice(0, 3) : [];

  return (
    <button type="button" onClick={onClick} dir={isAr ? "rtl" : "ltr"}
      className="w-full block text-start py-1 hover:opacity-70 transition-opacity">
      {/* الغلاف أُزيل من القائمة (تشوّه بصريّ بلا أغلفة) — يبقى داخل صفحة المدخل فقط */}
      <div className="min-w-0">
        {!hideType && (
          <div className="mb-0.5">
            <span className="text-[10px] font-body font-semibold" style={{ color: m.color }}>{isAr ? m.ar : m.en}</span>
          </div>
        )}
        <p className="font-body text-sm font-semibold truncate" style={{ color: "var(--brand)" }} dir={isAr ? "rtl" : "ltr"}>{isAr ? (ar || en) : (en || ar)}</p>
        {((isAr ? en : ar)) && <p className="font-body text-[11px] text-muted-foreground truncate" dir={isAr ? "ltr" : "rtl"}>{isAr ? en : ar}</p>}
        {metaLine && <p className="font-body text-[10.5px] text-muted-foreground truncate mt-0.5">{metaLine}</p>}
        {why && <p className="font-body text-[11px] mt-1 line-clamp-2" style={{ color: "var(--brand)", opacity: 0.85 }}>{why}</p>}
        {moods.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1.5">
            {moods.map((mk) => (
              <span key={mk} className="text-[9.5px] font-body rounded-none px-1.5 py-0.5" style={{ background: "transparent", color: "var(--brand)" }}>
                {isAr ? (MOODS[mk] || mk) : (MOODS_EN[mk] || mk)}
              </span>
            ))}
          </div>
        )}
      </div>
    </button>
  );
}

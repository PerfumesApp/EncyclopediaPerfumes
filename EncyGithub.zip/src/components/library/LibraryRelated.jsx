import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import LibraryCard from "@/components/library/LibraryCard";

// «لو أعجبك هذا» — توصيات من المكتبة بحسب المخرج المشترك ثم الثيمات فالمزاج فالنوع.
function score(a, b) {
  const la = a.library || {}, lb = b.library || {};
  let s = 0;
  if (la.creator_en && lb.creator_en && la.creator_en === lb.creator_en) s += 4;
  const ta = new Set(la.themes || []), tb = lb.themes || [];
  tb.forEach((t) => { if (ta.has(t)) s += 2; });
  const ma = new Set(la.moods || []), mb = lb.moods || [];
  mb.forEach((m) => { if (ma.has(m)) s += 1; });
  if (la.media_type && la.media_type === lb.media_type) s += 0.5;
  return s;
}

export default function LibraryRelated({ entry, allEntries }) {
  const { isAr } = useLang();
  const navigate = useNavigate();

  const related = useMemo(() => {
    if (!entry?.library) return [];
    return (allEntries || [])
      .filter((e) => e.library && String(e.id) !== String(entry.id) && !e.library.user_added)
      .map((e) => ({ e, s: score(entry, e) }))
      .filter((x) => x.s > 0)
      .sort((a, b) => b.s - a.s)
      .slice(0, 4)
      .map((x) => x.e);
  }, [entry, allEntries]);

  if (related.length === 0) return null;

  return (
    <div className="mt-6 pt-4 border-t" style={{ borderColor: "#14532D22" }}>
      <h3 className="font-heading text-sm font-bold mb-2.5" style={{ color: "#14532D" }}>{isAr ? "لو أعجبك هذا" : "If you liked this"}</h3>
      <div className="space-y-2">
        {related.map((e) => (
          <LibraryCard key={e.id} entry={e} onClick={() => navigate(`/encyclopedia/view/${e.id}`)} />
        ))}
      </div>
    </div>
  );
}

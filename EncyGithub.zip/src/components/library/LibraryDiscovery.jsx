import { useLang } from "@/lib/LanguageContext";

// شريط المكتبة — الأقسام الرئيسية (أنواع) أزرار نصّية، ثم الوسوم (مزاج)، ثم مقترح/عشوائي.
// بلا إطارات ولا جداول ولا خلفيات ملوّنة — حالة مفعّلة بالخطّ/التحته فقط.
export const LIB_TYPES = [
  ["film", "فيلم", "Film"],
  ["series", "مسلسل", "Series"],
  ["tv", "برنامج", "Show"],
  ["book", "كتاب", "Book"],
];
const MOODS = [
  ["cozy_night", "ليلة دافئة", "Cozy"],
  ["good_cry", "بكاء جميل", "Good cry"],
  ["adrenaline", "إثارة", "Adrenaline"],
  ["laugh", "ضحك", "Laugh"],
  ["mind_bender", "حيرة", "Mind-bender"],
  ["epic", "ملحمي", "Epic"],
  ["wonder", "دهشة", "Wonder"],
  ["think_deep", "تأمل", "Think"],
  ["feel_good", "شعور طيب", "Feel-good"],
  ["dark_tense", "توتر", "Tense"],
  ["nostalgia", "حنين", "Nostalgia"],
  ["romance", "رومانسي", "Romance"],
];

export default function LibraryDiscovery({ activeMood, onMood, onSurprise, onTonight }) {
  const { isAr } = useLang();
  const GREEN = "#14532D";
  return (
    <div className="mt-4 pt-3" dir={isAr ? "rtl" : "ltr"} style={{ borderTop: `1px solid ${GREEN}1f` }}>
      {/* الوسوم — رقاقات مزاج نصّية (بلا خلفية ملوّنة) */}
      <div className="flex flex-wrap gap-x-3 gap-y-1 mb-2.5">
        {MOODS.map(([key, ar, en]) => {
          const on = activeMood === key;
          return (
            <button key={key} type="button" onClick={() => onMood(on ? null : key)}
              className="font-body text-[11px] transition-opacity hover:opacity-70 bg-transparent p-0"
              style={{ color: GREEN, fontWeight: on ? 700 : 400, textDecoration: on ? "underline" : "none", opacity: on ? 1 : 0.65 }}>
              {isAr ? ar : en}
            </button>
          );
        })}
      </div>
      {/* مقترح / عشوائي — نصّ */}
      <div className="flex gap-5">
        <button type="button" onClick={onTonight} className="font-body text-xs font-semibold hover:opacity-70 bg-transparent p-0" style={{ color: GREEN }}>{isAr ? "مقترح" : "Suggested"}</button>
        <button type="button" onClick={onSurprise} className="font-body text-xs font-semibold hover:opacity-70 bg-transparent p-0" style={{ color: GREEN }}>{isAr ? "عشوائي" : "Random"}</button>
      </div>
    </div>
  );
}

import { useState, useMemo, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

export default function Pagination({ items, itemsPerPage = 50, renderItem, emptyMessage = "No items found" }) {
  const { isAr } = useLang();
  const [page, setPage] = useState(1);

  const { totalPages, paginatedItems, startIdx, endIdx } = useMemo(() => {
    const totalPages = Math.ceil(items.length / itemsPerPage);
    const startIdx = (page - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const paginatedItems = items.slice(startIdx, endIdx);
    return { totalPages, paginatedItems, startIdx, endIdx };
  }, [items, page, itemsPerPage]);

  // إذا تغيّرت القائمة (بحث/فلترة) والصفحة الحالية صارت خارج النطاق، ارجع لصفحة صحيحة
  useEffect(() => {
    if (page > totalPages && totalPages > 0) {
      setPage(1);
    }
  }, [totalPages, page]);

  if (items.length === 0) {
    return <p className="text-center text-sm text-muted-foreground py-8">{emptyMessage}</p>;
  }

  return (
    <div className="space-y-3">
      {/* Items */}
      <div>{renderItem(paginatedItems)}</div>

      {/* Pagination Controls — أدنى: أسهم للخارج بلا إطار/خلفية، المدى فقط بـ9px، اتجاه موحّد */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-5 pt-2" dir="ltr">
          <button
            type="button"
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="text-muted-foreground disabled:opacity-25 p-2 -m-1"
            aria-label={isAr ? "السابق" : "Previous"}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <span className="text-[9px] text-muted-foreground font-body tabular-nums">
            {startIdx + 1}-{Math.min(endIdx, items.length)}
          </span>

          <button
            type="button"
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="text-muted-foreground disabled:opacity-25 p-2 -m-1"
            aria-label={isAr ? "التالي" : "Next"}
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
/**
 * HealthRatingSection — تخصيص المستخدم الصحي: صداع — جيوب — تحسس (كما في مؤشر العطر).
 * 
 *   - ثلاث فئات تطابق فئات العطر الثلاث (صداع، جيوب، تحسس).
 *   - الأجوبة إيموجي فقط — بلا جداول و لا صناديق و لا نصوص داخل الأزرار
 *     (النص يظهر تلميحاً صغيراً تحت الإيموجي المختار فقط).
 *   - الجيوب و التحسس بسلم رباعي: لا أعلم 😏 - لا - قليلاً - نعم.
 *   - الصداع يبقى بسلمه اللوني: ⬜ لا — 🟨 ضعيف — 🟧 متوسط — 🟥 قوي.
 * تستعمل في PerfumeDetail و BrandDetail (قسم NOSE). تنعكس على بطاقة التصدير.
 *
 * Props:
 *   activeUserData — the current user's perfume/brand data object
 *   activePerson   — "person1" | "person2"
 *   onUpdate(field, value) — callback to save field
 */
export default function HealthRatingSection({ activeUserData, activePerson, onUpdate }) {
  const HEADACHE_OPTIONS = [
    { value: "none",   emoji: "⬜", labelEn: "None",   labelAr: "لا" },
    { value: "weak",   emoji: "🟨", labelEn: "Weak",   labelAr: "ضعيف" },
    { value: "medium", emoji: "🟧", labelEn: "Medium", labelAr: "متوسط" },
    { value: "strong", emoji: "🟥", labelEn: "Strong", labelAr: "قوي" },
  ];

  // سلم رباعي موحد للجيوب و التحسس — بترتيب A: لا أعلم 😏 - لا - قليلاً - نعم
  const SINUS_OPTIONS = [
    { value: "dont_know", emoji: "😏", labelEn: "Don't know", labelAr: "لا أعلم" },
    { value: "no",        emoji: "😊", labelEn: "No",         labelAr: "لا" },
    { value: "a_little",  emoji: "😕", labelEn: "A Little",   labelAr: "قليلاً" },
    { value: "yes",       emoji: "😤", labelEn: "Yes",        labelAr: "نعم" },
  ];
  const ALLERGY_OPTIONS = [
    { value: "dont_know", emoji: "😏", labelEn: "Don't know", labelAr: "لا أعلم" },
    { value: "no",        emoji: "😊", labelEn: "No",         labelAr: "لا" },
    { value: "a_little",  emoji: "😕", labelEn: "A Little",   labelAr: "قليلاً" },
    { value: "yes",       emoji: "🤧", labelEn: "Yes",        labelAr: "نعم" },
  ];

  const ROWS = [
    { field: "headache",            labelAr: "صداع",  labelEn: "Headache", options: HEADACHE_OPTIONS },
    { field: "sinus_sensitivity",   labelAr: "جيوب",  labelEn: "Sinus",    options: SINUS_OPTIONS },
    { field: "allergy_sensitivity", labelAr: "تحسس",  labelEn: "Allergy",  options: ALLERGY_OPTIONS },
  ];

  return (
    <div className="space-y-3 border-t border-border/30 pt-4">
      {ROWS.map(({ field, labelAr, labelEn, options }) => {
        const current = activeUserData?.[field];
        return (
          <div key={field} className="flex items-center gap-3">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider w-24 flex-shrink-0">
              {labelAr} {labelEn}
            </p>
            <div className="flex items-center gap-1">
              {options.map(({ value, emoji, labelEn: oEn, labelAr: oAr }) => {
                const active = current === value;
                return (
                  <button
                    key={value}
                    type="button"
                    onClick={() => onUpdate(field, active ? null : value)}
                    title={`${oAr} ${oEn}`}
                    className={`flex flex-col items-center px-1.5 py-1 bg-transparent transition-all ${
                      active ? "opacity-100" : "opacity-45 hover:opacity-80"
                    }`}
                    style={{ border: "none" }}
                  >
                    <span className={`text-xl leading-none ${active ? "scale-110" : ""}`} style={{ transition: "transform .15s" }}>{emoji}</span>
                    <span className={`text-[8px] font-body leading-tight mt-0.5 ${active ? "text-primary font-semibold" : "text-transparent"}`}>{oAr}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

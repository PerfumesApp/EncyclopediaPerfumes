import { memo } from "react";
import { Link } from "react-router-dom";
import AccordFlaconCard from "./AccordFlaconCard";
import FlaconRating from "./FlaconRating";
import { useLang } from "@/lib/LanguageContext";

/**
 * PerfumeCard — البطاقة المعتمدة (تصميم «Dior»):
 *   - القنينة الملوّنة بالأكورد (AccordFlaconCard) هي البطاقة، بلا إطار خارجي.
 *   - يسار القنينة: تقييم المستخدم (معيّنات ذهبية عمودية) — يظهر فقط عند التقييم.
 *   - تحت القنينة: اسم العطر (يتحوّل ذهبياً عند التقييم) ثم البراند.
 *   - شرائط رفيعة قصيرة يسار النص:
 *       اسم العطر → أحمر (نوتة مقيّدة) — بنّي (العطر منقطع).
 *       البراند   → لون الجنس (ضمن مجموعة) — أحمر (البراند متوقّف عن العمل).
 *   - الأسماء الطويلة تُقصَّر بنقطتين «..».
 */
const GOLD = "var(--brand)";
const RED = "#dc2626";
const BROWN = "#8a5a2b";

// النوتات الـ17 المقيّدة (is_allowed=false) — مطابقة بحدود الكلمات لتفادي اللبس (Amber≠Ambergris).
const RESTRICTED_RE =
  /\b(?:grey ambergris|white ambergris|ambergris|benzyl benzoate|cinnamaldehyde|civet absolute|civettone|civetone|civet|coumarin|deer musk|eugenol|indian sandalwood|lilial|lyral|peru balsam|pine tar)\b/i;

function genderColor(g) {
  if (g === "Men" || g === "Male") return "#22c55e";
  if (g === "Women" || g === "Female") return "#f472b6";
  if (g === "Unisex" || g === "Unisexe") return "#fcd34d"; // للجميع — لون مميّز
  return "#9ca3af"; // غير محدد — رمادي محايد
}
// خلفية شريط الجنس: «للجميع» = ثلاثة ألوان متساوية 33/33/33 (أخضر+وردي+ذهبي) عموديًّا.
function genderBg(g) {
  if (g === "Unisex" || g === "Unisexe")
    return "linear-gradient(to bottom, #22c55e 0 33.333%, #f472b6 33.333% 66.666%, #fcd34d 66.666% 100%)";
  return genderColor(g);
}

function truncate(s, n) {
  s = String(s || "");
  return s.length > n ? s.slice(0, n).trimEnd() + ".." : s;
}

function hasRestrictedNote(p) {
  const txt = `${p.top_notes || ""} ${p.heart_notes || ""} ${p.base_notes || ""}`;
  return RESTRICTED_RE.test(txt);
}

function Strip({ color, h }) {
  return <span className="block w-[2px] rounded-none" style={{ height: h, background: color }} />;
}

function PerfumeCard({ perfume, showRating = true, ltr = false, compact = false }) {
  const { isAr } = useLang();
  // ltr=true يُجبر صفّ الاسم/البراند على اتجاه إنجليزي (الشريط يسار النص، محاذاة يسار)
  // بصرف النظر عن لغة الواجهة — يُستعمل في /explore ليطابق الإنجليزية تماماً.
  const rowDir = ltr || !isAr ? "ltr" : "rtl";
  const rating = showRating ? Number(perfume.rating) || 0 : 0;
  const rated = rating > 0;

  // اسم البطاقة بالإنجليزية دائماً؛ الاسم العربي يظهر داخل صفحة التفاصيل فقط
  const cleanLatin = (s) => /[\u0600-\u06FF]/.test(s || "") ? "" : s;
  const title = perfume.name_en || (isAr ? cleanLatin(perfume.name) : perfume.name);
  const brand = perfume.brand_name || "";

  const gcol = genderColor(perfume.gender);
  const gbar = genderBg(perfume.gender);
  const restricted = hasRestrictedNote(perfume);
  const discontinued = perfume.discontinued === true || perfume.discontinued === "true" || perfume.discontinued === 1;
  const inCollection = !!(perfume.collection && String(perfume.collection).trim());
  const brandDefunct = perfume.brand_in_business === false; // مُهيّأ؛ يظهر متى توفّرت البيانات

  const nameStrips = restricted || discontinued;
  const brandStrips = inCollection || brandDefunct;

  return (
    <Link to={`/perfume?id=${perfume.id}`} className="block group">
      {/* القنينة + التقييم العمودي يساره */}
      <div className={`relative aspect-square bg-transparent overflow-hidden flex items-center justify-center ${rated ? "pl-2.5" : ""} ${compact ? "mx-auto" : ""}`}
        style={compact ? { maxWidth: `${typeof compact === "number" ? compact : 50}%` } : undefined}>
        {rated ? (
          <div className="absolute left-0 top-[56%] -translate-y-1/2 h-[64%] w-[9%] flex items-center justify-center">
            <FlaconRating rating={rating} />
          </div>
        ) : null}
        <AccordFlaconCard perfume={perfume} className="w-full h-full" />
      </div>

      {/* اسم العطر */}
      <div className="pt-1 pb-2 px-1">
        <div className="flex items-center justify-center gap-1" dir={rowDir}>
          {nameStrips ? (
            <span className="flex items-center gap-[1.5px] shrink-0">
              {restricted ? <Strip color={RED} h={7} /> : null}
              {discontinued ? <Strip color={BROWN} h={7} /> : null}
            </span>
          ) : null}
          <h3
            className="whitespace-nowrap overflow-hidden text-[12px] leading-tight"
            style={{ fontFamily: "'Cormorant', Georgia, serif", color: rated ? GOLD : undefined, fontWeight: 500 }}
          >
            {truncate(title, 18)}
          </h3>
        </div>

        {/* البراند */}
        {brand ? (
          <div className="flex items-center justify-center gap-1 mt-[2px]" dir={rowDir}>
            {brandStrips ? (
              <span className="flex items-center gap-[1.5px] shrink-0">
                {inCollection ? <Strip color={gbar} h={5.5} /> : null}
                {brandDefunct ? <Strip color={RED} h={5.5} /> : null}
              </span>
            ) : null}
            <span className="whitespace-nowrap overflow-hidden text-[10px] text-muted-foreground">
              {truncate(brand, 20)}
            </span>
          </div>
        ) : null}
      </div>
    </Link>
  );
}

export default memo(PerfumeCard);

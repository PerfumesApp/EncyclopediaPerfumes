import { STRENGTH_SCALE, strengthInfo } from "@/lib/perfumeTypes";

// مؤشر قوّة العطر — لون هادئ يدلّ على القوّة، يتدرّج أخضر ← كهرماني ← أحمر ← بنّي غامق.
// ثلاثة أشكال: bar (يمتلئ بنسبة الدرجة)، cells (عشر خلايا)، track (مسار متدرّج بعلامة).

// شريط هادئ يمتلئ بنسبة الدرجة بلونها — للإضافة وصفحة العطر والبطاقة والتصدير.
export function StrengthBar({ strength, width = 54, height = 6, scale = 1 }) {
  const info = strengthInfo(strength);
  if (!info) return null;
  // مربّع صلب بلون الدرجة (بدل المستطيل الممتلئ)
  const sq = Math.max(height, 9) * scale;
  return (
    <span
      title={info.ar}
      style={{
        display: "inline-block",
        width: sq,
        height: sq,
        background: info.color,
        verticalAlign: "middle",
        flex: "0 0 auto",
      }}
    />
  );
}

// عشر خلايا تمتلئ حتى الدرجة بلونها — لصفحة الشرح.
export function StrengthCells({ strength, cell = 9, gap = 2, height = 14 }) {
  const info = strengthInfo(strength);
  if (!info) return null;
  return (
    <span style={{ display: "inline-flex", gap, verticalAlign: "middle" }}>
      {STRENGTH_SCALE.map((s) => (
        <span
          key={s.key}
          style={{
            width: cell,
            height,
            borderRadius: 1,
            background: s.level <= info.level ? info.color : "#ece7da",
          }}
        />
      ))}
    </span>
  );
}

// شريط مطوّل يمتلئ حتى درجة العطر بلون تلك الدرجة، و الباقي خافت
// «يقف عند اللون الذي في فئته» (لا قوس قزح كامل).
export function StrengthFill({ strength, width = 120, height = 6 }) {
  const info = strengthInfo(strength);
  if (!info) return null;
  const pct = (info.level / STRENGTH_SCALE.length) * 100; // مثال: معتدل 4/10 = 40٪
  return (
    <span
      title={info.ar}
      style={{
        display: "inline-block",
        width,
        height,
        background: "#ece7da",
        verticalAlign: "middle",
        position: "relative",
        flex: "0 0 auto",
        overflow: "hidden",
      }}
    >
      <span style={{ position: "absolute", insetInlineStart: 0, top: 0, height: "100%", width: `${pct}%`, background: info.color }} />
    </span>
  );
}

// مسار متدرّج كامل بعلامة موضع — لصفحة الشرح.
export function StrengthTrack({ strength, width = 170, height = 7 }) {
  const info = strengthInfo(strength);
  if (!info) return null;
  const colors = STRENGTH_SCALE.map((s) => s.color).join(", ");
  const pos = (info.level - 0.5) * 10; // مركز خلية الدرجة
  return (
    <span style={{ position: "relative", display: "inline-block", width, height, background: `linear-gradient(90deg, ${colors})`, verticalAlign: "middle" }}>
      <span style={{ position: "absolute", insetInlineStart: `${pos}%`, top: -3, transform: "translateX(-50%)", width: 3, height: height + 6, background: "#2C2C2A" }} />
    </span>
  );
}

export default StrengthBar;

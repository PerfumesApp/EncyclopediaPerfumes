import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { perfumeIdsByNote, splitNoteToken } from "@/lib/searchIndex";
import { Link } from "react-router-dom";

// العطور المتقاربة عبر فهرس النوتات (لا تحميل ~130 ألف عطر):
// 1) نأخذ نوتات العطر الحاليّ، 2) نجلب مرشّحين من دلاء النوتة في الفهرس
// (≤CAP لكلّ نوتة)، نرتّبهم حسب عدد النوتات المشتركة، 3) نجلب أفضلهم فقط عبر
// getMany، 4) نحسب نتيجة جاكار الدقيقة على هذه المجموعة الصغيرة. إن لم يكن الفهرس
// جاهزاً بعد لا نُحمّل شيئاً (الودجة غير جوهرية، تظهر فور جهوز الفهرس).
export default function SimilarPerfumes({ perfume, isAr }) {
  const [expanded, setExpanded] = useState(false);

  // نوتات العطر الحاليّ (رموز خام، بلا تكرار)
  // عطر المثال فريد بلا شبيه — لا نعرض له متقاربة
  const noteTokens = useMemo(() => {
    if (!perfume || perfume.source === "app_example") return [];
    const raw = [perfume.top_notes, perfume.heart_notes, perfume.base_notes]
      .filter(Boolean)
      .join(",")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    return [...new Set(raw)];
  }, [perfume]);

  const { data: similar = [] } = useQuery({
    queryKey: ["similar-perfumes", perfume?.id, noteTokens.length],
    enabled: !!perfume?.id && noteTokens.length > 0,
    staleTime: 1000 * 60 * 10,
    queryFn: async () => {
      const selfId = String(perfume.id);

      // (أ) جمع المرشّحين من دلاء النوتة في الفهرس + عدد النوتات المشتركة لكلّ مرشّح.
      const lookups = await Promise.all(
        noteTokens.map((nt) => {
          const { en, ar } = splitNoteToken(nt);
          return perfumeIdsByNote(en, ar);
        })
      );
      const shareCount = new Map(); // id → عدد النوتات المشتركة
      for (const r of lookups) {
        for (const id of r?.ids || []) {
          if (id === selfId) continue;
          shareCount.set(id, (shareCount.get(id) || 0) + 1);
        }
      }
      if (shareCount.size === 0) return [];

      // (ب) أفضل ~40 مرشّحاً حسب عدد النوتات المشتركة.
      const topIds = [...shareCount.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, 40)
        .map(([id]) => id);

      // (ج) جلب هؤلاء فقط (لا مسح كامل).
      const recs = await apphost.entities.Perfume.getMany(topIds);

      // (د) نتيجة جاكار الدقيقة على المجموعة الصغيرة، باستثناء نفس البراند.
      const currentNotes = new Set(
        noteTokens.map((n) => n.trim().toLowerCase()).filter(Boolean)
      );
      return (recs || [])
        .filter((p) => p && String(p.id) !== selfId && p.brand_name !== perfume.brand_name)
        .map((p) => {
          const otherNotes = new Set(
            [p.top_notes, p.heart_notes, p.base_notes]
              .filter(Boolean)
              .join(",")
              .split(",")
              .map((n) => n.trim().toLowerCase())
              .filter(Boolean)
          );
          const intersection = [...currentNotes].filter((n) => otherNotes.has(n));
          const score = intersection.length / Math.max(currentNotes.size, otherNotes.size || 1);
          return { perfume: p, score, matches: intersection.length };
        })
        .filter((item) => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 6);
    },
  });

  if (similar.length === 0) return null;

  const displayCount = expanded ? similar.length : 2;

  return (
    <div className="bg-transparent rounded-none space-y-2">
      <div className="mb-2">
        <h3 className="font-heading font-semibold text-sm px-1">{isAr ? "متقارب" : "Similar"}</h3>
      </div>

      <div className="space-y-2">
        {similar.slice(0, displayCount).map((item) => (
          <Link
            key={item.perfume.id}
            to={`/perfume?id=${item.perfume.id}`}
            className="flex items-center gap-3 py-2.5 group"
            style={{ borderBottom: "1px solid rgba(200,160,46,0.25)" }}
          >
            {item.perfume.image_url && (
              <div className="w-12 h-12 rounded-none overflow-hidden flex-shrink-0 proc-frame-img" style={{ background: "#fff", borderBottom: "1.5px solid var(--brand)" }}>
                <img
                  src={item.perfume.image_url}
                  alt={item.perfume.name_en}
                  className="w-full h-full object-contain"
                  loading="lazy"
                  decoding="async"
                />
              </div>
            )}

            <div className="flex-1 min-w-0">
              <button
                onClick={() => {}}
                className="text-left w-full group-hover:opacity-70 transition-opacity"
              >
                <p className="font-body text-xs text-muted-foreground uppercase tracking-widest">
                  {item.perfume.brand_name}
                </p>
                <p className="font-heading font-semibold text-sm line-clamp-1">
                  {item.perfume.name_en || item.perfume.name_ar}
                </p>
              </button>
            </div>

          </Link>
        ))}
      </div>

      {similar.length > 2 && (
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full py-2 text-xs font-body font-semibold bg-transparent transition-opacity hover:opacity-70" style={{ color: "var(--brand)" }}
        >
          {expanded ? (isAr ? "إخفاء" : "Show Less") : `${isAr ? "عرض" : "Show"} ${similar.length - 2} ${isAr ? "أخرى" : "More"}`}
        </button>
      )}
    </div>
  );
}

import { useState, useMemo } from "react";
import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { useLang } from "@/lib/LanguageContext";
import { X, Plus } from "lucide-react";

// منتقي الأكوردات المبسّط — للمستخدم العادي.
// القيمة تُخزَّن بصيغة محرّك القنينة: "id:نسبة;id:نسبة".
// الأعلى نسبةً = الأكورد المسيطر (يملأ قاع القنينة)، و البقية تتكدّس فوقه.
function parseAccords(v) {
  return String(v || "")
    .split(";")
    .map((e) => { const [id, w] = e.split(":"); return id ? { id, w: parseInt(w, 10) || 50 } : null; })
    .filter(Boolean);
}
function serialize(list) { return list.map((x) => `${x.id}:${x.w}`).join(";"); }

export default function AccordsPicker({ value, onChange }) {
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const list = useMemo(() => parseAccords(value), [value]);
  const selectedIds = useMemo(() => new Set(list.map((x) => x.id)), [list]);
  const domId = useMemo(() => (list.length ? list.slice().sort((a, b) => b.w - a.w)[0].id : null), [list]);

  const options = useMemo(() => {
    const q = search.trim().toLowerCase();
    const qar = search.trim();
    return Object.entries(ACCORDS)
      .filter(([id, a]) => !selectedIds.has(id) && (!q || (a.en || "").toLowerCase().includes(q) || (a.ar || "").includes(qar)))
      .slice(0, 24);
  }, [search, selectedIds]);

  const add = (id) => { onChange(serialize([...list, { id, w: 50 }])); setSearch(""); };
  const setW = (id, w) => onChange(serialize(list.map((x) => (x.id === id ? { ...x, w: Math.max(1, Math.min(100, w)) } : x))));
  const remove = (id) => onChange(serialize(list.filter((x) => x.id !== id)));

  return (
    <div dir={isAr ? "rtl" : "ltr"} className="space-y-3">
      <div className="flex items-baseline justify-between">
        <span className="font-body text-sm font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "الأكوردات و النسب" : "Accords & Ratios"}</span>
        <span className="font-body text-[11px] text-muted-foreground">{isAr ? "الأعلى نسبةً = المسيطر (يرسم القنينة)" : "Highest = dominant (draws bottle)"}</span>
      </div>

      {/* الأكوردات المختارة — كل سطر: لون + اسم + شريط نسبة + حذف */}
      {list.length > 0 && (
        <div className="space-y-2">
          {list.map((x) => {
            const a = ACCORDS[x.id] || { en: x.id, ar: x.id, bar: "#94a3b8" };
            const isDom = x.id === domId;
            return (
              <div key={x.id} className="flex items-center gap-2 min-w-0">
                <span style={{ width: 16, height: 16, background: a.bar, flexShrink: 0, border: "1px solid rgba(0,0,0,.12)" }} />
                <span className="font-body text-xs truncate flex-shrink-0" style={{ maxWidth: 104, color: "#3a3a37" }}>
                  {isAr ? (a.ar || a.en) : (a.en || a.ar)}
                  {isDom && <span className="text-[10px] font-semibold" style={{ color: "var(--brand)" }}> {isAr ? "مسيطر" : "dominant"}</span>}
                </span>
                <input type="range" min="1" max="100" value={x.w} onChange={(e) => setW(x.id, parseInt(e.target.value, 10))}
                  className="flex-1 min-w-0 sq-range" />
                <input type="number" min="1" max="100" value={x.w} onChange={(e) => setW(x.id, parseInt(e.target.value, 10) || 1)}
                  className="w-10 text-center font-body text-xs rounded-none border-0 bg-transparent flex-shrink-0" style={{ color: "var(--brand)" }} />
                <span className="font-body text-[11px] text-muted-foreground flex-shrink-0">%</span>
                <button type="button" onClick={() => remove(x.id)} aria-label="remove" className="hover:opacity-60 flex-shrink-0" style={{ color: "#B76E79" }}>
                  <X className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* البحث و الإضافة */}
      <input value={search} onChange={(e) => setSearch(e.target.value)}
        placeholder={isAr ? "ابحث عن أكورد لإضافته.." : "Search an accord to add.."}
        className="w-full h-10 rounded-none border-0 border-b font-body text-sm bg-transparent px-1"
        style={{ borderColor: "color-mix(in srgb, var(--brand) 30%, transparent)" }} dir={isAr ? "rtl" : "ltr"} />
      {search.trim() && (
        <div className="flex flex-wrap gap-1.5">
          {options.length === 0 ? (
            <span className="font-body text-xs text-muted-foreground py-1">{isAr ? "لا نتائج" : "No matches"}</span>
          ) : options.map(([id, a]) => (
            <button key={id} type="button" onClick={() => add(id)}
              className="inline-flex items-center gap-1.5 px-2 py-1 font-body text-xs hover:opacity-80"
              style={{ background: "color-mix(in srgb, var(--brand) 9%, transparent)", color: "#3a3a37" }}>
              <span style={{ width: 11, height: 11, background: a.bar, border: "1px solid rgba(0,0,0,.12)" }} />
              {isAr ? (a.ar || a.en) : (a.en || a.ar)}
              <Plus className="w-3 h-3" style={{ color: "var(--brand)" }} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

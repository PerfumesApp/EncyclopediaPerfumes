import { useLang } from "@/lib/LanguageContext";
import { LONGEVITY, SILLAGE, VALUE, SEASONS, TIMES, GENDER_COLORS, GENDER_LABELS } from "@/lib/crowdLabels";

// بطاقة العطر: رأي الجمهور المستورد (الثبات/الفوحان/القيمة/الجنس/الفصول/اليوم).
// تظهر فقط للعطور المطابَقة (التي تحمل perfume.cd). بلا أيقونات، بالوسط، زوايا حادة.
export default function PerfumeCardBox({ perfume }) {
  const { isAr } = useLang();
  const cd = perfume?.cd;
  if (!cd) return null;

  const rows = [];
  if (cd.lon && LONGEVITY[cd.lon]) rows.push({ ar: "ثبات", en: "Longevity", v: LONGEVITY[cd.lon] });
  if (cd.sil && SILLAGE[cd.sil]) rows.push({ ar: "فوحان", en: "Sillage", v: SILLAGE[cd.sil] });
  if (cd.val && VALUE[cd.val]) rows.push({ ar: "قيمة سعرية", en: "Value", v: VALUE[cd.val] });

  const g = Array.isArray(cd.g) && cd.g.length === 3 ? cd.g : null;
  const se = Array.isArray(cd.se) && cd.se.length === 4 ? cd.se : null;
  const td = Array.isArray(cd.td) && cd.td.length === 2 ? cd.td : null;

  if (!rows.length && !g && !se && !td) return null;

  const Bar = ({ label, val, color }) => (
    <div style={{ textAlign: "center", width: 30, flex: "0 0 auto" }}>
      <div style={{ height: 18, width: 18, margin: "0 auto", background: "#f1ede3", display: "flex", alignItems: "flex-end", overflow: "hidden", borderRadius: 0 }}>
        <span style={{ display: "block", width: "100%", height: `${Math.max(0, Math.min(100, val))}%`, background: color }} />
      </div>
      <div style={{ fontSize: 8.5, color: "#2C2C2A", marginTop: 4, textTransform: "uppercase", whiteSpace: "nowrap" }}>{label}</div>
    </div>
  );

  return (
    <div dir="rtl" className="text-center" style={{ borderRadius: 0, padding: "10px 15px" }}>

      {rows.map((r, i) => {
        const enLab = String(r.en).toUpperCase();
        const enVer = String(r.v.en).toUpperCase();
        const lab = isAr ? [r.ar, enLab] : [enLab, r.ar];
        const ver = isAr ? [r.v.ar, enVer] : [enVer, r.v.ar];
        return (
          <div key={i} style={{ padding: "2px 0", fontSize: 12, color: "#2C2C2A" }}>
            {lab[0]} <span style={{ fontSize: 10, color: "#888" }}>{lab[1]}</span>
            <span style={{ fontWeight: 700, color: r.v.color, marginRight: 6 }}>
              {ver[0]} <span style={{ fontSize: 10, fontWeight: 400 }}>{ver[1]}</span>
            </span>
          </div>
        );
      })}

      {g && (
        <>
          <div style={{ display: "flex", justifyContent: "center", margin: "11px 0 4px" }}>
            <div style={{ display: "flex", height: 9, width: "calc(60% + 2px)", overflow: "hidden" }}>
              {g.map((w, i) => <span key={i} style={{ width: `${w}%`, background: GENDER_COLORS[i] }} />)}
            </div>
          </div>
          <div style={{ display: "flex", gap: 14, justifyContent: "center", fontSize: 9.5, color: "#888", marginBottom: 11 }}>
            {GENDER_LABELS.map((gl, i) => (
              <span key={i} style={{ textTransform: "uppercase" }}><span style={{ color: GENDER_COLORS[i] }}>◆</span> {isAr ? gl.ar : gl.en}</span>
            ))}
          </div>
        </>
      )}

      {(se || td) && (
        <div style={{ borderTop: "1px solid #EADFB4", paddingTop: 11, display: "flex", flexWrap: "nowrap", alignItems: "flex-end", justifyContent: "center", gap: 8 }}>
          {se && (
            <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
              {se.map((v, i) => <Bar key={i} label={isAr ? SEASONS[i].ar : SEASONS[i].en} val={v} color={SEASONS[i].color} />)}
            </div>
          )}
          {se && td && <div style={{ width: 1, alignSelf: "stretch", background: "#EADFB4", margin: "0 2px" }} />}
          {td && (
            <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
              {td.map((v, i) => <Bar key={i} label={isAr ? TIMES[i].ar : TIMES[i].en} val={v} color={TIMES[i].color} />)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

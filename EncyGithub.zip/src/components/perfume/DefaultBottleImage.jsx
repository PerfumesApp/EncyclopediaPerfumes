import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { unknownAccord } from "@/lib/accordFallback";

/**
 * DefaultBottleImage — القنينة الافتراضية الفوتوغرافية (الغطاء المرصّع) للعطور بلا صورة.
 *
 * القواعد المعتمدة:
 *   - إن رفع المستخدم صورة عطر فلا يُستعمل هذا المكوّن إطلاقاً (يقرّره المستدعي).
 *   - بلا تعبئة أكورد إذا لم تتوفر معلومات كافية (لا أكوردات) — تُعرض القنينة فارغة.
 *   - عند وجود أكوردات: تعبئة أعلى من الربع قليلاً وأقل من نصف العلبة (~35% من جسم
 *     الزجاج)، حتى خمسة أكوردات بالمجمل، المسيطر في الأسفل بنصف ارتفاع التعبئة،
 *     والبقية (حتى أربعة) مكدّسة فوقه بأوزانها في النصف الأعلى.
 *
 * هندسة الصورة (pinkbottle_transparent.webp 480×745):
 *   - أرضية العلبة الداخلية عند 81.5% من الارتفاع، جسم الزجاج يبدأ عند ~45.5%.
 *   - جدران الزجاج الداخلية بإزاحة 8% من كل جانب.
 */
const BOTTLE_SRC = `${import.meta.env.BASE_URL || "/"}bottle/pinkbottle_transparent.webp`;
const ASPECT = 480 / 745;          // عرض/ارتفاع الصورة
const FLOOR_PCT = 18.5;            // المسافة من أسفل الصورة إلى أرضية العلبة الداخلية (%)
const BODY_PCT = 36;               // ارتفاع جسم الزجاج نسبة لارتفاع الصورة (%)
const FILL_OF_BODY = 0.35;         // فوق الربع قليلاً وأقل من النصف
const SIDE_INSET_PCT = 8;          // إزاحة الجدار الداخلي من كل جانب (%)
const MAX_ACCORDS = 5;

export function parseTopAccords(raw, max = MAX_ACCORDS) {
  const list = String(raw || "")
    .split(";")
    .map((e) => {
      const [id, w] = e.split(":");
      if (!id) return null;
      const ref = ACCORDS[id] || unknownAccord(id);
      return { id, w: parseFloat(w) || 1, color: ref.bar || "#94a3b8" };
    })
    .filter(Boolean);
  list.sort((a, b) => b.w - a.w);
  return list.slice(0, max);
}

export default function DefaultBottleImage({ perfume = {}, height = 280, style, className = "" }) {
  const accords = parseTopAccords(perfume.accords);
  const has = accords.length > 0;
  const dom = accords[0];
  const rest = accords.slice(1);
  const sumR = rest.reduce((a, x) => a + x.w, 0) || 1;

  const fillPct = BODY_PCT * FILL_OF_BODY;        // ارتفاع التعبئة الكلي (% من الصورة)
  const domPct = fillPct / 2;                     // المسيطر نصف التعبئة من الأسفل
  const restPct = fillPct - domPct;

  // الكدسة فوق المسيطر: من الأسفل للأعلى بترتيب تنازلي للوزن
  let acc = 0;
  const restBands = rest.map((a) => {
    const h = (restPct * a.w) / sumR;
    const band = { color: a.color, bottomPct: FLOOR_PCT + domPct + acc, hPct: h, key: a.id };
    acc += h;
    return band;
  });

  return (
    <div
      className={className}
      style={{ position: "relative", height, width: height * ASPECT, ...style }}
    >
      <img
        src={BOTTLE_SRC}
        alt=""
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain" }}
      />
      {has && (
        <>
          <div
            style={{
              position: "absolute",
              left: `${SIDE_INSET_PCT}%`,
              right: `${SIDE_INSET_PCT}%`,
              bottom: `${FLOOR_PCT}%`,
              height: `${domPct}%`,
              backgroundColor: dom.color,
              opacity: 0.6,
            }}
          />
          {restBands.map((b) => (
            <div
              key={b.key}
              style={{
                position: "absolute",
                left: `${SIDE_INSET_PCT}%`,
                right: `${SIDE_INSET_PCT}%`,
                bottom: `${b.bottomPct}%`,
                height: `${b.hPct}%`,
                backgroundColor: b.color,
                opacity: 0.55,
              }}
            />
          ))}
        </>
      )}
    </div>
  );
}

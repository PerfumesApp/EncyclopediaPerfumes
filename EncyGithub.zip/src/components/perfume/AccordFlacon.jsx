import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { unknownAccord } from "@/lib/accordFallback";

/**
 * AccordFlacon — قنينة العطر الافتراضية (نفس شكل PerfumePlaceholder) ملوّنة
 * حسب أكوردات العطر:
 *   - الأكورد المسيطر (الأول) يلوّن حدود القنينة + السائل.
 *   - الأكورد الثاني يلوّن الغطاء.
 *   - بلا أكوردات → قنينة رمادية محايدة.
 *
 * البيانات (`accords` = "a24:100;a34:76;..") موجودة أصلاً في سجلّ العطر المحمّل،
 * فالتلوين مجرّد تقسيم نصّ + بحث في خريطة 92 أكوردًا بالذاكرة — لا أثر على الأداء.
 */
function parseAccords(raw) {
  return String(raw || "")
    .split(";")
    .map((e) => {
      const id = e.split(":")[0];
      if (!id) return null;
      const ref = ACCORDS[id] || unknownAccord(id);
      return { id, ...ref };
    })
    .filter(Boolean);
}

// أعلى أكورد (للاسم/اللون في زاوية البطاقة)
export function dominantAccord(accords) {
  return parseAccords(accords)[0] || null;
}

export function topAccords(accords, n = 4) {
  return parseAccords(accords).slice(0, n);
}

export default function AccordFlacon({ accords, className = "", style }) {
  const list = parseAccords(accords);
  const dom = list[0];
  const sec = list[1] || list[0];
  const has = !!dom;
  const lineC = has ? dom.bar : "#94a3b8"; // حدود الجسم/الرقبة + السائل
  const capC = has ? sec.bar : "#94a3b8";  // الغطاء (الأكورد الثاني)

  return (
    <svg
      viewBox="22 57 82 82"
      width="100%"
      height="100%"
      className={className}
      style={style}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      {/* جسم أبيض */}
      <rect x="27" y="80" width="72" height="52" fill="transparent" />
      {/* السائل بلون المسيطر — زاوية سفلية حادّة */}
      <path
        d="M29 108 H97 V132 H29 Z"
        fill={lineC}
        opacity={has ? 0.78 : 0.45}
      />
      {/* الغطاء بلون الثاني */}
      <rect x="49" y="62" width="28" height="11" rx="2" fill={capC} opacity={has ? 0.65 : 0.6} />
      <rect x="53" y="73" width="20" height="7" fill={lineC} opacity="0.2" />
      {/* الحدود: الجسم/الرقبة بالمسيطر، الغطاء بالثاني */}
      <g fill="none" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round">
        <rect x="27" y="80" width="72" height="52" stroke={lineC} />
        <rect x="53" y="73" width="20" height="7" stroke={lineC} />
        <rect x="49" y="62" width="28" height="11" rx="2" stroke={capC} />
      </g>
    </svg>
  );
}

import { cn } from "@/lib/utils";

/**
 * SquareRating — تقييم بمربّعات حادّة الزوايا بلون التطبيق، دائما من أربعة.
 * يُستعمل للمحاور الفرعية (الأصالة/الاتساق/القيمة/الحرفية).
 * الممتلئ = لون التطبيق مصمت، الفارغ = إطار مجوّف. نفس API التقييم.
 */
const BRAND = "var(--brand)";

function SquareIcon({ filled, sizeClass }) {
  return (
    <svg viewBox="0 0 24 24" className={cn(sizeClass)} aria-hidden="true">
      <rect x="4" y="4" width="16" height="16" fill={filled ? BRAND : "none"} stroke={BRAND} strokeWidth={filled ? 0 : 1.5} />
    </svg>
  );
}

export default function SquareRating({ rating = 0, onChange, size = "md" }) {
  const sizeClass = size === "sm" ? "w-3 h-3" : size === "lg" ? "w-6 h-6" : "w-5 h-5";
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4].map((idx) => (
        <button
          key={idx}
          type="button"
          onClick={() => onChange?.(idx === rating ? 0 : idx)}
          className={cn("transition-all duration-150", onChange ? "cursor-pointer hover:scale-110" : "cursor-default")}
        >
          <SquareIcon filled={idx <= rating} sizeClass={sizeClass} />
        </button>
      ))}
    </div>
  );
}

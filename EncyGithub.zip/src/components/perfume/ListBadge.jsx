import { Heart, ThumbsDown, Award, ShoppingBag, Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const listConfig = {
  favorite: { icon: Heart, label: "Favorite", className: "bg-red-50 text-red-600 border-red-200" },
  dislike: { icon: ThumbsDown, label: "Dislike", className: "bg-slate-100 text-slate-500 border-slate-200" },
  recommend: { icon: Award, label: "Recommend", className: "bg-amber-50 text-amber-600 border-amber-200" },
  wishlist: { icon: ShoppingBag, label: "Wishlist", className: "bg-blue-50 text-blue-600 border-blue-200" },
  own: { icon: Package, label: "Own", className: "bg-emerald-50 text-emerald-600 border-emerald-200" },
};

export default function ListBadge({ list }) {
  if (!list || list === "none") return null;
  const config = listConfig[list];
  if (!config) return null;
  const Icon = config.icon;

  return (
    <Badge variant="outline" className={cn("text-xs font-body gap-1", config.className)}>
      <Icon className="w-3 h-3" />
      {config.label}
    </Badge>
  );
}
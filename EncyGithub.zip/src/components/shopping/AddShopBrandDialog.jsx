import { useState } from "react";
import { apphost } from "@/api/apphostClient";
import { X, Upload } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { useHistoryDismiss } from "@/lib/useHistoryDismiss";

const BRAND_TYPES = [
  { value: "shopping_store", en: "Shopping Store", ar: "متجر تسوق" },
  { value: "perfume_store", en: "Perfume Store", ar: "متجر عطور" },
  { value: "online_platform", en: "Online Platform", ar: "منصة إلكترونية" },
  { value: "brand_only", en: "Brand Only", ar: "شركة/ماركة فقط" },
  { value: "personal_store", en: "Personal Store", ar: "متجر شخصي" },
];

const PERSONS = [
  { value: "person1", en: "Profile A", ar: "ملف أ" },
  { value: "person2", en: "Profile B", ar: "ملف ب" },
  { value: "family", en: "Family", ar: "العائلة" },
  { value: "all", en: "All", ar: "الكل" },
];

export default function AddShopBrandDialog({ isAr, categories, onClose, onSaved }) {
  useHistoryDismiss(true, onClose);
  const [form, setForm] = useState({
    name: "", name_ar: "", type: "perfume_store", category_id: "", category_name_en: "", category_name_ar: "",
    logo_url: "", website: "", description: "", description_ar: "", country: "", person: "family", is_online: false, notes: "",
  });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);

  const update = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleLogo = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await apphost.integrations.Core.UploadFile({ file });
      update("logo_url", file_url);
    } catch (err) {
      console.error("logo upload failed", err);
      toast.error(isAr ? "تعذّر رفع الشعار" : "Logo upload failed");
    } finally {
      setUploading(false);
      e.target.value = ""; // يسمح بإعادة اختيار نفس الملف بعد الفشل
    }
  };

  const handleSave = async () => {
    if (saving) return; // امنع الإرسال المزدوج
    if (!form.name.trim()) { toast.error(isAr ? "الاسم مطلوب" : "Name required"); return; }
    setSaving(true);
    try {
      await apphost.entities.ShopBrand.create(form);
      toast.success(isAr ? "تمت الإضافة" : "Added!");
      onSaved(); // يُغلق النافذة (يُلغي تركيب المكوّن) عند النجاح
    } catch (err) {
      console.error("add brand failed", err);
      toast.error(isAr ? "تعذّر الحفظ، حاول مجدداً" : "Couldn't save, try again");
      setSaving(false); // أعِد تفعيل الزرّ عند الفشل فقط
    }
  };

  const setCategory = (catId) => {
    const cat = categories.find(c => String(c.id) === String(catId));
    update("category_id", catId);
    update("category_name_en", cat?.name_en || "");
    update("category_name_ar", cat?.name_ar || "");
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="bg-background w-full max-w-lg rounded-none max-h-[88vh] overflow-y-auto pb-safe" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-background flex items-center justify-between px-5 py-4 border-b border-border">
          <h2 className="font-heading text-lg font-bold">{isAr ? "إضافة متجر / شركة" : "Add Store / Brand"}</h2>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>
        <div className="p-5 space-y-4">
          {/* Logo */}
          <div className="flex justify-center">
            <label className="w-20 h-20 rounded-none bg-secondary flex items-center justify-center cursor-pointer overflow-hidden border-2 border-dashed border-border">
              {uploading ? <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                : form.logo_url ? <img src={form.logo_url} className="w-full h-full object-cover" />
                : <Upload className="w-5 h-5 text-muted-foreground" />}
              <input type="file" accept="image/*" className="hidden" onChange={handleLogo} />
            </label>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الاسم (EN)" : "Name (EN)"}</label>
              <Input value={form.name} onChange={e => update("name", e.target.value)} placeholder="e.g. Simple" className="rounded-none h-10 font-body mt-1" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">الاسم (AR)</label>
              <Input value={form.name_ar} onChange={e => update("name_ar", e.target.value)} placeholder="مثال: سمبل" className="rounded-none h-10 font-body mt-1" dir="rtl" />
            </div>
          </div>

          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "النوع" : "Type"}</label>
            <div className="flex flex-wrap gap-2 mt-1">
              {BRAND_TYPES.map(t => (
                <button key={t.value} onClick={() => update("type", t.value)}
                  className={` rounded-none text-xs font-body font-medium transition-all ${form.type === t.value ? " text-primary-foreground " : " text-foreground"}`}>
                  {isAr ? t.ar : t.en}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "القسم" : "Category"}</label>
            <Select value={form.category_id} onValueChange={setCategory}>
              <SelectTrigger className="rounded-none h-10 font-body mt-1">
                <SelectValue placeholder={isAr ? "اختر قسم" : "Select category"} />
              </SelectTrigger>
              <SelectContent>
                {categories.filter(c => !c.parent_id).map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.icon} {isAr ? c.name_ar : c.name_en}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الموقع الإلكتروني" : "Website"}</label>
            <Input value={form.website} onChange={e => update("website", e.target.value)} placeholder="https://.." className="rounded-none h-10 font-body mt-1" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الوصف (EN)" : "Description (EN)"}</label>
              <Textarea value={form.description} onChange={e => update("description", e.target.value)} className="rounded-none font-body min-h-[60px] mt-1" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">الوصف (AR)</label>
              <Textarea value={form.description_ar} onChange={e => update("description_ar", e.target.value)} className="rounded-none font-body min-h-[60px] mt-1" dir="rtl" />
            </div>
          </div>

          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "المستخدم" : "Person"}</label>
            <div className="flex flex-wrap gap-2 mt-1">
              {PERSONS.map(p => (
                <button key={p.value} onClick={() => update("person", p.value)}
                  className={`flex-1 min-w-[60px] py-1.5 rounded-none text-xs font-body border transition-all ${form.person === p.value ? "bg-primary text-primary-foreground border-primary" : "bg-secondary border-border"}`}>
                  {isAr ? p.ar : p.en}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => update("is_online", !form.is_online)}
              className={`w-10 h-5 rounded-none transition-colors relative ${form.is_online ? "bg-primary" : "bg-border"}`}>
              <div className={`absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all ${form.is_online ? "left-5" : "left-0.5"}`} />
            </button>
            <span className="text-sm font-body">{isAr ? "منصة إلكترونية / أونلاين" : "Online Platform"}</span>
          </div>

          <Button className="w-full h-11 rounded-none font-body" onClick={handleSave} disabled={saving}>
            {saving ? (isAr ? "جاري الحفظ.." : "Saving..") : (isAr ? "إضافة متجر" : "Add Store")}
          </Button>
          <div className="h-6" />
        </div>
      </div>
    </div>
  );
}
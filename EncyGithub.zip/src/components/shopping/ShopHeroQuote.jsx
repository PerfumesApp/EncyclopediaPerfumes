import { useState, useRef } from "react";
import { apphost } from "@/api/apphostClient";
import { useQueryClient } from "@tanstack/react-query";
import { RefreshCw, Image, Heart, ThumbsUp, ThumbsDown } from "lucide-react";
import { toast } from "sonner";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { DEFAULT_USER_MARK, resolveUserMark } from "@/lib/exportSettings";
import BookmarkButton from "@/components/shared/BookmarkButton";

export default function ShopHeroQuote({ quotes, isAr, viewMode, setViewMode, mark }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [editing, setEditing] = useState(false);
  const [addingNew, setAddingNew] = useState(false);
  const [editText, setEditText] = useState({ en: "", ar: "" });
  const [newText, setNewText] = useState({ en: "", ar: "" });
  const [exporting, setExporting] = useState(false);
  const [localReactions, setLocalReactions] = useState({}); // { [id]: reactions }
  const cardRef = useRef(null);
  const queryClient = useQueryClient();

  const activePerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";

  // صفّ تفاعلات ذهبيّ موحّد (نوت بوك · مفضّلة · إعجاب · عدم · ماذا) — يُحفظ في الموسوعة/الحكمة
  const reactBtnGold = (active) => `flex items-center justify-center w-8 h-8 bg-transparent transition-all ${active ? "text-[#B76E79]" : "text-[var(--brand)] hover:opacity-70"}`;
  const curReactions = (q) => (q ? (localReactions[q.id] ?? q.reactions ?? {}) : {});
  const react = (kind) => {
    if (!current) return;
    const cur = curReactions(current)[activePerson] || "none";
    const next = cur === kind ? "none" : kind;
    const reactions = { ...(curReactions(current) || {}) };
    if (next === "none") delete reactions[activePerson]; else reactions[activePerson] = next;
    setLocalReactions((m) => ({ ...m, [current.id]: reactions }));
    try {
      if (current.builtin) apphost.entities.EncEntry.update(current.id, { reactions }).then(() => queryClient.invalidateQueries({ queryKey: ["enc-fav-entries"] })).catch(() => {});
      else apphost.entities.Wisdom.update(current.id, { reactions }).catch(() => {});
    } catch { /* غير حرِج */ }
  };

  const activeQuotes = quotes.filter(q => q.is_active !== false);
  const current = activeQuotes[currentIdx % Math.max(activeQuotes.length, 1)];

  const shuffle = () => setCurrentIdx(i => (i + 1) % Math.max(activeQuotes.length, 1));

  const startEdit = () => {
    if (!current) return;
    setEditText({ en: current.text_en || "", ar: current.text_ar || "" });
    setEditing(true);
    setAddingNew(false);
  };

  const saveEdit = async () => {
    if (!current) return;
    if (current.builtin) { setEditing(false); toast.info(isAr ? "مدخل من الموسوعة — غير قابل للتعديل هنا" : "Encyclopedia entry — not editable here"); return; }
    await apphost.entities.Wisdom.update(current.id, { wisdom: editText.en, wisdom_ar: editText.ar });
    queryClient.invalidateQueries({ queryKey: ["wisdom"] });
    setEditing(false);
    toast.success(isAr ? "تم الحفظ" : "Saved");
  };

  const startAddNew = () => {
    setNewText({ en: "", ar: "" });
    setAddingNew(true);
    setEditing(false);
  };

  const saveNew = async () => {
    if (!newText.en && !newText.ar) { toast.error(isAr ? "أدخل نصاً" : "Enter text"); return; }
    await apphost.entities.Wisdom.create({ wisdom: newText.en, wisdom_ar: newText.ar, category: "shopping", is_user: true });
    queryClient.invalidateQueries({ queryKey: ["wisdom"] });
    setCurrentIdx(activeQuotes.length);
    setAddingNew(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  const handleExport = async () => {
    if (!current) return;
    setExporting(true);
    try {
      const GOLD = "#c8a24a", GOLD_DEEP = "#9c7a2e";
      let userMark = (mark && mark.trim()) ? mark.trim() : "";
      if (!userMark) { try { userMark = (await resolveUserMark()) || ""; } catch { /* ignore */ } }
      if (!userMark) userMark = DEFAULT_USER_MARK;
      // بطاقة بيضاء بلا إطارات، كتابة ذهبية، بلا فاصل في المنتصف.
      const card = document.createElement("div");
      card.style.cssText = `
        position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none;
        width:680px; max-width:680px; box-sizing:border-box;
        background:#ffffff;
        padding:44px 40px; display:flex; flex-direction:column; gap:18px;
        font-family:'Playfair Display','Amiri','Georgia',serif;
      `;

      // الإنجليزية — يسار، من اليسار لليمين
      if (current.text_en) {
        const en = document.createElement("div");
        en.textContent = current.text_en;
        en.style.cssText = `position:relative; direction:ltr; text-align:left; color:${GOLD}; font-size:30px; font-style:italic; line-height:1.4;`;
        card.appendChild(en);
      }

      // العربية — يمين، من اليمين لليسار (ذهبي مقروء على الأبيض)
      if (current.text_ar) {
        const ar = document.createElement("div");
        ar.textContent = current.text_ar;
        ar.style.cssText = `position:relative; direction:rtl; text-align:right; color:${GOLD}; font-size:26px; line-height:1.7; font-family:'Amiri','Traditional Arabic',serif;`;
        card.appendChild(ar);
      }

      // علامة المستخدم — ذهبية أنيقة (تظهر دائماً)
      {
        const markEl = document.createElement("div");
        markEl.textContent = userMark;
        markEl.style.cssText = `position:relative; color:${GOLD_DEEP}; font-size:15px; letter-spacing:3px; text-align:center; margin-top:6px; font-family:sans-serif;`;
        card.appendChild(markEl);
      }

      document.body.appendChild(card);
      // كل البطاقات 680×680 كحدّ أقصى لا يُتجاوز
      const cw = Math.min(card.scrollWidth || 680, 680);
      const ch = Math.min(card.scrollHeight || 680, 680);
      const canvas = await captureElement(card, { scale: 2, useCORS: true, backgroundColor: "#ffffff", width: cw, height: ch, windowWidth: cw, windowHeight: ch });
      document.body.removeChild(card);

      // اسم ملف مميّز: مقتطف من النص + ختم زمني
      const base = (current.text_en || current.text_ar || "wisdom")
        .replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-+|-+$/g, "").slice(0, 28) || "wisdom";
      const d = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
      await saveCanvasAsImage(canvas, `Wisdom-${base}-${stamp}.png`);

      toast(isAr ? "تم التصدير" : "Exported", { position: "bottom-right" });
    } catch (e) {
      toast.error(isAr ? "فشل التصدير" : "Export failed", { position: "bottom-right" });
    }
    setExporting(false);
  };

  const inlineForms = editing || addingNew;
  const ur = (curReactions(current)[activePerson]) || "none";

  return (
    <div className="relative overflow-hidden">
      {viewMode === "magazine" ? (
        <div className="px-5 pb-5" style={{paddingTop: "calc(env(safe-area-inset-top, 0px) + 26px)"}}>
          <div className="relative text-center space-y-2">
            <p className="text-[8px] tracking-widest text-emerald-600 dark:text-emerald-400 font-body uppercase opacity-90">
              {isAr ? "اقتباسات" : "Quotes"}
            </p>

            {editing ? (
              <div className="space-y-2">
                <input name="ShopHeroQuote-1" value={editText.en} onChange={e => setEditText(p => ({ ...p, en: e.target.value }))}
                  placeholder="حكمة بالإنجليزية... English wisdom.."
                  className="w-full bg-transparent text-foreground text-center italic text-base font-heading rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" />
                <input name="ShopHeroQuote-2" value={editText.ar} onChange={e => setEditText(p => ({ ...p, ar: e.target.value }))}
                  placeholder="الحكمة بالعربي.."
                  className="w-full bg-transparent text-foreground text-center text-sm font-body rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" dir="rtl" />
                <div className="flex gap-2 justify-center">
                  <button onClick={saveEdit} className="px-4 py-1.5 bg-[var(--brand)] text-white rounded-none text-xs font-body font-bold">
                    {isAr ? "حفظ" : "Save"}
                  </button>
                  <button onClick={() => setEditing(false)} className="px-4 py-1.5 text-muted-foreground rounded-none text-xs font-body">
                    {isAr ? "إلغاء" : "Cancel"}
                  </button>
                </div>
              </div>
            ) : addingNew ? (
              <div className="space-y-2">
                <input name="ShopHeroQuote-3" value={newText.en} onChange={e => setNewText(p => ({ ...p, en: e.target.value }))}
                  placeholder="حكمة بالإنجليزية... English wisdom.."
                  className="w-full bg-transparent text-foreground text-center italic text-base font-heading rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" />
                <input name="ShopHeroQuote-4" value={newText.ar} onChange={e => setNewText(p => ({ ...p, ar: e.target.value }))}
                  placeholder="الحكمة بالعربي.."
                  className="w-full bg-transparent text-foreground text-center text-sm font-body rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" dir="rtl" />
                <div className="flex gap-2 justify-center">
                  <button onClick={saveNew} className="px-4 py-1.5 bg-[var(--brand)] text-white rounded-none text-xs font-body font-bold">
                    {isAr ? "حفظ" : "Save"}
                  </button>
                  <button onClick={() => setAddingNew(false)} className="px-4 py-1.5 text-muted-foreground rounded-none text-xs font-body">
                    {isAr ? "إلغاء" : "Cancel"}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <h1
                  className={`leading-snug px-2 ${isAr ? "text-sm font-normal not-italic" : "text-sm font-normal not-italic"}`}
                  style={{ color: "var(--brand)", ...(isAr ? { fontFamily: "'Amiri','Traditional Arabic',serif" } : {}) }}
                  dir={isAr ? "rtl" : undefined}
                >
                  {isAr ? (current?.text_ar || current?.text_en) : (current?.text_en || "")}
                </h1>
                {!isAr && current?.text_ar && (
                  <p className="text-xs font-body" style={{ color: "rgba(200,160,46,0.7)" }} dir="rtl">{current.text_ar}</p>
                )}
                {isAr && current?.text_en && (
                  <p className="text-xs font-body" style={{ color: "rgba(200,160,46,0.7)" }}>{current.text_en}</p>
                )}
              </>
            )}

            {!inlineForms && (
              <div className="flex items-center justify-center gap-1.5 pt-1 flex-wrap">
                <button onClick={shuffle} className="p-1.5 text-[#9a7b1f]/50 hover:text-[#9a7b1f] transition-opacity" title={isAr ? "تحديث" : "Refresh"}>
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => react("favorite")} className={reactBtnGold(ur === "favorite")} title={isAr ? "مفضّل" : "Favourite"}>
                  <Heart className={`w-3.5 h-3.5 ${ur === "favorite" ? "fill-current" : ""}`} />
                </button>
                <button onClick={() => react("like")} className={reactBtnGold(ur === "like")} title={isAr ? "إعجاب" : "Like"}>
                  <ThumbsUp className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => react("dislike")} className={reactBtnGold(ur === "dislike")} title={isAr ? "عدم إعجاب" : "Dislike"}>
                  <ThumbsDown className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => react("wtf")} className={reactBtnGold(ur === "wtf")} title={isAr ? "ماذا" : "What"}>
                  <span className={`text-sm leading-none ${ur === "wtf" ? "opacity-100" : "opacity-60"}`}>😱</span>
                </button>
                <BookmarkButton size={28} descriptor={{ item_type: "marking", item_id: String(current?.id || ""), title_en: current?.text_en || "", title_ar: current?.text_ar || "", subtitle: "", path: current?.builtin ? `/encyclopedia/view/${current?.id}` : "/shopping" }} />
                <button onClick={handleExport} disabled={exporting} className="p-1.5 text-[#9a7b1f]/50 hover:text-[#9a7b1f] transition-opacity" title="Export as Image">
                  {exporting ? <div className="w-3.5 h-3.5 border border-[var(--brand)] border-t-transparent rounded-full animate-spin" /> : <Image className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="px-5 pb-4" style={{paddingTop: "calc(env(safe-area-inset-top, 0px) + 26px)"}}>
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-[8px] tracking-widest text-emerald-600 font-body uppercase opacity-70">
                {isAr ? "اقتباسات" : "Quotes"}
              </p>
              {addingNew ? (
                <div className="mt-1 space-y-1.5">
                  <input name="ShopHeroQuote-5" value={newText.en} onChange={e => setNewText(p => ({ ...p, en: e.target.value }))}
                    placeholder="حكمة بالإنجليزية... English wisdom.."
                    className="w-full border border-border rounded-none px-2 py-1 text-sm font-body outline-none bg-background" />
                  <input name="ShopHeroQuote-6" value={newText.ar} onChange={e => setNewText(p => ({ ...p, ar: e.target.value }))}
                    placeholder="الحكمة بالعربي.."
                    className="w-full border border-border rounded-none px-2 py-1 text-sm font-body outline-none bg-background" dir="rtl" />
                  <div className="flex gap-2">
                    <button onClick={saveNew} className=" text-primary-foreground rounded-none text-xs font-body font-bold">{isAr ? "حفظ" : "Save"}</button>
                    <button onClick={() => setAddingNew(false)} className=" text-foreground rounded-none text-xs font-body">{isAr ? "إلغاء" : "Cancel"}</button>
                  </div>
                </div>
              ) : (
                <h1 className="text-base font-heading font-bold mt-0.5 leading-snug">
                  {isAr ? (current?.text_ar || current?.text_en) : (current?.text_en || "")}
                </h1>
              )}
            </div>
            <div className="flex gap-1 flex-shrink-0 flex-wrap justify-end">
              <button onClick={shuffle} className="p-1.5 text-muted-foreground hover:text-foreground"><RefreshCw className="w-3.5 h-3.5" /></button>
              {!current?.builtin && <button onClick={startEdit} className="p-1.5 text-muted-foreground hover:text-foreground"><Edit3 className="w-3.5 h-3.5" /></button>}
              <button onClick={startAddNew} className="px-2 py-1 text-[10px] text-muted-foreground hover:text-foreground font-body" title={isAr ? "أضف اقتباس" : "Add Quote"}>{isAr ? "أضف" : "Add"}</button>
              <button onClick={handleExport} disabled={exporting} className="p-1.5 text-muted-foreground hover:text-foreground">
                {exporting ? <div className="w-3.5 h-3.5 border border-border border-t-foreground rounded-full animate-spin" /> : <Image className="w-3.5 h-3.5" />}
              </button>
              <button onClick={() => { setViewMode("magazine"); localStorage.setItem("shopViewMode", "magazine"); }}
                className="p-1.5 text-muted-foreground hover:text-foreground"><BookOpen className="w-3.5 h-3.5" /></button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
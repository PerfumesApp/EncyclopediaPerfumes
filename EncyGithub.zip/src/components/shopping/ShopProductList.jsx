import { useState, useMemo } from "react";
import { apphost } from "@/api/apphostClient";
import { useQueryClient } from "@tanstack/react-query";
import { Package, Diamond, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import { openExternalUrl } from "@/lib/exportHelper";

function StarDisplay({ value, size = "sm" }) {
  return (
    <div className="flex gap-0.5">
      {[1,2,3,4,5].map(n => (
        <Diamond key={n} className={cn(size === "sm" ? "w-3 h-3" : "w-4 h-4", n <= value ? "fill-[var(--brand)] text-[var(--brand)]" : "fill-none text-[var(--brand)]/30")} />
      ))}
    </div>
  );
}

export default function ShopProductList({ products, brands, search, isAr, names, currency, categories, viewMode, onRefresh }) {
  const [filter, setFilter] = useState("all");
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const mainCats = useMemo(() => categories.filter(c => !c.parent_id), [categories]);

  const filtered = useMemo(() => {
    let list = products;
    if (search) list = list.filter(p => p.name?.toLowerCase().includes(search.toLowerCase()) || p.brand_name?.toLowerCase().includes(search.toLowerCase()));
    if (filter !== "all") list = list.filter(p => p.category_id === filter || p.brand_id === filter);
    return list.sort((a, b) => new Date(b.purchase_date || b.created_date) - new Date(a.purchase_date || a.created_date));
  }, [products, search, filter]);

  const deleteProduct = async (id) => {
    if (!confirm(isAr ? "هل تريد الحذف؟" : "Delete?")) return;
    await apphost.entities.ShopProduct.delete(id);
    onRefresh();
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  if (filtered.length === 0) return (
    <div className="text-center py-16">
      <Package className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
      <p className="text-sm text-muted-foreground font-body">{isAr ? "لا يوجد منتجات" : "No products yet"}</p>
    </div>
  );

  return (
    <div className="space-y-3 pb-10">
      {/* Category filter chips */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        <button onClick={() => setFilter("all")}
          className={cn("px-3 py-1 rounded-none text-[10px] font-body font-medium whitespace-nowrap border transition-all",
            filter === "all" ? "bg-primary text-primary-foreground border-primary" : "bg-secondary border-border text-muted-foreground")}>
          {isAr ? "الكل" : "All"}
        </button>
        {mainCats.map(c => (
          <button key={c.id} onClick={() => setFilter(c.id)}
            className={cn("px-3 py-1 rounded-none text-[10px] font-body font-medium whitespace-nowrap border transition-all",
              filter === c.id ? "bg-primary text-primary-foreground border-primary" : "bg-secondary border-border text-muted-foreground")}>
            {c.icon} {isAr ? c.name_ar : c.name_en}
          </button>
        ))}
      </div>

      {filtered.map(product => (
        <div key={product.id} className="border-b border-border/40 last:border-b-0 transition-colors">
          {/* Product Card — art card design */}
          <div className="flex gap-3 p-3 cursor-pointer" onClick={() => navigate(`/shop-product?id=${product.id}`)}>
            {product.image_url ? (
              <img src={product.image_url} alt={product.name}
                className="w-20 h-20 rounded-none object-cover flex-shrink-0" />
            ) : (
              <div className="w-20 h-20 rounded-none bg-gradient-to-br from-secondary to-secondary/50 flex items-center justify-center flex-shrink-0">
                <Package className="w-8 h-8 text-muted-foreground/40" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-1">
                <div className="min-w-0">
                  <h4 className="font-body font-semibold text-sm leading-tight truncate">{isAr ? (product.name_ar || product.name) : product.name}</h4>
                  {product.brand_name && <p className="text-[10px] text-muted-foreground font-body">{product.brand_name}</p>}
                </div>
                <button onClick={() => deleteProduct(product.id)} className="p-1 text-red-400 hover:text-red-600 flex-shrink-0">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="flex flex-wrap gap-1 mt-1">
                {product.subcategory_name_en && (
                  <span className="text-[9px] rounded-none font-body text-muted-foreground">
                    {isAr ? product.subcategory_name_ar : product.subcategory_name_en}
                  </span>
                )}
                {product.recurring && (
                  <span className="text-[9px] text-blue-600 dark:text-blue-400 rounded-none font-body">
                    🔄 {isAr ? (product.recurring_frequency === "monthly" ? "شهري" : product.recurring_frequency === "weekly" ? "أسبوعي" : "سنوي") : product.recurring_frequency}
                  </span>
                )}
                <span className={cn("text-[9px] px-1.5 py-0.5 rounded-none font-body",
                  product.person === "person1" ? "bg-primary/10 text-primary" :
                  product.person === "person2" ? "bg-purple-100 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400" :
                  "bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400")}>
                  {names?.[product.person] || product.person}
                </span>
              </div>

              <div className="flex items-center justify-between mt-2">
                <p className="text-sm font-bold text-primary">{(product.cost || 0).toFixed(0)} {currency}</p>
                {product.rating > 0 && <StarDisplay value={product.rating} />}
              </div>
            </div>
          </div>

          {/* Review section if exists */}
          {(product.review || product.review_ar) && (
            <div className="px-3 pb-3 border-t border-border/30">
              <p className="text-xs text-muted-foreground font-body mt-2 italic leading-relaxed line-clamp-2">
                "{isAr ? (product.review_ar || product.review) : (product.review || product.review_ar)}"
              </p>
              {(product.quality_rating > 0 || product.value_rating > 0) && (
                <div className="flex gap-4 mt-1.5">
                  {product.quality_rating > 0 && (
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-muted-foreground font-body">{isAr ? "جودة" : "Quality"}</span>
                      <StarDisplay value={product.quality_rating} />
                    </div>
                  )}
                  {product.value_rating > 0 && (
                    <div className="flex items-center gap-1">
                      <span className="text-[9px] text-muted-foreground font-body">{isAr ? "قيمة" : "Value"}</span>
                      <StarDisplay value={product.value_rating} />
                    </div>
                  )}
                  {product.repurchase && (
                    <span className="text-[9px] text-emerald-600 font-body font-medium">✓ {isAr ? "سيشتري مجدداً" : "Would repurchase"}</span>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Receipt link */}
          {product.receipt_url && (
            <div className="px-3 pb-2">
              <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(product.receipt_url); }}className="text-[10px] text-primary font-body hover:underline">
                📄 {isAr ? "عرض الفاتورة" : "View Receipt"}
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
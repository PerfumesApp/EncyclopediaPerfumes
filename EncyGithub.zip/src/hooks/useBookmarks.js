import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";

/**
 * Unified bookmark system.
 *
 * A single `Bookmark` entity stores a reference to any item across the app:
 *   { item_type, item_id, title_en, title_ar, subtitle, path }
 *
 * `item_type` is one of: "brand" | "perfume" | "perfumer" | "quote" |
 * "note" | "blog" | "glossary" | "story". The page that owns the item passes
 * a small descriptor so the dedicated Bookmarks page can render and link back
 * to it without re-fetching every source entity.
 *
 * This hook is intentionally tiny and additive: it never touches the existing
 * reaction / thought system, so wiring it into a page can't break anything.
 */
export function useBookmarks() {
  const qc = useQueryClient();
  const { data: bookmarks = [] } = useQuery({
    queryKey: ["bookmarks"],
    queryFn: () => apphost.entities.Bookmark.list("-created_date"),
  });

  const isBookmarked = (itemType, itemId) =>
    bookmarks.some(
      (b) => b.item_type === itemType && String(b.item_id) === String(itemId)
    );

  const findBookmark = (itemType, itemId) =>
    bookmarks.find(
      (b) => b.item_type === itemType && String(b.item_id) === String(itemId)
    );

  const toggle = useMutation({
    mutationFn: async (descriptor) => {
      const existing = findBookmark(descriptor.item_type, descriptor.item_id);
      if (existing) {
        return apphost.entities.Bookmark.delete(existing.id);
      }
      return apphost.entities.Bookmark.create({
        item_type: descriptor.item_type,
        item_id: String(descriptor.item_id),
        title_en: descriptor.title_en || "",
        title_ar: descriptor.title_ar || "",
        subtitle: descriptor.subtitle || "",
        path: descriptor.path || "",
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["bookmarks"] }),
  });

  return { bookmarks, isBookmarked, findBookmark, toggleBookmark: (d) => toggle.mutate(d) };
}

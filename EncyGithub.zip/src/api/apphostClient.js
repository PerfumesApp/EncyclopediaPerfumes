/**
 * Encyclopedia — Local-First Apphost Client
 * Uses IndexedDB locally (full offline mode).
 * Original platform integration removed; data now lives entirely on-device.
 */

import { localApphost } from '@/lib/localApphost';

export const apphost = localApphost;

console.log('🌿 Encyclopedia running in OFFLINE mode (IndexedDB)');

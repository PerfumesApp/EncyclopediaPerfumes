/**
 * apply-android-icons.mjs
 * نسخ أيقونات المُطلِق المُعدّة من `android-icons/` إلى مشروع `android/` المولَّد،
 * حتى يحمل الـAPK أيقونتك أنت لا أيقونة Capacitor/Android الافتراضية.
 *
 * Copies prepared launcher icons from android-icons/ into the generated
 * android/ native project so your APK ships YOUR icon, not the default one.
 *
 * شغّليه بعد `npx cap add android` (أو `npx cap sync android`) وقبل بناء الـAPK:
 *   node scripts/apply-android-icons.mjs      (أو: npm run icons:android)
 */
import { cpSync, existsSync, rmSync, readdirSync } from 'node:fs';
import { resolve, join } from 'node:path';

const src = resolve('android-icons/app/src/main/res');
const dest = resolve('android/app/src/main/res');

if (!existsSync(src)) {
  console.error('❌ المصدر غير موجود / source missing:', src);
  process.exit(1);
}
if (!existsSync(dest)) {
  console.error('❌ مشروع android/ غير موجود. شغّلي أولاً: npx cap add android (أو npx cap sync android) ثم أعيدي.');
  console.error('   android/ project not found. Run `npx cap add android` (or `cap sync android`) first.');
  process.exit(1);
}
cpSync(src, dest, { recursive: true });

// احذف الأيقونة التكيّفيّة (Adaptive) التي تفرض الخلفية البيضاء — حتى تبقى الأيقونة شفّافة
const adaptive = join(dest, 'mipmap-anydpi-v26');
if (existsSync(adaptive)) {
  for (const f of readdirSync(adaptive)) {
    if (f.startsWith('ic_launcher')) rmSync(join(adaptive, f));
  }
  try { if (readdirSync(adaptive).length === 0) rmSync(adaptive, { recursive: true }); } catch { /* ignore */ }
}
// احذف أيّ foreground للأيقونة التكيّفيّة (بقايا) من كلّ الكثافات
for (const d of ['mdpi', 'hdpi', 'xhdpi', 'xxhdpi', 'xxxhdpi']) {
  const fg = join(dest, `mipmap-${d}`, 'ic_launcher_foreground.png');
  if (existsSync(fg)) rmSync(fg);
}

console.log('✅ أيقونة شفّافة مطبّقة + حُذفت الأيقونة التكيّفيّة (لا مربّع أبيض). أعيدي بناء الـAPK الآن.');
console.log('✅ Transparent launcher icon applied + adaptive icon removed. Rebuild the APK now.');

# شاشة البدء — لوقو شفّاف وسط الشاشة (يحلّ خطأ Duplicate resources)

الهدف: شعار شفّاف في وسط خلفية ذهبية `#C8A02E` — لا صورة مقصوصة تملأ الشاشة.

## ما تغيّر في الكود (جاهز في الحزمة)
`capacitor.config.ts` → `androidScaleType: 'FIT_CENTER'` (كان `CENTER_CROP` الذي يقصّ/يكبّر الصورة). الخلفية `backgroundColor: '#C8A02E'` كما هي.

## خطوات أندرويد ستوديو (مرّة واحدة)
خطأ «Duplicate resources» سببه وجود `splash.png` و`splash.xml` معاً باسم `splash` في `drawable/`. الحلّ:

اختر طريقة واحدة:

### الطريقة الأسهل (صورة شفّافة فقط)
1. في `android/app/src/main/res/drawable/` احذف `splash.xml`.
2. استبدل `splash.png` (في `drawable/` وكلّ مجلّدات `drawable-port-*` و`drawable-land-*`) بالملفّ المرفق `splash.png` (شعار شفّاف وسط لوحة شفّافة).
3. الخلفية الذهبية تأتي من `backgroundColor` في capacitor.config — مع `FIT_CENTER` يظهر الشعار وسط الذهبي بلا قصّ.

### الطريقة الأمتن (ذهبي من اللحظة الأولى — موصى بها)
تُظهر الذهبي + الشعار من أوّل إطار قبل تحميل الإضافة:
1. في `drawable/` احذف `splash.png` و`splash.xml` المتعارضين.
2. ضع المرفق `splash.xml` في `res/drawable/` و`splash_logo.png` في `res/drawable/`.
3. أضف في `res/values/colors.xml` السطر من `colors-snippet.xml`:
   `<color name="splash_bg">#C8A02E</color>`
4. احذف أيّ `splash.png` في مجلّدات `drawable-*` كي يبقى `splash` واحداً (الـxml).

## بعد أيّ طريقة
```
npx cap sync android
```
ثمّ Build ‹ Clean Project ‹ Rebuild. سيختفي خطأ التكرار ويظهر الشعار شفّافاً وسط الذهبي.

> الملفّات هنا مرجعيّة لمشروع أندرويد المُولَّد محلّياً (مجلّد android/ ليس ضمن مصدر الويب).
